# 风险权重校准与敏感性实验说明

## 目标

这部分用于回答“风险阈值和融合权重是不是人为拍脑袋设定”的问题。代码中将阈值和权重分开处理：

- 阈值：由参考多旋翼平台能力、气象危险等级和任务约束给出，回答“什么时候危险/不可飞”。
- 权重：通过代理标签、路径级安全指标和敏感性实验确定，回答“多种风险同时存在时谁更影响路径选择”。

## 权重搜索协议

入口：

```powershell
python run_project.py risk-search --output-dir outputs\risk-search
```

默认设置：

- 样本数：30 个 calibration cases。
- 候选数：50 组拉丁超立方候选 + 1 组基线，共 51 组。
- 数据划分：calibration/validation/test = 18/6/6，符合 6:2:2。
- 优化目标：安全优先，禁飞侵入、高风险暴露、CVaR、重规划失败的权重大于路径长度和能耗。
- 校准集保留一条窄安全走廊：`soften_weather_corridor()` 只用于风险权重校准，使不同权重候选都有可比较路径；极端阻断和动态关闭场景放在 benchmark、多时刻真实回放和重规划实验中验证。

本次全量输出：

- `outputs/risk-search/risk_weight_search_summary.json`
- `outputs/risk-search/weight_search_trials.csv`
- `outputs/risk-search/weight_search_summary.csv`
- `outputs/risk-search/best_risk_fusion_calibrated.yaml`

关键结果：

- `case_count = 30`
- `candidate_count = 51`
- `validation_success_rate = 1.0`
- `test_success_rate = 1.0`
- `validation_nofly_intrusions_mean = 0.0`
- `test_nofly_intrusions_mean = 0.0`

## 敏感性实验协议

入口：

```powershell
python run_project.py sensitivity --output-dir outputs\sensitivity
```

默认设置：

- 使用 `benchmark_suite` 的 27 组统计样本。
- 任务组成：3 类航路任务 x 3 档气象强度/动态速度 x 3 个随机种子。
- 扰动对象：风、阵风、风切变/湍流、对流、降水、能见度、不确定性、CVaR、能耗、走廊偏离、机会约束限制。
- 扰动幅度：+/-10%、+/-20%、+/-30%。
- 候选数：1 组基线 + 11 个参数 x 6 个扰动方向/幅度 = 67 组。
- 逐案记录数：67 x 27 = 1809 条。

本次全量输出：

- `outputs/sensitivity/risk_weight_sensitivity_summary.json`
- `outputs/sensitivity/risk_weight_sensitivity.csv`
- `outputs/sensitivity/risk_weight_sensitivity_table.csv`

关键结果：

- `case_count = 27`
- `candidate_count = 67`
- `within_20_percent.min_success_rate = 1.0`
- `within_20_percent.max_nofly_intrusions_mean = 0.0`
- `within_30_percent.min_success_rate = 1.0`
- `within_30_percent.max_nofly_intrusions_mean = 0.0`

## 答辩口径

风险阈值不是规划器任意学习出来的，而是来自参考多旋翼平台能力和气象危险边界；融合权重不是单次手工指定，而是在代理标签和路径级安全目标上搜索，并在独立 benchmark 任务集上做扰动敏感性验证。

可以表述为：

> 在 +/-20% 权重扰动范围内，规划成功率保持 1.0，禁飞区侵入均值保持 0，说明本文方法的安全性结论不依赖某一组特定人工权重；路径长度、能耗和 CVaR 可作为效率与保守性的可解释波动项。

关于校准集安全走廊，需要主动说明：

> 权重校准阶段为了比较不同融合参数的风险权衡能力，保留了一条窄安全走廊，避免所有候选在极端阻断样本中同时失败；这不是给最终算法“留路”，因为极端阻断、动态风险闭合和重规划能力在 benchmark 与动态重规划实验中单独验证。
