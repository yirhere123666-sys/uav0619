# 轨迹优化与 NMPC 接口说明

## 当前完成内容

本次新增了轻量版轨迹层和控制层代码，用于支撑中期检查中“全局路径规划之后如何进入轨迹优化和控制执行”的技术闭环。

新增模块：

- `uav_weather_planning/trajectory/bspline_smoother.py`
- `uav_weather_planning/trajectory/trajectory_checker.py`
- `uav_weather_planning/control/multirotor_model.py`
- `uav_weather_planning/control/nmpc_interface.py`

## B-spline 轨迹层

`BSplineSmoother` 将全局规划输出的离散 4D 路径点转换为连续轨迹采样：

- 输入：`State4D = (time, height, y, x)` 路径、`RiskField4D` 坐标定义、`FlightConstraints`
- 输出：`ContinuousTrajectory`
- 包含：`time_s`、`position_m`、`velocity_mps`、`acceleration_mps2`、`jerk_mps3`

当前实现使用 `scipy.make_interp_spline`，环境缺少 SciPy 时退回线性插值。

## 轨迹约束检查

`KinodynamicTrajectoryChecker` 用于检查连续轨迹是否满足多旋翼运动学约束：

- 最大速度
- 最大水平速度
- 最大爬升率
- 最大下降率
- 最大加速度
- 最大 jerk
- 风险场禁飞区侵入
- 安全裕度

它会输出 `TrajectoryCheckReport`，包括是否有效、违规项、指标、约束限值和连续轨迹采样到风险立方体后的状态序列。

## NMPC 设计接口

`RobustNMPCInterface` 当前不是完整非线性优化求解器，而是设计阶段接口：

- 状态变量：`x, y, z, vx, vy, vz, yaw`
- 控制变量：`ax_cmd, ay_cmd, az_cmd, yaw_rate_cmd`
- 约束：速度、垂直速度、加速度、偏航角速度、鲁棒裕度
- 目标函数项：位置跟踪、速度跟踪、控制能耗、控制变化率、天气风险暴露、终端误差
- 扰动通道：`wind_u, wind_v, wind_w, risk_uncertainty`

同时提供 `simulate_tracking()` 伪闭环仿真，用受限 PD 反馈跟踪 B-spline 轨迹，目的是验证接口链路，不宣称已完成真实鲁棒 NMPC 求解。

## 验证实验

新增实验：

```powershell
python -m uav_weather_planning.experiments.trajectory_control_smoke --output-dir outputs\trajectory_control_smoke
```

输出：

- `trajectory_control_summary.json`

最近一次验证结果：

- 全局路径规划成功
- B-spline 连续轨迹有效
- 最大速度约 `7.071 m/s`
- 最大爬升率 `0.0 m/s`
- 最大加速度 `0.0 m/s^2`
- 禁飞区采样命中数 `0`
- NMPC 占位闭环最大跟踪误差约 `4.525 m`
- NMPC 占位闭环平均跟踪误差约 `3.422 m`

## 答辩口径

建议中期表述：

> 当前已建立从 4D 动态全局路径到 B-spline 连续轨迹、轨迹运动学约束检查和 NMPC 控制接口的问题定义链路。中期重点仍是风险场建模和动态全局规划；B-spline 优化器与鲁棒 NMPC 求解器将在后续阶段继续完善。

不建议表述：

> 已完整完成 B-spline 轨迹优化和鲁棒 NMPC 闭环控制。
