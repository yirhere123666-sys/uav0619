# 中期检查答辩口径

## 已完成内容

本阶段完成 B-spline / NMPC 之前的研究闭环：

- 数据输入：ERA5 / HRRR loader、缓存接口、统一 `WeatherCube`。
- 真实回放：已接入本地 GFS NetCDF4 样例，形成 `LOCAL_GFS_REPLAY -> WeatherCube -> RiskField4D -> 动态规划 -> 指标/图表` 的离线闭环。
- 风险建模：风场、阵风、风切变/湍流、对流/雷暴、降水、低能见度/低云底、不确定性与 CVaR。
- 校准证据：基于真实 GFS 回放变量生成代理危险标签，输出各风险通道的 Brier score、MAE、ECE、可靠性分箱和校准曲线。
- 数据变量：除风、降水、能见度外，合成场和接口中还包含温度、相对湿度、气压、露点差、云液态水、上升气流等支撑变量。
- 风险场：四维多通道概率风险场 `RiskField4D`，支持查询、更新、xarray 转换和动态变化检测。
- 全局规划：时间依赖 A*，状态为 `(time, height, y, x)`。
- 航迹约束：全局层显式约束单步水平移动、爬升/下降层数、硬禁飞、安全裕度和最大转向角，并加入等待、爬升和转向惩罚。
- 动态重规划：默认展示为风险更新触发的路径前缀保留与局部修复；代码中另有 LPA* / D* Lite 同族 `g/rhs/UpdateVertex/ComputeShortestPath` 模块，可作为后续性能优化和更严格增量搜索的基础。
- 实验验证：风险通道图、4D 风险时间序列图、动态路径图、重规划过程图、算法对比图、指标表。

## 不过度声明

当前阶段不声称完成：

- B-spline / kinodynamic 轨迹优化。
- 鲁棒 NMPC 闭环控制。
- PX4 / Gazebo / AirSim 联合仿真。

这些是后续阶段内容，输入就是当前阶段输出的全局时空路径和风险场查询接口。

## 为什么路径规划是动态的

低空气象风险不是静态障碍物。风、阵风、强对流、降水和低能见度都会随时间移动、增强或减弱，因此路径状态必须包含时间维度。

本代码中全局路径节点为：

```text
s = (time, height, y, x)
```

边权在到达未来节点时查询风险：

```text
c(s_i, s_j) = distance + time + total_risk + CVaR + energy_penalty + safety_margin_penalty
```

因此同一个空间点在不同时间的通行代价不同。

## 为什么要建模多类风险

研究方案要求的风险不是单一 `travel_cost`，而是多通道风险：

- `wind_risk`：平均风、侧风、垂直风。
- `gust_risk`：短时阵风和突发斑块。
- `shear_risk` / `turbulence_risk`：垂直风切变、水平风场梯度和湍流代理。
- `convection_risk`：雷暴核心、强回波、对流外流。
- `precipitation_risk`：降水强度和强降水带。
- `visibility_risk`：雾、低能见度、低云底。
- `uncertainty` / `cvar_cost`：预测不确定性和尾部风险。
- `no_fly_mask`：强对流、极端风、极端剪切、严重低能见度等硬禁飞区域。

## 图中的红圈是什么

红色闭合线是硬禁飞边界，即 `no_fly_mask[t, z, :, :]` 在当前时间和高度层上的等值线。它不是手工画圈，也不是简单把原始气象量按阈值二值化。实现逻辑是：

- 各气象变量先通过连续归一化或 sigmoid 映射为风险概率。
- 多通道风险与预测不确定性、CVaR 尾部风险融合为 `violation_probability`。
- `violation_probability` 超过机会约束上限时，体素进入 `no_fly_mask`。
- 极端风、极端阵风、强对流、极端降水、严重低能见度等仍保留为运行安全包络，但也是先映射为超限概率后触发。

答辩时可以说：阈值不是本文风险场主体，而是风险概率映射和运行安全包络的参数；本文主体是四维概率风险场、期望风险、尾部风险和机会约束。

## 风险立方体尺寸怎么说

当前中期演示的风险立方体为：

```text
RiskField4D(time=34, height=3, y=28, x=28)
height = [0 m, 250 m, 500 m]
```

`x/y` 在合成实验中是规划网格索引。真实 ERA5/HRRR 回放中，`x/y` 应由经纬度裁剪、投影和重采样得到，因此可以替换成实际米级分辨率。

## 推荐展示顺序

1. `01_risk_channels.png`：证明几类气象风险都已独立建模。
2. `02_4d_risk_timeseries.png`：证明 4D 地图随时间变化，不是静态复制。
3. `03_dynamic_path.png`：证明路径规划使用动态风险场。
4. `04_incremental_replanning.png`：证明风险更新后会触发动态重规划，并保留已执行路径前缀后修复剩余航段。
5. `05_algorithm_comparison.png`：对比无天气、静态风险、时间依赖和增量重规划。
6. `10_dynamic_weather_channels.gif`：分别展示风场、阵风、风切变/湍流、对流雷暴、降水、低能见度六类风险的时变过程。
7. `07_dynamic_risk_field.gif`：动态展示融合风险场移动、增强和禁飞区变化。
8. `08_time_dependent_path.gif` / `09_incremental_replanning_path.gif`：动态展示路径随时间推进和更新后修复。
9. `metrics.csv`：给出路径长度、风险、CVaR、禁飞区侵入、扩展节点数和耗时。

## 真实气象闭环怎么说

当前代码已经提供本地真实天气回放入口：

```bash
python -m uav_weather_planning.experiments.historical_weather_replay
```

该入口读取 `real_weather_wind.nc`、`real_weather_rain.nc` 和 `processed_env.nc`，从 GFS 风场和反射率样例中裁剪区域、重采样为规划网格，生成统一 `WeatherCube`，再转换为四维概率风险场并运行时间依赖规划和动态重规划。

需要谨慎表述的是：当前仓库只有一个真实预报有效时刻，因此动态序列采用“真实天气快照 + 低层风平流外推”的方式构建；这已经打通真实数据闭环，但多 forecast hour 的 HRRR/GFS 历史回放仍是下一步增强。

## 风险校准怎么说

当前中期阶段没有实飞事故标签，因此代码采用“真实气象代理标签校准”的证据链：从 GFS 风场、反射率、降水、能见度、云底、湿度等变量构造独立的代理危险概率，再与模型输出的 `wind_risk`、`gust_risk`、`convection_risk`、`visibility_risk`、`violation_probability` 等通道做可靠性分箱。

可运行：

```bash
python -m uav_weather_planning.experiments.risk_calibration_evidence
```

输出包括：

- `risk_calibration_report.json`：Brier score、MAE、ECE、相关系数、分箱表。
- `risk_calibration_curves.png`：预测风险与代理危险概率的校准曲线。
- `risk_calibration_histograms.png`：风险样本分布。

答辩时可以说：这不是把阈值当结论，而是把气象变量、风险映射、代理危险标签、校准误差和可视化曲线串成证据链。后续若获得实飞事件、历史告警标签或集合预报误差，可替换代理标签继续校准。
