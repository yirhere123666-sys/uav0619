# 中期检查版代码说明

本版本按研究方案补齐 B-spline / NMPC 之前的完整研究内容：

- ERA5 / HRRR 真实数据接入接口与缓存机制。
- 六类低空气象风险独立建模：风场、阵风、风切变/湍流、对流/雷暴、降水、低能见度/低云底。
- 四维多通道概率风险场：`R(t, z, y, x, c)`。
- 动态全局路径规划：时间依赖 A*。
- 增量动态重规划：默认演示使用事件触发的路径前缀保留与局部修复；同时提供 LPA* / D* Lite 同族 `g/rhs/UpdateVertex/ComputeShortestPath` 模块用于小规模严格验证和后续优化。
- 对比实验、消融指标、风险通道图和 4D 时间序列图。

## 运行完整合成风险实验

```bash
python run_midterm_demo.py
```

输出目录：

```text
outputs/midterm_simulated_risk_demo/
```

主要输出：

- `01_risk_channels.png`：各类气象风险通道。
- `02_4d_risk_timeseries.png`：4D 风险场随时间变化。
- `03_dynamic_path.png`：动态风险场中的时间依赖路径。
- `04_incremental_replanning.png`：风险更新后的增量重规划。
- `05_algorithm_comparison.png`：不同全局规划方法对比。
- `06_metrics_summary.png`、`metrics.csv`、`summary.json`：指标统计。
- `risk_model_report.json`：风险映射参数、概率约束边界定义、风险立方体尺寸、融合权重和航迹约束说明。
- `07_dynamic_risk_field.gif`：融合风险场随时间演化动画。
- `08_time_dependent_path.gif`：时间依赖 A* 路径随时间推进动画。
- `09_incremental_replanning_path.gif`：风险更新后动态修复路径动画。
- `10_dynamic_weather_channels.gif`：风场、阵风、风切变/湍流、对流雷暴、降水、低能见度六类气象风险分面动画。

## 运行真实数据入口

默认可运行本地 GFS 历史天气回放，不依赖网络。它读取仓库中的 `real_weather_wind.nc`、`real_weather_rain.nc`、`processed_env.nc`，裁剪区域并转换为统一 `WeatherCube` 缓存：

```bash
python -m uav_weather_planning.experiments.historical_weather_replay
```

输出目录：

```text
outputs/historical_weather_replay/
```

主要输出：

- `01_realdata_risk_channels.png`：真实天气样例风险通道。
- `02_realdata_4d_risk_timeseries.png`：真实天气回放风险时间序列。
- `03_realdata_dynamic_path.png`：真实天气回放下的时间依赖路径。
- `04_realdata_incremental_replanning.png`：真实天气更新触发的动态修复。
- `05_realdata_algorithm_comparison.png`：真实天气回放算法对比。
- `07_realdata_dynamic_risk_field.gif`、`08_realdata_time_dependent_path.gif`、`09_realdata_weather_channels.gif`：真实天气动态图。
- `10_risk_calibration_curves.png`、`11_risk_calibration_histograms.png`：真实天气样例下的风险校准证据图。
- `risk_calibration_report.json`：风险通道校准指标与可靠性分箱。
- `metrics.csv`、`summary.json`：真实数据指标与数据源元信息。

快速检查入口：

```bash
python -m uav_weather_planning.experiments.midterm_realdata_demo --source local_gfs
```

ERA5/HRRR 下载入口仍然保留，默认只读缓存，不会静默退回合成数据：

```bash
python -m uav_weather_planning.experiments.midterm_realdata_demo --source era5
python -m uav_weather_planning.experiments.midterm_realdata_demo --source hrrr
```

如需尝试下载：

```bash
python -m uav_weather_planning.experiments.midterm_realdata_demo --source era5 --download
python -m uav_weather_planning.experiments.midterm_realdata_demo --source hrrr --download
```

ERA5 需要 `cdsapi` 和 CDS API key；HRRR 需要 `herbie-data`、`cfgrib`、`eccodes`。

当前本地 GFS 回放使用一个真实预报有效时刻，并根据低层风场进行短时外推，形成动态回放序列。若后续下载多个 HRRR/GFS forecast hour，可直接替换为多时刻真实预报堆叠。

## 当前阶段答辩表述

建议表述为：

> 本阶段已完成低空气象风险建模、ERA5/HRRR 数据接口、四维多通道概率风险场构建、时间依赖全局路径规划和风险更新触发的动态重规划验证。后续将在全局时空路径基础上继续加入 B-spline 轨迹优化和鲁棒 NMPC 执行层。

## 图中红色边界说明

图中的红色闭合线是 `no_fly_mask` 的等值线，表示硬禁飞边界，不是人工画圈。当前实现不把原始气象量直接二值化为风险，而是先将风、阵风、风切变/湍流、对流、降水、能见度等变量连续映射为风险概率，再融合预测不确定性和 CVaR 尾部风险形成 `violation_probability`。当违反概率超过机会约束上限，或极端气象安全包络超限概率过高时，才进入 `no_fly_mask`。

## 当前风险立方体尺寸

合成中期演示使用 `RiskField4D(time=34, height=3, y=28, x=28)`，高度层为 `0 m / 250 m / 500 m`。`x/y` 当前是规划网格索引；接入 ERA5/HRRR 历史回放时，由预处理投影坐标确定实际米级分辨率。

## 风险校准与证据链

可单独运行风险建模校准证据实验：

```bash
python -m uav_weather_planning.experiments.risk_calibration_evidence
```

输出目录：

```text
outputs/risk_calibration_evidence/
```

主要输出：

- `risk_calibration_report.json`：各风险通道的样本量、Brier score、MAE、ECE、相关系数和可靠性分箱。
- `risk_calibration_curves.png`：预测风险与代理危险概率的校准曲线。
- `risk_calibration_histograms.png`：各风险通道样本分布。

当前校准证据使用真实 GFS 回放气象变量构造代理危险标签，例如反射率/对流概率、阵风、风切变、降水率、能见度/云底等。它不是实飞事故标签校准，但能证明风险通道与真实天气危险代理之间存在可量化证据链；后续可替换为历史运行事件、人工标注或集合预报误差标签。

## 航迹约束

全局规划层已加入显式航迹约束：单步水平移动上限、单步爬升/下降层数上限、最小安全裕度、最大转向角、等待/爬升/转向惩罚。B-spline 和 NMPC 阶段再继续处理连续曲率、动力学、执行误差和闭环控制。
