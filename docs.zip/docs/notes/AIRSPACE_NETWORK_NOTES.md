# 低空航路网络约束说明

## 模块位置

```text
uav_weather_planning/airspace/
    corridor_graph.py
    corridor_cost.py
    geofence.py
    altitude_layer.py
```

该模块把低空航路显式表示为：

```text
G_air = (V_air, E_air)
```

其中：

- `V_air`：航路节点，包括入口点、出口点、中间航路点和备降点。
- `E_air`：航段走廊，包括中心线、宽度、高度范围、速度限制和开放/关闭状态。

## 航段字段

`CorridorSegment` 包含：

```text
segment_id
start_node
end_node
centerline
width_m
altitude_min_m
altitude_max_m
speed_limit_mps
status
closed_time_windows
```

如果 `status != "open"` 或处于 `closed_time_windows`，该航段不可用。

## 如何进入规划代价

全局规划边权中加入航路偏离代价：

```text
J_corridor = lambda * (d(p, centerline) / (width_m / 2))^2
```

同时有硬约束：

- 超出走廊宽度：不可飞。
- 超出航段允许高度：不可飞。
- 超过航段速度限制：不可飞。
- 进入关闭 geofence：不可飞。

这些逻辑由 `CorridorCostModel` 计算，并由 `FlightConstraints` 在 `is_feasible()` 和 `metric_penalty()` 中调用。

## 当前实验输出

真实天气回放已输出航路网络文件：

```text
outputs/historical_weather_replay_airspace/airspace_network.json
```

对应指标表：

```text
outputs/historical_weather_replay_airspace/metrics.csv
```

新增指标包括：

- `airspace_violations`
- `max_corridor_deviation_m`
- `mean_corridor_deviation_m`
- `max_corridor_deviation_ratio`
- `corridor_segments_used`
- `alternate_landing_points`

当前验证结果：

```text
airspace_enabled = true
G_air segment_count = 8
alternate_landing_point_count = 2
airspace_violations = 0
```

## 答辩表述

建议表述为：

> 本研究不是在自由三维空间中做普通避障，而是在结构化低空航路网络中进行气象风险约束下的动态路径规划。低空航路被建模为 `G_air=(V_air,E_air)`，每条航段具有中心线、走廊宽度、允许高度层、速度限制和开放/关闭状态。规划边权中包含航路偏离二次代价，越界、超高度、超限速和进入关闭区域会被判定为不可飞。气象风险场决定航路中的时变风险代价，航路网络决定飞行结构约束。

如果被追问“航路在哪里”：

> 航路网络保存在 `airspace_network.json`，代码模块为 `uav_weather_planning.airspace`，规划器通过 `FlightConstraints.airspace` 调用，指标表中有 `airspace_violations` 和 `corridor_segments_used` 字段。
