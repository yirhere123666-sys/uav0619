# 多时刻真实气象回放说明

## 已补强的问题

原先真实气象回放更接近“单个真实天气场 + 局部平流外推”。现在新增 `multi_time_real_weather_replay.py`，把真实天气实验升级为：

```text
连续 forecast hour / 历史 valid_time
-> WeatherCube(time, z, y, x, variables)
-> 局地低空规划网格降尺度
-> RiskField4D
-> 飞行过程中按 valid_time 更新风险场
-> 触发时间依赖 A* 重规划
-> 输出变化日志、重规划日志和指标
```

## 新增代码

- `uav_weather_planning/experiments/multi_time_real_weather_replay.py`
  - 读取 `data/replay_cases/<case>/` 下的多时刻 `WeatherCube` 缓存；
  - 每个仿真步对应一个真实或 forecast valid_time；
  - 记录 `changed_voxel_ratio`、`new_no_fly_voxels`、`path_risk_before_update`、`path_risk_after_update`；
  - 输出 `real_replay_metrics.csv`、`real_replay_summary.json`、`risk_field_change_log.csv`、`replan_event_log.csv`。

- `uav_weather_planning/preprocessing/local_weather_downscaling.py`
  - 将 GFS/ERA5/HRRR 区域背景场映射到低空局部任务网格；
  - 支持水平插值、垂直插值、置信度降低和局地扰动补充；
  - 在 metadata 中标记 `synthetic_local_perturbation`，避免把局地补充项误说成真实观测。

- `uav_weather_planning/data_interface/weather_cube.py`
  - 增加 `slice_time()` 和 `query_time()`；
  - 支持按真实时间查询最近时刻或线性插值时刻。

## 运行方式

严格真实多时刻案例：

```powershell
python -m uav_weather_planning.experiments.multi_time_real_weather_replay --case-dir data/replay_cases/case_001_wind_precip
```

当前已落地的中期案例：

```powershell
python run_project.py multi-real --output-dir outputs/multi-real
```

当前 `data/replay_cases/case_001_wind_precip/` 包含 GFS f000-f006 共 7 个真实 forecast valid time，`outputs/multi-real/real_replay_summary.json` 中应显示：

```text
strict_historical_sequence = true
real_valid_times_count = 7
forecast_hours = 0;1;2;3;4;5;6
```

变化体素统计现在分为两类：

```text
raw_changed_voxel_ratio
significant_changed_voxel_ratio
```

`raw_changed_voxel_ratio` 记录所有浮点数值变化，真实天气场连续更新时通常接近 1。`significant_changed_voxel_ratio` 只记录足以影响重规划的显著变化，默认阈值为：

```text
abs(total_cost_delta) > 0.3
abs(cvar_delta) > 0.2
abs(violation_probability_delta) > 0.1
no_fly_mask changed
```

当前案例中 f000->f001 是背景风场整体更新，因此显著变化比例为 1；f002 之后显著变化比例约为 2%-4.5%，用于说明增量更新主要作用于局部显著变化邻域。

没有连续真实案例时的流程烟测：

```powershell
python -m uav_weather_planning.experiments.multi_time_real_weather_replay --allow-nowcast-fallback
```

统一入口：

```powershell
python run_project.py multi-real
```

## 答辩边界

可以说：

> 已实现多时刻真实气象序列驱动的历史回放框架；当前中期案例使用 GFS f000-f006 连续 forecast hour，风险场更新来自真实时间序列，并在 f003 更新时触发一次路径修复。

必须谨慎说：

> 若 `strict_historical_sequence=false`，该次运行只是本地单 valid_time fallback，用于验证代码闭环，不作为真实多时刻动态天气证据。

推荐中期展示时优先使用 `strict_historical_sequence=true` 的案例输出。
