# 多真实历史天气过程回放说明

## 当前状态

当前仓库已经具备严格多时刻真实天气回放能力，但已落地的真实案例数量仍然偏少：

- 已完成案例：`data/replay_cases/case_001_wind_precip`
- 数据来源：GFS forecast hour `0-6`
- 严格性：每个 `weather_fXXX.npz` 对应一个真实 forecast valid time，不是单帧平流外推
- 中期定位：足够展示“真实气象序列 -> WeatherCube -> RiskField4D -> 动态重规划 -> 指标输出”的闭环

论文阶段不应只依赖这一个案例。单案例只能证明流程可行，不能充分说明方法对不同真实天气过程都稳定。

## 新增批量实验入口

运行所有本地真实回放案例：

```powershell
python run_project.py multi-case-real --output-dir outputs/multi-case-real
```

或直接运行模块：

```powershell
python -m uav_weather_planning.experiments.multi_case_real_weather_replay --case-root data/replay_cases
```

输出文件：

- `real_case_inventory.csv`：扫描到的真实案例、forecast hour、严格多时刻校验结果
- `multi_case_real_replay_metrics.csv`：每个案例的路径风险、禁飞侵入、约束、能耗和重规划指标
- `multi_case_real_replay_summary.json`：案例数量、天气类型覆盖度、论文可用性判断
- `<case_id>/real_replay_summary.json`：单案例详细回放结果
- `<case_id>/real_replay_metrics.csv`：单案例路径指标

## 论文阶段建议案例集

建议最终扩展到 `3-5` 个真实历史天气过程，每个过程包含 `6-12` 个 forecast hour：

| 案例 | 目标天气过程 | 主要用途 |
| --- | --- | --- |
| `case_001_wind_precip` | 风和降水背景 | 当前已完成，中期展示用 |
| `case_002_high_wind` | 大风或强阵风过程 | 验证风风险、侧风、阵风和能耗约束 |
| `case_003_precip_convection` | 强降水或对流阻断过程 | 验证对流禁飞、降水风险和动态绕行 |
| `case_004_low_visibility` | 低能见度或低云底过程 | 验证感知风险、低云底高度约束和保守规划 |
| `case_005_compound_weather` | 风、雨、能见度复合天气 | 验证多通道融合和 CVaR 尾部风险 |

## 答辩口径

中期可以说：

> 已完成一个严格多时刻真实天气回放案例，验证了真实 forecast valid time 序列驱动下的风险场更新和动态重规划闭环。

不要说：

> 已经通过大量真实历史天气过程验证。

最终论文建议说：

> 真实数据实验覆盖多个历史天气过程，包括大风、降水/对流、低能见度和复合天气。每个过程使用连续 forecast hour 构成多时刻 WeatherCube，并统计路径风险、禁飞侵入、约束违反、能耗和重规划事件，从而降低单案例偶然性。
