# 课题代码结构说明

## 主线代码

当前课题代码统一收敛到 `uav_weather_planning/` 包内：

- `risk_models/`：风、阵风、风切变/湍流、对流、降水、能见度、不确定性和融合模型。
- `risk_field/`：`RiskField4D` 四维多通道概率风险场。
- `data_interface/`：ERA5、HRRR、本地 GFS 回放、缓存和 `WeatherCube`。
- `global_planner/`：时间依赖 A*、LPA*/D* Lite 同族增量搜索、事件触发修复、约束、能耗和指标。
- `airspace/`：低空航路网络、走廊约束、地理围栏和高度层。
- `trajectory/`：B-spline 连续轨迹采样和运动学约束检查。
- `control/`：多旋翼简化动力学模型和 NMPC 设计接口。
- `experiments/`：中期演示、真实天气回放、消融实验、统计基准实验、校准证据和轨迹/控制 smoke 测试。
- `visualization/`：静态图和动态图生成。

## 统一运行入口

新增统一入口：

```powershell
python run_project.py simulated
python run_project.py realdata
python run_project.py benchmark
python run_project.py ablation
python run_project.py incremental
python run_project.py trajectory
python run_project.py calibration
```

可通过 `--output-dir` 指定输出目录。

## 已删除的旧原型代码

以下旧代码已删除，避免和当前研究主线混淆：

- `algorithms/dslite.py`
- `models/weather.py`
- `run_real_simulation.py`
- `run_lab_simulation.py`

删除原因：

- 旧 `algorithms/dslite.py` 类名叫 `DStarLite`，但实际更接近从目标反向搜索的 A* 原型，不是严格 D* Lite。
- 旧 `models/weather.py` 只把静态 `travel_cost` 扩展成 4D 容器，不能代表现在的多通道概率风险场。
- 旧运行脚本依赖上述旧接口，且图示和命名会混淆中期答辩口径。

## 命名整理

当前事件触发路径修复基线命名为 `EventTriggeredRepairReplanner`。

旧的 D* Lite 风格命名已经移除，避免和严格 `g/rhs/open` 增量搜索混淆。严格增量搜索证据来自 `IncrementalLPAStar` 和 `incremental_search_validation.py`；事件触发路径修复基线统一命名为 `EventTriggeredRepairReplanner`。

## 中期展示建议

答辩展示时建议只从以下入口和输出讲：

- 合成动态风险演示：`python run_project.py simulated`
- 真实天气回放：`python run_project.py realdata`
- 统计基准实验：`python run_project.py benchmark`
- 增量搜索验证：`python run_project.py incremental`
- 轨迹/NMPC 接口：`python run_project.py trajectory`
- 多时刻真实气象回放：`python run_project.py multi-real`
- 风险校准证据：`python run_project.py calibration`
- 风险权重搜索：`python run_project.py risk-search`
- 风险权重敏感性：`python run_project.py sensitivity`

不要再展示或引用已删除的旧 `DStarLite`、旧 `MeteoRiskCube` 和旧单脚本仿真。

## 多时刻真实气象回放

新增入口：
```powershell
python -m uav_weather_planning.experiments.multi_time_real_weather_replay --case-dir data/replay_cases/case_001_wind_precip
python run_project.py multi-real
```

对应模块：
- `uav_weather_planning/experiments/build_real_replay_case.py`
- `uav_weather_planning/experiments/multi_time_real_weather_replay.py`
- `uav_weather_planning/preprocessing/local_weather_downscaling.py`
- `data/replay_cases/README.md`
- `MULTI_TIME_REAL_REPLAY_NOTES.md`

当前真实案例：
- `data/replay_cases/case_001_wind_precip/weather_f000.npz` 到 `weather_f006.npz`
- GFS 连续 forecast hour 0-6
- `outputs/multi-real/real_replay_summary.json` 已验证 `strict_historical_sequence=true`、`real_valid_times_count=7`
- 变化检测区分 `raw_changed_voxel_ratio` 和 `significant_changed_voxel_ratio`，增量更新只使用显著变化体素及其前驱邻域，后继由 `g/rhs` 传播更新。

答辩口径中要区分两种模式：
- `strict_historical_sequence=true`：连续真实 valid_time 或 forecast hour 驱动的动态天气回放。
- `strict_historical_sequence=false`：无连续真实案例时的 nowcast fallback，只用于验证流程可运行。

## 阈值、权重、校准和敏感性

新增配置：
- `configs/risk_thresholds_reference.yaml`：物理参考阈值，只回答“什么时候危险/不可飞”。
- `configs/risk_fusion_calibrated.yaml`：融合和规划权重，只回答“多风险同时存在时谁更影响路径选择”。

新增模块：
- `uav_weather_planning/risk_calibration/proxy_label.py`：体素级和路径级代理标签。
- `uav_weather_planning/risk_calibration/weight_search.py`：随机/拉丁超立方权重搜索。
- `uav_weather_planning/experiments/risk_weight_sensitivity.py`：对校准权重做扰动并统计稳定性。

当前实验协议：
- `python run_project.py risk-search`：默认 30 个校准样本、50 组拉丁超立方候选加 1 组基线，按 6:2:2 划分为 calibration/validation/test。
- `python run_project.py sensitivity`：默认使用 benchmark_suite 的 27 组任务，协议为 3 类航路任务 x 3 档气象强度/动态速度 x 3 个随机种子。
- 敏感性分析对风、阵风、风切变/湍流、对流、降水、能见度、不确定性、CVaR、能耗、走廊偏离和机会约束限制做 +/-10%、+/-20%、+/-30% 扰动。
- 权重校准样本通过 `soften_weather_corridor()` 保留窄安全走廊，只用于比较权重候选；极端阻断和动态闭合场景由 benchmark 与重规划实验验证。
- 主要输出位于 `outputs/risk-search/` 和 `outputs/sensitivity/`，其中 summary JSON 记录样本规模、候选数量、稳定性指标和答辩口径。

当前全量运行结果：
- `outputs/risk-search/risk_weight_search_summary.json`：`case_count=30`，`candidate_count=51`，`case_splits=18/6/6`，验证集和测试集成功率均为 1.0，禁飞区侵入均值为 0。
- `outputs/sensitivity/risk_weight_sensitivity_summary.json`：`case_count=27`，`candidate_count=67`，CSV 共 1809 条逐案记录。
- +/-20% 权重扰动下 `min_success_rate=1.0`，`max_nofly_intrusions_mean=0.0`，说明安全性结论不依赖单一人工权重。

答辩口径：
阈值来自参考多旋翼平台能力和气象危险等级，融合权重通过代理标签校准和路径级验证选择，并通过敏感性实验说明结论不依赖单组拍脑袋参数。

## 主 benchmark 航路约束接入

`benchmark_suite.py` 不再只预留 airspace 指标，而是在每个 case 中基于任务起终点和风险场构建 `CorridorGraph.from_mission()`：

- 航路图：`G_air=(V_air,E_air)`。
- 走廊宽度：`2.0` 个局部规划网格。
- 局部网格分辨率：`100 m`。
- 时间步长：`15 s`。
- 速度限制：`15 m/s`。
- 高度层范围：`80-120 m`。

正式输出 `outputs/benchmark_suite/benchmark_metrics.csv` 已验证：
- `corridor_segments_used` 空值行数为 `0`。
- `mean_corridor_deviation_m` 空值行数为 `0`。
- `max_corridor_deviation_ratio` 空值行数为 `0`。
- `airspace_violations` 最大值为 `0`。
- `benchmark_summary.json` 包含 `protocol.airspace_constraints`、`airspace_networks` 和逐 case 的 `airspace_network_summary`。
