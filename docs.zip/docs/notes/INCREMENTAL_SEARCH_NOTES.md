# D* Lite / LPA* 增量搜索实现说明

## 当前实现边界

本项目现在保留两类重规划代码：

- `IncrementalLPAStar`：主力的 LPA* / D* Lite 同族增量搜索实现，包含 `g`、`rhs`、优先队列、`update_vertex()` 和 `compute_shortest_path()`。
- `EventTriggeredRepairReplanner`：演示用路径前缀修复基线，用于较大图上的快速可视化，不作为“严格 D* Lite 已完成”的核心证据。

中期答辩建议表述为：

> 已实现 D* Lite / LPA* 同族的增量搜索框架，风险更新后复用历史 `g/rhs/open` 状态，仅对显著变化体素及其前驱邻域执行 `UpdateVertex`，后继由 `g/rhs` 传播自然更新，并与重新全局搜索进行节点数和耗时对比。

不建议表述为：

> 已完整实现标准 D* Lite，并已经证明实时性显著优于全局重搜。

## 本次修正内容

1. `update_risk_field()` 不再清空 `g`、`rhs` 和 open queue。
2. 风险更新后区分 `raw_changed_voxels` 和 `significant_changed_voxels`，增量更新只使用显著变化体素。
3. 对显著变化体素及其前驱邻域执行 `update_vertex()`，后继节点由 `compute_shortest_path()` 中的 `g/rhs` 传播更新。
4. 增加边代价缓存和邻接缓存，风险场更新时清空边代价缓存，避免一次修复内重复计算同一边。
5. `compute_shortest_path()` 记录本次修复扩展节点数和耗时，便于和全局重搜对比。
6. 新增 `incremental_search_validation.py`，输出 `incremental_search_metrics.csv` 与 `incremental_search_summary.json`。

## 最近一次验证结果

验证场景：`14 x 1 x 12 x 12` 的 4D 风险立方体，局部天气更新影响 80 个显著变化体素，扩展到 196 个受影响节点。

- 更新前 `g` 数量：237
- 更新前 `rhs` 数量：368
- 更新前 open queue 记录：131
- 更新后 `g` 数量：237
- 更新后 `rhs` 数量：458
- 更新后 open queue 记录：210
- `queue_reused`: true
- `g_rhs_reused`: true
- `edge_cost_cache_enabled`: true
- `neighbor_cache_enabled`: true
- 增量修复扩展节点：`578`
- 全局重搜扩展节点：`622`
- 增量修复耗时：约 `329 ms`
- 全局重搜耗时：约 `296 ms`

这说明当前版本已经不是“清空后重跑”，而是真正保留了历史搜索状态。

## 性能解释口径

当前局部阻断场景中，增量修复路径成功，扩展节点数相对重新全局搜索减少约 7.1%；加入边代价缓存后，耗时从秒级降低到约 `329 ms`，已经接近全局重搜的约 `296 ms`，但仍不能宣称显著更快。这是合理的阶段性结果：

- 当更新只影响路径附近小区域，增量搜索应减少无关区域扩展。
- 当更新切断旧最优路径并导致代价升高传播时，LPA* 需要先修正旧 `g` 值，再形成新路径，可能不如一次全局 A* 快。
- 当前 Python 原型已加入邻接缓存和代价缓存，但仍没有做到标准工业级优先队列去重、批量边更新和更细粒度的 D* Lite 工程优化，因此耗时指标不能过度宣称。

中期可防守结论应落在“机制正确、状态复用真实、实验指标可审计”，而不是“实时性已经显著领先”。
