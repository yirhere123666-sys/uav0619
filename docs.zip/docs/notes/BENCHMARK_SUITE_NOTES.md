# 统计实验协议说明

## 目的

此前中期实验以单个合成风险场和单个真实天气回放为主，容易被质疑“是否只对这个例子有效”。本次新增 `benchmark_suite.py`，将实验改造成统一任务集和参数化气象扰动样本库上的批量统计协议。

## 默认协议

默认协议为 27 个场景：

- 3 类航路任务
- 3 档配对气象扰动等级
- 3 个随机种子

气象等级采用配对设计：

- 低强度 + 慢速移动
- 中强度 + 常速移动
- 高强度 + 快速移动

这样正好形成 `3 × 3 × 3 = 27` 组实验。代码同时支持 `--full-factorial`，可扩展为 `3 类任务 × 3 档风险强度 × 3 档动态速度 × 3 个种子 = 81` 组实验。

## 输出文件

运行命令：

```powershell
python -m uav_weather_planning.experiments.benchmark_suite --output-dir outputs\benchmark_suite
```

输出：

- `benchmark_metrics.csv`：每个场景、每个算法的完整指标。
- `benchmark_summary.json`：任务集、样本库参数、协议说明和关键结论。
- `mean_std_table.csv`：按算法汇总的均值和标准差表。

## 对比算法

默认统计 5 类算法结果：

- `No-weather A*`
- `Static-risk A*`
- `Time-dependent A*`
- `Restart full search`
- `Event-triggered repair`

其中 `Event-triggered repair` 是事件触发路径修复基线；严格 `g/rhs/open` 增量搜索证据见 `incremental_search_validation.py`。

## 最近一次统计结果

正式输出目录：`outputs/benchmark_suite`

协议规模：

- 场景数：27
- 算法数：5
- 指标行数：135

关键统计结果：

- 时间依赖 A* 成功率：`1.0`
- 时间依赖 A* 平均禁飞侵入：`0.0`
- 无天气 A* 平均禁飞侵入：`1.1852`
- 时间依赖 A* 平均期望风险：`79.1974`
- 静态风险 A* 平均期望风险：`79.7052`
- 事件触发修复平均扩展节点：`1479.1481`
- 全局重搜平均扩展节点：`1497.6667`
- 事件触发修复成功率：`1.0`
- 事件触发修复平均禁飞侵入：`0.0`
- 事件触发修复平均约束违规：`0.0`
- 事件触发修复 fallback 次数：`3 / 27`
- 主 benchmark 航路违规最大值：`0`
- `corridor_segments_used` 空值行数：`0`
- `mean_corridor_deviation_m` 空值行数：`0`
- `max_corridor_deviation_ratio` 空值行数：`0`
- 平均走廊偏离：`6.871 m`
- 航路网络：每个 case 由 `CorridorGraph.from_mission()` 生成 `G_air=(V_air,E_air)`，并写入 `benchmark_summary.json` 的 `airspace_networks` 与 `case_summaries[*].airspace_network_summary`。

这组结果可用于答辩说明：

> 实验不是单个案例演示，而是在统一低空航路任务集和参数化动态气象扰动样本库上进行统计对比；主 benchmark 已显式接入结构化航路网络，时间依赖 4D 风险规划在 27 组任务中保持零禁飞侵入和零航路违规，并相对静态风险规划降低平均风险。

事件触发修复的答辩口径需要谨慎：

> 事件触发修复采用“先局部修复、再安全审计、必要时回退到全局时间依赖 A*”的安全策略，因此主 benchmark 中安全性追平全局重搜；但它仍是工程安全基线，不应宣称纯增量修复已经显著快于全局重搜。

## 答辩边界

可以说：

> 已建立统计实验协议，覆盖多任务、多风险强度、多动态速度和多随机种子，并输出均值/标准差表。

不要说：

> 已完成大规模真实气象统计验证。

真实 ERA5/HRRR 回放仍属于真实性验证链路；本模块主要解决“合成动态气象扰动下算法是否具有统计稳定性”的问题。
