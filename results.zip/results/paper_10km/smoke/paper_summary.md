# 10 km WRF 气象风险场论文图摘要

- 实验模式：smoke。
- 验证级别：快速可视化 / 冒烟验证（Smoke Validation）。
- 主配置：10 km 任务，12 km x 12 km，100 m 网格，121 x 121，60-180 m，10 s，1200 s。
- WRF 边界说明：WRF 是背景气象场。当前 WRF 个例主要支撑风场、风切变和能耗风险实验；强降水、强对流和低能见度通道在该样本中较弱，相关动态主要由局地扰动模型补充，用于验证风险场和动态重规划机制。
- 局地扰动说明：局地风切变和阵风扰动标记为 synthetic_local_perturbation，用于补足公开模式资料难以解析的低空秒级扰动。
- 动态重规划：当前主输出为 `incremental_dstar_lite`，planner=`dstar_lite_4d`。
- 主实验最大垂直速度：上升 2.0 m/s，下降 2.0 m/s。
- Monte Carlo 样本数：2。
- CVaR 分块体素数：260000。
- 任务距离：9914.782 m。
- 风险场 shape：[121, 7, 81, 81]。

## 路径指标

- 无气象约束 A*：Expected=227.332，CVaR=6.537，no-fly=0。
- 时间依赖风险 A*：Expected=215.784，CVaR=5.421，no-fly=0。
- D* Lite 修复：Expected=3.277，CVaR=0.0，no-fly=0。
- 全局重搜基线：Expected=173.038，CVaR=3.683，no-fly=0。

## 增量复用证据

- 状态格式：`(time_index, height_index, y_index, x_index)`。
- g/rhs reused：True。
- queue reused：True。
- changed_voxel_count：513。
- affected_state_count：4。
- update_vertex_count：4。
- compute_shortest_path_iterations：0。
- nodes_expanded_incremental：0。
- nodes_expanded_full_restart：84。
- elapsed_ms_incremental：102.623。
- elapsed_ms_full_restart：151.536。
- speedup_ratio：1.476624。

## 结论口径

WRF 是背景气象场。当前 WRF 个例主要支撑风场、风切变和能耗风险实验；强降水、强对流和低能见度通道在该样本中较弱，相关动态主要由局地扰动模型补充。正式 CVaR 指标使用 `smoke` 模式的样本数；`smoke` 模式只作为快速可视化 / 冒烟验证。
