# D* Lite 路径受影响重规划实验摘要

- 实验模式：smoke。
- 验证级别：快速可视化 / 冒烟验证（Smoke Validation）。
- WRF 边界说明：WRF 是背景气象场。当前 WRF 个例主要支撑风场、风切变和能耗风险实验；强降水、强对流和低能见度通道在该样本中较弱，相关动态主要由局地扰动模型补充，用于验证风险场和动态重规划机制。
- 局地扰动说明：局地风切变和阵风扰动标记为 synthetic_local_perturbation，用于补足公开模式资料难以解析的低空秒级扰动。
- 主实验最大垂直速度：上升 2.0 m/s，下降 2.0 m/s。
- Monte Carlo 样本数：2。
- CVaR 分块体素数：260000。
- 任务距离：9914.782 m。
- 路径是否受影响：True。
- D* Lite 状态复用：g/rhs=True，queue=True。
- compute_shortest_path_iterations：2。
- affected_state_count：23846。
- update_vertex_count：23848。
- changed_voxel_count：7561。
- 增量修复耗时：26184.956 ms。
- 全局重搜耗时：91.64 ms。
- 加速比：0.0035。

## 风险改善

- 原路径未来段期望风险：5.093。
- 修复路径期望风险：2.637。
- 原路径未来段 CVaR：0.025。
- 修复路径 CVaR：0.018。
- 原路径最大违反概率：0.794。
- 修复路径最大违反概率：0.469。

## 结论口径

WRF 是背景气象场；局地风切变和阵风扰动是 synthetic_local_perturbation。该场景用于验证 D* Lite 动态重规划机制，强降水、强对流、低能见度在当前 WRF 个例中不是主要真实背景证据。
