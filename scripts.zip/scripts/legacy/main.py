from uav_weather_planning.experiments.midterm_simulated_risk_demo import main


if __name__ == "__main__":
    main()
