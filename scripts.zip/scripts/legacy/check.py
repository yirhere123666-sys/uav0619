import os
import sys
import numpy as np
import xarray as xr

# --- 注入 DLL 路径 (防止报错) ---
current_env = sys.prefix
dll_path = os.path.join(current_env, 'Library', 'bin')
if os.path.exists(dll_path):
    os.environ['PATH'] = dll_path + os.pathsep + os.environ.get('PATH', '')


# -----------------------------

def inspect_environment():
    print("==========================================")
    print("   🚑 V9.0 DATA HEALTH CHECK DIAGNOSIS    ")
    print("==========================================")

    file_path = "processed_env.nc"
    if not os.path.exists(file_path):
        print("❌ Error: processed_env.nc not found!")
        return

    try:
        ds = xr.open_dataset(file_path)
        cost_map = ds['travel_cost'].values  # Shape: (Height, Lat, Lon)

        print(f"✅ Data Loaded. Shape: {cost_map.shape}")

        # 1. 检查全图统计
        print("\n[1] Map Statistics:")
        print(f"   - Min Cost: {np.nanmin(cost_map):.2f}")
        print(f"   - Max Cost: {np.nanmax(cost_map):.2f}")
        print(f"   - Mean Cost: {np.nanmean(cost_map):.2f}")
        print(f"   - NaN Count: {np.isnan(cost_map).sum()} (Should be 0)")
        print(f"   - Inf Count: {np.isinf(cost_map).sum()}")

        # 2. 检查起点和终点状态
        # 仿真中设定的点：Start(5,5,5), Goal(5, 44, 44) (注意：Y=Lat, X=Lon)
        # 这里假设 height=5 (约500m)
        sz, sy, sx = 5, 5, 5
        gz, gy, gx = 5, 44, 44

        print("\n[2] Mission Check (Height Layer 5):")

        # 检查起点
        start_val = cost_map[sz, sy, sx]
        print(f"   👉 Start Node ({sz}, {sy}, {sx}): Cost = {start_val}")
        if start_val >= 5000:
            print("      ❌ CRITICAL: Start point is inside a STORM or NO-FLY ZONE!")
        elif start_val >= 100:
            print("      ⚠️ WARNING: Start point is in HIGH WIND.")
        else:
            print("      ✅ Start point is SAFE.")

        # 检查终点
        goal_val = cost_map[gz, gy, gx]
        print(f"   👉 Goal Node ({gz}, {gy}, {gx}): Cost = {goal_val}")
        if goal_val >= 5000:
            print("      ❌ CRITICAL: Goal point is inside a STORM!")
        elif goal_val >= 100:
            print("      ⚠️ WARNING: Goal point is in HIGH WIND.")
        else:
            print("      ✅ Goal point is SAFE.")

        # 3. 检查这一层有多少障碍物
        layer_5 = cost_map[5, :, :]
        storm_pixels = np.sum(layer_5 >= 5000)
        total_pixels = layer_5.size
        print(f"\n[3] Obstacle Density (Layer 5):")
        print(f"   - Storm Coverage: {storm_pixels} / {total_pixels} pixels ({storm_pixels / total_pixels * 100:.1f}%)")

        if storm_pixels / total_pixels > 0.8:
            print("      ❌ MAP IS BLOCKED: Over 80% of the map is a storm!")

    except Exception as e:
        print(f"❌ Diagnosis Failed: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    inspect_environment()