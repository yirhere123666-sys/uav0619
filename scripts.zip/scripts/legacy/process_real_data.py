import os
import sys

# =========================================================
# 🚑【强力修复模块】必须在每个脚本开头都加，确保万无一失
# =========================================================
current_env = sys.prefix
dll_path = os.path.join(current_env, 'Library', 'bin')

if os.path.exists(dll_path):
    os.environ['PATH'] = dll_path + os.pathsep + os.environ.get('PATH', '')
else:
    fallback_path = r"C:\Users\DELL\.conda\envs\uav_lab\Library\bin"
    if os.path.exists(fallback_path):
        os.environ['PATH'] = fallback_path + os.pathsep + os.environ.get('PATH', '')
# =========================================================

import xarray as xr
import numpy as np


def process_data():
    print("==========================================")
    print("   V8.0: PHYSICS-BASED DATA PROCESSING    ")
    print("==========================================")

    file_wind = "real_weather_wind.nc"
    file_rain = "real_weather_rain.nc"
    output_file = "processed_env.nc"

    # 1. 检查原材料
    if not os.path.exists(file_wind) or not os.path.exists(file_rain):
        print(f"❌ Missing files! Please wait for 'get_real_data.py' to finish.")
        return

    try:
        print("[1/6] Loading Raw Data...")
        ds_wind = xr.open_dataset(file_wind, engine="netcdf4")
        ds_rain = xr.open_dataset(file_rain, engine="netcdf4")

        print(f"   Wind Vars: {list(ds_wind.data_vars)}")
        print(f"   Rain Vars: {list(ds_rain.data_vars)}")
        print(f"   Wind Dims: {list(ds_wind.dims)}")  # 打印维度确认

        # 2. 统一坐标系 & 切片
        print("[2/6] Slicing Data (50x50 Grid)...")

        # 【关键修改】去掉了 step=0，因为单时刻数据没有 step 维度
        # 我们只切取经纬度范围 (前50个网格)
        # 注意：确保变量名 latitude/longitude 是正确的 (GFS通常是这两个)
        ds_wind = ds_wind.isel(latitude=slice(0, 50), longitude=slice(0, 50))
        ds_rain = ds_rain.isel(latitude=slice(0, 50), longitude=slice(0, 50))

        # 3. 垂直插值：从 气压(mb) -> 几何高度(m)
        print("[3/6] Performing Vertical Interpolation (Pressure -> Altitude)...")

        # 自动识别高度变量
        z_var = None
        for v in ds_wind.data_vars:
            if 'gh' in v.lower() or 'hgt' in v.lower():
                z_var = v
                break

        if z_var:
            # 这里的 dim 可能叫 isobaricInhPa，需要动态获取
            p_dim = 'isobaricInhPa' if 'isobaricInhPa' in ds_wind.dims else list(ds_wind.dims)[0]

            mean_heights = ds_wind[z_var].mean(dim=['latitude', 'longitude'])
            ds_wind = ds_wind.assign_coords(height=(p_dim, mean_heights.values))
            ds_wind = ds_wind.swap_dims({p_dim: "height"})
        else:
            print("   ⚠️ Warning: Geopotential Height not found. Using Standard Atmosphere Approx.")
            p_dim = 'isobaricInhPa'
            pressure_levels = ds_wind[p_dim].values
            approx_heights = 44330 * (1 - (pressure_levels / 1013.25) ** 0.1903)
            ds_wind = ds_wind.assign_coords(height=(p_dim, approx_heights))
            ds_wind = ds_wind.swap_dims({p_dim: "height"})

        # 定义目标高度层 (0m 到 2000m，每100m一层)
        target_z = np.linspace(0, 2000, 21)
        ds_interp = ds_wind.interp(height=target_z, method="linear")

        # 4. 计算风切变 (Shear) - 核心物理模型
        print("[4/6] Calculating Wind Shear (Physics Model)...")

        u_var = [v for v in ds_wind.data_vars if 'u' in v.lower()][0]
        v_var = [v for v in ds_wind.data_vars if 'v' in v.lower()][0]

        u = ds_interp[u_var]
        v = ds_interp[v_var]

        dz = 100.0
        du_dz = u.diff("height") / dz
        dv_dz = v.diff("height") / dz

        shear = np.sqrt(du_dz ** 2 + dv_dz ** 2)
        shear = shear.reindex(height=target_z, method="nearest")

        # 5. 处理雷暴禁飞区
        print("[5/6] Mapping Thunderstorm No-Fly Zones...")
        ref_var = [v for v in ds_rain.data_vars if 'ref' in v.lower()][0]
        refc = ds_rain[ref_var]

        # 广播到 3D
        refc_3d, _ = xr.broadcast(refc, ds_interp.height)

        # 6. 生成代价地图
        print("[6/6] Generating Final Cost Map...")

        cost = xr.ones_like(shear)

        # A. 风切变代价 (Cost 100)
        # 用 fillna(0) 处理可能出现的 NaN
        shear = shear.fillna(0)
        cost = cost.where(shear < 0.05, 100)

        # B. 雷暴禁飞 (Cost 5000)
        refc_3d = refc_3d.fillna(0)
        cost = cost.where(refc_3d < 40, 5000)

        # 7. 保存
        ds_out = xr.Dataset({
            "travel_cost": cost,
            "shear": shear,
            "refc": refc_3d,
            "u": u,
            "v": v
        })
        ds_out.to_netcdf(output_file)

        print(f"\n✅ SUCCESS! Processed environment saved to: {output_file}")
        print("   Ready for V8.0 Simulation Integration!")

    except Exception as e:
        print(f"\n❌ PROCESSING ERROR: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    process_data()