import os
import sys

# =========================================================
# 🚑【强力修复模块】手动指定 ecCodes DLL 路径
# =========================================================
current_env = sys.prefix
dll_path = os.path.join(current_env, 'Library', 'bin')

if os.path.exists(dll_path):
    os.environ['PATH'] = dll_path + os.pathsep + os.environ.get('PATH', '')
    print(f"✅ [System] Successfully injected DLL path: {dll_path}")
else:
    fallback_path = r"C:\Users\DELL\.conda\envs\uav_lab\Library\bin"
    if os.path.exists(fallback_path):
        os.environ['PATH'] = fallback_path + os.pathsep + os.environ.get('PATH', '')
        print(f"✅ [System] Used fallback path: {fallback_path}")
# =========================================================

from herbie import Herbie
from pandas import Timestamp, Timedelta
import xarray as xr


def download_gfs_data():
    print("==========================================")
    print("   REAL-WORLD DATA ACQUISITION (GFS)      ")
    print("==========================================")

    # 1. 设定时间
    date = Timestamp.now().floor('1D') - Timedelta('1D')
    print(f"[1/4] Targeting Date: {date} (00:00 UTC)")

    # 2. 初始化 Herbie
    H = Herbie(
        date,
        model='gfs',
        product='pgrb2.0p25',
        fxx=6,
        save_dir='.',
        verbose=True
    )

    # 3. 构建正则
    search_pattern = r":(U|V)GRD:\d+ mb|:HGT:\d+ mb|:REFC:"
    print(f"[2/4] Search Pattern: {search_pattern}")
    print("[3/4] Downloading & Filtering Data...")

    try:
        # 4. 下载
        # 注意：这里可能会返回一个 Dataset，也可能返回一个 List of Datasets
        ds_result = H.xarray(
            searchString=search_pattern,
            backend_kwargs={'indexpath': ''},
        )

        # 统一把结果变成列表，方便处理
        if not isinstance(ds_result, list):
            ds_list = [ds_result]
        else:
            ds_list = ds_result

        print(f"✅ Downloaded {len(ds_list)} data chunks (Hypercubes).")

        # 5. 智能分类保存
        for i, ds in enumerate(ds_list):
            # 获取变量名列表，用来判断这个块里装的是什么
            # 不同的 grib 版本变量名可能略有不同，通常 u/v/gh 是 3D 的，refc 是 2D 的
            var_names = list(ds.data_vars)
            print(f"   -> Processing Chunk {i + 1}: Variables {var_names}")

            # 自动命名逻辑
            filename = f"real_weather_part_{i}.nc"  # 默认名

            # 检查特征变量 (转换成小写比较)
            vars_lower = [v.lower() for v in var_names]

            # 如果包含 u/v 风速 或 gh 高度 -> 风场文件
            if any(x in vars_lower for x in ['u', 'v', 'gh', 'hgt', 'ugrd', 'vgrd']):
                filename = "real_weather_wind.nc"
            # 如果包含 refc 反射率 -> 雷暴文件
            elif any(x in vars_lower for x in ['refc', 'ref']):
                filename = "real_weather_rain.nc"

            # 删除旧文件
            if os.path.exists(filename):
                try:
                    os.remove(filename)
                except:
                    pass

            ds.to_netcdf(filename)
            print(f"      💾 Saved to: {filename}")

        print(f"\n>>> SUCCESS! All data parts saved successfully.")
        print(">>> Ready for V8.0 Processing.")

    except Exception as e:
        print(f"\n>>> ERROR: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    download_gfs_data()