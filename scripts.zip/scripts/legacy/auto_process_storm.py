import os
import sys
import xarray as xr
import numpy as np

# --- 注入 DLL 路径 ---
current_env = sys.prefix
dll_path = os.path.join(current_env, 'Library', 'bin')
if os.path.exists(dll_path):
    os.environ['PATH'] = dll_path + os.pathsep + os.environ.get('PATH', '')


# --------------------

def find_and_process_storm():
    print("==========================================")
    print("   🌩️ AUTOMATIC STORM HUNTER (V9.1)     ")
    print("==========================================")

    file_wind = "real_weather_wind.nc"
    file_rain = "real_weather_rain.nc"
    output_file = "processed_env.nc"

    if not os.path.exists(file_rain):
        print("❌ Error: Data files not found.")
        return

    # 1. 加载雷暴数据并寻找最大值
    print("[1/5] Scanning Global Data for Storms...")
    ds_rain = xr.open_dataset(file_rain, engine="netcdf4")

    # 获取反射率变量
    ref_var = [v for v in ds_rain.data_vars if 'ref' in v.lower()][0]
    ref_data = ds_rain[ref_var]  # 通常是 (step, lat, lon) 或 (lat, lon)

    # 如果有时间维度，取第0帧
    if 'step' in ref_data.dims:
        ref_data = ref_data.isel(step=0)

    # 找到最大值的索引
    max_val = ref_data.max().values
    print(f"   🌊 Detected Max Reflectivity: {max_val:.2f} dBZ")

    if max_val < 20:
        print("   ⚠️ Warning: The weather seems calm globally. Simulation might be boring.")

    # 获取最大值的坐标索引 (argmax)
    flat_idx = ref_data.argmax()
    # 将扁平索引转换为 (lat, lon) 二维索引
    # 注意：unravel_index 返回的是 tuple
    max_idx = np.unravel_index(flat_idx, ref_data.shape)

    center_lat_idx = max_idx[0]  # lat index
    center_lon_idx = max_idx[1]  # lon index

    print(f"   🎯 Storm Center Found at Indices: Lat={center_lat_idx}, Lon={center_lon_idx}")

    # 2. 定义切片范围 (50x50)
    # 确保不越界
    lat_size, lon_size = ref_data.shape
    half_size = 25

    lat_min = max(0, center_lat_idx - half_size)
    lat_max = min(lat_size, center_lat_idx + half_size)
    lon_min = max(0, center_lon_idx - half_size)
    lon_max = min(lon_size, center_lon_idx + half_size)

    # 修正：如果切片不足50，强行向一侧补齐（略）
    print(f"   ✂️ Slicing Region: Lat[{lat_min}:{lat_max}], Lon[{lon_min}:{lon_max}]")

    # 3. 加载并切片风场数据
    print("[2/5] Slicing Wind & Rain Data...")
    ds_wind = xr.open_dataset(file_wind, engine="netcdf4")

    # 统一处理 time/step 维度 (如果有的话就 squeeze 掉)
    if 'step' in ds_wind.dims: ds_wind = ds_wind.isel(step=0)

    # 执行切片
    # 注意：要确保维度名称匹配 (latitude/longitude)
    lat_dim = [d for d in ds_wind.dims if 'lat' in d][0]
    lon_dim = [d for d in ds_wind.dims if 'lon' in d][0]

    ds_wind_sub = ds_wind.isel({lat_dim: slice(lat_min, lat_max), lon_dim: slice(lon_min, lon_max)})
    ds_rain_sub = ds_rain.isel({lat_dim: slice(lat_min, lat_max), lon_dim: slice(lon_min, lon_max)})

    # 如果 rain 还有 step 维度
    if 'step' in ds_rain_sub.dims: ds_rain_sub = ds_rain_sub.isel(step=0)

    # 4. 垂直插值 (Copied from previous script)
    print("[3/5] Interpolating Vertical Layers...")
    z_var = [v for v in ds_wind_sub.data_vars if 'gh' in v.lower() or 'hgt' in v.lower()]
    if z_var:
        z_var = z_var[0]
        # 动态获取气压维度名
        p_dim = [d for d in ds_wind_sub[z_var].dims if 'iso' in d or 'pres' in d or 'lev' in d][0]
        mean_heights = ds_wind_sub[z_var].mean(dim=[lat_dim, lon_dim])
        ds_wind_sub = ds_wind_sub.assign_coords(height=(p_dim, mean_heights.values))
        ds_wind_sub = ds_wind_sub.swap_dims({p_dim: "height"})
    else:
        # Fallback (简略版)
        pass  # 假设一定能找到 GH，否则参考之前脚本

    target_z = np.linspace(0, 2000, 21)
    ds_interp = ds_wind_sub.interp(height=target_z, method="linear")

    # 5. 计算切变与代价
    print("[4/5] Calculating Physics & Risk...")
    u = ds_interp[[v for v in ds_interp.data_vars if 'u' in v.lower()][0]]
    v = ds_interp[[v for v in ds_interp.data_vars if 'v' in v.lower()][0]]
    refc = ds_rain_sub[[v for v in ds_rain_sub.data_vars if 'ref' in v.lower()][0]]

    # 广播雷暴
    refc_3d, _ = xr.broadcast(refc, ds_interp.height)

    # 切变
    dz = 100.0
    shear = np.sqrt((u.diff("height") / dz) ** 2 + (v.diff("height") / dz) ** 2)
    shear = shear.reindex(height=target_z, method="nearest").fillna(0)

    # 代价地图
    cost = xr.ones_like(shear)
    cost = cost.where(shear < 0.05, 100)  # 风切变 = 100

    # 确保 refc_3d 没有 NaN
    refc_3d = refc_3d.fillna(0)
    cost = cost.where(refc_3d < 35, 5000)  # 雷暴 = 5000 (阈值稍微调低点，确保能看到障碍)

    # 6. 保存
    print("[5/5] Saving Processed Data...")
    ds_out = xr.Dataset({
        "travel_cost": cost,
        "refc": refc_3d
    })
    ds_out.to_netcdf(output_file)
    print(f"✅ SUCCESS! Caught a storm at Index ({center_lat_idx}, {center_lon_idx}).")
    print(f"   Max Reflectivity in map: {refc_3d.max().values:.2f} dBZ")


if __name__ == "__main__":
    find_and_process_storm()