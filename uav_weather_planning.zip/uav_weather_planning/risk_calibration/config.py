from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from uav_weather_planning.risk_models import RiskFusionConfig


DEFAULT_THRESHOLDS_PATH = Path("configs/risk_thresholds_reference.yaml")
DEFAULT_FUSION_PATH = Path("configs/risk_fusion_calibrated.yaml")


@dataclass(frozen=True)
class ThresholdEvidence:
    values: dict[str, Any]
    source_path: str
    evidence_note: str = (
        "Thresholds are separated from fusion weights. Thresholds describe when a "
        "meteorological variable becomes unsafe for the reference multirotor task; "
        "fusion weights describe relative route-planning importance and are checked "
        "by calibration and sensitivity experiments."
    )


@dataclass(frozen=True)
class FusionParameterSet:
    weights: dict[str, float]
    planner_weights: dict[str, float] = field(default_factory=dict)
    chance_constraint_limit: float = 0.86
    envelope_probability_limit: float = 0.95
    cvar_alpha: float = 0.90
    cvar_lambda: float = 0.65
    base_cost: float = 1.0
    joint_risk_weight: float = 6.0
    uncertainty_conservative_weight: float = 0.05
    uncertainty_sigma0: float = 0.02
    uncertainty_beta: float = 0.55
    source_path: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_risk_fusion_config(self) -> RiskFusionConfig:
        return RiskFusionConfig(
            weights=dict(self.weights),
            cvar_alpha=float(self.cvar_alpha),
            cvar_lambda=float(self.cvar_lambda),
            base_cost=float(self.base_cost),
            joint_risk_weight=float(self.joint_risk_weight),
            chance_constraint_limit=float(self.chance_constraint_limit),
            envelope_probability_limit=float(self.envelope_probability_limit),
            uncertainty_conservative_weight=float(self.uncertainty_conservative_weight),
            uncertainty_sigma0=float(self.uncertainty_sigma0),
            uncertainty_beta=float(self.uncertainty_beta),
        )


def load_threshold_evidence(path: str | Path = DEFAULT_THRESHOLDS_PATH) -> ThresholdEvidence:
    path = Path(path)
    return ThresholdEvidence(values=load_simple_yaml(path), source_path=str(path))


def load_fusion_parameters(path: str | Path = DEFAULT_FUSION_PATH) -> FusionParameterSet:
    path = Path(path)
    data = load_simple_yaml(path)
    chance = data.get("chance_constraint", {})
    cvar = data.get("cvar", {})
    joint_risk = data.get("joint_risk_kernel", {})
    epistemic_uncertainty = data.get("epistemic_uncertainty", {})
    return FusionParameterSet(
        weights={str(k): float(v) for k, v in data.get("weights", {}).items()},
        planner_weights={str(k): float(v) for k, v in data.get("planner_weights", {}).items()},
        chance_constraint_limit=float(chance.get("violation_probability_limit", 0.86)),
        envelope_probability_limit=float(chance.get("envelope_probability_limit", 0.95)),
        cvar_alpha=float(cvar.get("alpha", 0.90)),
        cvar_lambda=float(cvar.get("lambda", 0.65)),
        base_cost=float(joint_risk.get("base_cost", 1.0)),
        joint_risk_weight=float(joint_risk.get("weight", 6.0)),
        uncertainty_conservative_weight=float(epistemic_uncertainty.get("conservative_weight", 0.05)),
        uncertainty_sigma0=float(epistemic_uncertainty.get("sigma0", 0.02)),
        uncertainty_beta=float(epistemic_uncertainty.get("beta", 0.55)),
        source_path=str(path),
        metadata=dict(data.get("metadata", {})),
    )


def write_fusion_parameters(params: FusionParameterSet, path: str | Path) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    lines = [
        "# Generated calibrated risk-fusion parameters.",
        "weights:",
    ]
    for name, value in params.weights.items():
        lines.append(f"  {name}: {float(value):.6g}")
    lines.append("")
    lines.append("planner_weights:")
    for name, value in params.planner_weights.items():
        lines.append(f"  {name}: {float(value):.6g}")
    lines.extend(
        [
            "",
            "joint_risk_kernel:",
            "  role: expected_cost_main_risk_kernel",
            f"  base_cost: {float(params.base_cost):.6g}",
            f"  weight: {float(params.joint_risk_weight):.6g}",
            "  note: expected_cost = base_cost + weight * noncompensatory joint_risk; weighted_soft_cost is retained as auxiliary evidence.",
            "",
            "epistemic_uncertainty:",
            "  role: distribution_width_modulator",
            f"  conservative_weight: {float(params.uncertainty_conservative_weight):.6g}",
            f"  sigma0: {float(params.uncertainty_sigma0):.6g}",
            f"  beta: {float(params.uncertainty_beta):.6g}",
            "  note: Not treated as a weather hazard weight; it widens Monte Carlo risk samples and adds a small conservative margin.",
            "",
            "chance_constraint:",
            f"  violation_probability_limit: {float(params.chance_constraint_limit):.6g}",
            f"  envelope_probability_limit: {float(params.envelope_probability_limit):.6g}",
            "",
            "cvar:",
            f"  alpha: {float(params.cvar_alpha):.6g}",
            f"  lambda: {float(params.cvar_lambda):.6g}",
            "",
            "metadata:",
        ]
    )
    metadata = params.metadata or {"source": "risk_weight_search"}
    for name, value in metadata.items():
        lines.append(f"  {name}: {value}")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path


def load_simple_yaml(path: str | Path) -> dict[str, Any]:
    """Load the project's simple YAML config without requiring PyYAML."""

    path = Path(path)
    try:
        import yaml  # type: ignore

        data = yaml.safe_load(path.read_text(encoding="utf-8"))
        return data or {}
    except Exception:
        return _parse_simple_yaml(path.read_text(encoding="utf-8"))


def _parse_simple_yaml(text: str) -> dict[str, Any]:
    root: dict[str, Any] = {}
    stack: list[tuple[int, dict[str, Any]]] = [(-1, root)]
    for raw_line in text.splitlines():
        line = raw_line.split("#", 1)[0].rstrip()
        if not line.strip():
            continue
        indent = len(line) - len(line.lstrip(" "))
        stripped = line.strip()
        if ":" not in stripped:
            continue
        key, raw_value = stripped.split(":", 1)
        key = key.strip()
        value_text = raw_value.strip()
        while stack and indent <= stack[-1][0]:
            stack.pop()
        parent = stack[-1][1]
        if value_text == "":
            child: dict[str, Any] = {}
            parent[key] = child
            stack.append((indent, child))
        else:
            parent[key] = _parse_scalar(value_text)
    return root


def _parse_scalar(value: str) -> Any:
    if value.lower() in {"true", "false"}:
        return value.lower() == "true"
    if value.startswith("[") and value.endswith("]"):
        items = [item.strip() for item in value[1:-1].split(",") if item.strip()]
        return [_parse_scalar(item) for item in items]
    try:
        if any(ch in value for ch in (".", "e", "E")):
            return float(value)
        return int(value)
    except ValueError:
        return value.strip("\"'")
