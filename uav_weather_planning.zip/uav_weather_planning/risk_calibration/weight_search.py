from __future__ import annotations

from dataclasses import asdict, dataclass, field
from pathlib import Path
import argparse
import csv
import json
from typing import Any

import numpy as np

from uav_weather_planning.data_interface.weather_cube import WeatherCube
from uav_weather_planning.global_planner import FlightConstraints, TimeDependentAStar, evaluate_path
from uav_weather_planning.risk_field.risk_field_4d import SpatialNode
from uav_weather_planning.risk_models import build_risk_field_from_weather
from uav_weather_planning.weather_simulation import make_multi_risk_weather_cube

from .config import (
    DEFAULT_FUSION_PATH,
    DEFAULT_THRESHOLDS_PATH,
    FusionParameterSet,
    load_fusion_parameters,
    load_threshold_evidence,
    write_fusion_parameters,
)
from .proxy_label import label_path, voxel_proxy_labels, voxel_proxy_probability


PARAMETER_RANGES: dict[str, tuple[float, float]] = {
    "wind_risk": (0.8, 2.5),
    "gust_risk": (0.8, 2.5),
    "shear_turbulence_risk": (1.0, 3.0),
    "convection_risk": (2.0, 5.0),
    "precipitation_risk": (0.8, 2.5),
    "visibility_risk": (0.6, 2.0),
    "cvar_weight": (0.5, 2.5),
    "energy_weight": (0.2, 1.5),
    "corridor_weight": (0.3, 1.5),
    "chance_limit": (0.75, 0.95),
    "uncertainty_conservative_weight": (0.0, 0.12),
    "uncertainty_sigma0": (0.01, 0.05),
    "uncertainty_beta": (0.25, 0.85),
}


CALIBRATION_CORRIDOR_DISCLOSURE = {
    "enabled": True,
    "function": "soften_weather_corridor",
    "scope": "risk-weight calibration cases only",
    "radius_cells": 1,
    "purpose": (
        "Retain a narrow feasible reference corridor so calibration compares how different fusion weights trade "
        "weather risk, CVaR, energy and path length instead of collapsing into all-failed missions."
    ),
    "operation": (
        "Along the start-goal reference line, convective reflectivity, rain rate, convection probability and updraft "
        "are reduced; gust is capped; visibility and ceiling are floored. The corridor is still evaluated by the "
        "risk model and planner metrics, but catastrophic hard blocking is softened for calibration comparability."
    ),
    "claim_boundary": (
        "This is not used as evidence that the planner can always find a path through extreme weather. Hard-blocking "
        "and dynamic closure cases are evaluated separately in benchmark_suite, multi-time real replay, and dynamic "
        "replanning experiments."
    ),
    "defense_statement": (
        "The calibration set keeps a narrow safe corridor only to make weight candidates comparable; extreme "
        "blocking scenarios are reserved for benchmark and dynamic replanning validation."
    ),
}


@dataclass(frozen=True)
class CalibrationCase:
    case_id: str
    split: str
    cube: WeatherCube
    start: SpatialNode
    goal: SpatialNode


@dataclass(frozen=True)
class WeightSearchConfig:
    sample_count: int = 50
    seed: int = 20260611
    case_count: int = 30
    t_size: int = 14
    z_size: int = 2
    y_size: int = 12
    x_size: int = 12
    calibration_fraction: float = 0.60
    validation_fraction: float = 0.20
    min_validation_success_rate: float = 0.50
    threshold_path: str | Path = DEFAULT_THRESHOLDS_PATH
    baseline_fusion_path: str | Path = DEFAULT_FUSION_PATH


@dataclass(frozen=True)
class SearchObjectiveWeights:
    voxel_loss: float = 0.35
    path_loss: float = 0.65
    nofly_intrusion: float = 1200.0
    high_risk_exposure: float = 65.0
    cvar: float = 0.32
    replan_failure: float = 900.0
    normalized_energy: float = 9.0
    normalized_path_length: float = 7.0
    failed_plan: float = 2500.0


def run_weight_search(
    output_dir: str | Path = "outputs/risk_weight_search",
    config: WeightSearchConfig | None = None,
    objective_weights: SearchObjectiveWeights | None = None,
) -> dict[str, Any]:
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    config = config or WeightSearchConfig()
    objective_weights = objective_weights or SearchObjectiveWeights()
    thresholds = load_threshold_evidence(config.threshold_path)
    baseline = load_fusion_parameters(config.baseline_fusion_path)
    cases = make_calibration_cases(config)
    candidates = [baseline] + generate_weight_candidates(config, baseline)

    rows: list[dict[str, Any]] = []
    for index, candidate in enumerate(candidates):
        candidate_id = "baseline" if index == 0 else f"candidate_{index:03d}"
        rows.extend(evaluate_candidate(candidate_id, candidate, cases, thresholds.values, objective_weights))

    aggregate_rows = aggregate_candidate_scores(rows)
    best = select_best_candidate(aggregate_rows, config.min_validation_success_rate)
    best_params = _candidate_from_row(best, candidates)
    write_fusion_parameters(best_params, output_dir / "best_risk_fusion_calibrated.yaml")
    _write_csv(output_dir / "weight_search_trials.csv", rows)
    _write_csv(output_dir / "weight_search_summary.csv", aggregate_rows)
    summary = {
        "protocol": {
            **asdict(config),
            "threshold_path": str(config.threshold_path),
            "baseline_fusion_path": str(config.baseline_fusion_path),
            "parameter_ranges": PARAMETER_RANGES,
            "objective_weights": asdict(objective_weights),
            "case_splits": _split_counts(cases),
            "candidate_count": len(candidates),
        },
        "threshold_evidence": {
            "source_path": thresholds.source_path,
            "note": thresholds.evidence_note,
        },
        "calibration_corridor_disclosure": CALIBRATION_CORRIDOR_DISCLOSURE,
        "best_candidate": best,
        "best_parameters": _params_as_dict(best_params),
        "outputs": [
            "weight_search_trials.csv",
            "weight_search_summary.csv",
            "best_risk_fusion_calibrated.yaml",
            "risk_weight_search_summary.json",
        ],
        "defense_statement": (
            "Thresholds come from reference multirotor/weather danger limits; fusion weights are selected by "
            "safety-first proxy-label calibration and path-level validation, then checked again by sensitivity experiments. "
            "The calibration cases retain a narrow softened corridor only to keep weight candidates comparable; "
            "hard-blocking and dynamic closure behavior is evaluated in the benchmark and replanning experiments."
        ),
    }
    with (output_dir / "risk_weight_search_summary.json").open("w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)
    return summary


def make_calibration_cases(config: WeightSearchConfig) -> list[CalibrationCase]:
    cases: list[CalibrationCase] = []
    for idx in range(config.case_count):
        split = _split_name(idx, config.case_count, config.calibration_fraction, config.validation_fraction)
        intensity = 0.78 + 0.16 * (idx % 5)
        wind_scale = 0.84 + 0.11 * ((idx * 2) % 5)
        precip_scale = 0.70 + 0.13 * ((idx * 3) % 5)
        visibility_drop = 0.10 * (idx % 4)
        cube = make_multi_risk_weather_cube(
            t_size=config.t_size,
            z_size=config.z_size,
            y_size=config.y_size,
            x_size=config.x_size,
            include_dynamic_convection=True,
            include_extreme_tail=idx % 2 == 0,
        )
        cube = perturb_weather_cube(
            cube,
            case_id=f"calib_case_{idx:03d}",
            wind_scale=wind_scale,
            convective_scale=intensity,
            precip_scale=precip_scale,
            visibility_drop_km=visibility_drop,
            time_shift=idx % 3,
        )
        reach = max(3, min(config.t_size - 5, config.y_size - 4, config.x_size - 4, 7))
        start = (0, 1, 1)
        goal = (0, 1 + reach, 1 + reach)
        cube = soften_weather_corridor(cube, start, goal, radius=1)
        cases.append(
            CalibrationCase(
                case_id=f"calib_case_{idx:03d}",
                split=split,
                cube=cube,
                start=start,
                goal=goal,
            )
        )
    return cases


def perturb_weather_cube(
    cube: WeatherCube,
    *,
    case_id: str,
    wind_scale: float,
    convective_scale: float,
    precip_scale: float,
    visibility_drop_km: float,
    time_shift: int,
) -> WeatherCube:
    variables = {name: value.copy() for name, value in cube.variables.items()}
    for name in ("u_wind", "v_wind", "w_wind", "gust"):
        if name in variables:
            variables[name] = variables[name] * wind_scale
    for name in ("reflectivity", "convection_probability", "updraft_speed"):
        if name in variables:
            variables[name] = np.roll(variables[name] * convective_scale, shift=time_shift, axis=0)
    if "rain_rate" in variables:
        variables["rain_rate"] = np.clip(variables["rain_rate"] * precip_scale, 0.0, None)
    if "visibility" in variables:
        variables["visibility"] = np.clip(variables["visibility"] - visibility_drop_km, 0.2, None)
    if "ceiling" in variables:
        variables["ceiling"] = np.clip(variables["ceiling"] - 55.0 * visibility_drop_km, 50.0, None)
    metadata = {
        **cube.source_metadata,
        "case_id": case_id,
        "calibration_perturbation": {
            "wind_scale": wind_scale,
            "convective_scale": convective_scale,
            "precip_scale": precip_scale,
            "visibility_drop_km": visibility_drop_km,
            "time_shift": time_shift,
        },
    }
    return WeatherCube(
        time=cube.time.copy(),
        height=cube.height.copy(),
        y=cube.y.copy(),
        x=cube.x.copy(),
        variables=variables,
        source_metadata=metadata,
        confidence=cube.confidence.copy() if isinstance(cube.confidence, np.ndarray) else cube.confidence,
    )


def soften_weather_corridor(cube: WeatherCube, start: SpatialNode, goal: SpatialNode, radius: int = 1) -> WeatherCube:
    variables = {name: value.copy() for name, value in cube.variables.items()}
    _, y0, x0 = start
    _, y1, x1 = goal
    steps = max(abs(y1 - y0), abs(x1 - x0), 1) + 1
    ys = np.linspace(y0, y1, steps).round().astype(int)
    xs = np.linspace(x0, x1, steps).round().astype(int)
    for y, x in zip(ys, xs):
        y_slice = slice(max(0, y - radius), min(cube.shape[2], y + radius + 1))
        x_slice = slice(max(0, x - radius), min(cube.shape[3], x + radius + 1))
        for name in ("reflectivity", "rain_rate", "convection_probability", "updraft_speed"):
            if name in variables:
                variables[name][:, :, y_slice, x_slice] *= 0.35
        if "gust" in variables:
            variables["gust"][:, :, y_slice, x_slice] = np.minimum(variables["gust"][:, :, y_slice, x_slice], 8.0)
        if "visibility" in variables:
            variables["visibility"][:, :, y_slice, x_slice] = np.maximum(variables["visibility"][:, :, y_slice, x_slice], 6.0)
        if "ceiling" in variables:
            variables["ceiling"][:, :, y_slice, x_slice] = np.maximum(variables["ceiling"][:, :, y_slice, x_slice], 350.0)
    metadata = {
        **cube.source_metadata,
        "calibration_corridor_policy": CALIBRATION_CORRIDOR_DISCLOSURE,
        "calibration_corridor_note": CALIBRATION_CORRIDOR_DISCLOSURE["defense_statement"],
    }
    return WeatherCube(
        time=cube.time.copy(),
        height=cube.height.copy(),
        y=cube.y.copy(),
        x=cube.x.copy(),
        variables=variables,
        source_metadata=metadata,
        confidence=cube.confidence.copy() if isinstance(cube.confidence, np.ndarray) else cube.confidence,
    )


def generate_weight_candidates(config: WeightSearchConfig, baseline: FusionParameterSet) -> list[FusionParameterSet]:
    rng = np.random.default_rng(config.seed)
    samples = _latin_hypercube(len(PARAMETER_RANGES), config.sample_count, rng)
    names = list(PARAMETER_RANGES)
    candidates: list[FusionParameterSet] = []
    for row in samples:
        sampled = {}
        for idx, name in enumerate(names):
            low, high = PARAMETER_RANGES[name]
            sampled[name] = float(low + row[idx] * (high - low))
        weights = dict(baseline.weights)
        for name in [
            "wind_risk",
            "gust_risk",
            "shear_turbulence_risk",
            "convection_risk",
            "precipitation_risk",
            "visibility_risk",
        ]:
            weights[name] = sampled[name]
        planner_weights = dict(baseline.planner_weights)
        planner_weights["cvar_weight"] = sampled["cvar_weight"]
        planner_weights["energy_weight"] = sampled["energy_weight"]
        planner_weights["corridor_weight"] = sampled["corridor_weight"]
        candidates.append(
            FusionParameterSet(
                weights=weights,
                planner_weights=planner_weights,
                chance_constraint_limit=sampled["chance_limit"],
                envelope_probability_limit=baseline.envelope_probability_limit,
                cvar_alpha=baseline.cvar_alpha,
                cvar_lambda=baseline.cvar_lambda,
                base_cost=baseline.base_cost,
                joint_risk_weight=baseline.joint_risk_weight,
                uncertainty_conservative_weight=sampled["uncertainty_conservative_weight"],
                uncertainty_sigma0=sampled["uncertainty_sigma0"],
                uncertainty_beta=sampled["uncertainty_beta"],
                source_path="latin_hypercube_weight_search",
                metadata={
                    "source": "risk_weight_search",
                    "seed": config.seed,
                    "sample_count": config.sample_count,
                    "uncertainty_role": "epistemic_distribution_width_modulator",
                },
            )
        )
    return candidates


def evaluate_candidate(
    candidate_id: str,
    params: FusionParameterSet,
    cases: list[CalibrationCase],
    thresholds: dict[str, Any],
    objective_weights: SearchObjectiveWeights,
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    constraints = FlightConstraints(max_horizontal_step_cells=1.5, max_vertical_step_layers=1, max_turn_angle_deg=135.0)
    for case in cases:
        risk_config = params.to_risk_fusion_config()
        risk_config.thresholds = thresholds
        risk_field = build_risk_field_from_weather(case.cube, risk_config)
        y_binary = voxel_proxy_labels(case.cube, risk_field, thresholds)
        y_soft = voxel_proxy_probability(case.cube, thresholds)
        prediction = np.clip(risk_field.violation_probability, 0.0, 1.0)
        voxel_brier = float(np.mean((prediction - y_binary) ** 2))
        voxel_soft_brier = float(np.mean((prediction - y_soft) ** 2))
        planner = TimeDependentAStar(
            risk_field,
            use_cvar=True,
            cvar_weight=float(params.planner_weights.get("cvar_weight", 0.55)),
            energy_weight=float(params.planner_weights.get("energy_weight", 0.35)),
            constraints=constraints,
        )
        result = planner.plan(case.start, case.goal)
        metrics = evaluate_path(
            candidate_id,
            result.path,
            risk_field,
            nodes_expanded=result.nodes_expanded,
            elapsed_ms=result.elapsed_ms,
            constraints=constraints,
        ).as_row()
        proxy = label_path(result.path, risk_field, metrics)
        path_loss = path_level_loss(metrics, proxy, result.success, objective_weights)
        total_loss = objective_weights.voxel_loss * voxel_brier + objective_weights.path_loss * path_loss
        rows.append(
            {
                "candidate_id": candidate_id,
                "case_id": case.case_id,
                "split": case.split,
                "voxel_brier": round(voxel_brier, 6),
                "voxel_soft_brier": round(voxel_soft_brier, 6),
                "path_loss": round(path_loss, 6),
                "total_loss": round(total_loss, 6),
                "planner_success": bool(result.success and metrics["success"]),
                "path_label": proxy.label,
                "nofly_intrusions": proxy.nofly_intrusions,
                "high_risk_exposure_time": proxy.high_risk_exposure_time,
                "cumulative_cvar": proxy.cumulative_cvar,
                "normalized_path_length": proxy.normalized_path_length,
                "normalized_energy": proxy.normalized_energy,
                "nodes_expanded": result.nodes_expanded,
                "elapsed_ms": round(result.elapsed_ms, 3),
                "path_length": metrics["path_length"],
                "geometric_length": metrics["geometric_length"],
                "expected_risk": metrics["expected_risk"],
                "cvar_risk": metrics["cvar_risk"],
                "total_cost": metrics["total_cost"],
                "chance_limit": round(params.chance_constraint_limit, 6),
                "uncertainty_conservative_weight": round(params.uncertainty_conservative_weight, 6),
                "uncertainty_sigma0": round(params.uncertainty_sigma0, 6),
                "uncertainty_beta": round(params.uncertainty_beta, 6),
                "base_cost": round(params.base_cost, 6),
                "joint_risk_weight": round(params.joint_risk_weight, 6),
                **{f"w_{name}": round(value, 6) for name, value in params.weights.items()},
                **{f"planner_{name}": round(value, 6) for name, value in params.planner_weights.items()},
            }
        )
    return rows


def path_level_loss(
    metrics: dict[str, Any],
    proxy: Any,
    planner_success: bool,
    weights: SearchObjectiveWeights,
) -> float:
    if not planner_success:
        return weights.failed_plan
    return float(
        weights.nofly_intrusion * proxy.nofly_intrusions
        + weights.high_risk_exposure * proxy.high_risk_exposure_time
        + weights.cvar * proxy.cumulative_cvar
        + weights.replan_failure * proxy.replan_failures
        + weights.normalized_energy * proxy.normalized_energy
        + weights.normalized_path_length * proxy.normalized_path_length
    )


def aggregate_candidate_scores(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    grouped: dict[str, list[dict[str, Any]]] = {}
    for row in rows:
        grouped.setdefault(str(row["candidate_id"]), []).append(row)
    out: list[dict[str, Any]] = []
    for candidate_id, group in grouped.items():
        row: dict[str, Any] = {"candidate_id": candidate_id}
        all_splits = sorted(set(str(item["split"]) for item in group))
        for split in all_splits + ["all"]:
            subset = group if split == "all" else [item for item in group if item["split"] == split]
            if not subset:
                continue
            prefix = f"{split}_"
            row[prefix + "case_count"] = len(subset)
            row[prefix + "success_rate"] = round(float(np.mean([bool(item["planner_success"]) for item in subset])), 6)
            for name in ["voxel_brier", "voxel_soft_brier", "path_loss", "total_loss", "nofly_intrusions", "cumulative_cvar", "normalized_path_length", "normalized_energy"]:
                row[prefix + name + "_mean"] = _finite_mean([item.get(name) for item in subset])
        first = group[0]
        for key, value in first.items():
            if (
                key.startswith("w_")
                or key.startswith("planner_")
                or key == "chance_limit"
                or key.startswith("uncertainty_")
                or key in {"base_cost", "joint_risk_weight"}
            ):
                row[key] = value
        out.append(row)
    out.sort(key=lambda item: (_score_value(item.get("validation_total_loss_mean", item.get("all_total_loss_mean"))), str(item["candidate_id"])))
    return out


def _finite_mean(values: list[Any]) -> float | None:
    numeric = []
    for value in values:
        try:
            item = float(value)
        except (TypeError, ValueError):
            continue
        if np.isfinite(item):
            numeric.append(item)
    return round(float(np.mean(numeric)), 6) if numeric else None


def select_best_candidate(rows: list[dict[str, Any]], min_validation_success_rate: float) -> dict[str, Any]:
    eligible = [
        row
        for row in rows
        if float(row.get("validation_success_rate", row.get("all_success_rate", 0.0))) >= min_validation_success_rate
    ]
    pool = eligible or rows
    return min(
        pool,
        key=lambda item: (
            _score_value(item.get("validation_total_loss_mean", item.get("all_total_loss_mean"))),
            _score_value(item.get("validation_nofly_intrusions_mean", item.get("all_nofly_intrusions_mean"))),
            _score_value(item.get("validation_cumulative_cvar_mean", item.get("all_cumulative_cvar_mean"))),
        ),
    )


def _score_value(value: Any) -> float:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return float("inf")
    return result if np.isfinite(result) else float("inf")


def _candidate_from_row(row: dict[str, Any], candidates: list[FusionParameterSet]) -> FusionParameterSet:
    candidate_id = str(row["candidate_id"])
    if candidate_id == "baseline":
        params = candidates[0]
    else:
        params = candidates[int(candidate_id.split("_")[-1])]
    return FusionParameterSet(
        weights=dict(params.weights),
        planner_weights=dict(params.planner_weights),
        chance_constraint_limit=float(params.chance_constraint_limit),
        envelope_probability_limit=float(params.envelope_probability_limit),
        cvar_alpha=float(params.cvar_alpha),
        cvar_lambda=float(params.cvar_lambda),
        base_cost=float(params.base_cost),
        joint_risk_weight=float(params.joint_risk_weight),
        uncertainty_conservative_weight=float(params.uncertainty_conservative_weight),
        uncertainty_sigma0=float(params.uncertainty_sigma0),
        uncertainty_beta=float(params.uncertainty_beta),
        source_path=params.source_path,
        metadata={
            **params.metadata,
            "selected_candidate_id": candidate_id,
            "selection_metric": "minimum validation total loss subject to validation success-rate constraint",
        },
    )


def _latin_hypercube(dimensions: int, sample_count: int, rng: np.random.Generator) -> np.ndarray:
    result = np.zeros((sample_count, dimensions), dtype=float)
    for dim in range(dimensions):
        bins = (np.arange(sample_count) + rng.random(sample_count)) / max(sample_count, 1)
        rng.shuffle(bins)
        result[:, dim] = bins
    return result


def _split_name(index: int, total: int, calibration_fraction: float, validation_fraction: float) -> str:
    calibration_end = max(1, int(round(total * calibration_fraction)))
    validation_end = min(total, calibration_end + max(1, int(round(total * validation_fraction))))
    if index < calibration_end:
        return "calibration"
    if index < validation_end:
        return "validation"
    return "test"


def _split_counts(cases: list[CalibrationCase]) -> dict[str, int]:
    counts: dict[str, int] = {}
    for case in cases:
        counts[case.split] = counts.get(case.split, 0) + 1
    return counts


def _params_as_dict(params: FusionParameterSet) -> dict[str, Any]:
    return {
        "weights": params.weights,
        "planner_weights": params.planner_weights,
        "chance_constraint_limit": params.chance_constraint_limit,
        "envelope_probability_limit": params.envelope_probability_limit,
        "cvar_alpha": params.cvar_alpha,
        "cvar_lambda": params.cvar_lambda,
        "base_cost": params.base_cost,
        "joint_risk_weight": params.joint_risk_weight,
        "uncertainty_conservative_weight": params.uncertainty_conservative_weight,
        "uncertainty_sigma0": params.uncertainty_sigma0,
        "uncertainty_beta": params.uncertainty_beta,
        "source_path": params.source_path,
        "metadata": params.metadata,
    }


def _write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        rows = [{"empty": True}]
    fieldnames: list[str] = []
    for row in rows:
        for key in row:
            if key not in fieldnames:
                fieldnames.append(key)
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", default="outputs/risk_weight_search")
    parser.add_argument("--sample-count", type=int, default=50)
    parser.add_argument("--case-count", type=int, default=30)
    parser.add_argument("--seed", type=int, default=20260611)
    parser.add_argument("--t-size", type=int, default=14)
    parser.add_argument("--y-size", type=int, default=12)
    parser.add_argument("--x-size", type=int, default=12)
    args = parser.parse_args()
    summary = run_weight_search(
        args.output_dir,
        WeightSearchConfig(
            sample_count=args.sample_count,
            case_count=args.case_count,
            seed=args.seed,
            t_size=args.t_size,
            y_size=args.y_size,
            x_size=args.x_size,
        ),
    )
    print("Risk weight search finished.")
    print(f"Outputs: {args.output_dir}")
    print(json.dumps({"best_candidate": summary["best_candidate"]}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
