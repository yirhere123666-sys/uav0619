from __future__ import annotations

from dataclasses import asdict, dataclass
import json
from pathlib import Path
from typing import Any

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from uav_weather_planning.data_interface.weather_cube import WeatherCube
from uav_weather_planning.risk_field import RiskField4D


matplotlib.rcParams["font.sans-serif"] = [
    "Microsoft YaHei",
    "SimHei",
    "SimSun",
    "KaiTi",
    "Arial Unicode MS",
    "DejaVu Sans",
]
matplotlib.rcParams["axes.unicode_minus"] = False


CHANNEL_LABELS = {
    "wind_risk": "风场风险",
    "gust_risk": "阵风风险",
    "shear_turbulence_risk": "风切变/湍流风险",
    "convection_risk": "对流/雷暴风险",
    "precipitation_risk": "降水风险",
    "visibility_risk": "低能见度/低云底风险",
    "violation_probability": "综合违反概率",
}


@dataclass
class CalibrationBin:
    bin_left: float
    bin_right: float
    count: int
    mean_prediction: float
    mean_proxy_probability: float
    absolute_gap: float


@dataclass
class CalibrationResult:
    channel: str
    sample_count: int
    brier_score: float
    mean_absolute_error: float
    expected_calibration_error: float
    correlation: float
    prediction_mean: float
    prediction_p95: float
    proxy_mean: float
    proxy_p95: float
    bins: list[CalibrationBin]

    def as_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["bins"] = [asdict(item) for item in self.bins]
        return payload


def build_calibration_evidence(
    cube: WeatherCube,
    risk_field: RiskField4D,
    n_bins: int = 10,
) -> dict[str, Any]:
    """Build calibration evidence from weather proxy hazards and risk channels."""

    proxy_labels = proxy_hazard_labels(cube)
    predictions = {
        "wind_risk": risk_field.wind_risk,
        "gust_risk": risk_field.gust_risk,
        "shear_turbulence_risk": risk_field.shear_turbulence_risk,
        "convection_risk": risk_field.convection_risk,
        "precipitation_risk": risk_field.precipitation_risk,
        "visibility_risk": risk_field.visibility_risk,
        "violation_probability": risk_field.violation_probability,
    }
    results = {}
    for channel, prediction in predictions.items():
        if channel not in proxy_labels:
            continue
        result = calibrate_channel(prediction, proxy_labels[channel], n_bins=n_bins)
        result.channel = channel
        results[channel] = result.as_dict()

    return {
        "evidence_type": "proxy-label calibration from real weather variables",
        "calibration_basis": {
            "description": "代理标签由真实/回放气象变量经过独立物理风险函数得到，用于检查风险通道是否与危险天气代理一致。",
            "limitations": "这不是实飞事故标签校准；当前用于中期阶段证明风险映射具备数据证据链。后续可替换为历史运行事件、人工标注或集合预报误差标签。",
            "bin_count": n_bins,
        },
        "source_metadata": cube.source_metadata,
        "weather_shape": list(cube.shape),
        "risk_shape": list(risk_field.shape),
        "sample_count_per_channel": int(np.prod(risk_field.shape)),
        "channels": results,
    }


def calibrate_channel(prediction: np.ndarray, proxy_probability: np.ndarray, n_bins: int = 10) -> CalibrationResult:
    pred = np.asarray(prediction, dtype=float).reshape(-1)
    proxy = np.asarray(proxy_probability, dtype=float).reshape(-1)
    valid = np.isfinite(pred) & np.isfinite(proxy)
    pred = np.clip(pred[valid], 0.0, 1.0)
    proxy = np.clip(proxy[valid], 0.0, 1.0)
    if pred.size == 0:
        raise ValueError("empty calibration channel")

    edges = np.linspace(0.0, 1.0, n_bins + 1)
    bins: list[CalibrationBin] = []
    ece = 0.0
    for i in range(n_bins):
        left, right = float(edges[i]), float(edges[i + 1])
        if i == n_bins - 1:
            mask = (pred >= left) & (pred <= right)
        else:
            mask = (pred >= left) & (pred < right)
        count = int(np.sum(mask))
        if count == 0:
            mean_pred = 0.0
            mean_proxy = 0.0
            gap = 0.0
        else:
            mean_pred = float(np.mean(pred[mask]))
            mean_proxy = float(np.mean(proxy[mask]))
            gap = abs(mean_pred - mean_proxy)
            ece += gap * count / pred.size
        bins.append(
            CalibrationBin(
                bin_left=left,
                bin_right=right,
                count=count,
                mean_prediction=round(mean_pred, 6),
                mean_proxy_probability=round(mean_proxy, 6),
                absolute_gap=round(gap, 6),
            )
        )

    if np.std(pred) < 1e-12 or np.std(proxy) < 1e-12:
        correlation = 0.0
    else:
        correlation = float(np.corrcoef(pred, proxy)[0, 1])

    return CalibrationResult(
        channel="",
        sample_count=int(pred.size),
        brier_score=round(float(np.mean((pred - proxy) ** 2)), 6),
        mean_absolute_error=round(float(np.mean(np.abs(pred - proxy))), 6),
        expected_calibration_error=round(float(ece), 6),
        correlation=round(correlation, 6),
        prediction_mean=round(float(np.mean(pred)), 6),
        prediction_p95=round(float(np.percentile(pred, 95)), 6),
        proxy_mean=round(float(np.mean(proxy)), 6),
        proxy_p95=round(float(np.percentile(proxy, 95)), 6),
        bins=bins,
    )


def proxy_hazard_labels(cube: WeatherCube) -> dict[str, np.ndarray]:
    u = cube.get("u_wind")
    v = cube.get("v_wind")
    w = cube.get("w_wind")
    speed = np.sqrt(u * u + v * v + w * w)
    crosswind = np.sqrt(v * v + w * w)
    vertical = np.abs(w)
    wind_proxy = clip01(0.46 * sigmoid((speed - 10.0) / 2.8) + 0.36 * sigmoid((crosswind - 7.0) / 2.0) + 0.18 * sigmoid((vertical - 2.0) / 0.8))

    gust = cube.get("gust")
    gust_proxy = sigmoid((gust - 12.0) / 2.5)

    shear_proxy = _shear_proxy(cube)

    reflectivity = cube.get("reflectivity")
    convection_probability = cube.get("convection_probability")
    convection_proxy = clip01(np.maximum(sigmoid((reflectivity - 35.0) / 5.5), convection_probability))

    rain_rate = cube.get("rain_rate")
    precipitation_proxy = sigmoid((rain_rate - 14.0) / 4.5)

    visibility = cube.get("visibility", default=8.0)
    ceiling = cube.get("ceiling", default=600.0)
    relative_humidity = cube.get("relative_humidity", default=60.0)
    cloud_liquid_water = cube.get("cloud_liquid_water", default=0.0)
    visibility_proxy = clip01(
        0.42 * sigmoid((2.5 - visibility) / 0.7)
        + 0.28 * sigmoid((180.0 - ceiling) / 45.0)
        + 0.18 * sigmoid((relative_humidity - 90.0) / 5.0)
        + 0.12 * sigmoid((cloud_liquid_water - 0.55) / 0.18)
    )

    combined = clip01(
        0.20 * wind_proxy
        + 0.15 * gust_proxy
        + 0.15 * shear_proxy
        + 0.22 * convection_proxy
        + 0.12 * precipitation_proxy
        + 0.16 * visibility_proxy
    )
    return {
        "wind_risk": wind_proxy,
        "gust_risk": gust_proxy,
        "shear_turbulence_risk": shear_proxy,
        "convection_risk": convection_proxy,
        "precipitation_risk": precipitation_proxy,
        "visibility_risk": visibility_proxy,
        "violation_probability": combined,
    }


def write_calibration_report(evidence: dict[str, Any], output_path: str | Path) -> Path:
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w", encoding="utf-8") as f:
        json.dump(evidence, f, ensure_ascii=False, indent=2)
    return output_path


def plot_calibration_curves(evidence: dict[str, Any], output_path: str | Path) -> None:
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    channels = list(evidence["channels"].items())
    rows = 2
    cols = 4
    fig, axes = plt.subplots(rows, cols, figsize=(15, 7.4))
    for ax, (channel, result) in zip(axes.ravel(), channels):
        bins = result["bins"]
        x = [item["mean_prediction"] for item in bins if item["count"] > 0]
        y = [item["mean_proxy_probability"] for item in bins if item["count"] > 0]
        sizes = [max(20, item["count"] / max(result["sample_count"], 1) * 3000) for item in bins if item["count"] > 0]
        ax.plot([0, 1], [0, 1], color="gray", linestyle="--", linewidth=1.0, label="理想校准")
        ax.scatter(x, y, s=sizes, alpha=0.75, color="tab:blue", edgecolors="black", linewidths=0.4)
        ax.plot(x, y, color="tab:blue", linewidth=1.2)
        ax.set_title(f"{CHANNEL_LABELS.get(channel, channel)}\nECE={result['expected_calibration_error']}, MAE={result['mean_absolute_error']}")
        ax.set_xlabel("预测风险")
        ax.set_ylabel("代理危险概率")
        ax.set_xlim(0, 1)
        ax.set_ylim(0, 1)
        ax.grid(alpha=0.25)
    for ax in axes.ravel()[len(channels):]:
        ax.axis("off")
    fig.suptitle("风险通道概率校准曲线（点大小表示样本数）")
    fig.tight_layout()
    fig.savefig(output_path, dpi=170)
    plt.close(fig)


def plot_calibration_histograms(evidence: dict[str, Any], output_path: str | Path) -> None:
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    channels = list(evidence["channels"].items())
    fig, axes = plt.subplots(2, 4, figsize=(15, 7))
    for ax, (channel, result) in zip(axes.ravel(), channels):
        bins = result["bins"]
        centers = [(item["bin_left"] + item["bin_right"]) / 2.0 for item in bins]
        counts = [item["count"] for item in bins]
        ax.bar(centers, counts, width=0.085, color="tab:green", alpha=0.8)
        ax.set_title(CHANNEL_LABELS.get(channel, channel))
        ax.set_xlabel("预测风险分箱")
        ax.set_ylabel("样本数")
        ax.grid(axis="y", alpha=0.25)
    for ax in axes.ravel()[len(channels):]:
        ax.axis("off")
    fig.suptitle("风险通道样本分布证据")
    fig.tight_layout()
    fig.savefig(output_path, dpi=170)
    plt.close(fig)


def sigmoid(value: np.ndarray) -> np.ndarray:
    return 1.0 / (1.0 + np.exp(-value))


def clip01(value: np.ndarray) -> np.ndarray:
    return np.clip(value, 0.0, 1.0)


def _shear_proxy(cube: WeatherCube) -> np.ndarray:
    u = cube.get("u_wind")
    v = cube.get("v_wind")
    dz = float(np.mean(np.diff(cube.height))) if len(cube.height) > 1 else 100.0
    dy = float(np.mean(np.diff(cube.y))) if len(cube.y) > 1 else 1.0
    dx = float(np.mean(np.diff(cube.x))) if len(cube.x) > 1 else 1.0
    du_dz = _gradient(u, axis=1, spacing=max(abs(dz), 1.0))
    dv_dz = _gradient(v, axis=1, spacing=max(abs(dz), 1.0))
    du_dx = _gradient(u, axis=3, spacing=max(abs(dx), 1.0))
    du_dy = _gradient(u, axis=2, spacing=max(abs(dy), 1.0))
    dv_dx = _gradient(v, axis=3, spacing=max(abs(dx), 1.0))
    dv_dy = _gradient(v, axis=2, spacing=max(abs(dy), 1.0))
    vertical_shear = np.sqrt(du_dz * du_dz + dv_dz * dv_dz)
    horizontal_gradient = np.sqrt(du_dx**2 + du_dy**2 + dv_dx**2 + dv_dy**2)
    return clip01(0.55 * sigmoid((vertical_shear - 0.025) / 0.008) + 0.45 * sigmoid((horizontal_gradient - 0.22) / 0.08))


def _gradient(arr: np.ndarray, axis: int, spacing: float) -> np.ndarray:
    if arr.shape[axis] <= 1:
        return np.zeros_like(arr)
    return np.gradient(arr, spacing, axis=axis, edge_order=1)
