from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any

import numpy as np

from uav_weather_planning.data_interface.weather_cube import WeatherCube
from uav_weather_planning.risk_field import RiskField4D
from uav_weather_planning.risk_field.risk_field_4d import State4D

from .config import ThresholdEvidence, load_threshold_evidence


@dataclass(frozen=True)
class PathProxyLabel:
    label: str
    unsafe: bool
    inefficient: bool
    nofly_intrusions: int
    cumulative_cvar: float
    high_risk_exposure_time: int
    normalized_path_length: float
    normalized_energy: float
    replan_failures: int

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


def voxel_proxy_labels(
    cube: WeatherCube,
    risk_field: RiskField4D | None = None,
    thresholds: ThresholdEvidence | dict[str, Any] | None = None,
) -> np.ndarray:
    """Return binary proxy labels for unsafe weather voxels.

    These labels are not accident labels. They mark threshold-exceeding weather
    states used to calibrate whether violation_probability tracks obvious
    danger patterns.
    """

    values = _threshold_values(thresholds)
    u = cube.get("u_wind")
    v = cube.get("v_wind")
    w = cube.get("w_wind")
    speed = np.sqrt(u * u + v * v + w * w)
    crosswind = np.sqrt(v * v + w * w)
    gust = cube.get("gust")
    reflectivity = cube.get("reflectivity")
    convection_probability = cube.get("convection_probability")
    rain_rate = cube.get("rain_rate")
    visibility_m = _visibility_m(cube.get("visibility", default=8.0))
    shear = vertical_shear_proxy(cube)

    wind_danger = _get(values, "wind", "danger_mps", 12.0)
    crosswind_danger = _get(values, "crosswind", "danger_mps", 10.0)
    gust_danger = _get(values, "gust", "danger_mps", 14.0)
    shear_danger = _get(values, "vertical_shear", "danger", 0.10)
    precip_danger = _get(values, "precipitation", "danger_mm_h", 10.0)
    visibility_danger = _get(values, "visibility", "danger_m", 1000.0)
    reflectivity_danger = _get(values, "convection", "reflectivity_danger_dbz", 40.0)
    convection_hard_probability = _get(values, "convection", "probability_hard", 0.85)

    labels = (
        (speed >= wind_danger)
        | (crosswind >= crosswind_danger)
        | (gust >= gust_danger)
        | (shear >= shear_danger)
        | (rain_rate >= precip_danger)
        | (visibility_m <= visibility_danger)
        | (reflectivity >= reflectivity_danger)
        | (convection_probability >= convection_hard_probability)
    )
    if risk_field is not None:
        labels = labels | risk_field.no_fly_mask
    return labels.astype(float)


def voxel_proxy_probability(
    cube: WeatherCube,
    thresholds: ThresholdEvidence | dict[str, Any] | None = None,
) -> np.ndarray:
    """Soft proxy probability used for Brier-score calibration evidence."""

    values = _threshold_values(thresholds)
    u = cube.get("u_wind")
    v = cube.get("v_wind")
    w = cube.get("w_wind")
    speed = np.sqrt(u * u + v * v + w * w)
    crosswind = np.sqrt(v * v + w * w)
    gust = cube.get("gust")
    reflectivity = cube.get("reflectivity")
    convection_probability = cube.get("convection_probability")
    rain_rate = cube.get("rain_rate")
    visibility_m = _visibility_m(cube.get("visibility", default=8.0))
    shear = vertical_shear_proxy(cube)

    wind = _soft_interval(speed, _get(values, "wind", "safe_mps", 5.0), _get(values, "wind", "danger_mps", 12.0))
    cross = _soft_interval(crosswind, _get(values, "crosswind", "safe_mps", 4.0), _get(values, "crosswind", "danger_mps", 10.0))
    gust_p = _soft_interval(gust, _get(values, "gust", "safe_mps", 8.0), _get(values, "gust", "danger_mps", 14.0))
    shear_p = _soft_interval(shear, _get(values, "vertical_shear", "safe", 0.03), _get(values, "vertical_shear", "danger", 0.10))
    precip = _soft_interval(rain_rate, _get(values, "precipitation", "safe_mm_h", 0.5), _get(values, "precipitation", "danger_mm_h", 10.0))
    vis = _soft_interval(
        _get(values, "visibility", "safe_m", 5000.0) - visibility_m,
        0.0,
        _get(values, "visibility", "safe_m", 5000.0) - _get(values, "visibility", "danger_m", 1000.0),
    )
    conv = np.maximum(
        _soft_interval(
            reflectivity,
            _get(values, "convection", "reflectivity_safe_dbz", 25.0),
            _get(values, "convection", "reflectivity_danger_dbz", 40.0),
        ),
        convection_probability,
    )
    return np.clip(
        0.16 * wind
        + 0.10 * cross
        + 0.14 * gust_p
        + 0.15 * shear_p
        + 0.20 * conv
        + 0.11 * precip
        + 0.14 * vis,
        0.0,
        1.0,
    )


def label_path(
    path: list[State4D],
    risk_field: RiskField4D,
    metrics_row: dict[str, Any],
    *,
    cvar_limit: float | None = None,
    high_risk_limit: float = 0.75,
    inefficient_length_ratio: float = 1.8,
    energy_margin_kj: float | None = None,
    replan_failures: int = 0,
) -> PathProxyLabel:
    if not path:
        return PathProxyLabel("unsafe", True, False, 1, 1e6, 0, 1e3, 1e3, replan_failures)
    nofly_intrusions = int(metrics_row.get("no_fly_violations", 0) or 0)
    cumulative_cvar = float(metrics_row.get("cvar_risk", 0.0) or 0.0)
    cumulative_energy = float(metrics_row.get("cumulative_energy_kj", 0.0) or 0.0)
    geometric_length = float(metrics_row.get("geometric_length", 0.0) or 0.0)
    direct_distance = _direct_grid_distance(path[0], path[-1])
    normalized_path_length = geometric_length / max(direct_distance, 1.0)
    normalized_energy = cumulative_energy / max(energy_margin_kj or max(cumulative_energy, 1.0), 1.0)
    high_risk_exposure_time = 0
    for state in path:
        t, z, y, x = state
        t = risk_field.clamp_time(t)
        if float(risk_field.violation_probability[t, z, y, x]) >= high_risk_limit:
            high_risk_exposure_time += 1
    cvar_limit = cvar_limit if cvar_limit is not None else 4.5 * max(len(path), 1)
    unsafe = nofly_intrusions > 0 or cumulative_cvar > cvar_limit or high_risk_exposure_time > max(2, 0.25 * len(path)) or replan_failures > 0
    inefficient = (not unsafe) and (normalized_path_length > inefficient_length_ratio or normalized_energy > 1.0)
    label = "unsafe" if unsafe else "inefficient" if inefficient else "success"
    return PathProxyLabel(
        label=label,
        unsafe=unsafe,
        inefficient=inefficient,
        nofly_intrusions=nofly_intrusions,
        cumulative_cvar=round(cumulative_cvar, 6),
        high_risk_exposure_time=int(high_risk_exposure_time),
        normalized_path_length=round(float(normalized_path_length), 6),
        normalized_energy=round(float(normalized_energy), 6),
        replan_failures=int(replan_failures),
    )


def vertical_shear_proxy(cube: WeatherCube) -> np.ndarray:
    u = cube.get("u_wind")
    v = cube.get("v_wind")
    dz = float(np.mean(np.diff(cube.height))) if len(cube.height) > 1 else 100.0
    du_dz = _gradient(u, axis=1, spacing=max(abs(dz), 1.0))
    dv_dz = _gradient(v, axis=1, spacing=max(abs(dz), 1.0))
    return np.sqrt(du_dz * du_dz + dv_dz * dv_dz)


def _threshold_values(thresholds: ThresholdEvidence | dict[str, Any] | None) -> dict[str, Any]:
    if thresholds is None:
        return load_threshold_evidence().values
    if isinstance(thresholds, ThresholdEvidence):
        return thresholds.values
    return thresholds


def _get(values: dict[str, Any], section: str, key: str, default: float) -> float:
    return float(values.get(section, {}).get(key, default))


def _visibility_m(visibility: np.ndarray) -> np.ndarray:
    visibility = np.asarray(visibility, dtype=float)
    finite = visibility[np.isfinite(visibility)]
    if finite.size and float(np.nanmedian(finite)) <= 50.0:
        return visibility * 1000.0
    return visibility


def _soft_interval(value: np.ndarray, safe: float, danger: float) -> np.ndarray:
    width = max(abs(danger - safe), 1e-6)
    return np.clip((value - safe) / width, 0.0, 1.0)


def _gradient(arr: np.ndarray, axis: int, spacing: float) -> np.ndarray:
    if arr.shape[axis] <= 1:
        return np.zeros_like(arr)
    return np.gradient(arr, spacing, axis=axis, edge_order=1)


def _direct_grid_distance(a: State4D, b: State4D) -> float:
    return float(np.sqrt((b[1] - a[1]) ** 2 + (b[2] - a[2]) ** 2 + (b[3] - a[3]) ** 2))
