from __future__ import annotations

from io import BytesIO
from pathlib import Path

import imageio.v2 as imageio
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from uav_weather_planning.global_planner.metrics import PathMetrics
from uav_weather_planning.global_planner.replanner import ReplanEvent
from uav_weather_planning.risk_field import RiskField4D
from uav_weather_planning.risk_field.risk_field_4d import State4D


matplotlib.rcParams["font.sans-serif"] = [
    "Microsoft YaHei",
    "SimHei",
    "SimSun",
    "KaiTi",
    "Arial Unicode MS",
    "DejaVu Sans",
]
matplotlib.rcParams["axes.unicode_minus"] = False


CHANNEL_LABELS = {
    "wind_risk": "平均风/侧风风险",
    "gust_risk": "阵风风险",
    "shear_risk": "风切变风险",
    "turbulence_risk": "湍流代理风险",
    "shear_turbulence_risk": "风切变/湍流风险",
    "convection_risk": "对流/雷暴风险",
    "precipitation_risk": "降水风险",
    "visibility_risk": "低能见度/低云底风险",
    "uncertainty": "认知不确定性",
    "epistemic_uncertainty": "认知不确定性",
    "joint_risk": "非补偿联合风险",
    "fatal_score": "安全关键风险包络",
    "cumulative_score": "累积软风险",
    "weighted_soft_cost": "线性加权软代价",
    "cvar_cost": "尾部风险 CVaR",
    "expected_cost": "期望风险代价",
    "total_cost": "融合总风险代价",
}

ALGORITHM_LABELS = {
    "No-weather A*": "无气象约束 A*",
    "Static-risk A*": "静态风险 A*",
    "Time-dependent A*": "时间依赖 A*",
    "Restart full search": "全局重搜",
    "Incremental dynamic repair": "事件触发修复",
    "D* Lite repair": "D* Lite 增量修复",
    "D* Lite-style repair": "D* Lite 式修复",
    "lpa_incremental_repair": "LPA*/D* Lite 同族增量修复",
}


def _ensure_out(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)


def _path_xy(path: list[State4D]) -> tuple[list[int], list[int]]:
    return [s[3] for s in path], [s[2] for s in path]


def _channel_label(channel: str) -> str:
    return CHANNEL_LABELS.get(channel, channel)


def _algorithm_label(name: str) -> str:
    return ALGORITHM_LABELS.get(name, name)


def _time_label(risk_field: RiskField4D, time_index: int) -> str:
    t = risk_field.clamp_time(time_index)
    axis = risk_field.coords.get("time")
    if axis is None or len(axis) <= t:
        return f"t = {t}"
    value = np.asarray(axis)[t]
    if np.issubdtype(np.asarray(axis).dtype, np.datetime64):
        return f"valid time = {value}"
    try:
        seconds = float(value)
        return f"t = {seconds:g} s"
    except (TypeError, ValueError):
        return f"t = {value}"


def _height_label(risk_field: RiskField4D, height_index: int) -> str:
    z = min(height_index, risk_field.z_size - 1)
    values = risk_field.coords.get("height")
    if values is None or len(values) <= z:
        return f"高度层 = {z}"
    try:
        return f"高度 = {float(np.asarray(values)[z]):g} m"
    except (TypeError, ValueError):
        return f"高度层 = {z}"


def _channel_tensor(risk_field: RiskField4D, channel: str) -> np.ndarray:
    if channel in {"epistemic_uncertainty", "uncertainty"}:
        return risk_field.uncertainty
    tensor = getattr(risk_field, channel)
    return np.asarray(tensor, dtype=float)


def _risk_background(risk_field: RiskField4D, channel: str, time_index: int, height_index: int) -> np.ndarray:
    tensor = _channel_tensor(risk_field, channel)
    t = risk_field.clamp_time(time_index)
    z = min(height_index, risk_field.z_size - 1)
    background = tensor[t, z].copy()
    return np.where(background > 1e5, np.nan, background)


def _axis_values(risk_field: RiskField4D, axis_name: str, expected_len: int) -> np.ndarray:
    if axis_name == "height" and _looks_like_synthetic_xy(risk_field):
        return np.arange(expected_len, dtype=float)
    values = risk_field.coords.get(axis_name)
    if values is None or len(values) != expected_len:
        return np.arange(expected_len, dtype=float)
    arr = np.asarray(values)
    if np.issubdtype(arr.dtype, np.datetime64):
        return np.arange(expected_len, dtype=float)
    try:
        return arr.astype(float)
    except (TypeError, ValueError):
        return np.arange(expected_len, dtype=float)


def _looks_like_synthetic_xy(risk_field: RiskField4D) -> bool:
    x_values = risk_field.coords.get("x")
    y_values = risk_field.coords.get("y")
    z_values = risk_field.coords.get("height")
    if x_values is None or y_values is None or z_values is None:
        return False
    try:
        x = np.asarray(x_values, dtype=float)
        y = np.asarray(y_values, dtype=float)
        z = np.asarray(z_values, dtype=float)
    except (TypeError, ValueError):
        return False
    x_span = float(np.ptp(x)) if x.size > 1 else 0.0
    y_span = float(np.ptp(y)) if y.size > 1 else 0.0
    z_span = float(np.ptp(z)) if z.size > 1 else 0.0
    return max(x_span, y_span) <= 100.0 and z_span > max(max(x_span, y_span) * 3.0, 50.0)


def _state_xyz(risk_field: RiskField4D, state: State4D) -> tuple[float, float, float]:
    _, z, y, x = state
    x_axis = _axis_values(risk_field, "x", risk_field.x_size)
    y_axis = _axis_values(risk_field, "y", risk_field.y_size)
    z_axis = _axis_values(risk_field, "height", risk_field.z_size)
    return float(x_axis[x]), float(y_axis[y]), float(z_axis[z])


def _path_xyz(risk_field: RiskField4D, path: list[State4D]) -> tuple[list[float], list[float], list[float]]:
    xs: list[float] = []
    ys: list[float] = []
    zs: list[float] = []
    for state in path:
        x, y, z = _state_xyz(risk_field, state)
        xs.append(x)
        ys.append(y)
        zs.append(z)
    return xs, ys, zs


def _robust_limits(values: np.ndarray) -> tuple[float, float]:
    finite = values[np.isfinite(values)]
    if finite.size == 0:
        return 0.0, 1.0
    lo, hi = np.percentile(finite, [5, 95])
    if np.isclose(lo, hi):
        hi = lo + 1.0
    return float(lo), float(hi)


def _figure_to_frame(fig) -> np.ndarray:
    buffer = BytesIO()
    fig.savefig(buffer, format="png", dpi=120)
    buffer.seek(0)
    return imageio.imread(buffer)


def _volume_points(
    risk_field: RiskField4D,
    *,
    channel: str,
    time_index: int,
    quantile: float = 0.72,
    max_points: int = 3500,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    t = risk_field.clamp_time(time_index)
    values = _channel_tensor(risk_field, channel)[t].copy()
    values = np.where(values > 1e5, np.nan, values)
    finite = values[np.isfinite(values)]
    if finite.size == 0:
        return tuple(np.asarray([], dtype=float) for _ in range(5))  # type: ignore[return-value]
    threshold = float(np.nanquantile(finite, np.clip(quantile, 0.0, 1.0)))
    high_mask = np.isfinite(values) & (values >= threshold)
    no_fly = risk_field.no_fly_mask[t]
    mask = high_mask | no_fly

    z_axis = _axis_values(risk_field, "height", risk_field.z_size)
    y_axis = _axis_values(risk_field, "y", risk_field.y_size)
    x_axis = _axis_values(risk_field, "x", risk_field.x_size)
    zz, yy, xx = np.meshgrid(z_axis, y_axis, x_axis, indexing="ij")
    xs = xx[mask].ravel()
    ys = yy[mask].ravel()
    zs = zz[mask].ravel()
    cs = values[mask].ravel()
    no_fly_values = no_fly[mask].ravel()
    if xs.size > max_points:
        order = np.argsort(np.nan_to_num(cs, nan=-1.0))[::-1][:max_points]
        xs, ys, zs, cs, no_fly_values = xs[order], ys[order], zs[order], cs[order], no_fly_values[order]
    return xs, ys, zs, cs, no_fly_values


def _style_3d_axes(ax, risk_field: RiskField4D) -> None:
    synthetic_xy = _looks_like_synthetic_xy(risk_field)
    ax.set_xlabel("x / m" if not synthetic_xy else "网格 x")
    ax.set_ylabel("y / m" if not synthetic_xy else "网格 y")
    ax.set_zlabel("高度 / m" if not synthetic_xy else "高度层")
    try:
        x_span = max(np.ptp(_axis_values(risk_field, "x", risk_field.x_size)), 1.0)
        y_span = max(np.ptp(_axis_values(risk_field, "y", risk_field.y_size)), 1.0)
        z_span = max(np.ptp(_axis_values(risk_field, "height", risk_field.z_size)), 1.0)
        horizontal_span = max(x_span, y_span)
        ax.set_box_aspect((x_span, y_span, max(z_span, 0.45 * horizontal_span)))
    except Exception:
        pass
    ax.view_init(elev=24, azim=-55)
    ax.grid(True, alpha=0.2)


def plot_path_on_risk(
    risk_field: RiskField4D,
    path: list[State4D],
    output_path: Path,
    title: str,
    time_index: int = 0,
    height_index: int = 1,
) -> None:
    _ensure_out(output_path)
    t = risk_field.clamp_time(time_index)
    z = min(height_index, risk_field.z_size - 1)
    fig, ax = plt.subplots(figsize=(7, 6))
    background = np.where(risk_field.expected_cost[t, z] > 1e5, np.nan, risk_field.expected_cost[t, z])
    im = ax.imshow(background, origin="lower", cmap="viridis")
    ax.contour(risk_field.no_fly_mask[t, z].astype(float), levels=[0.5], colors="red", linewidths=1.4, origin="lower")
    if path:
        xs, ys = _path_xy(path)
        ax.plot(xs, ys, color="white", linewidth=2.2, label="规划路径")
        ax.scatter(xs[0], ys[0], c="lime", s=80, marker="^", edgecolors="black", label="起点")
        ax.scatter(xs[-1], ys[-1], c="gold", s=90, marker="*", edgecolors="black", label="终点")
    ax.set_title(title)
    ax.set_xlabel("网格 x")
    ax.set_ylabel("网格 y")
    ax.legend(loc="upper right")
    fig.colorbar(im, ax=ax, label="期望风险代价")
    fig.tight_layout()
    fig.savefig(output_path, dpi=180)
    plt.close(fig)


def plot_replanning(
    risk_field: RiskField4D,
    path: list[State4D],
    events: list[ReplanEvent],
    output_path: Path,
    height_index: int = 1,
) -> None:
    _ensure_out(output_path)
    fig, ax = plt.subplots(figsize=(7, 6))
    z = min(height_index, risk_field.z_size - 1)
    t = events[0].event_time if events else min(20, risk_field.t_size - 1)
    background = np.where(risk_field.expected_cost[t, z] > 1e5, np.nan, risk_field.expected_cost[t, z])
    ax.imshow(background, origin="lower", cmap="magma")
    ax.contour(risk_field.no_fly_mask[t, z].astype(float), levels=[0.5], colors="cyan", linewidths=1.4, origin="lower")
    if path:
        xs, ys = _path_xy(path)
        ax.plot(xs, ys, color="white", linewidth=2.0, label="修复后路径")
    for event in events:
        _, _, y, x = event.repaired_from
        ax.scatter(x, y, c="deepskyblue", s=90, edgecolors="black", label="重规划触发点")
    ax.set_title("动态气象更新与事件触发重规划")
    ax.set_xlabel("网格 x")
    ax.set_ylabel("网格 y")
    ax.legend(loc="upper right")
    fig.tight_layout()
    fig.savefig(output_path, dpi=180)
    plt.close(fig)


def plot_algorithm_comparison(paths: dict[str, list[State4D]], risk_field: RiskField4D, output_path: Path) -> None:
    _ensure_out(output_path)
    fig, ax = plt.subplots(figsize=(7, 6))
    t = min(25, risk_field.t_size - 1)
    z = min(1, risk_field.z_size - 1)
    background = np.where(risk_field.expected_cost[t, z] > 1e5, np.nan, risk_field.expected_cost[t, z])
    ax.imshow(background, origin="lower", cmap="Greys", alpha=0.65)
    ax.contour(risk_field.no_fly_mask[t, z].astype(float), levels=[0.5], colors="red", linewidths=1.2, origin="lower")
    colors = ["tab:blue", "tab:orange", "tab:green", "tab:purple", "black", "tab:brown", "tab:pink"]
    for (label, path), color in zip(paths.items(), colors):
        if not path:
            continue
        xs, ys = _path_xy(path)
        ax.plot(xs, ys, linewidth=1.8, color=color, label=_algorithm_label(label))
    ax.set_title("同一任务下的全局路径规划方法对比")
    ax.set_xlabel("网格 x")
    ax.set_ylabel("网格 y")
    ax.legend(loc="lower right", fontsize=8)
    fig.tight_layout()
    fig.savefig(output_path, dpi=180)
    plt.close(fig)


def plot_metrics(metrics: list[PathMetrics], output_path: Path) -> None:
    _ensure_out(output_path)
    labels = [_algorithm_label(m.name) for m in metrics]
    risk = [m.cumulative_expected_risk if np.isfinite(m.cumulative_expected_risk) else 0 for m in metrics]
    elapsed = [m.elapsed_ms for m in metrics]
    violations = [m.no_fly_violations for m in metrics]

    fig, axes = plt.subplots(1, 3, figsize=(13, 4))
    axes[0].bar(labels, risk, color="tab:blue")
    axes[0].set_title("累计期望风险")
    axes[1].bar(labels, elapsed, color="tab:orange")
    axes[1].set_title("规划耗时 / ms")
    axes[2].bar(labels, violations, color="tab:red")
    axes[2].set_title("禁飞区侵入次数")
    for ax in axes:
        ax.tick_params(axis="x", labelrotation=35)
        ax.grid(axis="y", alpha=0.25)
    fig.tight_layout()
    fig.savefig(output_path, dpi=180)
    plt.close(fig)


def plot_ablation_metrics(rows: list[dict], output_path: Path) -> None:
    _ensure_out(output_path)
    if not rows:
        return
    labels = [str(row.get("label_cn") or row.get("name")) for row in rows]

    def values(key: str) -> list[float]:
        result = []
        for row in rows:
            try:
                number = float(row.get(key))
            except (TypeError, ValueError):
                number = 0.0
            if not np.isfinite(number):
                number = 0.0
            result.append(number)
        return result

    panels = [
        ("expected_risk", "累计期望风险", "tab:blue"),
        ("cvar_risk", "累计 CVaR 尾部风险", "tab:purple"),
        ("no_fly_violations", "禁飞区侵入次数", "tab:red"),
        ("cumulative_energy_kj", "累计能耗 / kJ", "tab:green"),
        ("nodes_expanded", "扩展节点数", "tab:orange"),
        ("elapsed_ms", "规划耗时 / ms", "tab:brown"),
    ]
    fig, axes = plt.subplots(2, 3, figsize=(16, 8.5))
    for ax, (key, title, color) in zip(axes.ravel(), panels):
        ax.bar(labels, values(key), color=color, alpha=0.86)
        ax.set_title(title)
        ax.tick_params(axis="x", labelrotation=35, labelsize=8)
        ax.grid(axis="y", alpha=0.25)
    fig.suptitle("消融实验指标对比：风险建模、动态性、尾部风险、能耗、航迹约束与重规划策略")
    fig.tight_layout()
    fig.savefig(output_path, dpi=180)
    plt.close(fig)


def plot_risk_channels(risk_field: RiskField4D, output_path: Path, time_index: int = 18, height_index: int = 1) -> None:
    _ensure_out(output_path)
    t = risk_field.clamp_time(time_index)
    z = min(height_index, risk_field.z_size - 1)
    channels = [
        ("wind_risk", risk_field.wind_risk),
        ("gust_risk", risk_field.gust_risk),
        ("shear_turbulence_risk", risk_field.shear_turbulence_risk),
        ("convection_risk", risk_field.convection_risk),
        ("precipitation_risk", risk_field.precipitation_risk),
        ("visibility_risk", risk_field.visibility_risk),
        ("epistemic_uncertainty", risk_field.uncertainty),
        ("joint_risk", risk_field.joint_risk),
    ]
    fig, axes = plt.subplots(2, 4, figsize=(14, 7))
    for ax, (name, tensor) in zip(axes.ravel(), channels):
        im = ax.imshow(tensor[t, z], origin="lower", cmap="viridis")
        ax.contour(risk_field.no_fly_mask[t, z].astype(float), levels=[0.5], colors="red", linewidths=0.8, origin="lower")
        ax.set_title(_channel_label(name))
        ax.set_xticks([])
        ax.set_yticks([])
        fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    fig.suptitle(f"四维气象风险通道切片：{_time_label(risk_field, t)}，{_height_label(risk_field, z)}（红线为硬禁飞边界）")
    fig.tight_layout()
    fig.savefig(output_path, dpi=180)
    plt.close(fig)


def plot_risk_timeseries(risk_field: RiskField4D, output_path: Path, height_index: int = 1) -> None:
    _ensure_out(output_path)
    z = min(height_index, risk_field.z_size - 1)
    times = [0, risk_field.t_size // 3, 2 * risk_field.t_size // 3, risk_field.t_size - 1]
    fig, axes = plt.subplots(1, len(times), figsize=(15, 4))
    for ax, t in zip(axes, times):
        total = np.where(risk_field.total_cost[t, z] > 1e5, np.nan, risk_field.total_cost[t, z])
        im = ax.imshow(total, origin="lower", cmap="magma")
        ax.contour(risk_field.no_fly_mask[t, z].astype(float), levels=[0.5], colors="cyan", linewidths=0.9, origin="lower")
        ax.set_title(_time_label(risk_field, t))
        ax.set_xticks([])
        ax.set_yticks([])
    fig.colorbar(im, ax=axes.ravel().tolist(), fraction=0.025, pad=0.02, label="融合总风险代价")
    fig.suptitle("四维动态风险场时间切片")
    fig.savefig(output_path, dpi=180)
    plt.close(fig)


def plot_risk_volume_3d(
    risk_field: RiskField4D,
    output_path: Path,
    *,
    time_index: int = 0,
    channel: str = "joint_risk",
    path: list[State4D] | None = None,
    quantile: float = 0.72,
    title: str | None = None,
) -> None:
    """Plot a 3D x-y-height risk volume at one time index."""

    _ensure_out(output_path)
    t = risk_field.clamp_time(time_index)
    xs, ys, zs, values, no_fly_values = _volume_points(risk_field, channel=channel, time_index=t, quantile=quantile)
    fig = plt.figure(figsize=(8.5, 7.2))
    ax = fig.add_subplot(111, projection="3d")
    if xs.size:
        sc = ax.scatter(xs, ys, zs, c=values, cmap="magma", s=24, alpha=0.62, depthshade=False)
        fig.colorbar(sc, ax=ax, shrink=0.62, pad=0.08, label=_channel_label(channel))
        if np.any(no_fly_values):
            ax.scatter(
                xs[no_fly_values.astype(bool)],
                ys[no_fly_values.astype(bool)],
                zs[no_fly_values.astype(bool)],
                c="red",
                s=38,
                marker="x",
                alpha=0.86,
                label="禁飞体素",
            )
    if path:
        px, py, pz = _path_xyz(risk_field, path)
        ax.plot(px, py, pz, color="white", linewidth=2.6, label="四维路径投影")
        ax.scatter(px[0], py[0], pz[0], c="lime", s=80, marker="^", edgecolors="black", label="起点")
        ax.scatter(px[-1], py[-1], pz[-1], c="gold", s=100, marker="*", edgecolors="black", label="终点")
    _style_3d_axes(ax, risk_field)
    ax.set_title(title or f"三维风险体展示：{_channel_label(channel)}，{_time_label(risk_field, t)}")
    if xs.size or path:
        ax.legend(loc="upper left", fontsize=8)
    fig.tight_layout()
    fig.savefig(output_path, dpi=180)
    plt.close(fig)


def plot_risk_channels_3d(
    risk_field: RiskField4D,
    output_path: Path,
    *,
    time_index: int = 0,
    quantile: float = 0.76,
) -> None:
    """Plot six weather mechanisms as 3D risk volumes at one time index."""

    _ensure_out(output_path)
    channels = [
        "wind_risk",
        "gust_risk",
        "shear_turbulence_risk",
        "convection_risk",
        "precipitation_risk",
        "visibility_risk",
    ]
    t = risk_field.clamp_time(time_index)
    fig = plt.figure(figsize=(15, 9))
    for idx, channel in enumerate(channels, start=1):
        ax = fig.add_subplot(2, 3, idx, projection="3d")
        xs, ys, zs, values, no_fly_values = _volume_points(risk_field, channel=channel, time_index=t, quantile=quantile, max_points=1600)
        if xs.size:
            sc = ax.scatter(xs, ys, zs, c=values, cmap="viridis", s=16, alpha=0.55, depthshade=False)
            fig.colorbar(sc, ax=ax, shrink=0.45, pad=0.02)
            if np.any(no_fly_values):
                mask = no_fly_values.astype(bool)
                ax.scatter(xs[mask], ys[mask], zs[mask], c="red", s=22, marker="x", alpha=0.75)
        _style_3d_axes(ax, risk_field)
        ax.set_title(_channel_label(channel))
        ax.tick_params(labelsize=7)
    fig.suptitle(f"不同气象风险通道的三维体素展示：{_time_label(risk_field, t)}（红色 x 为禁飞体素）")
    fig.tight_layout()
    fig.savefig(output_path, dpi=180)
    plt.close(fig)


def animate_risk_field(
    risk_field: RiskField4D,
    output_path: Path,
    height_index: int = 1,
    channel: str = "total_cost",
    fps: int = 4,
    frame_step: int = 1,
) -> None:
    _ensure_out(output_path)
    z = min(height_index, risk_field.z_size - 1)
    all_values = np.stack(
        [_risk_background(risk_field, channel, t, z) for t in range(0, risk_field.t_size, frame_step)],
        axis=0,
    )
    vmin, vmax = _robust_limits(all_values)
    frames = []
    for t in range(0, risk_field.t_size, frame_step):
        fig, ax = plt.subplots(figsize=(6.5, 5.8))
        background = _risk_background(risk_field, channel, t, z)
        im = ax.imshow(background, origin="lower", cmap="magma", vmin=vmin, vmax=vmax)
        ax.contour(risk_field.no_fly_mask[t, z].astype(float), levels=[0.5], colors="cyan", linewidths=1.0, origin="lower")
        ax.set_title(f"四维动态风险场：{_channel_label(channel)}，{_time_label(risk_field, t)}，{_height_label(risk_field, z)}")
        ax.set_xlabel("网格 x")
        ax.set_ylabel("网格 y")
        fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04, label=_channel_label(channel))
        fig.tight_layout()
        frames.append(_figure_to_frame(fig))
        plt.close(fig)
    imageio.mimsave(output_path, frames, fps=fps)


def animate_weather_channels(
    risk_field: RiskField4D,
    output_path: Path,
    height_index: int = 1,
    fps: int = 4,
    frame_step: int = 1,
) -> None:
    _ensure_out(output_path)
    z = min(height_index, risk_field.z_size - 1)
    channels = [
        ("wind_risk", risk_field.wind_risk),
        ("gust_risk", risk_field.gust_risk),
        ("shear_turbulence_risk", risk_field.shear_turbulence_risk),
        ("convection_risk", risk_field.convection_risk),
        ("precipitation_risk", risk_field.precipitation_risk),
        ("visibility_risk", risk_field.visibility_risk),
    ]
    limits = {}
    for name, tensor in channels:
        values = np.stack([tensor[t, z] for t in range(0, risk_field.t_size, frame_step)], axis=0)
        limits[name] = _robust_limits(values)

    frames = []
    for t in range(0, risk_field.t_size, frame_step):
        fig, axes = plt.subplots(2, 3, figsize=(12, 7.8))
        for ax, (name, tensor) in zip(axes.ravel(), channels):
            vmin, vmax = limits[name]
            im = ax.imshow(tensor[t, z], origin="lower", cmap="viridis", vmin=vmin, vmax=vmax)
            ax.contour(risk_field.no_fly_mask[t, z].astype(float), levels=[0.5], colors="red", linewidths=0.8, origin="lower")
            ax.set_title(_channel_label(name))
            ax.set_xticks([])
            ax.set_yticks([])
            fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
        fig.suptitle(f"不同低空气象风险的动态演化：{_time_label(risk_field, t)}，{_height_label(risk_field, z)}（红线为硬禁飞边界）")
        fig.tight_layout()
        frames.append(_figure_to_frame(fig))
        plt.close(fig)
    imageio.mimsave(output_path, frames, fps=fps)


def animate_path_over_time(
    risk_field: RiskField4D,
    path: list[State4D],
    output_path: Path,
    height_index: int = 1,
    channel: str = "total_cost",
    fps: int = 4,
    frame_step: int = 1,
) -> None:
    _ensure_out(output_path)
    z = min(height_index, risk_field.z_size - 1)
    max_frame = path[-1][0] if path else risk_field.t_size - 1
    max_frame = min(max_frame, risk_field.t_size - 1)
    frame_indices = list(range(0, max_frame + 1, max(1, int(frame_step))))
    if frame_indices[-1] != max_frame:
        frame_indices.append(max_frame)
    all_values = np.stack([_risk_background(risk_field, channel, t, z) for t in frame_indices], axis=0)
    vmin, vmax = _robust_limits(all_values)
    full_xs, full_ys = _path_xy(path)
    frames = []
    for t in frame_indices:
        fig, ax = plt.subplots(figsize=(6.5, 5.8))
        background = _risk_background(risk_field, channel, t, z)
        im = ax.imshow(background, origin="lower", cmap="magma", vmin=vmin, vmax=vmax)
        ax.contour(risk_field.no_fly_mask[t, z].astype(float), levels=[0.5], colors="cyan", linewidths=1.0, origin="lower")
        if path:
            reached = [state for state in path if state[0] <= t]
            if full_xs and full_ys:
                ax.plot(full_xs, full_ys, color="white", alpha=0.30, linewidth=1.5, linestyle="--", label="规划路径")
            if reached:
                xs, ys = _path_xy(reached)
                ax.plot(xs, ys, color="white", linewidth=2.4, label="已执行航段")
                _, _, cy, cx = reached[-1]
                ax.scatter(cx, cy, c="deepskyblue", s=100, edgecolors="black", zorder=4, label="当前无人机")
            ax.scatter(full_xs[0], full_ys[0], c="lime", s=70, marker="^", edgecolors="black", zorder=5, label="起点")
            ax.scatter(full_xs[-1], full_ys[-1], c="gold", s=90, marker="*", edgecolors="black", zorder=5, label="终点")
        ax.set_title(f"动态风险场中的四维路径推进：{_time_label(risk_field, t)}，{_height_label(risk_field, z)}")
        ax.set_xlabel("网格 x")
        ax.set_ylabel("网格 y")
        ax.legend(loc="upper right", fontsize=8)
        fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04, label=_channel_label(channel))
        fig.tight_layout()
        frames.append(_figure_to_frame(fig))
        plt.close(fig)
    imageio.mimsave(output_path, frames, fps=fps)


def animate_risk_volume_3d(
    risk_field: RiskField4D,
    output_path: Path,
    *,
    channel: str = "joint_risk",
    path: list[State4D] | None = None,
    fps: int = 3,
    frame_step: int = 1,
    quantile: float = 0.74,
) -> None:
    """Animate x-y-height risk volumes over time."""

    _ensure_out(output_path)
    frames = []
    for t in range(0, risk_field.t_size, frame_step):
        xs, ys, zs, values, no_fly_values = _volume_points(risk_field, channel=channel, time_index=t, quantile=quantile)
        fig = plt.figure(figsize=(8.2, 7))
        ax = fig.add_subplot(111, projection="3d")
        if xs.size:
            sc = ax.scatter(xs, ys, zs, c=values, cmap="magma", s=22, alpha=0.60, depthshade=False)
            fig.colorbar(sc, ax=ax, shrink=0.62, pad=0.08, label=_channel_label(channel))
            if np.any(no_fly_values):
                mask = no_fly_values.astype(bool)
                ax.scatter(xs[mask], ys[mask], zs[mask], c="red", s=36, marker="x", alpha=0.85, label="禁飞体素")
        if path:
            full_px, full_py, full_pz = _path_xyz(risk_field, path)
            ax.plot(full_px, full_py, full_pz, color="white", alpha=0.25, linewidth=1.6, linestyle="--", label="规划路径")
            reached = [state for state in path if state[0] <= t]
            if reached:
                px, py, pz = _path_xyz(risk_field, reached)
                ax.plot(px, py, pz, color="white", linewidth=2.8, label="已执行航段")
                ax.scatter(px[-1], py[-1], pz[-1], c="deepskyblue", s=90, edgecolors="black", label="当前无人机")
        _style_3d_axes(ax, risk_field)
        ax.set_title(f"四维风险场三维体随时间演化：{_channel_label(channel)}，{_time_label(risk_field, t)}")
        if xs.size or path:
            ax.legend(loc="upper left", fontsize=8)
        fig.tight_layout()
        frames.append(_figure_to_frame(fig))
        plt.close(fig)
    imageio.mimsave(output_path, frames, fps=fps)


def animate_path_over_time_3d(
    risk_field: RiskField4D,
    path: list[State4D],
    output_path: Path,
    *,
    channel: str = "joint_risk",
    fps: int = 3,
    frame_step: int = 1,
    quantile: float = 0.74,
) -> None:
    animate_risk_volume_3d(
        risk_field,
        output_path,
        channel=channel,
        path=path,
        fps=fps,
        frame_step=frame_step,
        quantile=quantile,
    )
