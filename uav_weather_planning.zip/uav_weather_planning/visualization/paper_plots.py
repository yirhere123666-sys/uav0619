from __future__ import annotations

from pathlib import Path
from typing import Any

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Circle
import numpy as np

from uav_weather_planning.risk_field import RiskField4D
from uav_weather_planning.risk_field.metric_coords import get_height_m, get_time_seconds, path_to_metric, state_to_metric
from uav_weather_planning.risk_field.risk_field_4d import State4D


plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "Arial Unicode MS", "DejaVu Sans"]
plt.rcParams["axes.unicode_minus"] = False


CHANNEL_LABELS = {
    "total_cost": "综合风险代价",
    "expected_cost": "期望风险代价",
    "cvar_cost": "CVaR 尾部风险",
    "joint_risk": "非补偿联合风险",
    "fatal_score": "安全关键风险",
    "cumulative_score": "累积软风险",
    "wind_risk": "平均风风险",
    "gust_risk": "阵风风险",
    "shear_risk": "风切变风险",
    "turbulence_risk": "湍流代理风险",
    "shear_turbulence_risk": "风切变/湍流风险",
    "convection_risk": "对流风险",
    "precipitation_risk": "降水风险",
    "visibility_risk": "能见度风险",
    "violation_probability": "约束违反概率",
}


def plot_low_altitude_wind_structure_3d(
    risk_field: RiskField4D,
    output_path: Path,
    *,
    time_index: int,
    risk_channel: str = "shear_turbulence_risk",
    risk_quantile: float = 0.90,
) -> dict[str, Any]:
    _ensure_out(output_path)
    t = risk_field.clamp_time(time_index)
    xs, ys, zs, values, _, threshold = _volume_points_metric(
        risk_field,
        risk_channel,
        t,
        quantile=risk_quantile,
        max_points=4500,
    )
    fig = plt.figure(figsize=(9.2, 7.4))
    ax = fig.add_subplot(111, projection="3d")
    if xs.size:
        sc = ax.scatter(xs, ys, zs, c=values, cmap="magma", s=18, alpha=0.58, depthshade=False, label="高风险体素")
        fig.colorbar(sc, ax=ax, shrink=0.60, pad=0.08, label=_channel_label(risk_channel))

    x_axis, y_axis, z_axis = _axes(risk_field)
    y_step = max(1, risk_field.y_size // 12)
    x_step = max(1, risk_field.x_size // 12)
    z_step = max(1, risk_field.z_size // 3)
    yy, zz, xx = np.meshgrid(y_axis[::y_step], z_axis[::z_step], x_axis[::x_step], indexing="ij")
    u = risk_field.wind_u[t, ::z_step, ::y_step, ::x_step].transpose(1, 0, 2)
    v = risk_field.wind_v[t, ::z_step, ::y_step, ::x_step].transpose(1, 0, 2)
    w = risk_field.wind_w[t, ::z_step, ::y_step, ::x_step].transpose(1, 0, 2)
    ax.quiver(xx, yy, zz, u, v, w, length=260.0, normalize=True, color="#1f77b4", alpha=0.48, linewidth=0.8)

    _style_3d_axes(ax, risk_field)
    ax.set_title(f"低空风场与风切变三维结构（{_time_label(risk_field, t)}）")
    ax.legend(loc="upper left", fontsize=8)
    fig.tight_layout()
    fig.savefig(output_path, dpi=220)
    plt.close(fig)
    return {
        "figure": output_path.name,
        "plotted_time_s": get_time_seconds(risk_field.coords, t),
        "risk_channel": risk_channel,
        "high_risk_threshold": threshold,
        "high_risk_voxel_count": int(xs.size),
        "wind_arrow_stride_yx": [int(y_step), int(x_step)],
    }


def plot_3d_risk_field_main(
    risk_field: RiskField4D,
    output_path: Path,
    *,
    time_index: int,
    channel: str,
    quantile: float = 0.90,
    path: list[State4D] | None = None,
    title: str | None = None,
) -> dict[str, Any]:
    _ensure_out(output_path)
    t = risk_field.clamp_time(time_index)
    xs, ys, zs, values, no_fly_values, threshold = _volume_points_metric(
        risk_field,
        channel,
        t,
        quantile=quantile,
        max_points=6200,
    )
    no_fly_count = int(np.sum(risk_field.no_fly_mask[t]))
    fig = plt.figure(figsize=(9.2, 7.4))
    ax = fig.add_subplot(111, projection="3d")
    if xs.size:
        sc = ax.scatter(xs, ys, zs, c=values, cmap="magma", s=18, alpha=0.58, depthshade=False, label="高风险体素")
        fig.colorbar(sc, ax=ax, shrink=0.60, pad=0.08, label=_channel_label(channel))
        if no_fly_count > 0 and np.any(no_fly_values):
            mask = no_fly_values.astype(bool)
            ax.scatter(xs[mask], ys[mask], zs[mask], c="#7f0000", s=35, marker="s", alpha=0.88, label="硬禁飞体素")
    if path:
        _plot_path_3d(ax, risk_field, path, color="white", linewidth=2.3, label="规划路径", linestyle="-")
    _style_3d_axes(ax, risk_field)
    ax.set_title(title or f"四维概率风险场三维切片：{_channel_label(channel)}（{_time_label(risk_field, t)}）")
    if xs.size or path:
        ax.legend(loc="upper left", fontsize=8)
    fig.tight_layout()
    fig.savefig(output_path, dpi=220)
    plt.close(fig)
    return {
        "figure": output_path.name,
        "plotted_time_s": get_time_seconds(risk_field.coords, t),
        "plotted_risk_channel": channel,
        "high_risk_threshold": threshold,
        "high_risk_voxel_count": int(xs.size),
        "no_fly_voxel_count": no_fly_count,
        "label_policy": "硬禁飞体素" if no_fly_count > 0 else "高风险体素",
    }


def plot_3d_path_comparison(
    risk_field: RiskField4D,
    output_path: Path,
    *,
    baseline_path: list[State4D],
    risk_aware_path: list[State4D],
    repaired_path: list[State4D] | None = None,
    time_index: int,
    channel: str = "cvar_cost",
    quantile: float = 0.90,
) -> dict[str, Any]:
    _ensure_out(output_path)
    t = risk_field.clamp_time(time_index)
    xs, ys, zs, values, no_fly_values, threshold = _volume_points_metric(risk_field, channel, t, quantile=quantile, max_points=5200)
    no_fly_count = int(np.sum(risk_field.no_fly_mask[t]))
    fig = plt.figure(figsize=(9.6, 7.5))
    ax = fig.add_subplot(111, projection="3d")
    if xs.size:
        sc = ax.scatter(xs, ys, zs, c=values, cmap="magma", s=15, alpha=0.45, depthshade=False, label="高 CVaR 风险体素")
        fig.colorbar(sc, ax=ax, shrink=0.58, pad=0.08, label=_channel_label(channel))
        if no_fly_count > 0 and np.any(no_fly_values):
            mask = no_fly_values.astype(bool)
            ax.scatter(xs[mask], ys[mask], zs[mask], c="#7f0000", s=30, marker="s", alpha=0.85, label="硬禁飞体素")
    _plot_path_3d(ax, risk_field, baseline_path, color="#767676", linewidth=2.0, label="无气象约束 A*", linestyle="--")
    _plot_path_3d(ax, risk_field, risk_aware_path, color="#00a86b", linewidth=2.8, label="时间依赖风险 A*", linestyle="-")
    if repaired_path:
        _plot_path_3d(ax, risk_field, repaired_path, color="#ff8c00", linewidth=2.5, label="动态修复路径", linestyle="-")
    _mark_start_goal(ax, risk_field, risk_aware_path or baseline_path)
    _style_3d_axes(ax, risk_field)
    ax.set_title(f"10 km 低空气象风险路径规划对比（{_time_label(risk_field, t)}）")
    ax.legend(loc="upper left", fontsize=8)
    fig.tight_layout()
    fig.savefig(output_path, dpi=220)
    plt.close(fig)
    return {
        "figure": output_path.name,
        "plotted_time_s": get_time_seconds(risk_field.coords, t),
        "risk_channel": channel,
        "high_risk_threshold": threshold,
        "no_fly_voxel_count": no_fly_count,
        "baseline_path_points": len(baseline_path),
        "risk_aware_path_points": len(risk_aware_path),
        "repaired_path_points": len(repaired_path or []),
    }


def plot_3d_risk_snapshots(
    risk_field: RiskField4D,
    output_path: Path,
    *,
    time_indices: tuple[int, int, int],
    channel: str = "total_cost",
    quantile: float = 0.90,
) -> dict[str, Any]:
    _ensure_out(output_path)
    finite_values = []
    for t in time_indices:
        tensor = _channel_tensor(risk_field, channel)[risk_field.clamp_time(t)]
        finite_values.append(_finite_plottable(tensor))
    merged = np.concatenate([value.ravel() for value in finite_values if value.size])
    threshold = float(np.nanquantile(merged, quantile)) if merged.size else 0.0
    vmin = float(np.nanpercentile(merged, 5)) if merged.size else 0.0
    vmax = float(np.nanpercentile(merged, 98)) if merged.size else 1.0

    fig = plt.figure(figsize=(15.4, 5.2))
    counts = []
    sc = None
    for idx, t in enumerate(time_indices, start=1):
        ax = fig.add_subplot(1, 3, idx, projection="3d")
        xs, ys, zs, values, no_fly_values, _ = _volume_points_metric(
            risk_field,
            channel,
            risk_field.clamp_time(t),
            threshold=threshold,
            max_points=2600,
        )
        counts.append(int(xs.size))
        if xs.size:
            sc = ax.scatter(xs, ys, zs, c=values, cmap="magma", s=11, alpha=0.56, vmin=vmin, vmax=vmax, depthshade=False)
            if np.any(no_fly_values):
                mask = no_fly_values.astype(bool)
                ax.scatter(xs[mask], ys[mask], zs[mask], c="#7f0000", s=20, marker="s", alpha=0.78)
        _style_3d_axes(ax, risk_field)
        ax.set_title(_time_label(risk_field, risk_field.clamp_time(t)))
        ax.tick_params(labelsize=7)
    if sc is not None:
        fig.colorbar(sc, ax=fig.axes, shrink=0.70, pad=0.03, label=_channel_label(channel))
    fig.suptitle(f"四维风险场多时刻三维快照：{_channel_label(channel)}")
    fig.savefig(output_path, dpi=220, bbox_inches="tight")
    plt.close(fig)
    return {
        "figure": output_path.name,
        "risk_channel": channel,
        "time_s": [get_time_seconds(risk_field.coords, risk_field.clamp_time(t)) for t in time_indices],
        "high_risk_threshold": threshold,
        "high_risk_voxel_counts": counts,
    }


def plot_changed_voxels_3d(
    risk_field: RiskField4D,
    changed_voxels: np.ndarray,
    output_path: Path,
    *,
    original_path: list[State4D],
    repaired_path: list[State4D],
    trigger_state: State4D,
    event_reason: str,
    repair_mode: str,
    planner_name: str,
    speedup_ratio: float | None = None,
    perturbation_metadata: dict[str, Any] | None = None,
    max_points: int = 6500,
) -> dict[str, Any]:
    return _plot_dstar_repair_common(
        risk_field,
        changed_voxels,
        output_path,
        original_path=original_path,
        repaired_path=repaired_path,
        trigger_state=trigger_state,
        event_reason=event_reason,
        repair_mode=repair_mode,
        planner_name=planner_name,
        speedup_ratio=speedup_ratio,
        perturbation_metadata=perturbation_metadata,
        title="路径定向局地风切变扰动下的 D* Lite 增量重规划",
        max_points=max_points,
    )


def plot_3d_dstar_path_affected_demo(
    risk_field: RiskField4D,
    changed_voxels: np.ndarray,
    output_path: Path,
    *,
    original_path: list[State4D],
    repaired_path: list[State4D],
    trigger_state: State4D,
    speedup_ratio: float | None,
    perturbation_metadata: dict[str, Any],
) -> dict[str, Any]:
    return _plot_dstar_repair_common(
        risk_field,
        changed_voxels,
        output_path,
        original_path=original_path,
        repaired_path=repaired_path,
        trigger_state=trigger_state,
        event_reason="路径未来段风切变/阵风风险升高",
        repair_mode="incremental_dstar_lite",
        planner_name="dstar_lite_4d",
        speedup_ratio=speedup_ratio,
        perturbation_metadata=perturbation_metadata,
        title="路径受影响案例：D* Lite 四维增量重规划",
        max_points=7800,
    )


def plot_2d_dstar_path_affected_demo(
    risk_field: RiskField4D,
    changed_voxels: np.ndarray,
    output_path: Path,
    *,
    original_path: list[State4D],
    repaired_path: list[State4D],
    trigger_state: State4D,
    perturbation_metadata: dict[str, Any],
    channel: str = "cvar_cost",
) -> dict[str, Any]:
    _ensure_out(output_path)
    event_t = risk_field.clamp_time(trigger_state[0])
    z = int(np.clip(trigger_state[1], 0, risk_field.z_size - 1))
    tensor = _channel_tensor(risk_field, channel)
    background = np.where(tensor[event_t, z] >= 1e5, np.nan, tensor[event_t, z])
    x_axis, y_axis, _ = _axes(risk_field)
    extent = [float(x_axis[0]), float(x_axis[-1]), float(y_axis[0]), float(y_axis[-1])]
    mask = _changed_mask_at_time(changed_voxels, event_t)
    changed_2d = np.any(mask, axis=0)

    fig, ax = plt.subplots(figsize=(8.8, 7.6))
    im = ax.imshow(background, origin="lower", cmap="magma", extent=extent, aspect="equal")
    if np.any(changed_2d):
        ax.contour(x_axis, y_axis, changed_2d.astype(float), levels=[0.5], colors="#9c27b0", linewidths=1.2)
    if np.any(risk_field.no_fly_mask[event_t, z]):
        ax.contour(x_axis, y_axis, risk_field.no_fly_mask[event_t, z].astype(float), levels=[0.5], colors="#7f0000", linewidths=1.4)
    future_original = [state for state in original_path if state[0] >= event_t]
    _plot_path_2d(ax, risk_field, future_original, color="#767676", linewidth=2.0, label="原路径未来段", linestyle="--")
    _plot_path_2d(ax, risk_field, repaired_path, color="#ff8c00", linewidth=2.7, label="D* Lite 修复路径", linestyle="-")
    _, height_m, y_m, x_m = state_to_metric(trigger_state, risk_field.coords)
    ax.scatter([x_m], [y_m], c="#1565c0", s=95, marker="o", edgecolors="white", label="触发点")
    _draw_perturbation_circle_2d(ax, perturbation_metadata)
    _mark_start_goal_2d(ax, risk_field, repaired_path or original_path)
    ax.set_xlabel("x / m")
    ax.set_ylabel("y / m")
    ax.set_title(f"D* Lite 路径受影响二维示意（{_time_label(risk_field, event_t)}，高度={height_m:g} m）")
    ax.legend(loc="upper left", fontsize=8)
    fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04, label=_channel_label(channel))
    fig.tight_layout()
    fig.savefig(output_path, dpi=220)
    plt.close(fig)
    return {
        "figure": output_path.name,
        "event_time_s": get_time_seconds(risk_field.coords, event_t),
        "height_m": height_m,
        "changed_voxel_count_at_event_time": int(np.sum(mask)),
        "path_affected": _path_intersects_mask(original_path, mask, event_t),
        "perturbation_center_m": perturbation_metadata.get("perturbation_center_m"),
    }


def plot_2d_path_comparison_weather_risk(
    risk_field: RiskField4D,
    output_path: Path,
    *,
    baseline_path: list[State4D],
    risk_aware_path: list[State4D],
    time_index: int,
    height_index: int,
    channel: str = "total_cost",
) -> dict[str, Any]:
    _ensure_out(output_path)
    t = risk_field.clamp_time(time_index)
    z = int(np.clip(height_index, 0, risk_field.z_size - 1))
    tensor = _channel_tensor(risk_field, channel)
    background = np.where(tensor[t, z] >= 1e5, np.nan, tensor[t, z])
    x_axis, y_axis, _ = _axes(risk_field)
    extent = [float(x_axis[0]), float(x_axis[-1]), float(y_axis[0]), float(y_axis[-1])]
    fig, ax = plt.subplots(figsize=(8.6, 7.4))
    im = ax.imshow(background, origin="lower", cmap="magma", extent=extent, aspect="equal")
    if np.any(risk_field.no_fly_mask[t, z]):
        ax.contour(x_axis, y_axis, risk_field.no_fly_mask[t, z].astype(float), levels=[0.5], colors="#7f0000", linewidths=1.4)
    _plot_path_2d(ax, risk_field, baseline_path, color="#767676", linewidth=2.0, label="无气象约束 A*", linestyle="--")
    _plot_path_2d(ax, risk_field, risk_aware_path, color="#00a86b", linewidth=2.5, label="时间依赖风险 A*", linestyle="-")
    _mark_start_goal_2d(ax, risk_field, risk_aware_path or baseline_path)
    ax.set_xlabel("x / m")
    ax.set_ylabel("y / m")
    ax.set_title(f"10 km 路径规划二维对比：{_channel_label(channel)}（{_time_label(risk_field, t)}，高度={get_height_m(risk_field.coords, z):g} m）")
    ax.legend(loc="upper left", fontsize=8)
    fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04, label=_channel_label(channel))
    fig.tight_layout()
    fig.savefig(output_path, dpi=220)
    plt.close(fig)
    return {
        "figure": output_path.name,
        "plotted_time_s": get_time_seconds(risk_field.coords, t),
        "height_m": get_height_m(risk_field.coords, z),
        "risk_channel": channel,
        "extent_m": extent,
    }


def _plot_dstar_repair_common(
    risk_field: RiskField4D,
    changed_voxels: np.ndarray,
    output_path: Path,
    *,
    original_path: list[State4D],
    repaired_path: list[State4D],
    trigger_state: State4D,
    event_reason: str,
    repair_mode: str,
    planner_name: str,
    speedup_ratio: float | None,
    perturbation_metadata: dict[str, Any] | None,
    title: str,
    max_points: int,
) -> dict[str, Any]:
    _ensure_out(output_path)
    event_t = risk_field.clamp_time(trigger_state[0])
    mask = _changed_mask_at_time(changed_voxels, event_t)
    xs, ys, zs = _mask_points_metric(risk_field, mask, max_points=max_points)
    changed_count = int(np.sum(mask))
    total_changed_count = int(np.sum(np.asarray(changed_voxels, dtype=bool)))
    denominator = max(mask.size, 1)
    path_affected = _path_intersects_mask(original_path, mask, event_t)

    fig = plt.figure(figsize=(9.8, 7.6))
    ax = fig.add_subplot(111, projection="3d")
    if xs.size:
        ax.scatter(xs, ys, zs, c="#9c27b0", s=17, alpha=0.50, depthshade=False, label="显著变化体素")
    future_original = [state for state in original_path if state[0] >= event_t]
    _plot_path_3d(ax, risk_field, future_original, color="#767676", linewidth=2.0, label="原路径未来段", linestyle="--")
    _plot_path_3d(ax, risk_field, repaired_path, color="#ff8c00", linewidth=2.8, label="D* Lite 修复路径", linestyle="-")
    _, height_m, y_m, x_m = state_to_metric(trigger_state, risk_field.coords)
    ax.scatter([x_m], [y_m], [height_m], c="#1565c0", s=95, marker="o", edgecolors="white", label="触发点")
    _draw_perturbation_region_3d(ax, perturbation_metadata)
    _style_3d_axes(ax, risk_field)
    speedup_text = "加速比=N/A" if speedup_ratio is None else f"加速比={speedup_ratio:g}"
    ax.set_title(
        f"{title}\nWRF 背景场 + 合成局地风切变/阵风扰动，"
        f"{_time_label(risk_field, event_t)}，路径受影响={path_affected}，变化体素={total_changed_count}，{speedup_text}"
    )
    ax.legend(loc="upper left", fontsize=8)
    fig.tight_layout()
    fig.savefig(output_path, dpi=220)
    plt.close(fig)
    return {
        "figure": output_path.name,
        "event_time_s": get_time_seconds(risk_field.coords, event_t),
        "event_reason": event_reason,
        "changed_voxel_count": total_changed_count,
        "changed_voxel_count_at_event_time": changed_count,
        "changed_voxel_ratio": round(changed_count / denominator, 6),
        "path_affected": path_affected,
        "repair_start_state": list(trigger_state),
        "repair_mode": repair_mode,
        "planner_name": planner_name,
        "title_policy": title,
        "speedup_ratio": speedup_ratio,
        "perturbation_center_m": (perturbation_metadata or {}).get("perturbation_center_m"),
    }


def _ensure_out(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)


def _axes(risk_field: RiskField4D) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    x = np.asarray(risk_field.coords.get("x", np.arange(risk_field.x_size)), dtype=float)
    y = np.asarray(risk_field.coords.get("y", np.arange(risk_field.y_size)), dtype=float)
    z = np.asarray(risk_field.coords.get("height", np.arange(risk_field.z_size)), dtype=float)
    return x, y, z


def _channel_label(channel: str) -> str:
    return CHANNEL_LABELS.get(channel, channel)


def _channel_tensor(risk_field: RiskField4D, channel: str) -> np.ndarray:
    if channel in {"uncertainty", "epistemic_uncertainty"}:
        return risk_field.uncertainty
    return np.asarray(getattr(risk_field, channel), dtype=float)


def _finite_plottable(values: np.ndarray) -> np.ndarray:
    arr = np.asarray(values, dtype=float)
    return arr[np.isfinite(arr) & (arr < 1e5)]


def _volume_points_metric(
    risk_field: RiskField4D,
    channel: str,
    time_index: int,
    *,
    quantile: float = 0.90,
    threshold: float | None = None,
    max_points: int = 5000,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray, float]:
    t = risk_field.clamp_time(time_index)
    values = _channel_tensor(risk_field, channel)[t].copy()
    finite = _finite_plottable(values)
    if finite.size == 0:
        return tuple(np.asarray([], dtype=float) for _ in range(5)) + (0.0,)  # type: ignore[return-value]
    threshold = float(np.nanquantile(finite, quantile)) if threshold is None else float(threshold)
    mask = np.isfinite(values) & (values < 1e5) & (values >= threshold)
    no_fly = risk_field.no_fly_mask[t]
    if np.any(no_fly):
        mask = mask | no_fly
    x_axis, y_axis, z_axis = _axes(risk_field)
    zz, yy, xx = np.meshgrid(z_axis, y_axis, x_axis, indexing="ij")
    xs = xx[mask].ravel()
    ys = yy[mask].ravel()
    zs = zz[mask].ravel()
    cs = values[mask].ravel()
    no_fly_values = no_fly[mask].ravel()
    if xs.size > max_points:
        order = np.argsort(np.nan_to_num(cs, nan=-1.0))[::-1][:max_points]
        xs, ys, zs, cs, no_fly_values = xs[order], ys[order], zs[order], cs[order], no_fly_values[order]
    return xs, ys, zs, cs, no_fly_values, threshold


def _mask_points_metric(risk_field: RiskField4D, mask: np.ndarray, *, max_points: int) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    x_axis, y_axis, z_axis = _axes(risk_field)
    zz, yy, xx = np.meshgrid(z_axis, y_axis, x_axis, indexing="ij")
    xs = xx[mask].ravel()
    ys = yy[mask].ravel()
    zs = zz[mask].ravel()
    if xs.size > max_points:
        rng = np.random.default_rng(20260618)
        chosen = rng.choice(xs.size, size=max_points, replace=False)
        xs, ys, zs = xs[chosen], ys[chosen], zs[chosen]
    return xs, ys, zs


def _changed_mask_at_time(changed_voxels: np.ndarray, event_t: int) -> np.ndarray:
    changed = np.asarray(changed_voxels, dtype=bool)
    if changed.ndim == 4:
        return changed[int(np.clip(event_t, 0, changed.shape[0] - 1))]
    if changed.ndim == 3:
        return changed
    raise ValueError("changed_voxels must be a 3D or 4D boolean array")


def _path_intersects_mask(path: list[State4D], mask: np.ndarray, event_t: int) -> bool:
    for state in path:
        if state[0] < event_t:
            continue
        _, z, y, x = state
        if 0 <= z < mask.shape[0] and 0 <= y < mask.shape[1] and 0 <= x < mask.shape[2] and mask[z, y, x]:
            return True
    return False


def _plot_path_3d(ax, risk_field: RiskField4D, path: list[State4D], *, color: str, linewidth: float, label: str, linestyle: str) -> None:
    if not path:
        return
    metric = path_to_metric(path, risk_field.coords)
    ax.plot(metric["x_m"], metric["y_m"], metric["height_m"], color=color, linewidth=linewidth, linestyle=linestyle, label=label)


def _plot_path_2d(ax, risk_field: RiskField4D, path: list[State4D], *, color: str, linewidth: float, label: str, linestyle: str) -> None:
    if not path:
        return
    metric = path_to_metric(path, risk_field.coords)
    ax.plot(metric["x_m"], metric["y_m"], color=color, linewidth=linewidth, linestyle=linestyle, label=label)


def _mark_start_goal(ax, risk_field: RiskField4D, path: list[State4D]) -> None:
    if not path:
        return
    _, z0, y0, x0 = state_to_metric(path[0], risk_field.coords)
    _, z1, y1, x1 = state_to_metric(path[-1], risk_field.coords)
    ax.scatter([x0], [y0], [z0], c="lime", s=90, marker="^", edgecolors="black", label="起点")
    ax.scatter([x1], [y1], [z1], c="#1565c0", s=110, marker="*", edgecolors="white", label="终点")


def _mark_start_goal_2d(ax, risk_field: RiskField4D, path: list[State4D]) -> None:
    if not path:
        return
    _, _, y0, x0 = state_to_metric(path[0], risk_field.coords)
    _, _, y1, x1 = state_to_metric(path[-1], risk_field.coords)
    ax.scatter([x0], [y0], c="lime", s=75, marker="^", edgecolors="black", zorder=5, label="起点")
    ax.scatter([x1], [y1], c="#1565c0", s=95, marker="*", edgecolors="white", zorder=5, label="终点")


def _draw_perturbation_circle_2d(ax, metadata: dict[str, Any] | None) -> None:
    if not metadata:
        return
    center = metadata.get("perturbation_center_m") or {}
    x = center.get("x")
    y = center.get("y")
    radius = metadata.get("gust_radius_m")
    if x is None or y is None or radius is None:
        return
    circle = Circle((float(x), float(y)), float(radius), color="#ff7043", alpha=0.18, label="局地扰动影响区")
    ax.add_patch(circle)
    ax.scatter([float(x)], [float(y)], c="#d84315", s=80, marker="x", label="扰动中心")


def _draw_perturbation_region_3d(ax, metadata: dict[str, Any] | None) -> None:
    if not metadata:
        return
    center = metadata.get("perturbation_center_m") or {}
    x = center.get("x")
    y = center.get("y")
    height_band = metadata.get("perturbation_height_band_m") or [80.0, 160.0]
    radius = metadata.get("gust_radius_m")
    if x is None or y is None or radius is None:
        return
    theta = np.linspace(0.0, 2.0 * np.pi, 80)
    circle_x = float(x) + float(radius) * np.cos(theta)
    circle_y = float(y) + float(radius) * np.sin(theta)
    z_mid = 0.5 * (float(height_band[0]) + float(height_band[1]))
    ax.plot(circle_x, circle_y, np.full_like(circle_x, z_mid), color="#ff7043", alpha=0.65, linewidth=2.0, label="局地扰动范围")
    ax.scatter([float(x)], [float(y)], [z_mid], c="#d84315", s=85, marker="x", label="扰动中心")


def _style_3d_axes(ax, risk_field: RiskField4D) -> None:
    x_axis, y_axis, z_axis = _axes(risk_field)
    ax.set_xlabel("x / m")
    ax.set_ylabel("y / m")
    ax.set_zlabel("高度 / m")
    x_span = max(float(np.ptp(x_axis)), 1.0)
    y_span = max(float(np.ptp(y_axis)), 1.0)
    z_span = max(float(np.ptp(z_axis)), 1.0)
    horizontal_span = max(x_span, y_span)
    ax.set_box_aspect((x_span, y_span, max(z_span, 0.42 * horizontal_span)))
    ax.set_xlim(float(x_axis[0]), float(x_axis[-1]))
    ax.set_ylim(float(y_axis[0]), float(y_axis[-1]))
    ax.set_zlim(float(z_axis[0]), float(z_axis[-1]))
    ax.view_init(elev=25, azim=-55)
    ax.grid(True, alpha=0.22)


def _time_label(risk_field: RiskField4D, time_index: int) -> str:
    return f"t = {get_time_seconds(risk_field.coords, time_index):g} s"
