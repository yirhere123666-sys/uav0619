from __future__ import annotations

import numpy as np

from uav_weather_planning.data_interface.weather_cube import WeatherCube
from .common import RiskModelResult
from .mapping import hard_mask_from_exceedance, mapping_evidence, ramp_safe_danger, sigmoid_hard


def model_precipitation_risk(
    cube: WeatherCube,
    light_rain: float = 1.0,
    heavy_rain: float = 20.0,
    extreme_rain: float = 45.0,
    hard_exceedance_limit: float = 0.95,
) -> RiskModelResult:
    rain_rate = cube.get("rain_rate")
    precipitation_risk = ramp_safe_danger(rain_rate, light_rain, heavy_rain)
    exceedance_probability = sigmoid_hard(rain_rate, extreme_rain, 6.0)
    no_fly = hard_mask_from_exceedance(exceedance_probability, hard_exceedance_limit)
    return RiskModelResult(
        channels={"precipitation_risk": precipitation_risk},
        masks={"no_fly_extreme_precipitation": no_fly},
        auxiliaries={"rain_rate": rain_rate, "precipitation_exceedance_probability": exceedance_probability},
        evidence={
            "precipitation_risk": mapping_evidence(
                variable="rain_rate",
                formula="r_precip=clip((rain_rate-safe)/(danger-safe),0,1); p_hard=sigmoid((rain_rate-hard)/6.0)",
                thresholds={
                    "safe_mm_h": light_rain,
                    "danger_mm_h": heavy_rain,
                    "hard_mm_h": extreme_rain,
                    "hard_probability_limit": hard_exceedance_limit,
                },
                exceedance_probability="precipitation_exceedance_probability",
                hard_mask="no_fly_extreme_precipitation",
                note="Rain-rate risk is a safe-danger ramp; extreme rainfall contributes to the hard safety envelope.",
            )
        },
    )
