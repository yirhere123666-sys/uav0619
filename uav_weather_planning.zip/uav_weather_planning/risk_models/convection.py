from __future__ import annotations

import numpy as np

from uav_weather_planning.data_interface.weather_cube import WeatherCube
from .common import RiskModelResult, clip01
from .mapping import hard_mask_from_exceedance, mapping_evidence, ramp_safe_danger, sigmoid_hard


def model_convection_risk(
    cube: WeatherCube,
    soft_reflectivity: float = 25.0,
    danger_reflectivity: float = 40.0,
    hard_reflectivity: float = 45.0,
    hard_probability: float = 0.85,
) -> RiskModelResult:
    reflectivity = cube.get("reflectivity")
    probability = cube.get("convection_probability")
    reflectivity_risk = ramp_safe_danger(reflectivity, soft_reflectivity, danger_reflectivity)
    convection_risk = clip01(np.maximum(reflectivity_risk, probability))
    reflectivity_exceedance = sigmoid_hard(reflectivity, hard_reflectivity, 4.0)
    exceedance_probability = clip01(0.55 * reflectivity_exceedance + 0.45 * probability)
    no_fly = hard_mask_from_exceedance(exceedance_probability, hard_probability)
    return RiskModelResult(
        channels={"convection_risk": convection_risk},
        masks={"no_fly_convection": no_fly},
        auxiliaries={
            "reflectivity": reflectivity,
            "convection_probability": probability,
            "convection_exceedance_probability": exceedance_probability,
        },
        evidence={
            "convection_risk": mapping_evidence(
                variable="reflectivity, convection_probability",
                formula=(
                    "r_ref=clip((Z-Z_safe)/(Z_danger-Z_safe),0,1); "
                    "r_conv=max(r_ref,P_conv); "
                    "p_hard=clip(0.55*sigmoid((Z-Z_hard)/4.0)+0.45*P_conv,0,1)"
                ),
                thresholds={
                    "reflectivity_safe_dbz": soft_reflectivity,
                    "reflectivity_danger_dbz": danger_reflectivity,
                    "reflectivity_hard_dbz": hard_reflectivity,
                    "hard_probability_limit": hard_probability,
                },
                exceedance_probability="convection_exceedance_probability",
                hard_mask="no_fly_convection",
                note="Convective cores use a hard envelope; peripheral convection remains a soft risk cost.",
            )
        },
    )
