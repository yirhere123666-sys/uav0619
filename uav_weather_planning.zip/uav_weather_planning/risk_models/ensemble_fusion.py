from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np

from uav_weather_planning.data_interface.pysteps_adapter import WeatherEnsemble
from uav_weather_planning.risk import compute_cvar
from uav_weather_planning.risk_field import RiskField4D
from .fusion import RiskFusionConfig, build_risk_field_from_weather


@dataclass(frozen=True)
class EnsembleFusionConfig:
    risk_fusion_config: RiskFusionConfig | None = None
    risk_threshold: float = 0.70
    no_fly_member_probability_limit: float = 0.50
    use_member_hard_masks: bool = True


def build_risk_field_from_weather_ensemble(
    ensemble: WeatherEnsemble,
    config: EnsembleFusionConfig | None = None,
) -> RiskField4D:
    """Build a risk field from weather ensemble members.

    Each member is mapped through the same explicit weather-risk models and
    noncompensatory fusion. Probability/CVaR are then computed from the member
    joint-risk stack, which matches the pySTEPS ensemble-nowcast reasoning:
    uncertainty is represented by weather members before risk statistics.
    """

    if not ensemble.members:
        raise ValueError("WeatherEnsemble has no members")
    config = config or EnsembleFusionConfig()
    risk_config = config.risk_fusion_config or RiskFusionConfig()
    member_fields = [build_risk_field_from_weather(member, risk_config) for member in ensemble.members]
    reference = member_fields[0]
    joint_stack = np.stack([field.joint_risk for field in member_fields], axis=0)
    no_fly_stack = np.stack([field.no_fly_mask for field in member_fields], axis=0)
    expected_joint_risk = np.mean(joint_stack, axis=0)
    member_spread = np.std(joint_stack, axis=0)
    cvar_risk = np.asarray(compute_cvar(joint_stack, alpha=risk_config.cvar_alpha, axis=0), dtype=float)
    violation_probability = np.mean(joint_stack > float(config.risk_threshold), axis=0)
    no_fly_probability = np.mean(no_fly_stack, axis=0)
    no_fly = violation_probability >= risk_config.chance_constraint_limit
    if config.use_member_hard_masks:
        no_fly = no_fly | (no_fly_probability >= config.no_fly_member_probability_limit)

    epistemic_uncertainty = np.maximum(np.mean(np.stack([field.uncertainty for field in member_fields], axis=0), axis=0), member_spread)
    expected_cost = risk_config.base_cost + risk_config.joint_risk_weight * expected_joint_risk
    total_cost = expected_cost + risk_config.cvar_lambda * cvar_risk + risk_config.uncertainty_conservative_weight * epistemic_uncertainty
    expected_cost = expected_cost.astype(float)
    total_cost = total_cost.astype(float)
    expected_cost[no_fly] = risk_config.no_fly_cost
    cvar_risk[no_fly] = risk_config.no_fly_cost
    total_cost[no_fly] = risk_config.no_fly_cost

    return RiskField4D(
        expected_cost=expected_cost,
        no_fly_mask=no_fly,
        uncertainty=epistemic_uncertainty,
        cvar_cost=cvar_risk,
        wind_risk=_mean_channel(member_fields, "wind_risk"),
        gust_risk=_mean_channel(member_fields, "gust_risk"),
        shear_risk=_mean_channel(member_fields, "shear_risk"),
        turbulence_risk=_mean_channel(member_fields, "turbulence_risk"),
        shear_turbulence_risk=_mean_channel(member_fields, "shear_turbulence_risk"),
        convection_risk=_mean_channel(member_fields, "convection_risk"),
        visibility_risk=_mean_channel(member_fields, "visibility_risk"),
        precipitation_risk=_mean_channel(member_fields, "precipitation_risk"),
        total_cost=total_cost,
        wind_u=_mean_channel(member_fields, "wind_u"),
        wind_v=_mean_channel(member_fields, "wind_v"),
        wind_w=_mean_channel(member_fields, "wind_w"),
        ground_speed_effect=_mean_channel(member_fields, "ground_speed_effect"),
        energy_penalty=_mean_channel(member_fields, "energy_penalty"),
        violation_probability=violation_probability,
        joint_risk=expected_joint_risk,
        fatal_score=_mean_channel(member_fields, "fatal_score"),
        cumulative_score=_mean_channel(member_fields, "cumulative_score"),
        weighted_soft_cost=_mean_channel(member_fields, "weighted_soft_cost"),
        coords={name: value.copy() for name, value in reference.coords.items()},
        confidence=reference.confidence.copy() if isinstance(reference.confidence, np.ndarray) else reference.confidence,
        source_metadata={
            **reference.source_metadata,
            "ensemble_source": ensemble.source,
            "ensemble_metadata": ensemble.metadata,
        },
        channel_metadata={
            **reference.channel_metadata,
            "probabilistic_risk_source": "weather_ensemble_member_statistics",
            "ensemble_member_count": ensemble.member_count,
            "ensemble_risk_formula": {
                "expected_joint_risk": "mean_m R_m",
                "violation_probability": "mean_m I(R_m > risk_threshold)",
                "cvar_cost": "CVaR_alpha({R_m})",
                "no_fly_mask": "P(R_m>threshold)>=chance_limit or P(member no-fly)>=hard-mask limit",
            },
            "ensemble_risk_threshold": config.risk_threshold,
            "no_fly_member_probability_limit": config.no_fly_member_probability_limit,
            "expected_cost_kernel": "base_cost + joint_risk_weight * mean(member joint_risk)",
        },
        metadata={
            **reference.metadata,
            "source": "weather_ensemble_risk_fusion",
            "purpose": "risk field from pySTEPS-style weather-member statistics",
            "member_count": ensemble.member_count,
        },
    )


def _mean_channel(fields: list[RiskField4D], name: str) -> np.ndarray:
    return np.mean(np.stack([np.asarray(getattr(field, name), dtype=float) for field in fields], axis=0), axis=0)
