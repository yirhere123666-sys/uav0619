from __future__ import annotations

from dataclasses import dataclass, field
import time
from typing import Any

import numpy as np

from uav_weather_planning.data_interface.weather_cube import WeatherCube
from uav_weather_planning.risk_field.risk_field_4d import RiskField4D
from uav_weather_planning.risk import compute_cvar_field
from .thresholds import load_risk_thresholds
from .common import RiskModelResult, clip01
from .convection import model_convection_risk
from .energy import model_energy_risk
from .gust import model_gust_risk
from .noncompensatory_fusion import fuse_noncompensatory, hard_mask_from_masks
from .precipitation import model_precipitation_risk
from .shear_turbulence import model_shear_turbulence_risk
from .uncertainty import model_epistemic_uncertainty
from .visibility import model_visibility_risk
from .wind import model_wind_risk


@dataclass
class RiskFusionConfig:
    weights: dict[str, float] = field(
        default_factory=lambda: {
            "wind_risk": 1.4,
            "gust_risk": 1.1,
            "shear_turbulence_risk": 1.6,
            "convection_risk": 3.5,
            "precipitation_risk": 0.9,
            "visibility_risk": 1.1,
            "energy_penalty": 0.8,
        }
    )
    cvar_alpha: float = 0.9
    cvar_lambda: float = 0.65
    base_cost: float = 1.0
    joint_risk_weight: float = 6.0
    uncertainty_conservative_weight: float = 0.05
    uncertainty_sigma0: float = 0.02
    uncertainty_beta: float = 0.55
    monte_carlo_samples: int = 64
    cvar_chunk_voxels: int = 200_000
    seed: int = 7
    no_fly_cost: float = 1e6
    chance_constraint_limit: float = 0.86
    envelope_probability_limit: float = 0.95
    thresholds: dict[str, Any] = field(default_factory=dict)
    fatal_channels: tuple[str, ...] = (
        "shear_risk",
        "shear_turbulence_risk",
        "convection_risk",
        "precipitation_risk",
        "gust_risk",
    )
    cumulative_weights: dict[str, float] = field(
        default_factory=lambda: {
            "wind_risk": 1.4,
            "visibility_risk": 1.1,
            "energy_risk": 0.8,
        }
    )


def build_risk_field_from_weather(cube: WeatherCube, config: RiskFusionConfig | None = None) -> RiskField4D:
    config = config or RiskFusionConfig()
    merged = RiskModelResult()
    threshold_source = "RiskFusionConfig.thresholds" if config.thresholds else "configs/risk_thresholds_reference.yaml"
    thresholds = config.thresholds or load_risk_thresholds()
    for result in [
        model_wind_risk(
            cube,
            safe_speed=_threshold(thresholds, "wind", "safe_mps", 5.0),
            resist_speed=_threshold(thresholds, "wind", "danger_mps", 12.0),
            safe_crosswind=_threshold(thresholds, "crosswind", "safe_mps", 4.0),
            crosswind_limit=_threshold(thresholds, "crosswind", "danger_mps", 8.0),
            extreme_speed=_threshold(thresholds, "wind", "hard_mps", 18.0),
            hard_exceedance_limit=config.envelope_probability_limit,
        ),
        model_gust_risk(
            cube,
            safe_gust=_threshold(thresholds, "gust", "safe_mps", 4.0),
            high_gust=_threshold(thresholds, "gust", "danger_mps", 13.0),
            extreme_gust=_threshold(thresholds, "gust", "hard_mps", 21.0),
            hard_exceedance_limit=config.envelope_probability_limit,
        ),
        model_shear_turbulence_risk(
            cube,
            vertical_shear_safe=_threshold(thresholds, "vertical_shear", "safe", 0.01),
            vertical_shear_limit=_threshold(thresholds, "vertical_shear", "danger", 0.035),
            extreme_shear=_threshold(thresholds, "vertical_shear", "hard", 0.075),
            hard_exceedance_limit=config.envelope_probability_limit,
        ),
        model_convection_risk(
            cube,
            soft_reflectivity=_threshold(thresholds, "convection", "reflectivity_safe_dbz", 25.0),
            danger_reflectivity=_threshold(thresholds, "convection", "reflectivity_danger_dbz", 40.0),
            hard_reflectivity=_threshold(thresholds, "convection", "reflectivity_hard_dbz", 45.0),
            hard_probability=_threshold(thresholds, "convection", "probability_hard", 0.85),
        ),
        model_precipitation_risk(
            cube,
            light_rain=_threshold(thresholds, "precipitation", "safe_mm_h", 1.0),
            heavy_rain=_threshold(thresholds, "precipitation", "danger_mm_h", 20.0),
            extreme_rain=_threshold(thresholds, "precipitation", "hard_mm_h", 45.0),
            hard_exceedance_limit=config.envelope_probability_limit,
        ),
        model_visibility_risk(
            cube,
            safe_visibility_km=_visibility_km(_threshold(thresholds, "visibility", "safe_m", 5000.0)),
            danger_visibility_km=_visibility_km(_threshold(thresholds, "visibility", "danger_m", 1000.0)),
            hard_visibility_km=_visibility_km(_threshold(thresholds, "visibility", "hard_m", 500.0)),
            hard_exceedance_limit=config.envelope_probability_limit,
        ),
        model_energy_risk(cube),
    ]:
        merged.merge(result)

    epistemic_uncertainty = model_epistemic_uncertainty(cube.shape, cube.confidence, floor=0.0, confidence_gain=0.85)
    merged.auxiliaries["epistemic_uncertainty"] = epistemic_uncertainty

    weighted_soft_cost = np.ones(cube.shape, dtype=np.float32)
    ignored_uncertainty_weight_keys: list[str] = []
    for name, weight in config.weights.items():
        if name in {"uncertainty_risk", "epistemic_uncertainty"}:
            ignored_uncertainty_weight_keys.append(name)
            continue
        if name in merged.channels:
            weighted_soft_cost += weight * merged.channels[name]
    weighted_soft_cost = weighted_soft_cost.astype(np.float32)

    fatal_score, cumulative_score, joint_risk, fusion_evidence = fuse_noncompensatory(
        merged.channels,
        fatal_channels=config.fatal_channels,
        cumulative_weights=config.cumulative_weights,
        shape=cube.shape,
    )

    expected = (float(config.base_cost) + float(config.joint_risk_weight) * joint_risk).astype(np.float32)
    cvar_start = time.perf_counter()
    cvar_cost = _monte_carlo_cvar(joint_risk, epistemic_uncertainty, config).astype(np.float32)
    cvar_elapsed_ms = (time.perf_counter() - cvar_start) * 1000.0
    tail_ratio = clip01(cvar_cost / np.maximum(joint_risk, 1e-6))
    envelope_probability = _max_exceedance_probability(merged.auxiliaries, cube.shape)
    violation_probability = clip01(
        0.70 * joint_risk
        + 0.20 * tail_ratio
        + 0.10 * envelope_probability
    )
    hard_mask = hard_mask_from_masks(merged.masks, cube.shape)
    safety_envelope = envelope_probability >= config.envelope_probability_limit
    no_fly = hard_mask | safety_envelope | (violation_probability >= config.chance_constraint_limit)
    total_cost = (
        expected
        + config.cvar_lambda * cvar_cost
        + config.uncertainty_conservative_weight * epistemic_uncertainty
    ).astype(np.float32)
    expected[no_fly] = config.no_fly_cost
    cvar_cost[no_fly] = config.no_fly_cost
    total_cost[no_fly] = config.no_fly_cost

    channels = merged.channels
    auxiliaries = merged.auxiliaries
    return RiskField4D(
        expected_cost=expected,
        no_fly_mask=no_fly,
        uncertainty=epistemic_uncertainty,
        cvar_cost=cvar_cost,
        wind_risk=channels["wind_risk"],
        gust_risk=channels["gust_risk"],
        shear_risk=channels["shear_risk"],
        turbulence_risk=channels["turbulence_risk"],
        shear_turbulence_risk=channels["shear_turbulence_risk"],
        convection_risk=channels["convection_risk"],
        visibility_risk=channels["visibility_risk"],
        precipitation_risk=channels["precipitation_risk"],
        total_cost=total_cost,
        joint_risk=joint_risk,
        fatal_score=fatal_score,
        cumulative_score=cumulative_score,
        weighted_soft_cost=weighted_soft_cost,
        wind_u=auxiliaries.get("wind_u"),
        wind_v=auxiliaries.get("wind_v"),
        wind_w=auxiliaries.get("wind_w"),
        ground_speed_effect=auxiliaries.get("ground_speed_effect"),
        energy_penalty=auxiliaries.get("energy_penalty"),
        violation_probability=violation_probability,
        coords={"time": cube.time, "height": cube.height, "y": cube.y, "x": cube.x},
        confidence=cube.confidence,
        source_metadata=cube.source_metadata,
        channel_metadata={
            "risk_masks": list(merged.masks.keys()),
            "weights": config.weights,
            "fatal_channels": list(config.fatal_channels),
            "cumulative_weights": config.cumulative_weights,
            "fusion_policy": "noncompensatory_safety_first_then_cumulative",
            "fusion_evidence": fusion_evidence,
            "cvar_alpha": config.cvar_alpha,
            "cvar_lambda": config.cvar_lambda,
            "base_cost": config.base_cost,
            "joint_risk_weight": config.joint_risk_weight,
            "expected_cost_kernel": "base_cost + joint_risk_weight * joint_risk",
            "weighted_soft_cost_role": "legacy linear weighted channel sum retained as auxiliary evidence, not the main planning risk kernel.",
            "uncertainty_role": "epistemic_distribution_width_modulator",
            "uncertainty_alias": "RiskField4D.uncertainty stores epistemic_uncertainty for backward compatibility.",
            "uncertainty_conservative_weight": config.uncertainty_conservative_weight,
            "uncertainty_sigma0": config.uncertainty_sigma0,
            "uncertainty_beta": config.uncertainty_beta,
            "ignored_uncertainty_weight_keys": ignored_uncertainty_weight_keys,
            "monte_carlo_samples": config.monte_carlo_samples,
            "cvar_chunk_voxels": config.cvar_chunk_voxels,
            "cvar_elapsed_ms": round(float(cvar_elapsed_ms), 3),
            "risk_tensor_dtype": "float32",
            "chance_constraint_limit": config.chance_constraint_limit,
            "envelope_probability_limit": config.envelope_probability_limit,
            "threshold_source": threshold_source,
            "thresholds": thresholds,
            "risk_mapping_evidence": merged.evidence,
            "safety_envelope_masks": list(merged.masks.keys()),
            "hard_mask_sources": list(merged.masks.keys()),
            "hard_mask_voxel_count": int(np.sum(hard_mask)),
            "fatal_score_max": float(np.nanmax(fatal_score)),
            "cumulative_score_max": float(np.nanmax(cumulative_score)),
            "joint_risk_max": float(np.nanmax(joint_risk)),
            "weighted_soft_cost_max": float(np.nanmax(weighted_soft_cost[np.isfinite(weighted_soft_cost)])),
        },
        metadata={
            "source": cube.source_metadata.get("source", "weather_cube"),
            "purpose": "fused multi-weather 4D risk field",
            "channels": [
                "wind_risk",
                "gust_risk",
                "shear_risk",
                "turbulence_risk",
                "shear_turbulence_risk",
                "convection_risk",
                "precipitation_risk",
                "visibility_risk",
                "energy_penalty",
                "epistemic_uncertainty",
                "joint_risk",
                "fatal_score",
                "cumulative_score",
                "weighted_soft_cost",
                "expected_cost",
                "cvar_cost",
                "total_cost",
                "violation_probability",
                "no_fly_mask",
            ],
        },
    )


def _monte_carlo_cvar(expected: np.ndarray, uncertainty: np.ndarray, config: RiskFusionConfig) -> np.ndarray:
    return compute_cvar_field(
        expected,
        uncertainty,
        alpha=config.cvar_alpha,
        n_samples=config.monte_carlo_samples,
        seed=config.seed,
        perturbation_scale=config.uncertainty_beta,
        base_sigma=config.uncertainty_sigma0,
        return_excess=True,
        chunk_voxels=config.cvar_chunk_voxels,
        dtype=np.float32,
    )


def _max_exceedance_probability(auxiliaries: dict[str, np.ndarray], shape: tuple[int, int, int, int]) -> np.ndarray:
    probabilities = [
        value
        for name, value in auxiliaries.items()
        if name.endswith("_exceedance_probability")
    ]
    if not probabilities:
        return np.zeros(shape, dtype=float)
    return clip01(np.maximum.reduce(probabilities))


def _threshold(thresholds: dict[str, Any], section: str, key: str, default: float) -> float:
    try:
        return float(thresholds.get(section, {}).get(key, default))
    except (TypeError, ValueError):
        return float(default)


def _visibility_km(value_m: float) -> float:
    return float(value_m) / 1000.0 if value_m > 50.0 else float(value_m)
