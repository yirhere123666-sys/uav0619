from __future__ import annotations

import numpy as np

from .common import clip01


def model_epistemic_uncertainty(
    shape: tuple[int, int, int, int],
    confidence: np.ndarray | float = 1.0,
    *,
    floor: float = 0.0,
    confidence_gain: float = 0.85,
) -> np.ndarray:
    """Return epistemic uncertainty as distribution width, not hazard.

    This term represents limited confidence in the weather state. It should
    modulate Monte Carlo/CVaR width and only enter cost as a small conservative
    margin; it is not a weather danger channel.
    """

    if isinstance(confidence, np.ndarray):
        base_uncertainty = 1.0 - confidence
    else:
        base_uncertainty = np.full(shape, 1.0 - float(confidence), dtype=float)
    return clip01(float(floor) + float(confidence_gain) * base_uncertainty)


def model_uncertainty_risk(channels: dict[str, np.ndarray], confidence: np.ndarray | float = 1.0) -> np.ndarray:
    """Backward-compatible alias for older callers.

    The implementation intentionally ignores hazard channels to avoid counting
    uncertainty as an additional weather danger.
    """

    sample = next(iter(channels.values()))
    return model_epistemic_uncertainty(sample.shape, confidence)
