from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np


def clip01(value: np.ndarray) -> np.ndarray:
    return np.clip(value, 0.0, 1.0)


def sigmoid(value: np.ndarray) -> np.ndarray:
    return 1.0 / (1.0 + np.exp(-value))


def normalize(value: np.ndarray, low: float, high: float) -> np.ndarray:
    if high <= low:
        raise ValueError("high must be greater than low")
    return clip01((value - low) / (high - low))


@dataclass
class RiskModelResult:
    channels: dict[str, np.ndarray] = field(default_factory=dict)
    masks: dict[str, np.ndarray] = field(default_factory=dict)
    auxiliaries: dict[str, np.ndarray] = field(default_factory=dict)
    evidence: dict[str, dict] = field(default_factory=dict)

    def merge(self, other: "RiskModelResult") -> "RiskModelResult":
        self.channels.update(other.channels)
        self.masks.update(other.masks)
        self.auxiliaries.update(other.auxiliaries)
        self.evidence.update(other.evidence)
        return self
