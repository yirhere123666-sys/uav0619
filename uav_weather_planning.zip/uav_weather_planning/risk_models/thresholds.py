from __future__ import annotations

from pathlib import Path
from typing import Any


DEFAULT_RISK_THRESHOLDS_PATH = Path("configs/risk_thresholds_reference.yaml")


def load_risk_thresholds(path: str | Path = DEFAULT_RISK_THRESHOLDS_PATH) -> dict[str, Any]:
    path = Path(path)
    if not path.exists():
        return default_risk_thresholds()
    text = path.read_text(encoding="utf-8")
    try:
        import yaml
    except ImportError:
        yaml = None
    if yaml is not None:
        data = yaml.safe_load(text) or {}
        if not isinstance(data, dict):
            raise ValueError("risk thresholds YAML must contain a mapping")
        return data
    return _parse_simple_yaml(text)


def threshold(thresholds: dict[str, Any], section: str, key: str, default: float) -> float:
    try:
        return float(thresholds.get(section, {}).get(key, default))
    except (TypeError, ValueError):
        return float(default)


def default_risk_thresholds() -> dict[str, Any]:
    return {
        "wind": {"safe_mps": 5.0, "danger_mps": 12.0, "hard_mps": 15.0},
        "gust": {"safe_mps": 8.0, "danger_mps": 14.0, "hard_mps": 18.0},
        "crosswind": {"safe_mps": 4.0, "danger_mps": 10.0, "hard_mps": 13.0},
        "vertical_shear": {"safe": 0.03, "danger": 0.10, "hard": 0.15},
        "precipitation": {"safe_mm_h": 0.5, "danger_mm_h": 10.0, "hard_mm_h": 25.0},
        "visibility": {"safe_m": 5000.0, "danger_m": 1000.0, "hard_m": 500.0},
        "convection": {
            "reflectivity_safe_dbz": 25.0,
            "reflectivity_danger_dbz": 40.0,
            "reflectivity_hard_dbz": 45.0,
            "probability_hard": 0.85,
        },
        "chance_constraint": {"violation_probability_limit": 0.85},
        "cvar": {"alpha": 0.90},
    }


def _parse_simple_yaml(text: str) -> dict[str, Any]:
    root: dict[str, Any] = {}
    stack: list[tuple[int, dict[str, Any]]] = [(-1, root)]
    for raw_line in text.splitlines():
        line = raw_line.split("#", 1)[0].rstrip()
        if not line.strip():
            continue
        indent = len(line) - len(line.lstrip(" "))
        key, _, value = line.strip().partition(":")
        while stack and indent <= stack[-1][0]:
            stack.pop()
        parent = stack[-1][1]
        if value.strip():
            parent[key] = _parse_scalar(value.strip())
        else:
            child: dict[str, Any] = {}
            parent[key] = child
            stack.append((indent, child))
    return root


def _parse_scalar(value: str) -> Any:
    if value.lower() in {"true", "false"}:
        return value.lower() == "true"
    try:
        return float(value) if "." in value else int(value)
    except ValueError:
        return value.strip('"').strip("'")
