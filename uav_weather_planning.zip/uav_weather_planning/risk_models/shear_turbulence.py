from __future__ import annotations

import numpy as np

from uav_weather_planning.data_interface.weather_cube import WeatherCube
from .common import RiskModelResult, clip01
from .mapping import hard_mask_from_exceedance, mapping_evidence, ramp_safe_danger, sigmoid_hard


def _gradient(arr: np.ndarray, axis: int, spacing: float) -> np.ndarray:
    if arr.shape[axis] <= 1:
        return np.zeros_like(arr)
    return np.gradient(arr, spacing, axis=axis, edge_order=1)


def model_shear_turbulence_risk(
    cube: WeatherCube,
    vertical_shear_safe: float = 0.01,
    vertical_shear_limit: float = 0.035,
    horizontal_gradient_safe: float = 0.05,
    horizontal_gradient_limit: float = 0.30,
    extreme_shear: float = 0.075,
    hard_exceedance_limit: float = 0.95,
) -> RiskModelResult:
    u = cube.get("u_wind")
    v = cube.get("v_wind")
    dz = float(np.mean(np.diff(cube.height))) if len(cube.height) > 1 else 100.0
    dy = float(np.mean(np.diff(cube.y))) if len(cube.y) > 1 else 1.0
    dx = float(np.mean(np.diff(cube.x))) if len(cube.x) > 1 else 1.0

    du_dz = _gradient(u, axis=1, spacing=max(abs(dz), 1.0))
    dv_dz = _gradient(v, axis=1, spacing=max(abs(dz), 1.0))
    vertical_shear = np.sqrt(du_dz * du_dz + dv_dz * dv_dz)

    du_dx = _gradient(u, axis=3, spacing=max(abs(dx), 1.0))
    du_dy = _gradient(u, axis=2, spacing=max(abs(dy), 1.0))
    dv_dx = _gradient(v, axis=3, spacing=max(abs(dx), 1.0))
    dv_dy = _gradient(v, axis=2, spacing=max(abs(dy), 1.0))
    horizontal_gradient = np.sqrt(du_dx**2 + du_dy**2 + dv_dx**2 + dv_dy**2)

    shear_risk = ramp_safe_danger(vertical_shear, vertical_shear_safe, vertical_shear_limit)
    horizontal_gradient_risk = ramp_safe_danger(horizontal_gradient, horizontal_gradient_safe, horizontal_gradient_limit)
    turbulence_risk = clip01(0.55 * shear_risk + 0.45 * horizontal_gradient_risk)
    exceedance_probability = sigmoid_hard(vertical_shear, extreme_shear, 0.012)
    no_fly = hard_mask_from_exceedance(exceedance_probability, hard_exceedance_limit)
    return RiskModelResult(
        channels={
            "shear_risk": shear_risk,
            "turbulence_risk": turbulence_risk,
            "shear_turbulence_risk": clip01(0.58 * shear_risk + 0.42 * turbulence_risk),
        },
        masks={"no_fly_extreme_shear": no_fly},
        auxiliaries={
            "vertical_shear": vertical_shear,
            "horizontal_wind_gradient": horizontal_gradient,
            "horizontal_wind_gradient_risk": horizontal_gradient_risk,
            "shear_exceedance_probability": exceedance_probability,
        },
        evidence={
            "shear_turbulence_risk": mapping_evidence(
                variable="vertical_wind_shear, horizontal_wind_gradient",
                formula=(
                    "r_shear=clip((vertical_shear-safe)/(danger-safe),0,1); "
                    "r_turb=clip(0.55*r_shear+0.45*r_horizontal_gradient,0,1); "
                    "p_hard=sigmoid((vertical_shear-hard)/0.012)"
                ),
                thresholds={
                    "vertical_shear_safe": vertical_shear_safe,
                    "vertical_shear_danger": vertical_shear_limit,
                    "vertical_shear_hard": extreme_shear,
                    "horizontal_gradient_safe": horizontal_gradient_safe,
                    "horizontal_gradient_danger": horizontal_gradient_limit,
                    "hard_probability_limit": hard_exceedance_limit,
                },
                exceedance_probability="shear_exceedance_probability",
                hard_mask="no_fly_extreme_shear",
                note="Shear is derived from vertical wind gradients; turbulence is a proxy from shear and horizontal wind-gradient risk.",
            )
        },
    )
