from __future__ import annotations

import numpy as np

from uav_weather_planning.data_interface.weather_cube import WeatherCube
from .common import RiskModelResult, clip01
from .mapping import hard_mask_from_exceedance, mapping_evidence, ramp_safe_danger, sigmoid_hard


def model_gust_risk(
    cube: WeatherCube,
    safe_gust: float = 4.0,
    high_gust: float = 13.0,
    extreme_gust: float = 21.0,
    hard_exceedance_limit: float = 0.95,
) -> RiskModelResult:
    gust = cube.get("gust")
    gust_risk = ramp_safe_danger(gust, safe_gust, high_gust)
    # Gust forecasts are usually less certain than mean wind; risk rises near threshold.
    gust_uncertainty = clip01(0.12 + 0.55 * gust_risk)
    exceedance_probability = sigmoid_hard(gust, extreme_gust, 2.5)
    no_fly = hard_mask_from_exceedance(exceedance_probability, hard_exceedance_limit)
    return RiskModelResult(
        channels={"gust_risk": gust_risk},
        masks={"no_fly_extreme_gust": no_fly},
        auxiliaries={"gust_uncertainty": gust_uncertainty, "gust_exceedance_probability": exceedance_probability},
        evidence={
            "gust_risk": mapping_evidence(
                variable="gust_speed",
                formula="r_gust=clip((gust-safe_gust)/(danger_gust-safe_gust),0,1); p_hard=sigmoid((gust-hard_gust)/2.5)",
                thresholds={
                    "safe_gust_mps": safe_gust,
                    "danger_gust_mps": high_gust,
                    "hard_gust_mps": extreme_gust,
                    "hard_probability_limit": hard_exceedance_limit,
                },
                exceedance_probability="gust_exceedance_probability",
                hard_mask="no_fly_extreme_gust",
                note="Gust risk uses a safe-danger ramp; forecast uncertainty rises with ramp risk.",
            )
        },
    )
