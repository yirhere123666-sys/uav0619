from __future__ import annotations

import numpy as np

from uav_weather_planning.data_interface.weather_cube import WeatherCube
from .common import RiskModelResult, clip01
from .mapping import hard_mask_from_exceedance, mapping_evidence, ramp_safe_danger, sigmoid_hard


def model_wind_risk(
    cube: WeatherCube,
    safe_speed: float = 5.0,
    resist_speed: float = 12.0,
    safe_crosswind: float = 4.0,
    crosswind_limit: float = 8.0,
    safe_vertical: float = 0.5,
    vertical_limit: float = 3.0,
    extreme_speed: float = 18.0,
    hard_exceedance_limit: float = 0.95,
) -> RiskModelResult:
    u = cube.get("u_wind")
    v = cube.get("v_wind")
    w = cube.get("w_wind")
    speed = np.sqrt(u * u + v * v + w * w)
    crosswind = np.sqrt(v * v + w * w)
    vertical = np.abs(w)

    speed_risk = ramp_safe_danger(speed, safe_speed, resist_speed)
    crosswind_risk = ramp_safe_danger(crosswind, safe_crosswind, crosswind_limit)
    vertical_risk = ramp_safe_danger(vertical, safe_vertical, vertical_limit)
    wind_risk = clip01(0.48 * speed_risk + 0.34 * crosswind_risk + 0.18 * vertical_risk)
    headwind = np.maximum(-u, 0.0)
    tailwind = np.maximum(u, 0.0)
    ground_speed_effect = tailwind - headwind
    energy_penalty = clip01(0.65 * headwind / resist_speed + 0.35 * vertical / vertical_limit)
    exceedance_probability = sigmoid_hard(speed, extreme_speed, 2.0)
    no_fly = hard_mask_from_exceedance(exceedance_probability, hard_exceedance_limit)

    return RiskModelResult(
        channels={"wind_risk": wind_risk},
        masks={"no_fly_extreme_wind": no_fly},
        auxiliaries={
            "wind_u": u,
            "wind_v": v,
            "wind_w": w,
            "wind_speed": speed,
            "wind_speed_risk": speed_risk,
            "crosswind_risk": crosswind_risk,
            "vertical_wind_risk": vertical_risk,
            "ground_speed_effect": ground_speed_effect,
            "energy_penalty": energy_penalty,
            "wind_exceedance_probability": exceedance_probability,
        },
        evidence={
            "wind_risk": mapping_evidence(
                variable="wind_speed, crosswind, vertical_wind",
                formula=(
                    "r_wind=clip(0.48*r_speed+0.34*r_crosswind+0.18*r_vertical,0,1); "
                    "r_i=clip((phi_i-phi_safe)/(phi_danger-phi_safe),0,1); "
                    "p_hard=sigmoid((wind_speed-phi_hard)/2.0)"
                ),
                thresholds={
                    "safe_speed_mps": safe_speed,
                    "danger_speed_mps": resist_speed,
                    "safe_crosswind_mps": safe_crosswind,
                    "danger_crosswind_mps": crosswind_limit,
                    "safe_vertical_mps": safe_vertical,
                    "danger_vertical_mps": vertical_limit,
                    "hard_speed_mps": extreme_speed,
                    "hard_probability_limit": hard_exceedance_limit,
                },
                exceedance_probability="wind_exceedance_probability",
                hard_mask="no_fly_extreme_wind",
                note="Mean wind, crosswind and vertical wind are mapped with safe-danger ramps; hard wind uses soft exceedance probability.",
            )
        },
    )
