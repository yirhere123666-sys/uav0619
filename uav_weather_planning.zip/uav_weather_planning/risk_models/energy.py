from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from uav_weather_planning.data_interface.weather_cube import WeatherCube
from .common import RiskModelResult, clip01


@dataclass(frozen=True)
class FieldEnergyConfig:
    nominal_airspeed_mps: float = 10.0
    vertical_reference_mps: float = 2.0
    gust_reference_mps: float = 12.0
    heavy_rain_reference_mmh: float = 20.0


def model_energy_risk(cube: WeatherCube, config: FieldEnergyConfig | None = None) -> RiskModelResult:
    """Direction-agnostic multirotor energy proxy for the 4D risk cube.

    Path-dependent energy is computed by the global planner. This field-level
    model estimates how much a voxel tends to increase power demand due to
    wind load, vertical air motion, gustiness, precipitation, and poor
    visibility/cloud conditions.
    """

    config = config or FieldEnergyConfig()
    u = cube.get("u_wind")
    v = cube.get("v_wind")
    w = cube.get("w_wind")
    gust = cube.get("gust")
    rain_rate = cube.get("rain_rate")
    visibility = cube.get("visibility", default=10.0)
    ceiling = cube.get("ceiling", default=800.0)

    horizontal_wind = np.sqrt(u * u + v * v)
    vertical_motion = np.abs(w)
    gust_increment = np.maximum(gust - horizontal_wind, 0.0)
    low_visibility_factor = clip01((4.0 - visibility) / 3.5)
    low_ceiling_factor = clip01((350.0 - ceiling) / 280.0)

    hover_power_factor = (
        1.0
        + 0.10 * clip01(horizontal_wind / config.nominal_airspeed_mps) ** 2
        + 0.08 * clip01(vertical_motion / config.vertical_reference_mps) ** 2
    )
    cruise_power_factor = (
        1.0
        + 0.28 * clip01(horizontal_wind / config.nominal_airspeed_mps) ** 3
        + 0.18 * clip01(gust_increment / config.gust_reference_mps)
        + 0.14 * clip01(vertical_motion / config.vertical_reference_mps)
    )
    weather_energy_factor = (
        1.0
        + 0.10 * clip01(rain_rate / config.heavy_rain_reference_mmh)
        + 0.06 * low_visibility_factor
        + 0.05 * low_ceiling_factor
    )
    estimated_power_factor = 0.42 * hover_power_factor + 0.43 * cruise_power_factor + 0.15 * weather_energy_factor
    energy_penalty = clip01((estimated_power_factor - 1.0) / 0.55)

    return RiskModelResult(
        channels={"energy_risk": energy_penalty},
        auxiliaries={
            "energy_penalty": energy_penalty,
            "hover_power_factor": hover_power_factor,
            "cruise_power_factor": cruise_power_factor,
            "weather_energy_factor": weather_energy_factor,
            "estimated_power_factor": estimated_power_factor,
        },
    )
