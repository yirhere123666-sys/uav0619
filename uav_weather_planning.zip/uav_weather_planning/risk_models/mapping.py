from __future__ import annotations

from typing import Any

import numpy as np


def clip01(value: np.ndarray) -> np.ndarray:
    return np.clip(value, 0.0, 1.0)


def ramp_safe_danger(x: np.ndarray, safe: float, danger: float) -> np.ndarray:
    """Linear ramp from safe threshold to danger threshold.

    Formula: r = clip((phi - phi_safe) / (phi_danger - phi_safe), 0, 1).
    """

    if danger <= safe:
        raise ValueError("danger threshold must be greater than safe threshold")
    return clip01((x - safe) / (danger - safe))


def ramp_low_is_danger(x: np.ndarray, safe: float, danger: float) -> np.ndarray:
    """Linear ramp for variables where smaller values are riskier."""

    if safe <= danger:
        raise ValueError("safe threshold must be greater than danger threshold")
    return clip01((safe - x) / (safe - danger))


def sigmoid_hard(x: np.ndarray, hard: float, scale: float) -> np.ndarray:
    """Soft exceedance probability for larger-is-riskier variables."""

    return 1.0 / (1.0 + np.exp(-(x - hard) / max(scale, 1e-9)))


def sigmoid_hard_low_is_danger(x: np.ndarray, hard: float, scale: float) -> np.ndarray:
    """Soft exceedance probability for smaller-is-riskier variables."""

    return 1.0 / (1.0 + np.exp(-(hard - x) / max(scale, 1e-9)))


def hard_mask_from_exceedance(p_exceed: np.ndarray, limit: float = 0.95) -> np.ndarray:
    return p_exceed >= float(limit)


def mapping_evidence(
    *,
    variable: str,
    formula: str,
    thresholds: dict[str, Any],
    exceedance_probability: str,
    hard_mask: str,
    threshold_source: str = "configs/risk_thresholds_reference.yaml",
    note: str = "",
) -> dict[str, Any]:
    return {
        "variable": variable,
        "formula": formula,
        "thresholds": thresholds,
        "exceedance_probability": exceedance_probability,
        "hard_mask": hard_mask,
        "threshold_source": threshold_source,
        "note": note,
    }
