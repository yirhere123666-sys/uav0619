from __future__ import annotations

import numpy as np

from uav_weather_planning.data_interface.weather_cube import WeatherCube
from .common import RiskModelResult, clip01
from .mapping import hard_mask_from_exceedance, mapping_evidence, ramp_low_is_danger, sigmoid_hard_low_is_danger


def model_visibility_risk(
    cube: WeatherCube,
    safe_visibility_km: float = 5.0,
    danger_visibility_km: float = 1.0,
    hard_visibility_km: float = 0.5,
    min_ceiling_m: float = 120.0,
    hard_exceedance_limit: float = 0.95,
) -> RiskModelResult:
    visibility = cube.get("visibility", default=safe_visibility_km)
    ceiling = cube.get("ceiling", default=500.0)
    relative_humidity = cube.get("relative_humidity", default=60.0)
    dewpoint_spread = cube.get("dewpoint_spread", default=8.0)
    cloud_liquid_water = cube.get("cloud_liquid_water", default=0.0)
    visibility_risk = ramp_low_is_danger(visibility, safe_visibility_km, danger_visibility_km)
    ceiling_risk = clip01((min_ceiling_m * 2.0 - ceiling) / max(min_ceiling_m * 2.0, 1.0))
    humidity_risk = clip01((relative_humidity - 82.0) / 18.0)
    dewpoint_risk = clip01((3.0 - dewpoint_spread) / 3.0)
    cloud_water_risk = clip01(cloud_liquid_water / 0.8)
    combined = clip01(
        0.52 * visibility_risk
        + 0.20 * ceiling_risk
        + 0.13 * humidity_risk
        + 0.08 * dewpoint_risk
        + 0.07 * cloud_water_risk
    )
    visibility_exceedance = sigmoid_hard_low_is_danger(visibility, hard_visibility_km, 0.35)
    ceiling_exceedance = sigmoid_hard_low_is_danger(ceiling, min_ceiling_m, 35.0)
    exceedance_probability = np.maximum(visibility_exceedance, ceiling_exceedance)
    no_fly = hard_mask_from_exceedance(exceedance_probability, hard_exceedance_limit)
    return RiskModelResult(
        channels={
            "visibility_risk": combined,
            "ceiling_risk": ceiling_risk,
            "humidity_risk": humidity_risk,
            "cloud_water_risk": cloud_water_risk,
        },
        masks={"no_fly_visibility": no_fly},
        auxiliaries={
            "visibility": visibility,
            "ceiling": ceiling,
            "relative_humidity": relative_humidity,
            "dewpoint_spread": dewpoint_spread,
            "cloud_liquid_water": cloud_liquid_water,
            "visibility_exceedance_probability": exceedance_probability,
        },
        evidence={
            "visibility_risk": mapping_evidence(
                variable="visibility, ceiling, relative_humidity, dewpoint_spread, cloud_liquid_water",
                formula=(
                    "r_vis=clip((vis_safe-vis)/(vis_safe-vis_danger),0,1); "
                    "r=clip(0.52*r_vis+0.20*r_ceiling+0.13*r_rh+0.08*r_dewpoint+0.07*r_cloud_water,0,1); "
                    "p_hard=max(sigmoid((vis_hard-vis)/0.35), sigmoid((ceiling_min-ceiling)/35.0))"
                ),
                thresholds={
                    "safe_visibility_km": safe_visibility_km,
                    "danger_visibility_km": danger_visibility_km,
                    "hard_visibility_km": hard_visibility_km,
                    "min_ceiling_m": min_ceiling_m,
                    "hard_probability_limit": hard_exceedance_limit,
                },
                exceedance_probability="visibility_exceedance_probability",
                hard_mask="no_fly_visibility",
                note="Low visibility and low ceiling use lower-is-riskier mappings; humidity/cloud terms act as fog proxies.",
            )
        },
    )
