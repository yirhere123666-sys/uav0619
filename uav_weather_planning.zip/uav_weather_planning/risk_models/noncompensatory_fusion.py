from __future__ import annotations

from typing import Any

import numpy as np

from .common import clip01


def fuse_noncompensatory(
    channels: dict[str, np.ndarray],
    *,
    fatal_channels: tuple[str, ...] | list[str],
    cumulative_weights: dict[str, float],
    shape: tuple[int, int, int, int] | None = None,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, dict[str, Any]]:
    """Safety-first fusion that prevents high-risk hazards from being diluted."""

    if shape is None:
        shape = _infer_shape(channels)
    fatal_arrays = [channels[name] for name in fatal_channels if name in channels]
    fatal_score = clip01(np.maximum.reduce(fatal_arrays)) if fatal_arrays else np.zeros(shape, dtype=float)

    cumulative_score = np.zeros(shape, dtype=float)
    weight_sum = 0.0
    used_weights: dict[str, float] = {}
    for name, weight in cumulative_weights.items():
        if name not in channels:
            continue
        cumulative_score += float(weight) * channels[name]
        weight_sum += float(weight)
        used_weights[name] = float(weight)
    cumulative_score = clip01(cumulative_score / max(weight_sum, 1e-6))
    joint_risk = clip01(np.maximum(fatal_score, cumulative_score))
    evidence = {
        "formula": {
            "fatal_score": "R_fatal=max_i r_i, i in F",
            "cumulative_score": "R_cum=sum_j w_j r_j / sum_j w_j, j in C",
            "joint_risk": "R=max(R_fatal,R_cum)",
        },
        "fatal_channels": [name for name in fatal_channels if name in channels],
        "cumulative_weights": used_weights,
        "noncompensatory_note": "Safety-critical hazards are fused by max, so high-risk convection/shear/gust/precipitation cannot be averaged away by low-risk channels.",
    }
    return fatal_score, cumulative_score, joint_risk, evidence


def hard_mask_from_masks(masks: dict[str, np.ndarray], shape: tuple[int, int, int, int]) -> np.ndarray:
    values = [np.asarray(mask, dtype=bool) for mask in masks.values()]
    if not values:
        return np.zeros(shape, dtype=bool)
    return np.logical_or.reduce(values)


def _infer_shape(channels: dict[str, np.ndarray]) -> tuple[int, int, int, int]:
    if not channels:
        raise ValueError("shape must be provided when channels are empty")
    first = next(iter(channels.values()))
    if first.ndim != 4:
        raise ValueError("risk channels must be 4D")
    return first.shape  # type: ignore[return-value]
