from __future__ import annotations

from typing import Any

import numpy as np

from .risk_field_4d import State4D


def state_to_metric(state: State4D, coords: dict[str, Any]) -> tuple[float, float, float, float]:
    """Convert (time_index, height_index, y_index, x_index) to metric coordinates."""

    t, z, y, x = state
    return (
        get_time_seconds(coords, t),
        get_height_m(coords, z),
        _axis_value(coords, "y", y),
        _axis_value(coords, "x", x),
    )


def path_to_metric(path: list[State4D], coords: dict[str, Any]) -> dict[str, np.ndarray]:
    """Return arrays for plotting a state-index path in metric coordinates."""

    if not path:
        return {
            "time_s": np.asarray([], dtype=float),
            "height_m": np.asarray([], dtype=float),
            "y_m": np.asarray([], dtype=float),
            "x_m": np.asarray([], dtype=float),
        }
    converted = [state_to_metric(state, coords) for state in path]
    time_s, height_m, y_m, x_m = zip(*converted)
    return {
        "time_s": np.asarray(time_s, dtype=float),
        "height_m": np.asarray(height_m, dtype=float),
        "y_m": np.asarray(y_m, dtype=float),
        "x_m": np.asarray(x_m, dtype=float),
    }


def get_time_seconds(coords: dict[str, Any], time_index: int) -> float:
    axis = np.asarray(coords.get("time", []))
    if axis.size == 0:
        return float(time_index)
    index = int(np.clip(time_index, 0, axis.size - 1))
    if np.issubdtype(axis.dtype, np.datetime64):
        return float((axis[index] - axis[0]).astype("timedelta64[ms]").astype(float) / 1000.0)
    try:
        return float(axis[index])
    except (TypeError, ValueError):
        return float(index)


def get_height_m(coords: dict[str, Any], height_index: int) -> float:
    return _axis_value(coords, "height", height_index)


def _axis_value(coords: dict[str, Any], name: str, index: int) -> float:
    axis = np.asarray(coords.get(name, []))
    if axis.size == 0:
        return float(index)
    idx = int(np.clip(index, 0, axis.size - 1))
    try:
        return float(axis[idx])
    except (TypeError, ValueError):
        return float(idx)
