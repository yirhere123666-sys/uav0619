from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Iterable

import numpy as np


State4D = tuple[int, int, int, int]  # (time, height, y, x)
SpatialNode = tuple[int, int, int]  # (height, y, x)


@dataclass
class RiskField4D:
    """Queryable 4D multi-channel weather risk field.

    The midterm version keeps the interface explicit and lightweight:
    every channel uses the same tensor shape, (time, height, y, x).
    """

    expected_cost: np.ndarray
    no_fly_mask: np.ndarray
    uncertainty: np.ndarray
    cvar_cost: np.ndarray
    wind_risk: np.ndarray
    shear_turbulence_risk: np.ndarray
    convection_risk: np.ndarray
    visibility_risk: np.ndarray
    precipitation_risk: np.ndarray
    metadata: dict
    gust_risk: np.ndarray | None = None
    shear_risk: np.ndarray | None = None
    turbulence_risk: np.ndarray | None = None
    total_cost: np.ndarray | None = None
    wind_u: np.ndarray | None = None
    wind_v: np.ndarray | None = None
    wind_w: np.ndarray | None = None
    ground_speed_effect: np.ndarray | None = None
    energy_penalty: np.ndarray | None = None
    violation_probability: np.ndarray | None = None
    joint_risk: np.ndarray | None = None
    fatal_score: np.ndarray | None = None
    cumulative_score: np.ndarray | None = None
    weighted_soft_cost: np.ndarray | None = None
    coords: dict[str, np.ndarray] = field(default_factory=dict)
    confidence: np.ndarray | float = 1.0
    source_metadata: dict[str, Any] = field(default_factory=dict)
    channel_metadata: dict[str, Any] = field(default_factory=dict)
    _safety_margin_cache: np.ndarray | None = field(default=None, init=False, repr=False)
    _resolution_metadata_cache: dict[str, Any] | None = field(default=None, init=False, repr=False)

    def __post_init__(self) -> None:
        shape = self.expected_cost.shape
        if len(shape) != 4:
            raise ValueError("risk tensors must have shape (time, height, y, x)")
        for name in [
            "no_fly_mask",
            "uncertainty",
            "cvar_cost",
            "wind_risk",
            "shear_turbulence_risk",
            "convection_risk",
            "visibility_risk",
            "precipitation_risk",
        ]:
            value = getattr(self, name)
            if value.shape != shape:
                raise ValueError(f"{name} shape {value.shape} does not match {shape}")
        self.no_fly_mask = self.no_fly_mask.astype(bool)
        self.gust_risk = self._default_channel(self.gust_risk, 0.0)
        self.shear_risk = self._default_channel(self.shear_risk, self.shear_turbulence_risk)
        self.turbulence_risk = self._default_channel(self.turbulence_risk, self.shear_turbulence_risk)
        self.total_cost = self._default_channel(self.total_cost, self.expected_cost + self.cvar_cost)
        self.wind_u = self._default_channel(self.wind_u, 0.0)
        self.wind_v = self._default_channel(self.wind_v, 0.0)
        self.wind_w = self._default_channel(self.wind_w, 0.0)
        self.ground_speed_effect = self._default_channel(self.ground_speed_effect, 0.0)
        self.energy_penalty = self._default_channel(self.energy_penalty, 0.0)
        self.violation_probability = self._default_channel(self.violation_probability, 0.0)
        self.joint_risk = self._default_channel(self.joint_risk, self._normalize_expected_cost(self.expected_cost))
        self.fatal_score = self._default_channel(self.fatal_score, self.joint_risk)
        self.cumulative_score = self._default_channel(self.cumulative_score, self.joint_risk)
        self.weighted_soft_cost = self._default_channel(self.weighted_soft_cost, self.expected_cost)
        for name in [
            "gust_risk",
            "shear_risk",
            "turbulence_risk",
            "total_cost",
            "wind_u",
            "wind_v",
            "wind_w",
            "ground_speed_effect",
            "energy_penalty",
            "violation_probability",
            "joint_risk",
            "fatal_score",
            "cumulative_score",
            "weighted_soft_cost",
        ]:
            value = getattr(self, name)
            if value.shape != shape:
                raise ValueError(f"{name} shape {value.shape} does not match {shape}")
        if not self.coords:
            self.coords = {
                "time": np.arange(shape[0]),
                "height": np.arange(shape[1]),
                "y": np.arange(shape[2]),
                "x": np.arange(shape[3]),
            }
        if isinstance(self.confidence, np.ndarray) and self.confidence.shape != shape:
            raise ValueError("confidence array must match risk field shape")

    def _default_channel(self, value: np.ndarray | float | None, fallback: np.ndarray | float) -> np.ndarray:
        if value is None:
            value = fallback
        if np.isscalar(value):
            return np.full(self.expected_cost.shape, float(value), dtype=float)
        return np.asarray(value, dtype=float)

    def _normalize_expected_cost(self, value: np.ndarray) -> np.ndarray:
        arr = np.asarray(value, dtype=float)
        finite = arr[np.isfinite(arr) & (arr < 1e5)]
        if finite.size == 0:
            return np.zeros_like(arr, dtype=float)
        lo = float(np.nanmin(finite))
        hi = float(np.nanmax(finite))
        if np.isclose(lo, hi):
            return np.zeros_like(arr, dtype=float)
        return np.clip((arr - lo) / (hi - lo), 0.0, 1.0)

    @property
    def shape(self) -> tuple[int, int, int, int]:
        return self.expected_cost.shape

    @property
    def t_size(self) -> int:
        return self.shape[0]

    @property
    def z_size(self) -> int:
        return self.shape[1]

    @property
    def y_size(self) -> int:
        return self.shape[2]

    @property
    def x_size(self) -> int:
        return self.shape[3]

    @classmethod
    def uniform(
        cls,
        t_size: int,
        z_size: int,
        y_size: int,
        x_size: int,
        base_cost: float = 1.0,
    ) -> "RiskField4D":
        shape = (t_size, z_size, y_size, x_size)
        zeros = np.zeros(shape, dtype=float)
        expected = np.full(shape, base_cost, dtype=float)
        return cls(
            expected_cost=expected,
            no_fly_mask=np.zeros(shape, dtype=bool),
            uncertainty=zeros.copy(),
            cvar_cost=expected.copy(),
            wind_risk=zeros.copy(),
            shear_turbulence_risk=zeros.copy(),
            convection_risk=zeros.copy(),
            visibility_risk=zeros.copy(),
            precipitation_risk=zeros.copy(),
            metadata={"source": "uniform_baseline"},
        )

    def in_bounds(self, state: State4D) -> bool:
        t, z, y, x = state
        return (
            0 <= t < self.t_size
            and 0 <= z < self.z_size
            and 0 <= y < self.y_size
            and 0 <= x < self.x_size
        )

    def clamp_time(self, t: int) -> int:
        return int(np.clip(t, 0, self.t_size - 1))

    def is_no_fly(self, state: State4D) -> bool:
        if not self.in_bounds(state):
            return True
        t, z, y, x = state
        return bool(self.no_fly_mask[t, z, y, x])

    def cost_at(self, state: State4D, use_cvar: bool = True) -> float:
        if not self.in_bounds(state) or self.is_no_fly(state):
            return float("inf")
        t, z, y, x = state
        expected = float(self.expected_cost[t, z, y, x])
        if use_cvar:
            return expected + float(self.cvar_cost[t, z, y, x])
        return expected

    def channel_at(self, channel: str, state: State4D) -> float:
        if not self.in_bounds(state):
            return float("inf")
        tensor = getattr(self, channel)
        t, z, y, x = state
        return float(tensor[t, z, y, x])

    def query_risk(self, state: State4D) -> dict[str, Any]:
        """Return the planning-facing risk bundle at one 4D state."""

        if not self.in_bounds(state):
            return {
                "is_feasible": False,
                "no_fly": True,
                "total_cost": float("inf"),
                "expected_risk": float("inf"),
                "cvar_risk": float("inf"),
                "safety_margin": 0.0,
            }
        t, z, y, x = state
        no_fly = bool(self.no_fly_mask[t, z, y, x])
        return {
            "is_feasible": not no_fly,
            "no_fly": no_fly,
            "total_cost": float(self.total_cost[t, z, y, x]),
            "expected_risk": float(self.expected_cost[t, z, y, x]),
            "cvar_risk": float(self.cvar_cost[t, z, y, x]),
            "joint_risk": float(self.joint_risk[t, z, y, x]),
            "fatal_score": float(self.fatal_score[t, z, y, x]),
            "cumulative_score": float(self.cumulative_score[t, z, y, x]),
            "weighted_soft_cost": float(self.weighted_soft_cost[t, z, y, x]),
            "wind_risk": float(self.wind_risk[t, z, y, x]),
            "gust_risk": float(self.gust_risk[t, z, y, x]),
            "shear_risk": float(self.shear_risk[t, z, y, x]),
            "turbulence_risk": float(self.turbulence_risk[t, z, y, x]),
            "convection_risk": float(self.convection_risk[t, z, y, x]),
            "precipitation_risk": float(self.precipitation_risk[t, z, y, x]),
            "visibility_risk": float(self.visibility_risk[t, z, y, x]),
            "uncertainty_risk": float(self.uncertainty[t, z, y, x]),
            "epistemic_uncertainty": float(self.uncertainty[t, z, y, x]),
            "wind_vector": (
                float(self.wind_u[t, z, y, x]),
                float(self.wind_v[t, z, y, x]),
                float(self.wind_w[t, z, y, x]),
            ),
            "ground_speed_effect": float(self.ground_speed_effect[t, z, y, x]),
            "energy_penalty": float(self.energy_penalty[t, z, y, x]),
            "violation_probability": float(self.violation_probability[t, z, y, x]),
            "safety_margin": self.safety_margin(state),
        }

    def query_risk_at(
        self,
        position_m: tuple[float, float, float] | list[float] | np.ndarray,
        time_s: float,
        *,
        return_channels: bool = True,
        include_resolution_metadata: bool = True,
    ) -> dict[str, Any]:
        """Query interpolated 4D risk at a metric position and mission time.

        position_m is ordered as (x_m, y_m, height_m). The returned metadata
        makes the scale separation explicit: regional weather risk grid,
        local planning graph, and later motion validation grid.
        """

        x_m, y_m, z_m = [float(value) for value in position_m]
        t_f = self._axis_fraction("time", float(time_s), is_time=True)
        z_f = self._axis_fraction("height", z_m)
        y_f = self._axis_fraction("y", y_m)
        x_f = self._axis_fraction("x", x_m)
        nearest = self._nearest_state(t_f, z_f, y_f, x_f)
        if self._is_grid_aligned(t_f, z_f, y_f, x_f):
            result = self.query_risk(nearest)
            result.update(
                {
                    "nearest_state": nearest,
                    "query_position_m": {"x": x_m, "y": y_m, "height": z_m},
                    "query_time_s": float(time_s),
                }
            )
            if include_resolution_metadata:
                result.update(
                    {
                        "source_resolution": self._resolution_metadata().get("weather_risk_grid"),
                        "planning_resolution": self._resolution_metadata().get("global_planning_graph"),
                        "motion_validation_resolution": self._resolution_metadata().get("motion_validation_grid"),
                    }
                )
            if not return_channels:
                for key in [
                    "wind_risk",
                    "gust_risk",
                    "shear_risk",
                    "turbulence_risk",
                    "convection_risk",
                    "precipitation_risk",
                    "visibility_risk",
                    "wind_vector",
                    "ground_speed_effect",
                    "energy_penalty",
                ]:
                    result.pop(key, None)
            return result
        no_fly = self.is_no_fly(nearest)

        result: dict[str, Any] = {
            "is_feasible": not no_fly,
            "no_fly": no_fly,
            "total_cost": self._interp_channel(self.total_cost, t_f, z_f, y_f, x_f),
            "expected_risk": self._interp_channel(self.expected_cost, t_f, z_f, y_f, x_f),
            "cvar_risk": self._interp_channel(self.cvar_cost, t_f, z_f, y_f, x_f),
            "joint_risk": self._interp_channel(self.joint_risk, t_f, z_f, y_f, x_f),
            "fatal_score": self._interp_channel(self.fatal_score, t_f, z_f, y_f, x_f),
            "cumulative_score": self._interp_channel(self.cumulative_score, t_f, z_f, y_f, x_f),
            "weighted_soft_cost": self._interp_channel(self.weighted_soft_cost, t_f, z_f, y_f, x_f),
            "uncertainty_risk": self._interp_channel(self.uncertainty, t_f, z_f, y_f, x_f),
            "epistemic_uncertainty": self._interp_channel(self.uncertainty, t_f, z_f, y_f, x_f),
            "violation_probability": self._interp_channel(self.violation_probability, t_f, z_f, y_f, x_f),
            "safety_margin": self.safety_margin(nearest),
            "nearest_state": nearest,
            "query_position_m": {"x": x_m, "y": y_m, "height": z_m},
            "query_time_s": float(time_s),
        }
        if include_resolution_metadata:
            result.update(
                {
                    "source_resolution": self._resolution_metadata().get("weather_risk_grid"),
                    "planning_resolution": self._resolution_metadata().get("global_planning_graph"),
                    "motion_validation_resolution": self._resolution_metadata().get("motion_validation_grid"),
                }
            )
        if return_channels:
            result.update(
                {
                    "wind_risk": self._interp_channel(self.wind_risk, t_f, z_f, y_f, x_f),
                    "gust_risk": self._interp_channel(self.gust_risk, t_f, z_f, y_f, x_f),
                    "shear_risk": self._interp_channel(self.shear_risk, t_f, z_f, y_f, x_f),
                    "turbulence_risk": self._interp_channel(self.turbulence_risk, t_f, z_f, y_f, x_f),
                    "convection_risk": self._interp_channel(self.convection_risk, t_f, z_f, y_f, x_f),
                    "precipitation_risk": self._interp_channel(self.precipitation_risk, t_f, z_f, y_f, x_f),
                    "visibility_risk": self._interp_channel(self.visibility_risk, t_f, z_f, y_f, x_f),
                    "wind_vector": (
                        self._interp_channel(self.wind_u, t_f, z_f, y_f, x_f),
                        self._interp_channel(self.wind_v, t_f, z_f, y_f, x_f),
                        self._interp_channel(self.wind_w, t_f, z_f, y_f, x_f),
                    ),
                    "ground_speed_effect": self._interp_channel(self.ground_speed_effect, t_f, z_f, y_f, x_f),
                    "energy_penalty": self._interp_channel(self.energy_penalty, t_f, z_f, y_f, x_f),
                }
            )
        return result

    @staticmethod
    def _is_grid_aligned(t_f: float, z_f: float, y_f: float, x_f: float) -> bool:
        return all(abs(value - round(value)) <= 1e-9 for value in (t_f, z_f, y_f, x_f))

    def _axis_fraction(self, axis_name: str, value: float, *, is_time: bool = False) -> float:
        values = self._numeric_axis(axis_name, is_time=is_time)
        if values.size <= 1:
            return 0.0
        if values[0] > values[-1]:
            values = values[::-1]
            reverse = True
        else:
            reverse = False
        if value <= values[0]:
            index = 0.0
        elif value >= values[-1]:
            index = float(values.size - 1)
        else:
            right = int(np.searchsorted(values, value, side="right"))
            left = right - 1
            span = max(float(values[right] - values[left]), 1e-9)
            index = left + float((value - values[left]) / span)
        if reverse:
            index = float(values.size - 1) - index
        return float(index)

    def _numeric_axis(self, axis_name: str, *, is_time: bool = False) -> np.ndarray:
        axis = np.asarray(self.coords.get(axis_name, np.arange(self.shape[0 if axis_name == "time" else 1])), dtype=object)
        if axis_name == "time":
            axis = np.asarray(self.coords.get("time", np.arange(self.t_size)))
            if np.issubdtype(axis.dtype, np.datetime64):
                return (axis - axis[0]).astype("timedelta64[ms]").astype(float) / 1000.0
        else:
            axis = np.asarray(
                self.coords.get(
                    axis_name,
                    np.arange({"height": self.z_size, "y": self.y_size, "x": self.x_size}[axis_name]),
                )
            )
        try:
            return axis.astype(float)
        except (TypeError, ValueError):
            return np.arange(axis.size, dtype=float)

    def _nearest_state(self, t_f: float, z_f: float, y_f: float, x_f: float) -> State4D:
        return (
            int(np.clip(round(t_f), 0, self.t_size - 1)),
            int(np.clip(round(z_f), 0, self.z_size - 1)),
            int(np.clip(round(y_f), 0, self.y_size - 1)),
            int(np.clip(round(x_f), 0, self.x_size - 1)),
        )

    def _interp_channel(self, tensor: np.ndarray, t_f: float, z_f: float, y_f: float, x_f: float) -> float:
        indices = [
            self._bounds(t_f, self.t_size),
            self._bounds(z_f, self.z_size),
            self._bounds(y_f, self.y_size),
            self._bounds(x_f, self.x_size),
        ]
        value = 0.0
        for t_i, t_w in indices[0]:
            for z_i, z_w in indices[1]:
                for y_i, y_w in indices[2]:
                    for x_i, x_w in indices[3]:
                        value += t_w * z_w * y_w * x_w * float(tensor[t_i, z_i, y_i, x_i])
        return float(value)

    @staticmethod
    def _bounds(value: float, size: int) -> list[tuple[int, float]]:
        if size <= 1:
            return [(0, 1.0)]
        lower = int(np.floor(np.clip(value, 0, size - 1)))
        upper = min(lower + 1, size - 1)
        alpha = float(np.clip(value - lower, 0.0, 1.0))
        if lower == upper:
            return [(lower, 1.0)]
        return [(lower, 1.0 - alpha), (upper, alpha)]

    def _resolution_metadata(self) -> dict[str, Any]:
        if self._resolution_metadata_cache is not None:
            return self._resolution_metadata_cache
        try:
            from uav_weather_planning.models import load_grid_hierarchy

            hierarchy = load_grid_hierarchy().as_dict()
        except Exception:
            hierarchy = {}
        axis_resolution = self._axis_resolution_metadata()
        motion_grid = self.source_metadata.get("motion_grid", {})
        geospatial_grid = self.source_metadata.get("geospatial_grid", {})
        self._resolution_metadata_cache = {
            "weather_risk_grid": {
                **dict(hierarchy.get("weather_risk_grid", {})),
                "actual_axis_resolution": axis_resolution,
                "source_metadata_grid": geospatial_grid,
            },
            "global_planning_graph": {
                **dict(hierarchy.get("global_planning_graph", {})),
                "motion_grid": motion_grid,
            },
            "motion_validation_grid": dict(hierarchy.get("motion_validation_grid", {})),
        }
        return self._resolution_metadata_cache

    def _axis_resolution_metadata(self) -> dict[str, float | None]:
        return {
            "x_resolution": self._median_axis_spacing("x"),
            "y_resolution": self._median_axis_spacing("y"),
            "height_resolution": self._median_axis_spacing("height"),
            "time_resolution_s": self._median_time_spacing_s(),
        }

    def _median_axis_spacing(self, axis_name: str) -> float | None:
        values = self._numeric_axis(axis_name)
        if values.size <= 1:
            return None
        spacing = float(np.nanmedian(np.abs(np.diff(values))))
        return spacing if np.isfinite(spacing) else None

    def _median_time_spacing_s(self) -> float | None:
        values = self._numeric_axis("time", is_time=True)
        if values.size <= 1:
            return None
        spacing = float(np.nanmedian(np.abs(np.diff(values))))
        return spacing if np.isfinite(spacing) else None

    def safety_margin(self, state: State4D, max_radius: int = 8) -> float:
        if not self.in_bounds(state):
            return 0.0
        t, z, y, x = state
        cache = self._safety_margins(max_radius=max_radius)
        return float(cache[t, z, y, x])

    def _safety_margins(self, max_radius: int = 8) -> np.ndarray:
        """Cache distance-to-no-fly margins for planning-time edge scoring."""

        if self._safety_margin_cache is not None:
            return self._safety_margin_cache

        margins = np.full(self.shape, float(max_radius), dtype=float)
        try:
            from scipy.ndimage import distance_transform_edt
        except ImportError:
            distance_transform_edt = None

        for t in range(self.t_size):
            for z in range(self.z_size):
                layer = self.no_fly_mask[t, z]
                if not np.any(layer):
                    continue
                if distance_transform_edt is not None:
                    margins[t, z] = np.minimum(distance_transform_edt(~layer), max_radius)
                else:
                    ys, xs = np.where(layer)
                    for y in range(self.y_size):
                        for x in range(self.x_size):
                            if layer[y, x]:
                                margins[t, z, y, x] = 0.0
                            else:
                                dist = np.sqrt((ys - y) ** 2 + (xs - x) ** 2)
                                margins[t, z, y, x] = min(float(np.min(dist)), max_radius)

        margins[self.no_fly_mask] = 0.0
        self._safety_margin_cache = margins
        return margins

    def update_risk_field(self, updates: dict[str, np.ndarray], metadata: dict[str, Any] | None = None) -> None:
        """Update one or more channels in-place for online replanning."""

        for name, value in updates.items():
            if not hasattr(self, name):
                raise ValueError(f"unknown risk channel: {name}")
            arr = np.asarray(value)
            if arr.shape != self.shape:
                raise ValueError(f"{name} update shape {arr.shape} does not match {self.shape}")
            setattr(self, name, arr.astype(bool) if name == "no_fly_mask" else arr.astype(float))
            if name == "no_fly_mask":
                self._safety_margin_cache = None
        if metadata:
            self.channel_metadata.setdefault("updates", []).append(metadata)

    def as_static_snapshot(self, time_index: int = 0) -> "RiskField4D":
        """Repeat one weather snapshot across time for static-risk baselines."""

        t = self.clamp_time(time_index)

        def repeat(tensor: np.ndarray) -> np.ndarray:
            return np.repeat(tensor[t : t + 1], self.t_size, axis=0)

        return RiskField4D(
            expected_cost=repeat(self.expected_cost),
            no_fly_mask=repeat(self.no_fly_mask),
            uncertainty=repeat(self.uncertainty),
            cvar_cost=repeat(self.cvar_cost),
            wind_risk=repeat(self.wind_risk),
            gust_risk=repeat(self.gust_risk),
            shear_risk=repeat(self.shear_risk),
            turbulence_risk=repeat(self.turbulence_risk),
            shear_turbulence_risk=repeat(self.shear_turbulence_risk),
            convection_risk=repeat(self.convection_risk),
            visibility_risk=repeat(self.visibility_risk),
            precipitation_risk=repeat(self.precipitation_risk),
            total_cost=repeat(self.total_cost),
            wind_u=repeat(self.wind_u),
            wind_v=repeat(self.wind_v),
            wind_w=repeat(self.wind_w),
            ground_speed_effect=repeat(self.ground_speed_effect),
            energy_penalty=repeat(self.energy_penalty),
            violation_probability=repeat(self.violation_probability),
            coords=self.coords,
            confidence=repeat(self.confidence) if isinstance(self.confidence, np.ndarray) else self.confidence,
            source_metadata=self.source_metadata,
            channel_metadata=self.channel_metadata,
            metadata={**self.metadata, "source": "static_snapshot", "snapshot_time": t},
        )

    def raw_changed_voxels(self, other: "RiskField4D", epsilon: float = 1e-6) -> np.ndarray:
        """Return all numerically changed voxels, including tiny float drift."""

        if self.shape != other.shape:
            raise ValueError("risk fields must have the same shape")
        expected_changed = np.abs(self.expected_cost - other.expected_cost) > epsilon
        mask_changed = self.no_fly_mask != other.no_fly_mask
        cvar_changed = np.abs(self.cvar_cost - other.cvar_cost) > epsilon
        total_changed = np.abs(self.total_cost - other.total_cost) > epsilon
        violation_changed = np.abs(self.violation_probability - other.violation_probability) > epsilon
        return expected_changed | mask_changed | cvar_changed | total_changed | violation_changed

    def significant_changed_voxels(
        self,
        other: "RiskField4D",
        *,
        total_cost_threshold: float = 0.3,
        cvar_threshold: float = 0.2,
        violation_probability_threshold: float = 0.1,
    ) -> np.ndarray:
        """Return voxels whose risk change is large enough to affect replanning."""

        if self.shape != other.shape:
            raise ValueError("risk fields must have the same shape")
        significant_cost_changed = np.abs(self.total_cost - other.total_cost) > total_cost_threshold
        mask_changed = self.no_fly_mask != other.no_fly_mask
        cvar_changed = np.abs(self.cvar_cost - other.cvar_cost) > cvar_threshold
        violation_changed = np.abs(self.violation_probability - other.violation_probability) > violation_probability_threshold
        return significant_cost_changed | mask_changed | cvar_changed | violation_changed

    def changed_voxels(self, other: "RiskField4D", *, significant: bool = True) -> np.ndarray:
        """Return changed voxels for planning updates.

        By default this reports significant risk changes, not tiny numerical
        drift. Use raw_changed_voxels() when auditing all float differences.
        """

        if significant:
            return self.significant_changed_voxels(other)
        return self.raw_changed_voxels(other)

    def iter_no_fly_xy(self, time_index: int, height_index: int) -> Iterable[tuple[int, int]]:
        t = self.clamp_time(time_index)
        z = int(np.clip(height_index, 0, self.z_size - 1))
        ys, xs = np.where(self.no_fly_mask[t, z])
        return zip(ys.tolist(), xs.tolist())

    def to_xarray(self):
        try:
            import xarray as xr
        except ImportError as exc:
            raise ImportError("xarray is required for RiskField4D.to_xarray()") from exc

        coords = {
            "time": self.coords.get("time", np.arange(self.t_size)),
            "height": self.coords.get("height", np.arange(self.z_size)),
            "y": self.coords.get("y", np.arange(self.y_size)),
            "x": self.coords.get("x", np.arange(self.x_size)),
        }
        dims = ("time", "height", "y", "x")
        data_vars = {
            "expected_cost": (dims, self.expected_cost),
            "total_cost": (dims, self.total_cost),
            "cvar_cost": (dims, self.cvar_cost),
            "no_fly_mask": (dims, self.no_fly_mask.astype(np.int8)),
            "uncertainty": (dims, self.uncertainty),
            "wind_risk": (dims, self.wind_risk),
            "gust_risk": (dims, self.gust_risk),
            "shear_risk": (dims, self.shear_risk),
            "turbulence_risk": (dims, self.turbulence_risk),
            "shear_turbulence_risk": (dims, self.shear_turbulence_risk),
            "convection_risk": (dims, self.convection_risk),
            "precipitation_risk": (dims, self.precipitation_risk),
            "visibility_risk": (dims, self.visibility_risk),
            "wind_u": (dims, self.wind_u),
            "wind_v": (dims, self.wind_v),
            "wind_w": (dims, self.wind_w),
            "ground_speed_effect": (dims, self.ground_speed_effect),
            "energy_penalty": (dims, self.energy_penalty),
            "violation_probability": (dims, self.violation_probability),
        }
        return xr.Dataset(data_vars=data_vars, coords=coords, attrs={"metadata": str(self.metadata)})

    @classmethod
    def from_xarray(cls, dataset) -> "RiskField4D":
        dims = ("time", "height", "y", "x")

        def arr(name: str, default: float | None = None):
            if name in dataset:
                return dataset[name].transpose(*dims).values
            if default is None:
                raise ValueError(f"missing required risk variable: {name}")
            shape = tuple(dataset.sizes[d] for d in dims)
            return np.full(shape, default, dtype=float)

        return cls(
            expected_cost=arr("expected_cost"),
            no_fly_mask=arr("no_fly_mask", 0).astype(bool),
            uncertainty=arr("uncertainty"),
            cvar_cost=arr("cvar_cost"),
            wind_risk=arr("wind_risk"),
            gust_risk=arr("gust_risk", 0.0),
            shear_risk=arr("shear_risk", 0.0),
            turbulence_risk=arr("turbulence_risk", 0.0),
            shear_turbulence_risk=arr("shear_turbulence_risk"),
            convection_risk=arr("convection_risk"),
            visibility_risk=arr("visibility_risk"),
            precipitation_risk=arr("precipitation_risk"),
            total_cost=arr("total_cost", 0.0),
            wind_u=arr("wind_u", 0.0),
            wind_v=arr("wind_v", 0.0),
            wind_w=arr("wind_w", 0.0),
            ground_speed_effect=arr("ground_speed_effect", 0.0),
            energy_penalty=arr("energy_penalty", 0.0),
            violation_probability=arr("violation_probability", 0.0),
            coords={name: dataset[name].values for name in dims if name in dataset.coords},
            metadata={"source": "xarray_dataset"},
        )


def _sigmoid(x: np.ndarray) -> np.ndarray:
    return 1.0 / (1.0 + np.exp(-x))


def make_midterm_synthetic_field(
    t_size: int = 60,
    z_size: int = 3,
    y_size: int = 45,
    x_size: int = 45,
    include_dynamic_storm: bool = True,
    include_static_barrier: bool = True,
) -> RiskField4D:
    """Build a deterministic 4D field for midterm experiments.

    The field is intentionally explainable:
    - wind and shear create soft, continuous risk;
    - a moving convection cell creates hard no-fly voxels;
    - uncertainty and CVaR rise around the storm edge.
    """

    t_grid = np.arange(t_size)[:, None, None, None]
    z_grid = np.arange(z_size)[None, :, None, None]
    y_grid = np.arange(y_size)[None, None, :, None]
    x_grid = np.arange(x_size)[None, None, None, :]

    y_mid = (y_size - 1) / 2.0
    x_mid = (x_size - 1) / 2.0

    crosswind_band = np.exp(-((y_grid - y_mid) ** 2) / (2.0 * 7.0**2))
    headwind_zone = np.exp(-((x_grid - 0.66 * x_size) ** 2) / (2.0 * 5.5**2))
    altitude_factor = 0.75 + 0.25 * z_grid
    wind_risk = np.broadcast_to(
        np.clip(0.10 + 0.32 * crosswind_band + 0.20 * headwind_zone * altitude_factor, 0, 1),
        (t_size, z_size, y_size, x_size),
    ).copy()

    shear_center = 0.35 * y_size + 0.15 * t_grid
    shear_band = np.exp(-((y_grid - shear_center) ** 2) / (2.0 * 3.5**2))
    shear_risk = np.broadcast_to(
        np.clip(0.08 + 0.40 * shear_band * (0.7 + 0.2 * z_grid), 0, 1),
        (t_size, z_size, y_size, x_size),
    ).copy()

    visibility_blob = np.exp(
        -(((y_grid - 0.72 * y_size) ** 2) + ((x_grid - 0.28 * x_size) ** 2))
        / (2.0 * 6.0**2)
    )
    visibility_risk = np.broadcast_to(
        np.clip(0.05 + 0.45 * visibility_blob, 0, 1),
        (t_size, z_size, y_size, x_size),
    ).copy()

    precipitation_risk = np.broadcast_to(
        np.clip(0.04 + 0.18 * _sigmoid((x_grid - 0.55 * x_size) / 3.5), 0, 1),
        (t_size, z_size, y_size, x_size),
    ).copy()

    convection_risk = np.zeros((t_size, z_size, y_size, x_size), dtype=float)
    no_fly = np.zeros_like(convection_risk, dtype=bool)

    if include_static_barrier:
        # A static restricted cell makes the baseline route visibly non-trivial.
        static_core = ((y_grid - 16.0) ** 2 + (x_grid - 17.0) ** 2) ** 0.5
        static_outer = np.broadcast_to(np.clip(1.0 - static_core / 8.0, 0, 1), convection_risk.shape)
        convection_risk = np.maximum(convection_risk, 0.45 * static_outer)
        no_fly |= np.broadcast_to(static_core < 3.8, convection_risk.shape)

    if include_dynamic_storm:
        for t in range(t_size):
            center_y = 13.0 + 0.45 * t
            center_x = 9.0 + 0.55 * t
            radius = 4.2 + 0.8 * np.sin(t / 8.0)
            dist = np.sqrt((np.arange(y_size)[:, None] - center_y) ** 2 + (np.arange(x_size)[None, :] - center_x) ** 2)
            outer = np.clip(1.0 - dist / (radius + 5.0), 0, 1)
            core = dist < radius
            for z in range(z_size):
                z_scale = 1.0 if z <= 1 else 0.78
                convection_risk[t, z] = np.maximum(convection_risk[t, z], z_scale * outer)
                no_fly[t, z] |= core & (z <= 1)

    uncertainty = np.clip(
        0.08 + 0.35 * convection_risk + 0.15 * shear_risk + 0.08 * precipitation_risk,
        0,
        1,
    )
    expected_cost = (
        1.0
        + 2.0 * wind_risk
        + 2.8 * shear_risk
        + 6.0 * convection_risk
        + 1.4 * visibility_risk
        + 1.2 * precipitation_risk
        + 1.5 * uncertainty
    )
    expected_cost = expected_cost.astype(float)
    expected_cost[no_fly] = 1e6
    cvar_cost = (0.7 * uncertainty + 0.8 * convection_risk + 0.25 * shear_risk).astype(float)
    cvar_cost[no_fly] = 1e6

    return RiskField4D(
        expected_cost=expected_cost,
        no_fly_mask=no_fly,
        uncertainty=uncertainty,
        cvar_cost=cvar_cost,
        wind_risk=wind_risk,
        shear_turbulence_risk=shear_risk,
        convection_risk=convection_risk,
        visibility_risk=visibility_risk,
        precipitation_risk=precipitation_risk,
        metadata={
            "source": "deterministic_midterm_synthetic",
            "purpose": "global planning and dynamic replanning demonstration",
            "channels": [
                "expected_cost",
                "no_fly_mask",
                "uncertainty",
                "cvar_cost",
                "wind_risk",
                "shear_turbulence_risk",
                "convection_risk",
                "visibility_risk",
                "precipitation_risk",
            ],
        },
    )
