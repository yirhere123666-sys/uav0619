from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any

import numpy as np

from uav_weather_planning.global_planner import FlightConstraints
from uav_weather_planning.risk_field import RiskField4D
from uav_weather_planning.risk_field.risk_field_4d import State4D
from .bspline_smoother import ContinuousTrajectory


@dataclass
class TrajectoryLimitSet:
    max_speed_mps: float = 15.0
    max_horizontal_speed_mps: float = 15.0
    max_climb_rate_mps: float = 3.0
    max_descent_rate_mps: float = 3.0
    max_acceleration_mps2: float = 4.0
    max_jerk_mps3: float = 8.0
    min_safety_margin_cells: float = 0.0

    @classmethod
    def from_constraints(cls, constraints: FlightConstraints | None = None) -> "TrajectoryLimitSet":
        constraints = constraints or FlightConstraints()
        return cls(
            max_speed_mps=constraints.max_ground_speed_mps or 15.0,
            max_horizontal_speed_mps=constraints.max_ground_speed_mps or 15.0,
            max_climb_rate_mps=constraints.max_climb_rate_mps or 3.0,
            max_descent_rate_mps=constraints.max_descent_rate_mps or 3.0,
            max_acceleration_mps2=constraints.max_acceleration_mps2 or 4.0,
            max_jerk_mps3=8.0,
            min_safety_margin_cells=max(constraints.min_safety_margin_cells, 0.0),
        )

    def as_dict(self) -> dict[str, float]:
        return asdict(self)


@dataclass
class TrajectoryCheckReport:
    valid: bool
    violations: list[dict[str, Any]]
    metrics: dict[str, Any]
    limits: dict[str, float]
    sampled_states: list[State4D]

    def as_dict(self) -> dict[str, Any]:
        return {
            "valid": self.valid,
            "violations": self.violations,
            "metrics": self.metrics,
            "limits": self.limits,
            "sampled_states": self.sampled_states,
        }


class KinodynamicTrajectoryChecker:
    """Audit a continuous trajectory against multirotor and risk-field constraints."""

    def __init__(
        self,
        risk_field: RiskField4D | None = None,
        constraints: FlightConstraints | None = None,
        limits: TrajectoryLimitSet | None = None,
    ) -> None:
        self.risk_field = risk_field
        self.constraints = constraints or FlightConstraints()
        self.limits = limits or TrajectoryLimitSet.from_constraints(self.constraints)

    def check(self, trajectory: ContinuousTrajectory, risk_field: RiskField4D | None = None) -> TrajectoryCheckReport:
        field = risk_field or self.risk_field
        states = self._sample_states(trajectory, field) if field is not None else []
        risk_metrics = self._risk_metrics(states, field, trajectory) if field is not None else {}
        metrics = {
            **trajectory.as_summary(),
            **risk_metrics,
        }
        violations = self._kinodynamic_violations(trajectory)
        if field is not None:
            violations.extend(self._risk_violations(states, field))
        return TrajectoryCheckReport(
            valid=len(violations) == 0,
            violations=violations,
            metrics=metrics,
            limits=self.limits.as_dict(),
            sampled_states=states,
        )

    def _kinodynamic_violations(self, trajectory: ContinuousTrajectory) -> list[dict[str, Any]]:
        checks = [
            ("speed", trajectory.speed_mps, self.limits.max_speed_mps, "m/s"),
            ("horizontal_speed", trajectory.horizontal_speed_mps, self.limits.max_horizontal_speed_mps, "m/s"),
            ("climb_rate", np.maximum(trajectory.climb_rate_mps, 0.0), self.limits.max_climb_rate_mps, "m/s"),
            ("descent_rate", np.maximum(-trajectory.climb_rate_mps, 0.0), self.limits.max_descent_rate_mps, "m/s"),
            ("acceleration", trajectory.acceleration_norm_mps2, self.limits.max_acceleration_mps2, "m/s^2"),
            ("jerk", trajectory.jerk_norm_mps3, self.limits.max_jerk_mps3, "m/s^3"),
        ]
        violations: list[dict[str, Any]] = []
        for name, values, limit, unit in checks:
            mask = values > limit + 1e-9
            if np.any(mask):
                violations.append(
                    {
                        "type": name,
                        "count": int(np.sum(mask)),
                        "max_value": round(float(np.nanmax(values)), 3),
                        "limit": float(limit),
                        "unit": unit,
                    }
                )
        return violations

    def _risk_violations(self, states: list[State4D], risk_field: RiskField4D) -> list[dict[str, Any]]:
        if not states:
            return []
        no_fly = [state for state in states if risk_field.is_no_fly(state)]
        violations: list[dict[str, Any]] = []
        if no_fly:
            violations.append(
                {
                    "type": "no_fly_mask",
                    "count": len(no_fly),
                    "max_value": 1.0,
                    "limit": 0.0,
                    "unit": "samples",
                }
            )
        margins = np.asarray([risk_field.safety_margin(state) for state in states], dtype=float)
        low_margin = margins < self.limits.min_safety_margin_cells
        if np.any(low_margin):
            violations.append(
                {
                    "type": "safety_margin",
                    "count": int(np.sum(low_margin)),
                    "max_value": round(float(np.nanmin(margins)), 3),
                    "limit": float(self.limits.min_safety_margin_cells),
                    "unit": "grid_cells",
                }
            )
        return violations

    def _risk_metrics(
        self,
        states: list[State4D],
        risk_field: RiskField4D,
        trajectory: ContinuousTrajectory,
    ) -> dict[str, Any]:
        if not states:
            return {
                "sampled_no_fly_hits": 0,
                "max_total_cost": None,
                "mean_total_cost": None,
                "min_safety_margin_cells": None,
            }
        total_cost = np.asarray([risk_field.total_cost[state] for state in states], dtype=float)
        margins = np.asarray([risk_field.safety_margin(state) for state in states], dtype=float)
        no_fly_hits = sum(1 for state in states if risk_field.is_no_fly(state))
        audit = self.constraints.audit_path(trajectory.source_path, risk_field)
        return {
            "sampled_no_fly_hits": int(no_fly_hits),
            "max_total_cost": round(float(np.nanmax(total_cost)), 3),
            "mean_total_cost": round(float(np.nanmean(total_cost)), 3),
            "min_safety_margin_cells": round(float(np.nanmin(margins)), 3),
            "source_path_constraint_audit": audit,
        }

    def _sample_states(self, trajectory: ContinuousTrajectory, risk_field: RiskField4D) -> list[State4D]:
        x_axis = np.asarray(risk_field.coords.get("x", np.arange(risk_field.x_size)), dtype=float)
        y_axis = np.asarray(risk_field.coords.get("y", np.arange(risk_field.y_size)), dtype=float)
        z_axis = np.asarray(risk_field.coords.get("height", np.arange(risk_field.z_size)), dtype=float)
        time_axis = self._numeric_time_axis(risk_field)
        time_origin = float(trajectory.metadata.get("time_origin_s", 0.0))
        states: list[State4D] = []
        for t_rel, xyz in zip(trajectory.time_s, trajectory.position_m):
            absolute_time = time_origin + float(t_rel)
            state = (
                _nearest_index(time_axis, absolute_time),
                _nearest_index(z_axis, float(xyz[2])),
                _nearest_index(y_axis, float(xyz[1])),
                _nearest_index(x_axis, float(xyz[0])),
            )
            if risk_field.in_bounds(state):
                states.append(state)
        return states

    @staticmethod
    def _numeric_time_axis(risk_field: RiskField4D) -> np.ndarray:
        axis = np.asarray(risk_field.coords.get("time", np.arange(risk_field.t_size)))
        if axis.size == 0:
            return np.arange(risk_field.t_size, dtype=float)
        if np.issubdtype(axis.dtype, np.datetime64):
            origin = axis[0]
            return np.asarray([(value - origin).astype("timedelta64[ms]").astype(float) / 1000.0 for value in axis], dtype=float)
        try:
            return axis.astype(float)
        except (TypeError, ValueError):
            return np.arange(risk_field.t_size, dtype=float)


def _nearest_index(axis: np.ndarray, value: float) -> int:
    if axis.size == 0:
        return 0
    return int(np.argmin(np.abs(axis - value)))

