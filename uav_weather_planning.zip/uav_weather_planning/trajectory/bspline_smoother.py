from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import numpy as np

from uav_weather_planning.global_planner import FlightConstraints
from uav_weather_planning.risk_field import RiskField4D
from uav_weather_planning.risk_field.risk_field_4d import State4D


@dataclass
class BSplineSmoothingConfig:
    degree: int = 3
    sample_dt_s: float = 0.5
    fallback_step_s: float = 1.0


@dataclass
class ContinuousTrajectory:
    """Continuous trajectory sampled from a B-spline representation."""

    time_s: np.ndarray
    position_m: np.ndarray
    velocity_mps: np.ndarray
    acceleration_mps2: np.ndarray
    jerk_mps3: np.ndarray
    source_path: list[State4D]
    degree: int
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def horizontal_speed_mps(self) -> np.ndarray:
        return np.linalg.norm(self.velocity_mps[:, :2], axis=1)

    @property
    def speed_mps(self) -> np.ndarray:
        return np.linalg.norm(self.velocity_mps, axis=1)

    @property
    def climb_rate_mps(self) -> np.ndarray:
        return self.velocity_mps[:, 2]

    @property
    def acceleration_norm_mps2(self) -> np.ndarray:
        return np.linalg.norm(self.acceleration_mps2, axis=1)

    @property
    def jerk_norm_mps3(self) -> np.ndarray:
        return np.linalg.norm(self.jerk_mps3, axis=1)

    def as_summary(self) -> dict[str, Any]:
        return {
            "sample_count": int(len(self.time_s)),
            "duration_s": float(self.time_s[-1] - self.time_s[0]) if len(self.time_s) > 1 else 0.0,
            "degree": int(self.degree),
            "max_speed_mps": _max_or_zero(self.speed_mps),
            "max_horizontal_speed_mps": _max_or_zero(self.horizontal_speed_mps),
            "max_climb_rate_mps": _max_or_zero(np.maximum(self.climb_rate_mps, 0.0)),
            "max_descent_rate_mps": _max_or_zero(np.maximum(-self.climb_rate_mps, 0.0)),
            "max_acceleration_mps2": _max_or_zero(self.acceleration_norm_mps2),
            "max_jerk_mps3": _max_or_zero(self.jerk_norm_mps3),
            "metadata": self.metadata,
        }


class BSplineSmoother:
    """Convert a discrete global 4D path into a sampled continuous trajectory."""

    def __init__(
        self,
        risk_field: RiskField4D,
        constraints: FlightConstraints | None = None,
        config: BSplineSmoothingConfig | None = None,
    ) -> None:
        self.risk_field = risk_field
        self.constraints = constraints or FlightConstraints()
        self.config = config or BSplineSmoothingConfig()

    def smooth(self, path: list[State4D]) -> ContinuousTrajectory:
        if len(path) < 2:
            raise ValueError("B-spline smoothing requires at least two path states")
        knot_time = np.asarray([self._time_seconds(state) for state in path], dtype=float)
        knot_time = _strictly_increasing(knot_time, min_step=max(self.config.fallback_step_s, 1e-6))
        points = np.asarray([self.constraints.xyz_m(self.risk_field, state) for state in path], dtype=float)
        sample_dt = max(float(self.config.sample_dt_s), 1e-6)
        sample_time = np.arange(knot_time[0], knot_time[-1] + 0.5 * sample_dt, sample_dt, dtype=float)
        if sample_time[-1] < knot_time[-1]:
            sample_time = np.append(sample_time, knot_time[-1])

        degree = max(1, min(int(self.config.degree), len(path) - 1))
        position, velocity, acceleration, jerk, method = self._evaluate_spline(knot_time, points, sample_time, degree)
        return ContinuousTrajectory(
            time_s=sample_time - sample_time[0],
            position_m=position,
            velocity_mps=velocity,
            acceleration_mps2=acceleration,
            jerk_mps3=jerk,
            source_path=list(path),
            degree=degree,
            metadata={
                "method": method,
                "input_waypoints": len(path),
                "risk_field_shape": self.risk_field.shape,
                "time_origin_s": float(sample_time[0]),
                "sample_dt_s": sample_dt,
            },
        )

    def _evaluate_spline(
        self,
        knot_time: np.ndarray,
        points: np.ndarray,
        sample_time: np.ndarray,
        degree: int,
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, str]:
        try:
            from scipy.interpolate import make_interp_spline
        except ImportError:
            return self._evaluate_linear(knot_time, points, sample_time)

        spline = make_interp_spline(knot_time, points, k=degree, axis=0)
        position = np.asarray(spline(sample_time), dtype=float)
        velocity = np.asarray(spline.derivative(1)(sample_time), dtype=float)
        if degree >= 2:
            acceleration = np.asarray(spline.derivative(2)(sample_time), dtype=float)
        else:
            acceleration = _finite_difference(velocity, sample_time)
        if degree >= 3:
            jerk = np.asarray(spline.derivative(3)(sample_time), dtype=float)
        else:
            jerk = _finite_difference(acceleration, sample_time)
        return position, velocity, acceleration, jerk, "scipy.make_interp_spline"

    @staticmethod
    def _evaluate_linear(
        knot_time: np.ndarray,
        points: np.ndarray,
        sample_time: np.ndarray,
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, str]:
        position = np.column_stack([np.interp(sample_time, knot_time, points[:, axis]) for axis in range(3)])
        velocity = _finite_difference(position, sample_time)
        acceleration = _finite_difference(velocity, sample_time)
        jerk = _finite_difference(acceleration, sample_time)
        return position, velocity, acceleration, jerk, "linear_fallback"

    def _time_seconds(self, state: State4D) -> float:
        time_axis = np.asarray(self.risk_field.coords.get("time", np.arange(self.risk_field.t_size)))
        t = state[0]
        if t >= len(time_axis):
            return float(t)
        value = time_axis[t]
        if np.issubdtype(time_axis.dtype, np.datetime64):
            origin = time_axis[0]
            return float((value - origin).astype("timedelta64[ms]").astype(float) / 1000.0)
        try:
            return float(value)
        except (TypeError, ValueError):
            return float(t)


def _strictly_increasing(values: np.ndarray, min_step: float) -> np.ndarray:
    fixed = values.astype(float).copy()
    for idx in range(1, len(fixed)):
        if fixed[idx] <= fixed[idx - 1]:
            fixed[idx] = fixed[idx - 1] + min_step
    return fixed


def _finite_difference(values: np.ndarray, time_s: np.ndarray) -> np.ndarray:
    if len(values) < 2:
        return np.zeros_like(values)
    return np.gradient(values, time_s, axis=0, edge_order=1)


def _max_or_zero(values: np.ndarray) -> float:
    if values.size == 0:
        return 0.0
    return round(float(np.nanmax(values)), 3)
