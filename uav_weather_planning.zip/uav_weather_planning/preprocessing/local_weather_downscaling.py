from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any

import numpy as np

from uav_weather_planning.data_interface.weather_cube import WeatherCube


@dataclass(frozen=True)
class LocalDownscalingConfig:
    y_size: int = 32
    x_size: int = 32
    height_levels_m: tuple[float, ...] = (60.0, 120.0, 180.0, 240.0)
    uncertainty_gain_per_km: float = 0.015
    add_local_perturbations: bool = True
    perturbation_seed: int = 20260611
    perturbation_strength: float = 1.0

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


def downscale_weather_cube_to_local_grid(
    cube: WeatherCube,
    config: LocalDownscalingConfig | None = None,
) -> WeatherCube:
    """Map regional weather background to a local low-altitude planning grid."""

    config = config or LocalDownscalingConfig()
    y_target = _target_axis(cube.y, config.y_size)
    x_target = _target_axis(cube.x, config.x_size)
    z_target = np.asarray(config.height_levels_m, dtype=float)
    variables = {
        name: _interp_tzyx(value, cube.height, cube.y, cube.x, z_target, y_target, x_target)
        for name, value in cube.variables.items()
    }
    confidence = _downscale_confidence(cube, variables[next(iter(variables))].shape, config)
    if isinstance(cube.confidence, np.ndarray):
        confidence = np.minimum(confidence, _interp_tzyx(cube.confidence, cube.height, cube.y, cube.x, z_target, y_target, x_target))
    else:
        confidence = np.minimum(confidence, float(cube.confidence))
    if config.add_local_perturbations:
        variables, confidence = _add_low_altitude_perturbations(variables, confidence, config)
    source_metadata = {
        **cube.source_metadata,
        "downscaling_method": "bilinear-horizontal + vertical-linear interpolation to local low-altitude planning grid",
        "local_downscaling": {
            **config.as_dict(),
            "source_shape": list(cube.shape),
            "target_shape": [int(len(cube.time)), int(len(z_target)), int(len(y_target)), int(len(x_target))],
            "uncertainty_inflation": "confidence reduced according to source horizontal spacing and local perturbation strength",
            "local_perturbation_role": (
                "synthetic_local_perturbation for unresolved low-altitude gust/shear variability"
                if config.add_local_perturbations
                else "disabled"
            ),
        },
        "grid": "regional_background_downscaled_to_local_low_altitude_grid",
    }
    return WeatherCube(
        time=cube.time.copy(),
        height=z_target,
        y=y_target,
        x=x_target,
        variables=variables,
        source_metadata=source_metadata,
        confidence=confidence,
    )


def _interp_tzyx(
    arr: np.ndarray,
    z_source: np.ndarray,
    y_source: np.ndarray,
    x_source: np.ndarray,
    z_target: np.ndarray,
    y_target: np.ndarray,
    x_target: np.ndarray,
) -> np.ndarray:
    arr = np.asarray(arr, dtype=float)
    z_source, arr = _sort_axis_with_array(z_source, arr, axis_index=1)
    y_source, arr = _sort_axis_with_array(y_source, arr, axis_index=2)
    x_source, arr = _sort_axis_with_array(x_source, arr, axis_index=3)
    z_target = np.asarray(z_target, dtype=float)
    y_target = np.asarray(y_target, dtype=float)
    x_target = np.asarray(x_target, dtype=float)
    t_size = arr.shape[0]
    tmp_z = np.zeros((t_size, len(z_target), arr.shape[2], arr.shape[3]), dtype=float)
    for t in range(t_size):
        for y in range(arr.shape[2]):
            for x in range(arr.shape[3]):
                tmp_z[t, :, y, x] = np.interp(z_target, z_source, arr[t, :, y, x])
    tmp_y = np.zeros((t_size, len(z_target), len(y_target), arr.shape[3]), dtype=float)
    for t in range(t_size):
        for z in range(len(z_target)):
            for x in range(arr.shape[3]):
                tmp_y[t, z, :, x] = np.interp(y_target, y_source, tmp_z[t, z, :, x])
    out = np.zeros((t_size, len(z_target), len(y_target), len(x_target)), dtype=float)
    for t in range(t_size):
        for z in range(len(z_target)):
            for y in range(len(y_target)):
                out[t, z, y] = np.interp(x_target, x_source, tmp_y[t, z, y])
    return out


def _target_axis(source: np.ndarray, size: int) -> np.ndarray:
    source = np.asarray(source, dtype=float)
    if source.size == 0:
        return np.arange(size, dtype=float)
    return np.linspace(float(np.nanmin(source)), float(np.nanmax(source)), size)


def _sort_axis_with_array(axis: np.ndarray, arr: np.ndarray, axis_index: int) -> tuple[np.ndarray, np.ndarray]:
    axis = np.asarray(axis, dtype=float)
    if axis.size <= 1:
        return np.arange(max(axis.size, 1), dtype=float), arr
    if axis[0] <= axis[-1]:
        return axis, arr
    return axis[::-1], np.flip(arr, axis=axis_index)


def _downscale_confidence(cube: WeatherCube, shape: tuple[int, int, int, int], config: LocalDownscalingConfig) -> np.ndarray:
    spacing_km = _source_spacing_km(cube)
    reduction = min(0.35, config.uncertainty_gain_per_km * spacing_km)
    return np.full(shape, max(0.35, 0.92 - reduction), dtype=float)


def _source_spacing_km(cube: WeatherCube) -> float:
    spacings = []
    for axis in (cube.y, cube.x):
        values = np.asarray(axis, dtype=float)
        if values.size > 1:
            spacings.append(float(np.nanmedian(np.abs(np.diff(values)))))
    if not spacings:
        return 10.0
    spacing = float(np.nanmean(spacings))
    return spacing / 1000.0 if spacing > 100.0 else spacing


def _add_low_altitude_perturbations(
    variables: dict[str, np.ndarray],
    confidence: np.ndarray,
    config: LocalDownscalingConfig,
) -> tuple[dict[str, np.ndarray], np.ndarray]:
    rng = np.random.default_rng(config.perturbation_seed)
    sample = next(iter(variables.values()))
    t_size, z_size, y_size, x_size = sample.shape
    yy = np.linspace(-1.0, 1.0, y_size)[None, None, :, None]
    xx = np.linspace(-1.0, 1.0, x_size)[None, None, None, :]
    tt = np.arange(t_size)[:, None, None, None]
    taper = np.linspace(1.0, 0.25, z_size)[None, :, None, None]
    blob = np.exp(-((yy - 0.35 * np.sin(tt / 2.0)) ** 2 + (xx - 0.35 * np.cos(tt / 2.5)) ** 2) / 0.22)
    wave = 0.5 + 0.5 * np.sin(2.7 * xx + 2.1 * yy + tt / 2.0)
    noise = rng.normal(0.0, 0.08, size=sample.shape)
    perturb = config.perturbation_strength * taper * np.clip(0.65 * blob + 0.35 * wave + noise, 0.0, 1.0)
    updated = {name: value.copy() for name, value in variables.items()}
    if "gust" in updated:
        updated["gust"] = updated["gust"] + 2.5 * perturb
    if "u_wind" in updated:
        updated["u_wind"] = updated["u_wind"] + 0.8 * perturb
    if "v_wind" in updated:
        updated["v_wind"] = updated["v_wind"] - 0.6 * perturb
    if "w_wind" in updated:
        updated["w_wind"] = updated["w_wind"] + 0.25 * perturb
    if "rain_rate" in updated:
        updated["rain_rate"] = np.clip(updated["rain_rate"] + 0.8 * perturb, 0.0, None)
    if "visibility" in updated:
        updated["visibility"] = np.clip(updated["visibility"] - 0.7 * perturb, 0.2, None)
    confidence = np.clip(confidence - 0.16 * perturb, 0.25, 0.95)
    return updated, confidence
