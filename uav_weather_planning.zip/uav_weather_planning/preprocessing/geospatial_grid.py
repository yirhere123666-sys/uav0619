from __future__ import annotations

from dataclasses import dataclass
from math import cos, radians

import numpy as np


EARTH_RADIUS_M = 6_371_000.0


@dataclass(frozen=True)
class GeoGridDefinition:
    """Local metric grid derived from a lat/lon bounding box.

    The planning tensors keep discrete indices internally, while this object
    records what each index means in real space. The y coordinate follows the
    source raster order: distance from the northern bbox edge toward the south.
    """

    bbox: tuple[float, float, float, float]
    x_m: np.ndarray
    y_m: np.ndarray
    latitude: np.ndarray
    longitude_360: np.ndarray
    longitude_display: np.ndarray
    center_latitude: float
    center_longitude_360: float
    width_m: float
    height_m: float

    @property
    def x_resolution_m(self) -> float:
        return _spacing(self.x_m)

    @property
    def y_resolution_m(self) -> float:
        return _spacing(self.y_m)

    def as_metadata(self) -> dict:
        north, west, south, east = self.bbox
        return {
            "crs": "LOCAL_TANGENT_EQUIRECTANGULAR_APPROX",
            "bbox_order": "north, west, south, east",
            "bbox": [float(north), float(west), float(south), float(east)],
            "bbox_longitude_convention": "input preserved; longitude_360 uses 0..360; longitude_display uses -180..180",
            "bbox_display": [
                float(north),
                float(_to_display_lon(west)),
                float(south),
                float(_to_display_lon(east)),
            ],
            "projection_origin": {
                "latitude_deg": float(self.center_latitude),
                "longitude_360_deg": float(self.center_longitude_360),
                "longitude_display_deg": float(_to_display_lon(self.center_longitude_360)),
            },
            "axis_definition": {
                "x": "meters eastward from western bbox edge",
                "y": "meters southward from northern bbox edge, matching source raster row order",
                "height": "meters above local ground/reference level",
                "time": "seconds from replay start",
            },
            "shape": {"y": int(len(self.y_m)), "x": int(len(self.x_m))},
            "extent_m": {"x": float(self.width_m), "y": float(self.height_m)},
            "resolution_m": {
                "x": float(self.x_resolution_m),
                "y": float(self.y_resolution_m),
            },
            "x_m": _round_list(self.x_m),
            "y_m": _round_list(self.y_m),
            "latitude_deg": _round_list(self.latitude, decimals=6),
            "longitude_360_deg": _round_list(self.longitude_360, decimals=6),
            "longitude_display_deg": _round_list(self.longitude_display, decimals=6),
        }


def build_local_grid_from_bbox(
    bbox: tuple[float, float, float, float],
    y_size: int,
    x_size: int,
) -> GeoGridDefinition:
    """Build a meter-based local grid from bbox=(north, west, south, east)."""

    if y_size <= 0 or x_size <= 0:
        raise ValueError("grid sizes must be positive")
    north, west, south, east = (float(v) for v in bbox)
    west_360 = _to_360_lon(west)
    east_360 = _to_360_lon(east)
    lon_span_deg = east_360 - west_360
    if lon_span_deg < 0.0:
        lon_span_deg += 360.0
    lat_span_deg = abs(north - south)
    center_lat = (north + south) / 2.0
    center_lon_360 = (west_360 + lon_span_deg / 2.0) % 360.0
    width_m = radians(lon_span_deg) * EARTH_RADIUS_M * cos(radians(center_lat))
    height_m = radians(lat_span_deg) * EARTH_RADIUS_M
    x_m = np.linspace(0.0, max(width_m, 0.0), x_size)
    y_m = np.linspace(0.0, max(height_m, 0.0), y_size)
    latitude = np.linspace(north, south, y_size)
    longitude_360 = (west_360 + np.linspace(0.0, lon_span_deg, x_size)) % 360.0
    longitude_display = np.array([_to_display_lon(value) for value in longitude_360], dtype=float)
    return GeoGridDefinition(
        bbox=(north, west, south, east),
        x_m=x_m,
        y_m=y_m,
        latitude=latitude,
        longitude_360=longitude_360,
        longitude_display=longitude_display,
        center_latitude=center_lat,
        center_longitude_360=center_lon_360,
        width_m=float(width_m),
        height_m=float(height_m),
    )


def build_bbox_from_center_extent(
    center_latitude: float,
    center_longitude: float,
    extent_x_m: float,
    extent_y_m: float,
) -> tuple[float, float, float, float]:
    """Return bbox=(north, west, south, east) for a local task extent."""

    center_lat = float(center_latitude)
    center_lon_360 = _to_360_lon(center_longitude)
    half_lat_deg = (float(extent_y_m) / 2.0) / EARTH_RADIUS_M * 180.0 / np.pi
    cos_lat = max(cos(radians(center_lat)), 1e-6)
    half_lon_deg = (float(extent_x_m) / 2.0) / (EARTH_RADIUS_M * cos_lat) * 180.0 / np.pi
    north = center_lat + half_lat_deg
    south = center_lat - half_lat_deg
    west = (center_lon_360 - half_lon_deg) % 360.0
    east = (center_lon_360 + half_lon_deg) % 360.0
    return float(north), float(west), float(south), float(east)


def _spacing(values: np.ndarray) -> float:
    values = np.asarray(values, dtype=float)
    if values.size <= 1:
        return 0.0
    return float(np.nanmean(np.diff(values)))


def _to_360_lon(value: float) -> float:
    return float(value) % 360.0


def _to_display_lon(value: float) -> float:
    lon = _to_360_lon(value)
    return lon - 360.0 if lon > 180.0 else lon


def _round_list(values: np.ndarray, decimals: int = 3) -> list[float]:
    return [float(round(v, decimals)) for v in np.asarray(values, dtype=float).tolist()]
