from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any

import numpy as np

from uav_weather_planning.data_interface.weather_cube import WeatherCube

from .local_short_time_perturbations import (
    ShortTimePerturbationConfig,
    add_short_time_low_altitude_perturbations,
)
from .local_weather_downscaling import _interp_tzyx, _source_spacing_km


@dataclass(frozen=True)
class LocalPlanningGridConfig:
    """Canonical 4D local risk grid before B-spline/NMPC layers."""

    x_extent_m: float = 12000.0
    y_extent_m: float = 12000.0
    xy_resolution_m: float = 100.0
    height_levels_m: tuple[float, ...] = (60.0, 80.0, 100.0, 120.0, 140.0, 160.0, 180.0)
    dt_s: float = 10.0
    horizon_s: float = 1200.0
    add_short_time_perturbations: bool = True
    perturbation_config: ShortTimePerturbationConfig = ShortTimePerturbationConfig()

    @property
    def x_axis_m(self) -> np.ndarray:
        size = int(round(self.x_extent_m / self.xy_resolution_m)) + 1
        return np.linspace(0.0, self.x_extent_m, max(size, 2), dtype=float)

    @property
    def y_axis_m(self) -> np.ndarray:
        size = int(round(self.y_extent_m / self.xy_resolution_m)) + 1
        return np.linspace(0.0, self.y_extent_m, max(size, 2), dtype=float)

    @property
    def height_axis_m(self) -> np.ndarray:
        return np.asarray(self.height_levels_m, dtype=float)

    @property
    def time_axis_s(self) -> np.ndarray:
        return np.arange(0.0, self.horizon_s + 0.5 * self.dt_s, self.dt_s, dtype=float)

    def as_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["x_size"] = int(self.x_axis_m.size)
        data["y_size"] = int(self.y_axis_m.size)
        data["z_size"] = int(self.height_axis_m.size)
        data["t_size"] = int(self.time_axis_s.size)
        data["x_range_m"] = [float(self.x_axis_m[0]), float(self.x_axis_m[-1])]
        data["y_range_m"] = [float(self.y_axis_m[0]), float(self.y_axis_m[-1])]
        data["time_range_s"] = [float(self.time_axis_s[0]), float(self.time_axis_s[-1])]
        data["actual_x_resolution_m"] = float(np.nanmedian(np.diff(self.x_axis_m))) if self.x_axis_m.size > 1 else None
        data["actual_y_resolution_m"] = float(np.nanmedian(np.diff(self.y_axis_m))) if self.y_axis_m.size > 1 else None
        return data


def normalize_weather_cube_to_local_planning_grid(
    cube: WeatherCube,
    config: LocalPlanningGridConfig | None = None,
) -> WeatherCube:
    """Convert regional background weather to the canonical 12 km / 10 s grid."""

    config = config or LocalPlanningGridConfig()
    z_target = config.height_axis_m
    y_target = config.y_axis_m
    x_target = config.x_axis_m
    time_target_s = config.time_axis_s
    source_time_s = _source_time_axis_seconds(cube)

    spatial_variables = {
        name: _interp_tzyx(value, cube.height, cube.y, cube.x, z_target, y_target, x_target)
        for name, value in cube.variables.items()
    }
    variables = {
        name: _interp_time_axis(value, source_time_s, time_target_s)
        for name, value in spatial_variables.items()
    }
    confidence = _local_grid_confidence(cube, (len(cube.time), len(z_target), len(y_target), len(x_target)), config)
    if isinstance(cube.confidence, np.ndarray):
        spatial_confidence = _interp_tzyx(cube.confidence, cube.height, cube.y, cube.x, z_target, y_target, x_target)
        confidence = np.minimum(confidence, _interp_time_axis(spatial_confidence, source_time_s, time_target_s))
    else:
        confidence = np.minimum(confidence, float(cube.confidence))

    perturbation_metadata: dict[str, Any] = {"enabled": False}
    if config.add_short_time_perturbations:
        variables, confidence, perturbation_metadata = add_short_time_low_altitude_perturbations(
            variables,
            confidence,
            time_s=time_target_s,
            height_m=z_target,
            y_m=y_target,
            x_m=x_target,
            config=config.perturbation_config,
        )

    source_metadata = {
        **cube.source_metadata,
        "background_source": cube.source_metadata.get("source", "unknown_background"),
        "background_resolution_m": float(_source_spacing_km(cube) * 1000.0),
        "grid": "canonical_local_4d_planning_grid",
        "time_axis_unit": "seconds",
        "time_axis_role": "local planning seconds from mission start",
        "local_grid_extent_m": [float(config.x_extent_m), float(config.y_extent_m)],
        "local_grid_resolution_m": float(config.xy_resolution_m),
        "local_planning_time_s": [float(v) for v in time_target_s],
        "time_step_s": float(config.dt_s),
        "height_levels_m": [float(v) for v in z_target],
        "synthetic_local_perturbation": bool(config.add_short_time_perturbations),
        "local_planning_grid": config.as_dict(),
        "background_weather_grid": {
            "source_shape": list(cube.shape),
            "source_x_range_m": _range_list(cube.x),
            "source_y_range_m": _range_list(cube.y),
            "source_height_range_m": _range_list(cube.height),
            "source_time_axis_s": [float(v) for v in source_time_s],
            "source_spacing_km_estimate": float(_source_spacing_km(cube)),
            "claim_boundary": (
                "Regional background weather is resampled to the local route-level risk grid; "
                "it is not claimed as a meter-level multirotor control grid."
            ),
        },
        "background_valid_times": _jsonable_time_axis(cube.time),
        "local_time_axis_s": [float(v) for v in time_target_s],
        "local_grid_shape": [int(time_target_s.size), int(z_target.size), int(y_target.size), int(x_target.size)],
        "local_grid_resolution": {
            "xy_resolution_m": float(config.xy_resolution_m),
            "height_levels_m": [float(v) for v in z_target],
            "time_step_s": float(config.dt_s),
            "horizon_s": float(config.horizon_s),
        },
        "downscaling_method": (
            "horizontal bilinear/axis interpolation + vertical linear interpolation + "
            "time interpolation from background valid time to local planning seconds"
        ),
        "scale_separation": {
            "background_weather_time": "WRF/GFS/ERA5 valid-time sequence",
            "local_risk_time": f"{config.dt_s:g} s planning risk update grid",
            "motion_validation_time": "reserved for later B-spline/NMPC validation",
        },
        "local_short_time_perturbation": perturbation_metadata,
        "geospatial_grid": {
            "crs": "LOCAL_METRIC",
            "resolution_m": float(config.xy_resolution_m),
            "altitude_range_m": [float(np.nanmin(z_target)), float(np.nanmax(z_target))],
            "time_axis": "local seconds from mission start",
            "axis_definition": {
                "x": "local east meters on the low-altitude route graph",
                "y": "local north meters on the low-altitude route graph",
                "height": "meters above local ground reference",
                "time": "seconds from mission start",
            },
        },
    }
    return WeatherCube(
        time=time_target_s,
        height=z_target,
        y=y_target,
        x=x_target,
        variables=variables,
        source_metadata=source_metadata,
        confidence=confidence,
    )


def _source_time_axis_seconds(cube: WeatherCube) -> np.ndarray:
    lead_hours = cube.source_metadata.get("lead_time_hours")
    if isinstance(lead_hours, list) and len(lead_hours) == len(cube.time):
        return (np.asarray(lead_hours, dtype=float) - float(lead_hours[0])) * 3600.0
    axis = np.asarray(cube.time)
    if np.issubdtype(axis.dtype, np.datetime64):
        return (axis - axis[0]).astype("timedelta64[s]").astype(float)
    try:
        numeric = axis.astype(float)
    except (TypeError, ValueError):
        return np.arange(len(axis), dtype=float) * 3600.0
    numeric = numeric - numeric[0]
    unit = str(cube.source_metadata.get("time_axis_unit", cube.source_metadata.get("time_unit", ""))).lower()
    if "hour" in unit:
        return numeric * 3600.0
    if numeric.size > 1 and float(np.nanmax(numeric)) <= 48.0 and cube.source_metadata.get("strict_historical_sequence"):
        return numeric * 3600.0
    return numeric.astype(float)


def _interp_time_axis(arr: np.ndarray | float, source_time_s: np.ndarray, target_time_s: np.ndarray) -> np.ndarray:
    arr = np.asarray(arr, dtype=float)
    if arr.ndim == 0:
        return np.full((target_time_s.size,), float(arr), dtype=float)
    if arr.shape[0] == target_time_s.size and np.allclose(source_time_s[: target_time_s.size], target_time_s):
        return arr.copy()
    if arr.shape[0] == 1 or source_time_s.size <= 1:
        return np.repeat(arr[:1], target_time_s.size, axis=0)
    order = np.argsort(source_time_s)
    source = np.asarray(source_time_s, dtype=float)[order]
    values = arr[order]
    flat = values.reshape(values.shape[0], -1)
    targets = np.asarray(target_time_s, dtype=float)
    right = np.searchsorted(source, targets, side="right")
    right = np.clip(right, 1, len(source) - 1)
    left = right - 1
    span = np.maximum(source[right] - source[left], 1e-9)
    alpha = ((targets - source[left]) / span).clip(0.0, 1.0)
    out_flat = (1.0 - alpha)[:, None] * flat[left] + alpha[:, None] * flat[right]
    return out_flat.reshape((targets.size,) + values.shape[1:])


def _local_grid_confidence(
    cube: WeatherCube,
    source_spatial_shape: tuple[int, int, int, int],
    config: LocalPlanningGridConfig,
) -> np.ndarray:
    spacing_km = _source_spacing_km(cube)
    target_km = max(config.xy_resolution_m / 1000.0, 1e-6)
    mismatch = max(spacing_km / target_km, 1.0)
    reduction = min(0.45, 0.035 * np.log1p(mismatch))
    source_conf = np.full(source_spatial_shape, max(0.38, 0.90 - reduction), dtype=float)
    return _interp_time_axis(source_conf, _source_time_axis_seconds(cube), config.time_axis_s)


def _range_list(values: np.ndarray) -> list[float]:
    arr = np.asarray(values, dtype=float)
    if arr.size == 0:
        return []
    return [float(np.nanmin(arr)), float(np.nanmax(arr))]


def _jsonable_time_axis(axis: np.ndarray) -> list[Any]:
    result = []
    for value in np.asarray(axis):
        if isinstance(value, np.datetime64):
            result.append(str(value))
            continue
        if isinstance(value, np.generic):
            value = value.item()
        if hasattr(value, "isoformat"):
            result.append(value.isoformat())
        else:
            result.append(value)
    return result
