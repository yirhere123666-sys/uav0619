from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any

import numpy as np

from uav_weather_planning.data_interface.weather_cube import WeatherCube
from uav_weather_planning.risk_field.risk_field_4d import State4D


@dataclass(frozen=True)
class ShortTimePerturbationConfig:
    """Physics-inspired unresolved low-altitude weather perturbations.

    Public mesoscale products such as WRF/GFS/ERA5 provide regional background
    weather, but not second-scale corridor gusts and shear at multirotor scale.
    This module adds documented synthetic local perturbations on top of the
    background field for planner robustness experiments.
    """

    enabled: bool = True
    seed: int = 20260618
    gust_peak_mps: float = 4.5
    shear_peak_mps: float = 2.2
    vertical_w_peak_mps: float = 0.8
    rain_peak_mmh: float = 4.0
    visibility_drop_km: float = 1.1
    ceiling_drop_m: float = 90.0
    pulse_centers_s: tuple[float, ...] = (60.0, 105.0, 240.0)
    pulse_width_s: float = 32.0

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class PathTargetedWindShearConfig:
    """Path-aware perturbation for D* Lite path-affected demonstrations."""

    event_time_s: float = 300.0
    perturbation_start_s: float = 360.0
    perturbation_end_s: float = 720.0
    gust_peak_time_s: float = 480.0
    gust_duration_s: float = 220.0
    gust_radius_m: float = 950.0
    shear_band_width_m: float = 760.0
    shear_band_length_m: float = 2300.0
    height_min_m: float = 80.0
    height_max_m: float = 160.0
    gust_strength_mps: float = 8.0
    shear_strength_mps: float = 5.8
    vertical_w_strength_mps: float = 1.4
    confidence_drop: float = 0.34
    target_future_window_s: tuple[float, float] = (120.0, 300.0)
    purpose: str = "dstar_path_affected_demo"

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


def add_short_time_low_altitude_perturbations(
    variables: dict[str, np.ndarray],
    confidence: np.ndarray,
    *,
    time_s: np.ndarray,
    height_m: np.ndarray,
    y_m: np.ndarray,
    x_m: np.ndarray,
    config: ShortTimePerturbationConfig | None = None,
) -> tuple[dict[str, np.ndarray], np.ndarray, dict[str, Any]]:
    """Add 20-120 s local gust/shear/outflow/rain/visibility evolution.

    The returned variables keep the same shape and units as the input
    WeatherCube variables. The metadata explicitly marks these fields as
    synthetic local perturbations, not observed WRF output.
    """

    config = config or ShortTimePerturbationConfig()
    if not config.enabled:
        return {name: value.copy() for name, value in variables.items()}, confidence.copy(), {"enabled": False}

    sample = next(iter(variables.values()))
    t_size, z_size, y_size, x_size = sample.shape
    time_s = np.asarray(time_s, dtype=float)
    height_m = np.asarray(height_m, dtype=float)
    y_m = np.asarray(y_m, dtype=float)
    x_m = np.asarray(x_m, dtype=float)
    if time_s.size != t_size or height_m.size != z_size or y_m.size != y_size or x_m.size != x_size:
        raise ValueError("time/height/y/x axes must match weather variable shape")

    rng = np.random.default_rng(config.seed)
    tt = time_s[:, None, None, None]
    zz = height_m[None, :, None, None]
    yy = y_m[None, None, :, None]
    xx = x_m[None, None, None, :]

    x_extent = max(float(np.nanmax(x_m) - np.nanmin(x_m)), 1.0)
    y_extent = max(float(np.nanmax(y_m) - np.nanmin(y_m)), 1.0)
    z_extent = max(float(np.nanmax(height_m) - np.nanmin(height_m)), 1.0)
    low_altitude_taper = np.clip(1.12 - (zz - np.nanmin(height_m)) / z_extent, 0.30, 1.15)

    pulse = np.zeros((t_size, 1, 1, 1), dtype=float)
    for center in config.pulse_centers_s:
        pulse += np.exp(-((tt - center) ** 2) / (2.0 * config.pulse_width_s**2))
    pulse = np.clip(pulse, 0.0, 1.35)

    gust_x = 900.0 + 2.7 * tt
    gust_y = 2900.0 + 180.0 * np.sin(tt / 75.0)
    gust_blob = np.exp(-(((xx - gust_x) / (0.18 * x_extent)) ** 2 + ((yy - gust_y) / (0.16 * y_extent)) ** 2))

    shear_center_y = 1100.0 + 3.4 * tt
    shear_band = np.exp(-((yy - shear_center_y) ** 2) / (2.0 * (0.075 * y_extent) ** 2))
    shear_phase = np.tanh((zz - np.nanmean(height_m)) / max(0.18 * z_extent, 1.0))

    outflow_radius = 520.0 + 5.5 * tt
    outflow_distance = np.sqrt((xx - 3000.0) ** 2 + (yy - 2500.0) ** 2)
    outflow_ring = np.exp(-((outflow_distance - outflow_radius) ** 2) / (2.0 * 145.0**2))

    rain_patch_x = 1750.0 + 1.8 * tt
    rain_patch_y = 3800.0 - 1.2 * tt
    rain_patch = np.exp(-(((xx - rain_patch_x) / 720.0) ** 2 + ((yy - rain_patch_y) / 520.0) ** 2))
    random_texture = rng.normal(0.0, 0.025, size=sample.shape)

    gust_signal = np.clip((0.75 * gust_blob + 0.35 * outflow_ring) * pulse * low_altitude_taper + random_texture, 0.0, None)
    shear_signal = np.clip(shear_band * (0.40 + 0.60 * pulse) * low_altitude_taper, 0.0, None)
    outflow_signal = np.clip(outflow_ring * (0.35 + 0.65 * pulse) * low_altitude_taper, 0.0, None)
    rain_signal = np.clip((0.65 * rain_patch + 0.35 * outflow_ring) * pulse, 0.0, None)

    updated = {name: value.copy() for name, value in variables.items()}
    if "gust" in updated:
        updated["gust"] = np.clip(updated["gust"] + config.gust_peak_mps * gust_signal, 0.0, None)
    if "u_wind" in updated:
        updated["u_wind"] = updated["u_wind"] + config.shear_peak_mps * shear_signal * shear_phase + 1.4 * outflow_signal
    if "v_wind" in updated:
        updated["v_wind"] = updated["v_wind"] - 0.75 * config.shear_peak_mps * shear_signal * shear_phase - 1.1 * outflow_signal
    if "w_wind" in updated:
        updated["w_wind"] = updated["w_wind"] + config.vertical_w_peak_mps * np.maximum(outflow_signal, 0.55 * shear_signal)
    if "updraft_speed" in updated:
        updated["updraft_speed"] = np.clip(updated["updraft_speed"] + 1.25 * outflow_signal, 0.0, None)
    if "rain_rate" in updated:
        updated["rain_rate"] = np.clip(updated["rain_rate"] + config.rain_peak_mmh * rain_signal, 0.0, None)
    if "reflectivity" in updated:
        updated["reflectivity"] = np.clip(updated["reflectivity"] + 9.0 * rain_signal + 7.0 * outflow_signal, 0.0, 65.0)
    if "convection_probability" in updated:
        updated["convection_probability"] = np.clip(updated["convection_probability"] + 0.20 * outflow_signal + 0.14 * rain_signal, 0.0, 1.0)
    if "visibility" in updated:
        updated["visibility"] = np.clip(updated["visibility"] - config.visibility_drop_km * rain_signal, 0.15, None)
    if "ceiling" in updated:
        updated["ceiling"] = np.clip(updated["ceiling"] - config.ceiling_drop_m * rain_signal, 25.0, None)
    if "cloud_liquid_water" in updated:
        updated["cloud_liquid_water"] = np.clip(updated["cloud_liquid_water"] + 0.05 * rain_signal, 0.0, None)

    perturbation_intensity = np.clip(
        np.maximum.reduce(
            [
                np.broadcast_to(gust_signal, sample.shape),
                np.broadcast_to(shear_signal, sample.shape),
                np.broadcast_to(outflow_signal, sample.shape),
                np.broadcast_to(rain_signal, sample.shape),
            ]
        ),
        0.0,
        1.0,
    )
    confidence = np.clip(confidence - 0.18 * perturbation_intensity, 0.20, 0.97)
    metadata = {
        "enabled": True,
        "type": "synthetic_local_perturbation",
        "role": "unresolved second-scale low-altitude gust, shear, outflow, rain and visibility variability",
        "time_scale_s": "20-120",
        "pulse_centers_s": list(config.pulse_centers_s),
        "config": config.as_dict(),
        "max_added_gust_mps": float(config.gust_peak_mps * np.nanmax(gust_signal)),
        "max_added_shear_mps": float(config.shear_peak_mps * np.nanmax(shear_signal)),
        "max_added_rain_mmh": float(config.rain_peak_mmh * np.nanmax(rain_signal)),
    }
    return updated, confidence, metadata


def apply_path_targeted_wind_shear_perturbation(
    cube: WeatherCube,
    original_path: list[State4D],
    *,
    event_time_s: float = 300.0,
    config: PathTargetedWindShearConfig | None = None,
) -> tuple[WeatherCube, dict[str, Any]]:
    """Place a gust/shear perturbation on the future segment of a planned path.

    The perturbation is applied to weather variables, not directly to risk
    tensors. It is explicitly marked as synthetic_local_perturbation because
    the WRF background does not resolve second-scale low-altitude corridor
    wind shear.
    """

    config = config or PathTargetedWindShearConfig(event_time_s=event_time_s)
    if not original_path:
        metadata = {"enabled": False, "reason": "empty_original_path"}
        return cube, metadata

    time_s = _numeric_time_axis(cube.time)
    center_state = _select_future_path_state(cube, original_path, event_time_s, config.target_future_window_s)
    center = _state_to_metric(cube, center_state)
    heading = _path_heading_xy(cube, original_path, center_state)
    tangent = np.asarray(heading, dtype=np.float32)
    normal = np.asarray((-tangent[1], tangent[0]), dtype=np.float32)

    tt = time_s[:, None, None, None].astype(np.float32)
    zz = cube.height[None, :, None, None].astype(np.float32)
    yy = cube.y[None, None, :, None].astype(np.float32)
    xx = cube.x[None, None, None, :].astype(np.float32)

    dx = xx - np.float32(center["x_m"])
    dy = yy - np.float32(center["y_m"])
    along_route = dx * tangent[0] + dy * tangent[1]
    across_route = dx * normal[0] + dy * normal[1]
    shear_band = np.exp(
        -0.5 * (along_route / max(config.shear_band_width_m, 1.0)) ** 2
        -0.5 * (across_route / max(config.shear_band_length_m, 1.0)) ** 2
    ).astype(np.float32)
    gust_blob = np.exp(
        -0.5 * (dx * dx + dy * dy) / max(config.gust_radius_m, 1.0) ** 2
    ).astype(np.float32)
    height_gate = (
        _smooth_step(zz, config.height_min_m, config.height_min_m + 12.0)
        * (1.0 - _smooth_step(zz, config.height_max_m - 12.0, config.height_max_m))
    ).astype(np.float32)
    onset = _smooth_step(tt, config.perturbation_start_s, config.perturbation_start_s + 40.0)
    decay = 1.0 - _smooth_step(tt, config.perturbation_end_s - 60.0, config.perturbation_end_s)
    time_gate = np.clip(onset * decay, 0.0, 1.0).astype(np.float32)
    gust_pulse = np.exp(
        -0.5 * ((tt - np.float32(config.gust_peak_time_s)) / max(config.gust_duration_s / 2.355, 1.0)) ** 2
    ).astype(np.float32)

    shear_phase = np.tanh((zz - np.float32(0.5 * (config.height_min_m + config.height_max_m))) / 22.0).astype(np.float32)
    shear_signal = np.clip(shear_band * height_gate * time_gate, 0.0, 1.0).astype(np.float32)
    gust_signal = np.clip(gust_blob * height_gate * np.maximum(time_gate, gust_pulse), 0.0, 1.0).astype(np.float32)
    combined = np.clip(np.maximum(shear_signal, gust_signal), 0.0, 1.0).astype(np.float32)

    variables = {name: np.asarray(value, dtype=np.float32).copy() for name, value in cube.variables.items()}
    if "u_wind" in variables:
        variables["u_wind"] += np.float32(config.shear_strength_mps) * shear_signal * shear_phase * normal[0]
        variables["u_wind"] += np.float32(0.55 * config.gust_strength_mps) * gust_signal * tangent[0]
    if "v_wind" in variables:
        variables["v_wind"] += np.float32(config.shear_strength_mps) * shear_signal * shear_phase * normal[1]
        variables["v_wind"] += np.float32(0.55 * config.gust_strength_mps) * gust_signal * tangent[1]
    if "w_wind" in variables:
        variables["w_wind"] += np.float32(config.vertical_w_strength_mps) * np.maximum(shear_signal, 0.55 * gust_signal)
    if "gust" in variables:
        variables["gust"] += np.float32(config.gust_strength_mps) * gust_signal + np.float32(0.45 * config.shear_strength_mps) * shear_signal
    if "updraft_speed" in variables:
        variables["updraft_speed"] += np.float32(config.vertical_w_strength_mps) * np.maximum(shear_signal, 0.35 * gust_signal)

    if isinstance(cube.confidence, np.ndarray):
        confidence = np.asarray(cube.confidence, dtype=np.float32).copy()
    else:
        confidence = np.full(cube.shape, float(cube.confidence), dtype=np.float32)
    confidence = np.clip(confidence - np.float32(config.confidence_drop) * combined, 0.16, 0.98)

    metadata = {
        "enabled": True,
        "synthetic_local_perturbation": True,
        "perturbation_type": "path_targeted_wind_shear_gust",
        "perturbation_purpose": config.purpose,
        "event_time_s": float(event_time_s),
        "perturbation_time_window_s": [float(config.perturbation_start_s), float(config.perturbation_end_s)],
        "gust_peak_time_s": float(config.gust_peak_time_s),
        "gust_duration_s": float(config.gust_duration_s),
        "gust_radius_m": float(config.gust_radius_m),
        "gust_strength": float(config.gust_strength_mps),
        "shear_strength": float(config.shear_strength_mps),
        "shear_band_width_m": float(config.shear_band_width_m),
        "shear_band_length_m": float(config.shear_band_length_m),
        "perturbation_center_m": {
            "x": float(center["x_m"]),
            "y": float(center["y_m"]),
            "height": float(center["height_m"]),
            "time_s": float(center["time_s"]),
        },
        "perturbation_height_band_m": [float(config.height_min_m), float(config.height_max_m)],
        "target_path_state": [int(v) for v in center_state],
        "max_shear_signal": float(np.nanmax(shear_signal)),
        "max_gust_signal": float(np.nanmax(gust_signal)),
        "claim_boundary": "WRF background + synthetic local wind-shear/gust perturbation for D* Lite dynamic replanning validation.",
        "config": config.as_dict(),
    }
    source_metadata = {
        **cube.source_metadata,
        "synthetic_local_perturbation": True,
        "path_targeted_perturbation": metadata,
    }
    updated_cube = WeatherCube(
        time=cube.time.copy(),
        height=cube.height.copy(),
        y=cube.y.copy(),
        x=cube.x.copy(),
        variables=variables,
        source_metadata=source_metadata,
        confidence=confidence,
    )
    return updated_cube, metadata


def _select_future_path_state(
    cube: WeatherCube,
    path: list[State4D],
    event_time_s: float,
    future_window_s: tuple[float, float],
) -> State4D:
    time_s = _numeric_time_axis(cube.time)
    lo = event_time_s + float(future_window_s[0])
    hi = event_time_s + float(future_window_s[1])
    candidates = [
        state
        for state in path
        if 0 <= state[0] < time_s.size and lo <= float(time_s[state[0]]) <= hi
    ]
    if candidates:
        return candidates[len(candidates) // 2]
    future = [state for state in path if 0 <= state[0] < time_s.size and float(time_s[state[0]]) >= event_time_s]
    if future:
        return future[min(len(future) - 1, max(1, len(future) // 2))]
    return path[-1]


def _path_heading_xy(cube: WeatherCube, path: list[State4D], center_state: State4D) -> tuple[float, float]:
    try:
        idx = path.index(center_state)
    except ValueError:
        idx = min(range(len(path)), key=lambda i: abs(path[i][0] - center_state[0]))
    left = path[max(0, idx - 3)]
    right = path[min(len(path) - 1, idx + 3)]
    left_xy = _state_to_metric(cube, left)
    right_xy = _state_to_metric(cube, right)
    dx = float(right_xy["x_m"] - left_xy["x_m"])
    dy = float(right_xy["y_m"] - left_xy["y_m"])
    norm = max(float(np.hypot(dx, dy)), 1e-6)
    return dx / norm, dy / norm


def _state_to_metric(cube: WeatherCube, state: State4D) -> dict[str, float]:
    t, z, y, x = state
    time_s = _numeric_time_axis(cube.time)
    return {
        "time_s": float(time_s[int(np.clip(t, 0, time_s.size - 1))]),
        "height_m": float(cube.height[int(np.clip(z, 0, cube.height.size - 1))]),
        "y_m": float(cube.y[int(np.clip(y, 0, cube.y.size - 1))]),
        "x_m": float(cube.x[int(np.clip(x, 0, cube.x.size - 1))]),
    }


def _numeric_time_axis(axis: np.ndarray) -> np.ndarray:
    arr = np.asarray(axis)
    if np.issubdtype(arr.dtype, np.datetime64):
        return (arr - arr[0]).astype("timedelta64[ms]").astype(float) / 1000.0
    return arr.astype(float)


def _smooth_step(values: np.ndarray, left: float, right: float) -> np.ndarray:
    x = np.clip((values - float(left)) / max(float(right - left), 1e-6), 0.0, 1.0)
    return x * x * (3.0 - 2.0 * x)
