from __future__ import annotations

from dataclasses import dataclass
import math

import numpy as np

from uav_weather_planning.risk_field import RiskField4D
from uav_weather_planning.risk_field.risk_field_4d import State4D

from .corridor_graph import CorridorGraph, CorridorSegment


@dataclass(frozen=True)
class CorridorCostConfig:
    required: bool = True
    penalty_weight: float = 0.65
    boundary_buffer_ratio: float = 0.0
    enforce_segment_speed_limit: bool = True


@dataclass(frozen=True)
class CorridorEvaluation:
    allowed: bool
    penalty: float
    distance_to_centerline_m: float | None
    normalized_deviation: float | None
    segment_id: str | None
    reason: str = ""


class CorridorCostModel:
    def __init__(self, graph: CorridorGraph, config: CorridorCostConfig | None = None) -> None:
        self.graph = graph
        self.config = config or CorridorCostConfig()

    def evaluate_edge(
        self,
        current: State4D,
        neighbor: State4D,
        risk_field: RiskField4D,
    ) -> CorridorEvaluation:
        nt, nz, ny, nx = neighbor
        x, y, altitude = _state_xyz(risk_field, neighbor)
        zone = self.graph.geofence_violation(x, y, altitude)
        if zone is not None:
            return CorridorEvaluation(False, float("inf"), None, None, None, f"inside closed geofence {zone.zone_id}")

        candidates = self.graph.candidate_segments(x, y, altitude, nt, include_outside=True)
        if not candidates:
            if self.config.required:
                return CorridorEvaluation(False, float("inf"), None, None, None, "no open corridor segment at altitude")
            return CorridorEvaluation(True, 0.0, None, None, None, "corridor optional")

        segment, distance = candidates[0]
        half_width = max(segment.width_m / 2.0, 1e-6)
        allowed_width = half_width * (1.0 + self.config.boundary_buffer_ratio)
        if self.config.required and distance > allowed_width:
            return CorridorEvaluation(False, float("inf"), distance, distance / half_width, segment.segment_id, "outside corridor width")

        if self.config.enforce_segment_speed_limit:
            speed = _ground_speed_mps(risk_field, current, neighbor)
            if speed is not None and speed > segment.speed_limit_mps + 1e-9:
                return CorridorEvaluation(
                    False,
                    float("inf"),
                    distance,
                    distance / half_width,
                    segment.segment_id,
                    f"exceeds corridor speed limit {segment.speed_limit_mps:.2f} m/s",
                )

        normalized = distance / half_width
        penalty = self.config.penalty_weight * normalized * normalized
        return CorridorEvaluation(True, penalty, distance, normalized, segment.segment_id)

    def evaluate_path(self, path: list[State4D], risk_field: RiskField4D) -> dict:
        if not path:
            return {
                "airspace_violations": 1,
                "max_corridor_deviation_m": None,
                "mean_corridor_deviation_m": None,
                "max_corridor_deviation_ratio": None,
                "corridor_segments_used": [],
                "alternate_landing_points": list(self.graph.alternate_landing_points.keys()),
            }
        violations = 0
        distances = []
        ratios = []
        segments = []
        for idx, state in enumerate(path):
            if idx == 0 and len(path) > 1:
                current = state
                neighbor = path[idx + 1]
            elif idx == 0:
                current = state
                neighbor = state
            else:
                current = path[idx - 1]
                neighbor = state
            evaluation = self.evaluate_edge(current, neighbor, risk_field)
            if not evaluation.allowed:
                violations += 1
            if evaluation.distance_to_centerline_m is not None:
                distances.append(evaluation.distance_to_centerline_m)
            if evaluation.normalized_deviation is not None:
                ratios.append(evaluation.normalized_deviation)
            if evaluation.segment_id is not None:
                segments.append(evaluation.segment_id)
        return {
            "airspace_violations": int(violations),
            "max_corridor_deviation_m": round(max(distances), 3) if distances else None,
            "mean_corridor_deviation_m": round(sum(distances) / len(distances), 3) if distances else None,
            "max_corridor_deviation_ratio": round(max(ratios), 3) if ratios else None,
            "corridor_segments_used": sorted(set(segments)),
            "alternate_landing_points": list(self.graph.alternate_landing_points.keys()),
        }


def _state_xyz(risk_field: RiskField4D, state: State4D) -> tuple[float, float, float]:
    _, z, y, x = state
    x_axis = np.asarray(risk_field.coords.get("x", np.arange(risk_field.x_size)), dtype=float)
    y_axis = np.asarray(risk_field.coords.get("y", np.arange(risk_field.y_size)), dtype=float)
    z_axis = np.asarray(risk_field.coords.get("height", np.arange(risk_field.z_size)), dtype=float)
    return float(x_axis[x]), float(y_axis[y]), float(z_axis[z])


def _ground_speed_mps(risk_field: RiskField4D, current: State4D, neighbor: State4D) -> float | None:
    t0, _, y0, x0 = current
    t1, _, y1, x1 = neighbor
    time_axis = np.asarray(risk_field.coords.get("time", np.arange(risk_field.t_size)))
    if t0 >= len(time_axis) or t1 >= len(time_axis):
        return None
    if np.issubdtype(time_axis.dtype, np.datetime64):
        dt = float((time_axis[t1] - time_axis[t0]).astype("timedelta64[ms]").astype(float) / 1000.0)
    else:
        try:
            dt = float(time_axis[t1] - time_axis[t0])
        except (TypeError, ValueError):
            return None
    if dt <= 0.0:
        return None
    x_axis = np.asarray(risk_field.coords.get("x", np.arange(risk_field.x_size)), dtype=float)
    y_axis = np.asarray(risk_field.coords.get("y", np.arange(risk_field.y_size)), dtype=float)
    dx = float(x_axis[x1] - x_axis[x0])
    dy = float(y_axis[y1] - y_axis[y0])
    return math.hypot(dx, dy) / dt
