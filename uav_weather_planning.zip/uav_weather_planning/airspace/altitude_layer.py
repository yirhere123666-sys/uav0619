from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

import numpy as np


@dataclass(frozen=True)
class AltitudeLayer:
    layer_id: str
    min_m: float
    max_m: float
    nominal_m: float
    status: str = "open"

    def contains(self, altitude_m: float) -> bool:
        return self.status == "open" and self.min_m <= altitude_m <= self.max_m

    def as_dict(self) -> dict:
        return {
            "layer_id": self.layer_id,
            "min_m": float(self.min_m),
            "max_m": float(self.max_m),
            "nominal_m": float(self.nominal_m),
            "status": self.status,
        }


@dataclass(frozen=True)
class AltitudeLayerSet:
    layers: tuple[AltitudeLayer, ...]

    @classmethod
    def from_height_axis(
        cls,
        height_axis: Iterable[float],
        layer_margin_m: float | None = None,
    ) -> "AltitudeLayerSet":
        heights = np.asarray(list(height_axis), dtype=float)
        if heights.size == 0:
            return cls(())
        if layer_margin_m is None:
            if heights.size > 1:
                layer_margin_m = float(np.nanmedian(np.abs(np.diff(heights)))) / 2.0
            else:
                layer_margin_m = 60.0
        layers = []
        for index, value in enumerate(heights):
            layers.append(
                AltitudeLayer(
                    layer_id=f"L{index}",
                    min_m=float(value - layer_margin_m),
                    max_m=float(value + layer_margin_m),
                    nominal_m=float(value),
                )
            )
        return cls(tuple(layers))

    def contains(self, altitude_m: float) -> bool:
        return any(layer.contains(altitude_m) for layer in self.layers)

    def nearest(self, altitude_m: float) -> AltitudeLayer | None:
        if not self.layers:
            return None
        return min(self.layers, key=lambda layer: abs(layer.nominal_m - altitude_m))

    def as_dict(self) -> list[dict]:
        return [layer.as_dict() for layer in self.layers]
