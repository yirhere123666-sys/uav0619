from __future__ import annotations

from dataclasses import dataclass
import math


Point2D = tuple[float, float]


@dataclass(frozen=True)
class GeofenceZone:
    zone_id: str
    polygon_xy: tuple[Point2D, ...] = ()
    center_xy: Point2D | None = None
    radius_m: float | None = None
    altitude_min_m: float | None = None
    altitude_max_m: float | None = None
    status: str = "closed"
    reason: str = ""

    def contains(self, x_m: float, y_m: float, altitude_m: float | None = None) -> bool:
        if altitude_m is not None:
            if self.altitude_min_m is not None and altitude_m < self.altitude_min_m:
                return False
            if self.altitude_max_m is not None and altitude_m > self.altitude_max_m:
                return False
        if self.center_xy is not None and self.radius_m is not None:
            dx = x_m - self.center_xy[0]
            dy = y_m - self.center_xy[1]
            return math.hypot(dx, dy) <= self.radius_m
        if self.polygon_xy:
            return _point_in_polygon((x_m, y_m), self.polygon_xy)
        return False

    def as_dict(self) -> dict:
        return {
            "zone_id": self.zone_id,
            "polygon_xy": [[float(x), float(y)] for x, y in self.polygon_xy],
            "center_xy": list(self.center_xy) if self.center_xy is not None else None,
            "radius_m": self.radius_m,
            "altitude_min_m": self.altitude_min_m,
            "altitude_max_m": self.altitude_max_m,
            "status": self.status,
            "reason": self.reason,
        }


def _point_in_polygon(point: Point2D, polygon: tuple[Point2D, ...]) -> bool:
    x, y = point
    inside = False
    j = len(polygon) - 1
    for i, (xi, yi) in enumerate(polygon):
        xj, yj = polygon[j]
        intersects = (yi > y) != (yj > y) and x < (xj - xi) * (y - yi) / max(yj - yi, 1e-12) + xi
        if intersects:
            inside = not inside
        j = i
    return inside
