from __future__ import annotations

from dataclasses import dataclass, field
import math
from typing import Iterable

import numpy as np

from uav_weather_planning.risk_field import RiskField4D
from uav_weather_planning.risk_field.risk_field_4d import SpatialNode, State4D

from .altitude_layer import AltitudeLayerSet
from .geofence import GeofenceZone


Point2D = tuple[float, float]


@dataclass(frozen=True)
class AirspaceNode:
    node_id: str
    x_m: float
    y_m: float
    altitude_m: float | None = None
    kind: str = "waypoint"

    def as_dict(self) -> dict:
        return {
            "node_id": self.node_id,
            "x_m": float(self.x_m),
            "y_m": float(self.y_m),
            "altitude_m": self.altitude_m,
            "kind": self.kind,
        }


@dataclass(frozen=True)
class CorridorSegment:
    segment_id: str
    start_node: str
    end_node: str
    centerline: tuple[Point2D, ...]
    width_m: float
    altitude_min_m: float
    altitude_max_m: float
    speed_limit_mps: float = 15.0
    status: str = "open"
    bidirectional: bool = True
    closed_time_windows: tuple[tuple[int, int], ...] = ()

    def is_open(self, time_index: int | None = None) -> bool:
        if self.status != "open":
            return False
        if time_index is None:
            return True
        return not any(start <= time_index <= end for start, end in self.closed_time_windows)

    def altitude_allowed(self, altitude_m: float) -> bool:
        return self.altitude_min_m <= altitude_m <= self.altitude_max_m

    def distance_to_centerline(self, x_m: float, y_m: float) -> float:
        if len(self.centerline) == 1:
            px, py = self.centerline[0]
            return math.hypot(x_m - px, y_m - py)
        return min(
            _distance_point_to_segment((x_m, y_m), a, b)
            for a, b in zip(self.centerline[:-1], self.centerline[1:])
        )

    def contains(self, x_m: float, y_m: float, altitude_m: float, time_index: int | None = None) -> bool:
        return (
            self.is_open(time_index)
            and self.altitude_allowed(altitude_m)
            and self.distance_to_centerline(x_m, y_m) <= self.width_m / 2.0
        )

    def as_dict(self) -> dict:
        return {
            "segment_id": self.segment_id,
            "start_node": self.start_node,
            "end_node": self.end_node,
            "centerline": [[float(x), float(y)] for x, y in self.centerline],
            "width_m": float(self.width_m),
            "altitude_min_m": float(self.altitude_min_m),
            "altitude_max_m": float(self.altitude_max_m),
            "speed_limit_mps": float(self.speed_limit_mps),
            "status": self.status,
            "bidirectional": self.bidirectional,
            "closed_time_windows": [list(window) for window in self.closed_time_windows],
        }


@dataclass
class CorridorGraph:
    nodes: dict[str, AirspaceNode]
    segments: list[CorridorSegment]
    altitude_layers: AltitudeLayerSet = field(default_factory=lambda: AltitudeLayerSet(()))
    geofences: list[GeofenceZone] = field(default_factory=list)
    alternate_landing_points: dict[str, AirspaceNode] = field(default_factory=dict)
    metadata: dict = field(default_factory=dict)

    @classmethod
    def from_mission(
        cls,
        risk_field: RiskField4D,
        start: SpatialNode,
        goal: SpatialNode,
        corridor_width_cells: float = 4.0,
        speed_limit_mps: float = 15.0,
        altitude_min_m: float | None = None,
        altitude_max_m: float | None = None,
        include_alternates: bool = True,
    ) -> "CorridorGraph":
        """Build a compact structured low-altitude corridor network for one mission.

        The generated graph is intentionally simple but explicit: it contains
        nodes, corridor segments, centerlines, corridor widths, allowed altitude
        range, segment speed limits and alternates.
        """

        start_xyz = _spatial_xyz(risk_field, start)
        goal_xyz = _spatial_xyz(risk_field, goal)
        x0, y0, _ = start_xyz
        x1, y1, _ = goal_xyz
        x_mid = (x0 + x1) / 2.0
        y_mid = (y0 + y1) / 2.0
        span = max(math.hypot(x1 - x0, y1 - y0), 1.0)
        normal = _normal_vector(x0, y0, x1, y1)
        offset = max(0.22 * span, _nominal_resolution_m(risk_field) * 3.0)

        nodes = {
            "START": AirspaceNode("START", x0, y0, start_xyz[2], "entry"),
            "GOAL": AirspaceNode("GOAL", x1, y1, goal_xyz[2], "exit"),
            "MID_MAIN": AirspaceNode("MID_MAIN", x_mid, y_mid, None, "waypoint"),
            "MID_LEFT": AirspaceNode("MID_LEFT", x_mid + normal[0] * offset, y_mid + normal[1] * offset, None, "waypoint"),
            "MID_RIGHT": AirspaceNode("MID_RIGHT", x_mid - normal[0] * offset, y_mid - normal[1] * offset, None, "waypoint"),
        }
        if include_alternates:
            nodes["ALT_LEFT"] = AirspaceNode(
                "ALT_LEFT",
                x_mid + normal[0] * offset * 1.35,
                y_mid + normal[1] * offset * 1.35,
                goal_xyz[2],
                "alternate",
            )
            nodes["ALT_RIGHT"] = AirspaceNode(
                "ALT_RIGHT",
                x_mid - normal[0] * offset * 1.35,
                y_mid - normal[1] * offset * 1.35,
                goal_xyz[2],
                "alternate",
            )

        resolution = _nominal_resolution_m(risk_field)
        width = max(float(corridor_width_cells) * resolution, resolution * 1.5)
        heights = np.asarray(risk_field.coords.get("height", np.arange(risk_field.z_size)), dtype=float)
        altitude_min = float(altitude_min_m) if altitude_min_m is not None else (float(np.nanmin(heights)) if heights.size else 0.0)
        altitude_max = float(altitude_max_m) if altitude_max_m is not None else (float(np.nanmax(heights)) if heights.size else 0.0)
        segments = [
            _segment("AIR_MAIN_1", nodes, "START", "MID_MAIN", width, altitude_min, altitude_max, speed_limit_mps),
            _segment("AIR_MAIN_2", nodes, "MID_MAIN", "GOAL", width, altitude_min, altitude_max, speed_limit_mps),
            _segment("AIR_LEFT_1", nodes, "START", "MID_LEFT", width, altitude_min, altitude_max, speed_limit_mps),
            _segment("AIR_LEFT_2", nodes, "MID_LEFT", "GOAL", width, altitude_min, altitude_max, speed_limit_mps),
            _segment("AIR_RIGHT_1", nodes, "START", "MID_RIGHT", width, altitude_min, altitude_max, speed_limit_mps),
            _segment("AIR_RIGHT_2", nodes, "MID_RIGHT", "GOAL", width, altitude_min, altitude_max, speed_limit_mps),
        ]
        if include_alternates:
            segments.extend(
                [
                    _segment("AIR_ALT_LEFT", nodes, "MID_LEFT", "ALT_LEFT", width, altitude_min, altitude_max, speed_limit_mps),
                    _segment("AIR_ALT_RIGHT", nodes, "MID_RIGHT", "ALT_RIGHT", width, altitude_min, altitude_max, speed_limit_mps),
                ]
            )
        alternates = {node_id: node for node_id, node in nodes.items() if node.kind == "alternate"}
        return cls(
            nodes=nodes,
            segments=segments,
            altitude_layers=AltitudeLayerSet.from_height_axis(heights),
            alternate_landing_points=alternates,
            metadata={
                "graph": "G_air=(V_air,E_air)",
                "generator": "mission_corridor_network",
                "corridor_width_cells": float(corridor_width_cells),
                "corridor_width_m": float(width),
                "speed_limit_mps": float(speed_limit_mps),
                "altitude_min_m": float(altitude_min),
                "altitude_max_m": float(altitude_max),
                "role": "structured low-altitude airway constraint for global planning",
            },
        )

    def open_segments(self, time_index: int | None = None) -> list[CorridorSegment]:
        return [segment for segment in self.segments if segment.is_open(time_index)]

    def candidate_segments(
        self,
        x_m: float,
        y_m: float,
        altitude_m: float,
        time_index: int | None = None,
        include_outside: bool = False,
    ) -> list[tuple[CorridorSegment, float]]:
        candidates = []
        for segment in self.open_segments(time_index):
            if not segment.altitude_allowed(altitude_m):
                continue
            distance = segment.distance_to_centerline(x_m, y_m)
            if include_outside or distance <= segment.width_m / 2.0:
                candidates.append((segment, distance))
        return sorted(candidates, key=lambda item: item[1])

    def geofence_violation(self, x_m: float, y_m: float, altitude_m: float) -> GeofenceZone | None:
        for zone in self.geofences:
            if zone.status == "closed" and zone.contains(x_m, y_m, altitude_m):
                return zone
        return None

    def as_dict(self) -> dict:
        return {
            "metadata": self.metadata,
            "nodes": {node_id: node.as_dict() for node_id, node in self.nodes.items()},
            "segments": [segment.as_dict() for segment in self.segments],
            "altitude_layers": self.altitude_layers.as_dict(),
            "geofences": [zone.as_dict() for zone in self.geofences],
            "alternate_landing_points": {node_id: node.as_dict() for node_id, node in self.alternate_landing_points.items()},
        }

    def as_summary(self) -> dict:
        return {
            "graph": "G_air=(V_air,E_air)",
            "node_count": len(self.nodes),
            "segment_count": len(self.segments),
            "open_segment_count": len(self.open_segments()),
            "alternate_landing_point_count": len(self.alternate_landing_points),
            "corridor_width_m": self.metadata.get("corridor_width_m"),
            "speed_limit_mps": self.metadata.get("speed_limit_mps"),
            "segments": [
                {
                    "segment_id": segment.segment_id,
                    "start_node": segment.start_node,
                    "end_node": segment.end_node,
                    "width_m": segment.width_m,
                    "altitude_min_m": segment.altitude_min_m,
                    "altitude_max_m": segment.altitude_max_m,
                    "speed_limit_mps": segment.speed_limit_mps,
                    "status": segment.status,
                }
                for segment in self.segments
            ],
            "alternate_landing_points": list(self.alternate_landing_points.keys()),
        }


def _segment(
    segment_id: str,
    nodes: dict[str, AirspaceNode],
    start_node: str,
    end_node: str,
    width_m: float,
    altitude_min_m: float,
    altitude_max_m: float,
    speed_limit_mps: float,
) -> CorridorSegment:
    start = nodes[start_node]
    end = nodes[end_node]
    return CorridorSegment(
        segment_id=segment_id,
        start_node=start_node,
        end_node=end_node,
        centerline=((start.x_m, start.y_m), (end.x_m, end.y_m)),
        width_m=float(width_m),
        altitude_min_m=altitude_min_m,
        altitude_max_m=altitude_max_m,
        speed_limit_mps=speed_limit_mps,
    )


def _spatial_xyz(risk_field: RiskField4D, node: SpatialNode | State4D) -> tuple[float, float, float]:
    if len(node) == 4:
        _, z, y, x = node  # type: ignore[misc]
    else:
        z, y, x = node  # type: ignore[misc]
    x_axis = np.asarray(risk_field.coords.get("x", np.arange(risk_field.x_size)), dtype=float)
    y_axis = np.asarray(risk_field.coords.get("y", np.arange(risk_field.y_size)), dtype=float)
    z_axis = np.asarray(risk_field.coords.get("height", np.arange(risk_field.z_size)), dtype=float)
    return float(x_axis[x]), float(y_axis[y]), float(z_axis[z])


def _nominal_resolution_m(risk_field: RiskField4D) -> float:
    x_axis = np.asarray(risk_field.coords.get("x", np.arange(risk_field.x_size)), dtype=float)
    y_axis = np.asarray(risk_field.coords.get("y", np.arange(risk_field.y_size)), dtype=float)
    spacings = []
    if x_axis.size > 1:
        spacings.append(float(np.nanmedian(np.abs(np.diff(x_axis)))))
    if y_axis.size > 1:
        spacings.append(float(np.nanmedian(np.abs(np.diff(y_axis)))))
    positive = [value for value in spacings if value > 0.0]
    return min(positive) if positive else 1.0


def _normal_vector(x0: float, y0: float, x1: float, y1: float) -> tuple[float, float]:
    dx = x1 - x0
    dy = y1 - y0
    length = math.hypot(dx, dy)
    if length <= 1e-9:
        return 0.0, 1.0
    return -dy / length, dx / length


def _distance_point_to_segment(point: Point2D, start: Point2D, end: Point2D) -> float:
    px, py = point
    ax, ay = start
    bx, by = end
    dx = bx - ax
    dy = by - ay
    denom = dx * dx + dy * dy
    if denom <= 1e-12:
        return math.hypot(px - ax, py - ay)
    t = max(0.0, min(1.0, ((px - ax) * dx + (py - ay) * dy) / denom))
    cx = ax + t * dx
    cy = ay + t * dy
    return math.hypot(px - cx, py - cy)
