from __future__ import annotations

from pathlib import Path

import numpy as np

from uav_weather_planning.preprocessing import build_local_grid_from_bbox

from .weather_cache import WeatherCache, WeatherDependencyError, WeatherRequest
from .weather_cube import WeatherCube, WeatherDataError


class HRRRLoader:
    """HRRR loader using Herbie when available."""

    def __init__(self, cache_root: str | Path = "data/cache") -> None:
        self.cache = WeatherCache(cache_root)

    def load(self, request: WeatherRequest) -> WeatherCube:
        if request.cache_policy in {"reuse", "cache_only"} and self.cache.exists(request):
            return self.cache.load(request)
        if request.cache_policy == "cache_only":
            raise FileNotFoundError(f"HRRR cache not found: {self.cache.path_for(request)}")
        cube = self.download(request)
        self.cache.save(request, cube)
        return cube

    def download(self, request: WeatherRequest) -> WeatherCube:
        try:
            from herbie import Herbie  # type: ignore
        except ImportError as exc:
            raise WeatherDependencyError(
                "HRRR download requires herbie-data plus cfgrib/eccodes. "
                "Install these dependencies or use cache_only with a prepared cache."
            ) from exc

        if not request.forecast_hours:
            raise WeatherDataError("HRRR request requires forecast_hours, e.g. (0, 1, 2, 3)")

        datasets = []
        for fxx in request.forecast_hours:
            hrrr = Herbie(request.start_time, model="hrrr", product="prs", fxx=int(fxx), save_dir="data/cache/hrrr/grib")
            ds = hrrr.xarray(
                searchString=r":(UGRD|VGRD|GUST|REFC|APCP|VIS|TMP|RH|CLOUD):",
                backend_kwargs={"indexpath": ""},
            )
            datasets.append(ds[0] if isinstance(ds, list) else ds)
        return self._datasets_to_cube(datasets, request)

    def _datasets_to_cube(self, datasets, request: WeatherRequest) -> WeatherCube:
        # HRRR GRIB variables vary by product. This converter is deliberately
        # conservative and raises if the data cannot be normalized.
        if not datasets:
            raise WeatherDataError("no HRRR datasets returned")
        try:
            import xarray as xr  # noqa: F401
        except ImportError as exc:
            raise WeatherDependencyError("xarray is required to normalize HRRR datasets") from exc

        first = datasets[0]
        y_name = "y" if "y" in first.dims else "latitude"
        x_name = "x" if "x" in first.dims else "longitude"
        y_len = first.sizes[y_name]
        x_len = first.sizes[x_name]
        z_len = 1
        t_len = len(datasets)
        shape = (t_len, z_len, y_len, x_len)
        y_coord, x_coord, grid_metadata = _hrrr_coordinate_definition(first, y_name, x_name, y_len, x_len)

        def find(ds, candidates: tuple[str, ...], default: float = 0.0):
            for name in candidates:
                if name in ds:
                    arr = np.asarray(ds[name].values, dtype=float)
                    return arr.reshape((1, 1, y_len, x_len))
            return np.full((1, 1, y_len, x_len), default, dtype=float)

        variables = {
            name: []
            for name in [
                "u_wind",
                "v_wind",
                "w_wind",
                "gust",
                "reflectivity",
                "rain_rate",
                "visibility",
                "temperature",
                "relative_humidity",
                "cloud_liquid_water",
            ]
        }
        for ds in datasets:
            variables["u_wind"].append(find(ds, ("u", "u10", "u1000")))
            variables["v_wind"].append(find(ds, ("v", "v10", "v1000")))
            variables["w_wind"].append(np.zeros((1, 1, y_len, x_len)))
            variables["gust"].append(find(ds, ("gust", "GUST")))
            variables["reflectivity"].append(find(ds, ("refc", "REFC")))
            variables["rain_rate"].append(find(ds, ("tp", "APCP", "prate")))
            variables["visibility"].append(find(ds, ("vis", "VIS"), default=7500.0) / 1000.0)
            variables["temperature"].append(find(ds, ("t", "t2m", "TMP"), default=291.15) - 273.15)
            variables["relative_humidity"].append(find(ds, ("r", "r2", "RH"), default=70.0))
            variables["cloud_liquid_water"].append(find(ds, ("clwmr", "CLOUD"), default=0.0))

        stacked = {name: np.concatenate(values, axis=0).reshape(shape) for name, values in variables.items()}
        stacked["convection_probability"] = np.clip((stacked["reflectivity"] - 20.0) / 30.0, 0.0, 1.0)
        stacked["ceiling"] = np.full(shape, 500.0)
        stacked["dewpoint_spread"] = np.clip(12.0 * (1.0 - stacked["relative_humidity"] / 100.0), 0.0, 12.0)
        stacked["pressure"] = np.full(shape, 1000.0)
        stacked["updraft_speed"] = np.maximum(stacked["w_wind"], 0.0)
        return WeatherCube(
            time=np.arange(t_len),
            height=np.array([100.0]),
            y=y_coord,
            x=x_coord,
            variables=stacked,
            source_metadata={"source": "HRRR", "request": request.cache_key(), **grid_metadata},
            confidence=0.84,
        )


def _hrrr_coordinate_definition(first, y_name: str, x_name: str, y_len: int, x_len: int) -> tuple[np.ndarray, np.ndarray, dict]:
    if "latitude" in first and "longitude" in first:
        lat = np.asarray(first["latitude"].values, dtype=float)
        lon = np.asarray(first["longitude"].values, dtype=float)
        bbox = (float(np.nanmax(lat)), float(np.nanmin(lon)), float(np.nanmin(lat)), float(np.nanmax(lon)))
        geo_grid = build_local_grid_from_bbox(bbox, y_len, x_len)
        return (
            geo_grid.y_m,
            geo_grid.x_m,
            {
                "bbox": bbox,
                "geospatial_grid": geo_grid.as_metadata(),
                "grid": "hrrr_latlon_subset_projected_to_local_meter_grid",
            },
        )

    y_values = _numeric_coord(first, y_name, y_len)
    x_values = _numeric_coord(first, x_name, x_len)
    return (
        y_values,
        x_values,
        {
            "grid": "hrrr_native_projection_or_index_grid",
            "coordinate_status": "native x/y coordinates used when present; otherwise integer indices",
            "geospatial_grid": {
                "crs": "HRRR_NATIVE_OR_UNKNOWN",
                "axis_definition": {
                    "x": "native HRRR x coordinate if available, otherwise grid index",
                    "y": "native HRRR y coordinate if available, otherwise grid index",
                    "height": "meters above local ground/reference level",
                    "time": "forecast hour index",
                },
                "shape": {"y": int(y_len), "x": int(x_len)},
                "resolution": {"x": float(_spacing(x_values)), "y": float(_spacing(y_values))},
                "x": [float(v) for v in x_values.tolist()],
                "y": [float(v) for v in y_values.tolist()],
            },
        },
    )


def _numeric_coord(dataset, name: str, size: int) -> np.ndarray:
    if name in getattr(dataset, "coords", {}):
        values = np.asarray(dataset[name].values, dtype=float)
        if values.ndim == 1 and len(values) == size:
            return values
    return np.arange(size, dtype=float)


def _spacing(values: np.ndarray) -> float:
    if len(values) <= 1:
        return 0.0
    return float(np.nanmean(np.diff(np.asarray(values, dtype=float))))
