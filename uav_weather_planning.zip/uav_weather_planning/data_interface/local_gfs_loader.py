from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np

from uav_weather_planning.preprocessing import build_bbox_from_center_extent, build_local_grid_from_bbox

from .weather_cache import WeatherCache, WeatherRequest
from .weather_cube import WeatherCube, WeatherDataError


@dataclass
class LocalGFSReplayConfig:
    wind_path: str | Path = "real_weather_wind.nc"
    rain_path: str | Path = "real_weather_rain.nc"
    processed_path: str | Path | None = "processed_env.nc"
    bbox: tuple[float, float, float, float] | None = None  # regional background bbox: north, west, south, east
    planning_bbox: tuple[float, float, float, float] | None = None  # local multirotor task bbox
    planning_center: tuple[float, float] | None = None  # latitude, longitude
    planning_extent_km: float = 60.0
    add_local_perturbations: bool = True
    t_size: int = 24
    z_size: int = 4
    y_size: int = 32
    x_size: int = 32
    dt_minutes: int = 10
    cache_policy: str = "reuse"


class LocalGFSReplayLoader:
    """Convert cached local GFS NetCDF4/HDF5 files into a replay WeatherCube.

    The repository currently contains one forecast valid time. To make a
    dynamic replay without network access, the loader builds a short nowcast
    sequence by advecting the observed reflectivity/rain proxy with the
    low-level wind. When multi-forecast files are available, this class can be
    extended to stack those valid times directly.
    """

    def __init__(self, cache_root: str | Path = "data/cache") -> None:
        self.cache = WeatherCache(cache_root)

    def request_for(self, config: LocalGFSReplayConfig) -> WeatherRequest:
        background_bbox = config.bbox or self._bbox_from_processed(config.processed_path)
        planning_bbox = self._planning_bbox(config, background_bbox)
        return WeatherRequest(
            source="LOCAL_GFS",
            start_time=self._valid_time_string(config.wind_path),
            bbox=planning_bbox,
            variables=(
                "u_wind",
                "v_wind",
                "w_wind",
                "gust",
                "reflectivity",
                "convection_probability",
                "rain_rate",
                "visibility",
                "ceiling",
                "temperature",
                "relative_humidity",
                "pressure",
                "dewpoint_spread",
                "cloud_liquid_water",
                "updraft_speed",
                f"grid_{config.y_size}x{config.x_size}",
                f"extent_{config.planning_extent_km:.1f}km",
                f"dt_{config.dt_minutes}min",
                f"localperturb_{int(config.add_local_perturbations)}",
            ),
            levels=tuple(range(config.z_size)),
            forecast_hours=tuple(range(config.t_size)),
            cache_policy=config.cache_policy,
        )

    def load(self, config: LocalGFSReplayConfig | None = None) -> WeatherCube:
        config = config or LocalGFSReplayConfig()
        request = self.request_for(config)
        if config.cache_policy in {"reuse", "cache_only"} and self.cache.exists(request):
            cached = self.cache.load(request)
            if _has_geospatial_grid(cached):
                return cached
            if config.cache_policy == "cache_only":
                raise WeatherDataError(
                    "LOCAL_GFS cache exists but lacks geospatial_grid metadata; rebuild cache to use real coordinates."
                )
        if config.cache_policy == "cache_only":
            raise FileNotFoundError(f"LOCAL_GFS cache not found: {self.cache.path_for(request)}")
        cube = self.build_cube(config)
        self.cache.save(request, cube)
        return cube

    def build_cube(self, config: LocalGFSReplayConfig) -> WeatherCube:
        try:
            import h5py
        except ImportError as exc:
            raise WeatherDataError("h5py is required to read local NetCDF4/HDF5 GFS files") from exc

        wind_path = Path(config.wind_path)
        rain_path = Path(config.rain_path)
        processed_path = Path(config.processed_path) if config.processed_path else None
        if not wind_path.exists():
            raise FileNotFoundError(wind_path)
        if not rain_path.exists() and (processed_path is None or not processed_path.exists()):
            raise FileNotFoundError(rain_path)

        background_bbox = config.bbox or self._bbox_from_processed(processed_path)
        planning_bbox = self._planning_bbox(config, background_bbox)
        geo_grid = build_local_grid_from_bbox(planning_bbox, config.y_size, config.x_size)
        with h5py.File(wind_path, "r") as wind_file:
            lat = np.asarray(wind_file["latitude"][()])
            lon = np.asarray(wind_file["longitude"][()])
            levels = np.asarray(wind_file["isobaricInhPa"][()])
            lat_idx = _indices_for_range(lat, min(planning_bbox[2], planning_bbox[0]), max(planning_bbox[2], planning_bbox[0]))
            lon_idx = _indices_for_range(lon, _normalize_lon(planning_bbox[1]), _normalize_lon(planning_bbox[3]))
            level_idx = np.arange(min(config.z_size, len(levels)))
            u_base = _read_level_lat_lon(wind_file["u"], level_idx, lat_idx, lon_idx)
            v_base = _read_level_lat_lon(wind_file["v"], level_idx, lat_idx, lon_idx)
            gh_base = _read_level_lat_lon(wind_file["gh"], level_idx, lat_idx, lon_idx) if "gh" in wind_file else None
            valid_time = _scalar(wind_file, "valid_time")
            init_time = _scalar(wind_file, "time")

        if processed_path is not None and processed_path.exists():
            reflectivity_base = self._reflectivity_from_processed(processed_path, planning_bbox, config)
        else:
            reflectivity_base = self._reflectivity_from_rain(rain_path, planning_bbox, config)

        u_base = _resize_3d(u_base, config.z_size, config.y_size, config.x_size)
        v_base = _resize_3d(v_base, config.z_size, config.y_size, config.x_size)
        reflectivity_base = _resize_3d(reflectivity_base, config.z_size, config.y_size, config.x_size)
        if gh_base is not None:
            gh_base = _resize_3d(gh_base, config.z_size, config.y_size, config.x_size)

        weather = self._make_replay_sequence(
            u_base=u_base,
            v_base=v_base,
            reflectivity_base=reflectivity_base,
            gh_base=gh_base,
            levels=levels[: config.z_size],
            config=config,
        )
        source_metadata: dict[str, Any] = {
            "source": "LOCAL_GFS_REPLAY",
            "wind_path": str(wind_path),
            "rain_path": str(rain_path),
            "processed_path": str(processed_path) if processed_path else None,
            "bbox": planning_bbox,
            "background_bbox": background_bbox,
            "planning_bbox": planning_bbox,
            "geospatial_grid": geo_grid.as_metadata(),
            "initial_time_unix": init_time,
            "valid_time_unix": valid_time,
            "grid": "regional_weather_background_downscaled_to_local_multirotor_task_grid",
            "scale_separation": {
                "weather_data_role": "regional background risk input",
                "planning_grid_role": "local low-altitude multirotor task grid",
                "background_bbox": [float(v) for v in background_bbox],
                "planning_bbox": [float(v) for v in planning_bbox],
                "planning_extent_km": float(config.planning_extent_km),
                "x_resolution_m": float(geo_grid.x_resolution_m),
                "y_resolution_m": float(geo_grid.y_resolution_m),
                "note": "GFS/HRRR resolution is not used as the UAV motion grid; weather variables are sampled onto this local task grid and supplemented by local perturbations.",
            },
            "downscaling_method": (
                "sample regional GFS background inside local task bbox, resample to local metric grid, "
                "advect single valid-time features, and add deterministic low-altitude perturbations"
                if config.add_local_perturbations
                else "sample regional GFS background inside local task bbox and resample to local metric grid"
            ),
            "time_resolution_seconds": float(config.dt_minutes * 60),
            "time_axis_unit": "seconds_from_replay_start",
            "height_resolution_m": float(750.0 / max(config.z_size - 1, 1)),
            "height_levels_m": [float(v) for v in np.linspace(0.0, 750.0, config.z_size)],
            "temporal_method": "single-valid-time GFS snapshot advected by low-level wind",
            "historical_replay_mode": "single_valid_time_nowcast_fallback",
            "strict_historical_sequence": False,
            "snapshot_count": 1,
            "real_valid_times_count": 1,
            "fallback_reason": "repository local GFS files contain one real valid time; dynamic sequence is a documented nowcast fallback",
            "variables": sorted(weather.keys()),
        }
        confidence = self._confidence(weather["reflectivity"], config)
        return WeatherCube(
            time=np.arange(config.t_size, dtype=float) * config.dt_minutes * 60.0,
            height=np.linspace(0.0, 750.0, config.z_size),
            y=geo_grid.y_m,
            x=geo_grid.x_m,
            variables=weather,
            source_metadata=source_metadata,
            confidence=confidence,
        )

    def _reflectivity_from_processed(
        self,
        processed_path: Path,
        bbox: tuple[float, float, float, float],
        config: LocalGFSReplayConfig,
    ) -> np.ndarray:
        import h5py

        with h5py.File(processed_path, "r") as f:
            refc = np.asarray(f["refc"][()])
            if refc.ndim != 3:
                raise WeatherDataError("processed refc must be 3D")
            if "latitude" in f and "longitude" in f:
                lat = np.asarray(f["latitude"][()])
                lon = np.asarray(f["longitude"][()])
                lat_idx = _indices_for_range(lat, min(bbox[2], bbox[0]), max(bbox[2], bbox[0]))
                lon_idx = _indices_for_range(lon, _normalize_lon(bbox[1]), _normalize_lon(bbox[3]))
                refc = refc[np.ix_(lat_idx, lon_idx, np.arange(refc.shape[2]))]
            # processed_env stores (lat, lon, height); convert to (height, lat, lon)
            return np.moveaxis(refc, -1, 0)

    def _reflectivity_from_rain(
        self,
        rain_path: str | Path,
        bbox: tuple[float, float, float, float],
        config: LocalGFSReplayConfig,
    ) -> np.ndarray:
        import h5py

        with h5py.File(rain_path, "r") as f:
            lat = np.asarray(f["latitude"][()])
            lon = np.asarray(f["longitude"][()])
            lat_idx = _indices_for_range(lat, min(bbox[2], bbox[0]), max(bbox[2], bbox[0]))
            lon_idx = _indices_for_range(lon, _normalize_lon(bbox[1]), _normalize_lon(bbox[3]))
            ref2d = _read_lat_lon(f["refc"], lat_idx, lon_idx)
        return np.repeat(ref2d[None, :, :], config.z_size, axis=0)

    def _make_replay_sequence(
        self,
        u_base: np.ndarray,
        v_base: np.ndarray,
        reflectivity_base: np.ndarray,
        gh_base: np.ndarray | None,
        levels: np.ndarray,
        config: LocalGFSReplayConfig,
    ) -> dict[str, np.ndarray]:
        shape = (config.t_size, config.z_size, config.y_size, config.x_size)
        u = np.zeros(shape, dtype=float)
        v = np.zeros(shape, dtype=float)
        w = np.zeros(shape, dtype=float)
        reflectivity = np.zeros(shape, dtype=float)

        low_u = float(np.nanmean(u_base[: min(2, u_base.shape[0])]))
        low_v = float(np.nanmean(v_base[: min(2, v_base.shape[0])]))
        dx_shift_per_step = int(np.clip(np.round(low_u / 8.0), -1, 1))
        dy_shift_per_step = -int(np.clip(np.round(low_v / 8.0), -1, 1))
        if dx_shift_per_step == 0 and dy_shift_per_step == 0:
            dx_shift_per_step = 1

        for ti in range(config.t_size):
            phase = 0.08 * np.sin(ti / 4.0)
            dx = dx_shift_per_step * ti
            dy = dy_shift_per_step * ti
            intensity = 0.92 + 0.16 * np.sin(ti / 5.0)
            for zi in range(config.z_size):
                reflectivity[ti, zi] = np.clip(_shift2d(reflectivity_base[zi], dy, dx) * intensity, 0.0, 65.0)
            u[ti] = u_base + phase
            v[ti] = v_base + 0.06 * np.cos(ti / 5.0)
            convection_proxy = np.clip((reflectivity[ti] - 20.0) / 35.0, 0.0, 1.0)
            w[ti] = 0.08 * np.arange(config.z_size)[:, None, None] + 0.9 * convection_proxy

        wind_speed = np.sqrt(u * u + v * v + w * w)
        gust = wind_speed * 1.22 + 5.5 * np.clip((reflectivity - 25.0) / 35.0, 0.0, 1.0)
        convection_probability = np.clip((reflectivity - 18.0) / 32.0, 0.0, 1.0)
        rain_rate = _rain_rate_from_reflectivity(reflectivity)
        visibility = np.clip(8.0 - 0.10 * rain_rate - 3.6 * convection_probability, 0.4, 10.0)
        ceiling = np.clip(620.0 - 330.0 * convection_probability - 7.0 * rain_rate, 80.0, 900.0)

        if gh_base is not None:
            temperature_base = 18.0 - 0.0065 * np.clip(gh_base, 0.0, 3000.0)
        else:
            temperature_base = 18.0 - 4.5 * np.arange(config.z_size)[:, None, None]
        temperature = np.broadcast_to(temperature_base[None, :, :, :], shape).copy() - 2.5 * convection_probability
        relative_humidity = np.clip(58.0 + 38.0 * convection_probability + 0.8 * rain_rate, 25.0, 100.0)
        pressure_levels = np.asarray(levels[: config.z_size], dtype=float)
        if len(pressure_levels) < config.z_size:
            pressure_levels = np.linspace(1000.0, 925.0, config.z_size)
        pressure = np.broadcast_to(pressure_levels[None, :, None, None], shape).copy()
        dewpoint_spread = np.clip(12.0 * (1.0 - relative_humidity / 100.0), 0.0, 12.0)
        cloud_liquid_water = np.clip(0.05 * rain_rate + 0.75 * convection_probability, 0.0, 2.0)
        updraft_speed = np.maximum(w, 0.0) + 1.6 * convection_probability

        if config.add_local_perturbations:
            perturb = _local_low_altitude_perturbations(config)
            altitude_taper = np.linspace(1.0, 0.35, config.z_size)[None, :, None, None]
            u += 0.55 * perturb["wind_x"] * altitude_taper
            v += 0.55 * perturb["wind_y"] * altitude_taper
            w += 0.22 * perturb["vertical"] * altitude_taper
            gust += 2.8 * perturb["gust"] * altitude_taper
            reflectivity = np.clip(reflectivity + 5.5 * perturb["convective"] * altitude_taper, 0.0, 65.0)
            rain_rate = np.clip(rain_rate + 1.8 * perturb["precipitation"] * altitude_taper, 0.0, None)
            convection_probability = np.clip(convection_probability + 0.16 * perturb["convective"] * altitude_taper, 0.0, 1.0)
            visibility = np.clip(visibility - 1.2 * perturb["visibility"] * altitude_taper, 0.4, 10.0)
            ceiling = np.clip(ceiling - 60.0 * perturb["visibility"] * altitude_taper, 80.0, 900.0)
            temperature = temperature - 1.1 * perturb["convective"] * altitude_taper
            relative_humidity = np.clip(relative_humidity + 10.0 * perturb["visibility"] * altitude_taper, 25.0, 100.0)
            dewpoint_spread = np.clip(12.0 * (1.0 - relative_humidity / 100.0), 0.0, 12.0)
            cloud_liquid_water = np.clip(cloud_liquid_water + 0.18 * perturb["visibility"] * altitude_taper, 0.0, 2.0)
            updraft_speed = np.maximum(w, 0.0) + 1.6 * convection_probability

        return {
            "u_wind": np.nan_to_num(u),
            "v_wind": np.nan_to_num(v),
            "w_wind": np.nan_to_num(w),
            "gust": np.nan_to_num(gust),
            "reflectivity": np.nan_to_num(reflectivity),
            "convection_probability": np.nan_to_num(convection_probability),
            "rain_rate": np.nan_to_num(rain_rate),
            "visibility": np.nan_to_num(visibility),
            "ceiling": np.nan_to_num(ceiling),
            "temperature": np.nan_to_num(temperature),
            "relative_humidity": np.nan_to_num(relative_humidity),
            "pressure": np.nan_to_num(pressure),
            "dewpoint_spread": np.nan_to_num(dewpoint_spread),
            "cloud_liquid_water": np.nan_to_num(cloud_liquid_water),
            "updraft_speed": np.nan_to_num(updraft_speed),
        }

    def _confidence(self, reflectivity: np.ndarray, config: LocalGFSReplayConfig) -> np.ndarray:
        t = np.arange(config.t_size)[:, None, None, None]
        lead_time_decay = 0.015 * t
        storm_uncertainty = 0.25 * np.clip((reflectivity - 18.0) / 35.0, 0.0, 1.0)
        return np.clip(0.86 - lead_time_decay - storm_uncertainty, 0.42, 0.92)

    def _bbox_from_processed(self, processed_path: str | Path | None) -> tuple[float, float, float, float]:
        if processed_path is None:
            return (46.0, 125.0, 44.0, 127.0)
        path = Path(processed_path)
        if not path.exists():
            return (46.0, 125.0, 44.0, 127.0)
        try:
            import h5py

            with h5py.File(path, "r") as f:
                lat = np.asarray(f["latitude"][()])
                lon = np.asarray(f["longitude"][()])
            return (float(np.nanmax(lat)), float(np.nanmin(lon)), float(np.nanmin(lat)), float(np.nanmax(lon)))
        except Exception:
            return (46.0, 125.0, 44.0, 127.0)

    def _planning_bbox(
        self,
        config: LocalGFSReplayConfig,
        background_bbox: tuple[float, float, float, float],
    ) -> tuple[float, float, float, float]:
        if config.planning_bbox is not None:
            return tuple(float(v) for v in config.planning_bbox)  # type: ignore[return-value]
        if config.planning_center is not None:
            center_lat, center_lon = config.planning_center
        else:
            center_lat, center_lon = _bbox_center(background_bbox)
        extent_m = float(config.planning_extent_km) * 1000.0
        return build_bbox_from_center_extent(center_lat, center_lon, extent_m, extent_m)

    def _valid_time_string(self, wind_path: str | Path) -> str:
        try:
            import datetime as dt
            import h5py

            with h5py.File(wind_path, "r") as f:
                valid = float(np.asarray(f["valid_time"][()]))
            return dt.datetime.utcfromtimestamp(valid).strftime("%Y-%m-%dT%H:%M")
        except Exception:
            return "local-gfs-replay"


def _normalize_lon(value: float) -> float:
    return value % 360.0


def _bbox_center(bbox: tuple[float, float, float, float]) -> tuple[float, float]:
    north, west, south, east = (float(v) for v in bbox)
    west_360 = _normalize_lon(west)
    east_360 = _normalize_lon(east)
    lon_span = east_360 - west_360
    if lon_span < 0.0:
        lon_span += 360.0
    return (north + south) / 2.0, (west_360 + lon_span / 2.0) % 360.0


def _has_geospatial_grid(cube: WeatherCube) -> bool:
    grid = cube.source_metadata.get("geospatial_grid")
    return isinstance(grid, dict) and bool(grid.get("resolution_m"))


def _indices_for_range(values: np.ndarray, lower: float, upper: float) -> np.ndarray:
    values = np.asarray(values, dtype=float)
    if lower <= upper:
        mask = (values >= lower) & (values <= upper)
    else:
        mask = (values >= lower) | (values <= upper)
    indices = np.where(mask)[0]
    if indices.size == 0:
        center = (lower + upper) / 2.0
        nearest = int(np.argmin(np.abs(values - center)))
        half = 10
        indices = np.arange(max(0, nearest - half), min(len(values), nearest + half + 1))
    return indices


def _read_level_lat_lon(dataset, level_idx: np.ndarray, lat_idx: np.ndarray, lon_idx: np.ndarray) -> np.ndarray:
    out = np.zeros((len(level_idx), len(lat_idx), len(lon_idx)), dtype=float)
    for oi, li in enumerate(level_idx):
        out[oi] = _read_lat_lon(dataset[li], lat_idx, lon_idx)
    return out


def _read_lat_lon(dataset, lat_idx: np.ndarray, lon_idx: np.ndarray) -> np.ndarray:
    lat_slice = slice(int(lat_idx.min()), int(lat_idx.max()) + 1)
    lon_slice = slice(int(lon_idx.min()), int(lon_idx.max()) + 1)
    data = np.asarray(dataset[lat_slice, lon_slice], dtype=float)
    return data[np.searchsorted(np.arange(lat_idx.min(), lat_idx.max() + 1), lat_idx), :][
        :, np.searchsorted(np.arange(lon_idx.min(), lon_idx.max() + 1), lon_idx)
    ]


def _resize_3d(arr: np.ndarray, z_size: int, y_size: int, x_size: int) -> np.ndarray:
    arr = np.asarray(arr, dtype=float)
    z_source = np.linspace(0.0, 1.0, arr.shape[0])
    z_target = np.linspace(0.0, 1.0, z_size)
    resized_z = np.zeros((z_size, arr.shape[1], arr.shape[2]), dtype=float)
    for y in range(arr.shape[1]):
        for x in range(arr.shape[2]):
            resized_z[:, y, x] = np.interp(z_target, z_source, arr[:, y, x])
    return np.stack([_resize_2d(layer, y_size, x_size) for layer in resized_z], axis=0)


def _resize_2d(arr: np.ndarray, y_size: int, x_size: int) -> np.ndarray:
    arr = np.asarray(arr, dtype=float)
    src_y = np.linspace(0.0, 1.0, arr.shape[0])
    src_x = np.linspace(0.0, 1.0, arr.shape[1])
    dst_y = np.linspace(0.0, 1.0, y_size)
    dst_x = np.linspace(0.0, 1.0, x_size)
    tmp = np.zeros((y_size, arr.shape[1]), dtype=float)
    for x in range(arr.shape[1]):
        tmp[:, x] = np.interp(dst_y, src_y, arr[:, x])
    out = np.zeros((y_size, x_size), dtype=float)
    for y in range(y_size):
        out[y] = np.interp(dst_x, src_x, tmp[y])
    return out


def _shift2d(arr: np.ndarray, dy: int, dx: int) -> np.ndarray:
    out = np.zeros_like(arr)
    y_src_start = max(0, -dy)
    y_src_end = min(arr.shape[0], arr.shape[0] - dy) if dy >= 0 else arr.shape[0]
    x_src_start = max(0, -dx)
    x_src_end = min(arr.shape[1], arr.shape[1] - dx) if dx >= 0 else arr.shape[1]
    y_dst_start = max(0, dy)
    x_dst_start = max(0, dx)
    y_len = max(0, y_src_end - y_src_start)
    x_len = max(0, x_src_end - x_src_start)
    if y_len and x_len:
        out[y_dst_start : y_dst_start + y_len, x_dst_start : x_dst_start + x_len] = arr[
            y_src_start : y_src_start + y_len, x_src_start : x_src_start + x_len
        ]
    return out


def _rain_rate_from_reflectivity(reflectivity_dbz: np.ndarray) -> np.ndarray:
    z_linear = np.power(10.0, np.clip(reflectivity_dbz, 0.0, 70.0) / 10.0)
    rain = np.power(np.maximum(z_linear / 200.0, 0.0), 1.0 / 1.6)
    return np.where(reflectivity_dbz > 5.0, rain, 0.0)


def _local_low_altitude_perturbations(config: LocalGFSReplayConfig) -> dict[str, np.ndarray]:
    """Deterministic local weather structure used for low-altitude routing scale.

    Regional GFS/HRRR fields provide the background state, but a multirotor
    task grid also needs sub-grid gust, shear, visibility and convection
    structure. These perturbations are modest, deterministic, and documented
    in metadata so they are not mistaken for native GFS resolution.
    """

    t = np.arange(config.t_size)[:, None, None, None]
    yy = np.arange(config.y_size)[None, None, :, None]
    xx = np.arange(config.x_size)[None, None, None, :]
    shape = (config.t_size, 1, config.y_size, config.x_size)
    y_mid = (config.y_size - 1) / 2.0
    x_mid = (config.x_size - 1) / 2.0

    shear_band = np.exp(-((yy - (0.35 * config.y_size + 0.10 * t)) ** 2) / (2.0 * max(config.y_size * 0.10, 1.0) ** 2))
    gust_patch = np.exp(
        -(((yy - (0.20 * config.y_size + 0.22 * t)) ** 2) + ((xx - (0.24 * config.x_size + 0.18 * t)) ** 2))
        / (2.0 * max(config.x_size * 0.12, 1.0) ** 2)
    )
    convective_patch = np.exp(
        -(((yy - (0.68 * config.y_size - 0.12 * t)) ** 2) + ((xx - (0.62 * config.x_size - 0.10 * t)) ** 2))
        / (2.0 * max(config.x_size * 0.15, 1.0) ** 2)
    )
    fog_patch = np.exp(-(((yy - 0.74 * config.y_size) ** 2) + ((xx - 0.28 * config.x_size) ** 2)) / (2.0 * max(config.x_size * 0.18, 1.0) ** 2))
    wave_x = np.sin((xx - x_mid) / max(config.x_size, 1) * np.pi * 2.0 + 0.20 * t)
    wave_y = np.cos((yy - y_mid) / max(config.y_size, 1) * np.pi * 2.0 - 0.18 * t)

    return {
        "wind_x": np.broadcast_to(0.7 * wave_x + 1.1 * shear_band, shape).copy(),
        "wind_y": np.broadcast_to(0.6 * wave_y - 0.9 * shear_band, shape).copy(),
        "vertical": np.broadcast_to(0.8 * convective_patch - 0.25 * fog_patch, shape).copy(),
        "gust": np.broadcast_to(np.clip(gust_patch + 0.35 * shear_band, 0.0, 1.0), shape).copy(),
        "convective": np.broadcast_to(convective_patch, shape).copy(),
        "precipitation": np.broadcast_to(np.clip(0.55 * convective_patch + 0.20 * gust_patch, 0.0, 1.0), shape).copy(),
        "visibility": np.broadcast_to(fog_patch, shape).copy(),
    }


def _scalar(file, name: str) -> float | None:
    if name not in file:
        return None
    value = np.asarray(file[name][()])
    return float(value.reshape(-1)[0]) if value.shape else float(value)
