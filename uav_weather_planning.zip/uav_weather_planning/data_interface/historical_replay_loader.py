from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np

from .local_gfs_loader import LocalGFSReplayConfig, LocalGFSReplayLoader
from .weather_cube import WeatherCube, WeatherDataError


@dataclass
class HistoricalReplayConfig:
    """Configuration for strict historical weather replay datasets."""

    cube_paths: tuple[str | Path, ...] = ()
    cube_dir: str | Path | None = None
    allow_single_time_fallback: bool = True
    fallback_config: LocalGFSReplayConfig | None = None


class HistoricalWeatherReplayLoader:
    """Load real historical weather sequences as WeatherCube objects.

    Strict replay means the time axis is backed by multiple real valid times
    from cached WeatherCube files. When only the repository's single local GFS
    valid time is available, callers may explicitly allow the documented
    single-time nowcast fallback.
    """

    def __init__(self, cache_root: str | Path = "data/cache") -> None:
        self.cache_root = Path(cache_root)

    def load(self, config: HistoricalReplayConfig | None = None) -> WeatherCube:
        config = config or HistoricalReplayConfig()
        cube_paths = self._resolve_cube_paths(config)
        if cube_paths:
            cubes = [WeatherCube.from_npz(path) for path in cube_paths]
            strict = self._has_multiple_real_valid_times(cubes)
            if strict:
                return self._combine_cubes(cubes, cube_paths)
            if len(cubes) == 1 and self._is_strict_multitime_cube(cubes[0]):
                return self._mark_strict_single_cube(cubes[0], cube_paths[0])
            if not config.allow_single_time_fallback:
                raise WeatherDataError(
                    "Historical replay requires at least two cached real valid times. "
                    f"Found {len(cubes)} cube(s) with {self._valid_time_count(cubes)} unique valid time(s)."
                )
            fallback_cube = self._best_fallback_cube(cubes)
            return self._mark_single_time_fallback(
                fallback_cube,
                reason="cache contains fewer than two unique real valid times",
                input_paths=cube_paths,
            )

        if not config.allow_single_time_fallback:
            raise WeatherDataError(
                "No cached historical WeatherCube sequence was provided. "
                "Pass --cube-dir or --cube-paths with at least two real valid times."
            )

        fallback_config = config.fallback_config or LocalGFSReplayConfig(cache_policy="reuse")
        cube = LocalGFSReplayLoader(self.cache_root).load(fallback_config)
        return self._mark_single_time_fallback(
            cube,
            reason="repository local GFS files contain one real valid time; nowcast fallback requested",
            input_paths=[Path(fallback_config.wind_path), Path(fallback_config.rain_path)],
        )

    def _resolve_cube_paths(self, config: HistoricalReplayConfig) -> list[Path]:
        paths = [Path(path) for path in config.cube_paths]
        if config.cube_dir:
            paths.extend(sorted(Path(config.cube_dir).glob("*.npz")))
        unique: list[Path] = []
        seen = set()
        for path in paths:
            resolved = path.resolve()
            if resolved not in seen:
                seen.add(resolved)
                unique.append(path)
        return unique

    def _combine_cubes(self, cubes: list[WeatherCube], paths: list[Path]) -> WeatherCube:
        first = cubes[0]
        self._validate_compatible(cubes)
        variable_names = sorted(set.intersection(*(set(cube.variables.keys()) for cube in cubes)))
        variables = {name: np.concatenate([cube.variables[name] for cube in cubes], axis=0) for name in variable_names}
        confidence = self._combine_confidence(cubes)
        time_axis = self._combined_time_axis(cubes)
        metadata = {
            "source": "HISTORICAL_WEATHER_REPLAY",
            "historical_replay_mode": "strict_cached_sequence",
            "strict_historical_sequence": True,
            "snapshot_count": len(cubes),
            "real_valid_times_count": self._valid_time_count(cubes),
            "valid_times_unix": self._valid_times(cubes),
            "input_paths": [str(path) for path in paths],
            "temporal_method": "concatenated cached WeatherCube snapshots from real historical valid times",
            "variables": variable_names,
            "geospatial_grid": first.source_metadata.get("geospatial_grid"),
            "grid": first.source_metadata.get("grid"),
        }
        return WeatherCube(
            time=time_axis,
            height=first.height,
            y=first.y,
            x=first.x,
            variables=variables,
            source_metadata=metadata,
            confidence=confidence,
        )

    def _validate_compatible(self, cubes: list[WeatherCube]) -> None:
        first = cubes[0]
        spatial_shape = first.shape[1:]
        for index, cube in enumerate(cubes[1:], start=1):
            if cube.shape[1:] != spatial_shape:
                raise WeatherDataError(f"cube {index} spatial shape {cube.shape[1:]} does not match {spatial_shape}")
            for axis_name in ("height", "y", "x"):
                if not np.allclose(getattr(cube, axis_name), getattr(first, axis_name)):
                    raise WeatherDataError(f"cube {index} {axis_name} coordinates do not match the first cube")

    def _combined_time_axis(self, cubes: list[WeatherCube]) -> np.ndarray:
        valid_times = self._valid_times(cubes)
        if valid_times and len(valid_times) == len(cubes):
            base = valid_times[0]
            segments = []
            for cube, valid in zip(cubes, valid_times):
                local_time = self._numeric_time(cube)
                if len(local_time) == cube.shape[0]:
                    segments.append((valid - base) + local_time)
                else:
                    segments.append(np.full(cube.shape[0], valid - base, dtype=float))
            return np.concatenate(segments)
        offsets = []
        cursor = 0.0
        for cube in cubes:
            local_time = self._numeric_time(cube)
            if len(local_time) == cube.shape[0] and cube.shape[0] > 1:
                segment = cursor + (local_time - float(local_time[0]))
                cursor = float(segment[-1]) + self._time_step_seconds(local_time)
            else:
                segment = np.arange(cube.shape[0], dtype=float) + cursor
                cursor = float(segment[-1]) + 1.0
            offsets.append(segment)
        return np.concatenate(offsets)

    @staticmethod
    def _numeric_time(cube: WeatherCube) -> np.ndarray:
        time_axis = np.asarray(cube.time)
        if np.issubdtype(time_axis.dtype, np.datetime64):
            return (time_axis - time_axis[0]).astype("timedelta64[s]").astype(float)
        try:
            return time_axis.astype(float)
        except (TypeError, ValueError):
            return np.arange(cube.shape[0], dtype=float)

    @staticmethod
    def _time_step_seconds(time_axis: np.ndarray) -> float:
        if len(time_axis) <= 1:
            return 1.0
        diffs = np.diff(time_axis.astype(float))
        positive = diffs[diffs > 0]
        return float(np.nanmedian(positive)) if positive.size else 1.0

    def _combine_confidence(self, cubes: list[WeatherCube]) -> np.ndarray | float:
        if all(isinstance(cube.confidence, np.ndarray) for cube in cubes):
            return np.concatenate([cube.confidence for cube in cubes], axis=0)
        if all(not isinstance(cube.confidence, np.ndarray) for cube in cubes):
            return float(np.nanmean([float(cube.confidence) for cube in cubes]))
        pieces = []
        for cube in cubes:
            if isinstance(cube.confidence, np.ndarray):
                pieces.append(cube.confidence)
            else:
                pieces.append(np.full(cube.shape, float(cube.confidence), dtype=float))
        return np.concatenate(pieces, axis=0)

    def _mark_strict_single_cube(self, cube: WeatherCube, path: Path) -> WeatherCube:
        metadata = {
            **cube.source_metadata,
            "historical_replay_mode": "strict_multitime_cube",
            "strict_historical_sequence": True,
            "snapshot_count": 1,
            "real_valid_times_count": int(cube.shape[0]),
            "input_paths": [str(path)],
        }
        return self._copy_with_metadata(cube, metadata)

    def _mark_single_time_fallback(self, cube: WeatherCube, reason: str, input_paths: list[Path]) -> WeatherCube:
        metadata = {
            **cube.source_metadata,
            "historical_replay_mode": "single_valid_time_nowcast_fallback",
            "strict_historical_sequence": False,
            "snapshot_count": 1,
            "real_valid_times_count": self._valid_time_count([cube]),
            "fallback_reason": reason,
            "input_paths": [str(path) for path in input_paths],
            "data_audit": self._audit_cube(cube),
        }
        return self._copy_with_metadata(cube, metadata)

    @staticmethod
    def _copy_with_metadata(cube: WeatherCube, metadata: dict[str, Any]) -> WeatherCube:
        return WeatherCube(
            time=cube.time,
            height=cube.height,
            y=cube.y,
            x=cube.x,
            variables={name: value.copy() for name, value in cube.variables.items()},
            source_metadata=metadata,
            confidence=cube.confidence.copy() if isinstance(cube.confidence, np.ndarray) else cube.confidence,
        )

    @staticmethod
    def _has_multiple_real_valid_times(cubes: list[WeatherCube]) -> bool:
        valid_times = HistoricalWeatherReplayLoader._valid_times(cubes)
        return len(set(valid_times)) >= 2

    @staticmethod
    def _is_strict_multitime_cube(cube: WeatherCube) -> bool:
        metadata = cube.source_metadata
        if metadata.get("strict_historical_sequence") is True:
            return True
        source = str(metadata.get("source", "")).upper()
        temporal_method = str(metadata.get("temporal_method", "")).lower()
        if "single-valid-time" in temporal_method:
            return False
        return source in {"ERA5", "HRRR", "HISTORICAL_WEATHER_REPLAY"} and cube.shape[0] > 1

    @staticmethod
    def _valid_times(cubes: list[WeatherCube]) -> list[float]:
        values = []
        for cube in cubes:
            value = cube.source_metadata.get("valid_time_unix")
            if value is None:
                value = cube.source_metadata.get("initial_time_unix")
            if value is not None:
                values.append(float(value))
        return values

    @staticmethod
    def _valid_time_count(cubes: list[WeatherCube]) -> int:
        return len(set(HistoricalWeatherReplayLoader._valid_times(cubes)))

    @staticmethod
    def _audit_cube(cube: WeatherCube) -> dict[str, Any]:
        grid = cube.source_metadata.get("geospatial_grid") or {}
        return {
            "shape": list(cube.shape),
            "source": cube.source_metadata.get("source"),
            "valid_time_unix": cube.source_metadata.get("valid_time_unix"),
            "initial_time_unix": cube.source_metadata.get("initial_time_unix"),
            "temporal_method": cube.source_metadata.get("temporal_method"),
            "variables": sorted(cube.variables.keys()),
            "has_geospatial_grid": bool(grid),
            "resolution_m": grid.get("resolution_m") if isinstance(grid, dict) else None,
            "extent_m": grid.get("extent_m") if isinstance(grid, dict) else None,
            "scale_separation": cube.source_metadata.get("scale_separation"),
            "downscaling_method": cube.source_metadata.get("downscaling_method"),
        }

    @staticmethod
    def _best_fallback_cube(cubes: list[WeatherCube]) -> WeatherCube:
        def score(cube: WeatherCube) -> tuple[int, int]:
            has_geo = int(bool(cube.source_metadata.get("geospatial_grid")))
            size = int(np.prod(cube.shape))
            return has_geo, size

        return max(cubes, key=score)
