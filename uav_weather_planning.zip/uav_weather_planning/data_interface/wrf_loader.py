from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime
from io import BytesIO
from pathlib import Path
from typing import Any
import zipfile

import numpy as np
from scipy.io import netcdf_file

from .weather_cube import WeatherCube, WeatherDataError


@dataclass(frozen=True)
class WRFLoaderConfig:
    path: str | Path
    member_prefix: str = "wrfout"
    max_files: int | None = None
    height_levels_m: tuple[float, ...] = (60.0, 80.0, 100.0, 120.0, 140.0, 160.0, 180.0)
    visibility_clear_km: float = 10.0
    gravity_mps2: float = 9.80665

    def as_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["path"] = str(self.path)
        return data


class WRFLoader:
    """Read WRF NetCDF classic output into the project WeatherCube format."""

    def load(self, config: WRFLoaderConfig | str | Path) -> WeatherCube:
        if not isinstance(config, WRFLoaderConfig):
            config = WRFLoaderConfig(path=config)
        path = Path(config.path)
        if not path.exists():
            raise WeatherDataError(f"WRF file not found: {path}")
        records, source_grid = self._read_records(path, config)
        if not records:
            raise WeatherDataError(f"no WRF records found in {path}")
        records = _dedupe_sorted_records(records)
        time_axis = np.asarray([record["valid_time"] for record in records], dtype="datetime64[s]")
        height_axis = np.asarray(config.height_levels_m, dtype=float)
        variables = {
            name: np.stack([record[name] for record in records], axis=0).astype(float)
            for name in [
                "u_wind",
                "v_wind",
                "w_wind",
                "gust",
                "rain_rate",
                "visibility",
                "ceiling",
                "cloud_liquid_water",
                "reflectivity",
                "convection_probability",
                "updraft_speed",
                "relative_humidity",
                "dewpoint_spread",
                "temperature_2m",
                "surface_pressure",
            ]
        }
        variables["rain_rate"] = _rain_rate_from_cumulative(records, variables["rain_rate"], time_axis)
        variables["reflectivity"] = _reflectivity_proxy(variables["rain_rate"], variables["cloud_liquid_water"], variables["updraft_speed"])
        variables["convection_probability"] = np.clip(
            np.maximum(
                variables["convection_probability"],
                0.25 * np.clip((variables["reflectivity"] - 25.0) / 25.0, 0.0, 1.0) + 0.25 * np.clip(variables["updraft_speed"] / 5.0, 0.0, 1.0),
            ),
            0.0,
            1.0,
        )
        variables["visibility"] = np.clip(
            np.minimum(variables["visibility"], config.visibility_clear_km - 0.18 * variables["rain_rate"] - 1.6 * variables["cloud_liquid_water"]),
            0.15,
            config.visibility_clear_km,
        )

        confidence = _wrf_confidence_array(time_axis, variables["u_wind"].shape, source_grid)
        lead_time_hours = [round(float((value - time_axis[0]).astype("timedelta64[s]").astype(float) / 3600.0), 3) for value in time_axis]
        metadata = {
            "source": "WRF",
            "loader": "WRFLoader",
            "loader_config": config.as_dict(),
            "strict_historical_sequence": bool(len(time_axis) >= 2),
            "historical_replay_mode": "wrf_multi_valid_time_background",
            "real_valid_times_count": int(len(time_axis)),
            "lead_time_hours": lead_time_hours,
            "background_valid_times": [str(value) for value in time_axis],
            "time_axis_unit": "datetime64[s]",
            "original_grid": _jsonable_metadata(source_grid),
            "variable_mapping": {
                "XLAT/XLONG": "local metric y/x coordinates",
                "XTIME/Times": "valid time",
                "U/V/W": "destaggered and interpolated to low-altitude AGL levels as u_wind/v_wind/w_wind",
                "PH+PHB-HGT": "mass-level height above local ground",
                "U10/V10": "near-surface wind and gust proxy",
                "QRAIN/QCLOUD/CLDFRA": "rain/cloud/convection proxies",
                "RAINC+RAINNC": "rain_rate from cumulative precipitation difference",
                "T2/Q2/PSFC": "temperature/humidity/pressure auxiliaries",
            },
            "claim_boundary": (
                "WRF provides regional background weather valid times. "
                "Second-scale low-altitude gust and shear must be resolved by the local planning perturbation model."
            ),
        }
        return WeatherCube(
            time=time_axis,
            height=height_axis,
            y=source_grid["y_axis_m"],
            x=source_grid["x_axis_m"],
            variables=variables,
            source_metadata=metadata,
            confidence=confidence,
        )

    def _read_records(self, path: Path, config: WRFLoaderConfig) -> tuple[list[dict[str, Any]], dict[str, Any]]:
        records: list[dict[str, Any]] = []
        source_grid: dict[str, Any] | None = None
        entries = _wrf_entries(path, config)
        for entry_name, payload in entries:
            with netcdf_file(BytesIO(payload), "r", mmap=False) as ds:
                lats = _read_var(ds, "XLAT")
                lons = _read_var(ds, "XLONG")
                if lats.ndim == 3:
                    lats2d = lats[0]
                    lons2d = lons[0]
                else:
                    lats2d = lats
                    lons2d = lons
                x_axis_m, y_axis_m = _local_axes_from_latlon(lats2d, lons2d)
                source_grid = {
                    "source_path": str(path),
                    "file_count": len(entries),
                    "wrf_files": [name for name, _ in entries],
                    "entry_name_last_read": entry_name,
                    "native_horizontal_shape": [int(lats2d.shape[0]), int(lats2d.shape[1])],
                    "native_vertical_mass_levels": int(ds.dimensions.get("bottom_top", 0) or _read_var(ds, "U").shape[1]),
                    "native_vertical_stag_levels": int(ds.dimensions.get("bottom_top_stag", 0) or _read_var(ds, "W").shape[1]),
                    "x_axis_m": x_axis_m,
                    "y_axis_m": y_axis_m,
                    "lat_range": [float(np.nanmin(lats2d)), float(np.nanmax(lats2d))],
                    "lon_range": [float(np.nanmin(lons2d)), float(np.nanmax(lons2d))],
                }
                records.extend(self._records_from_dataset(ds, config, x_axis_m, y_axis_m, entry_name))
        if source_grid is None:
            raise WeatherDataError("WRF source grid could not be read")
        source_grid["original_grid_note"] = (
            f"{source_grid['native_horizontal_shape'][0]} x {source_grid['native_horizontal_shape'][1]} x "
            f"{source_grid['native_vertical_mass_levels']} native WRF mass grid"
        )
        return records, source_grid

    def _records_from_dataset(
        self,
        ds: Any,
        config: WRFLoaderConfig,
        x_axis_m: np.ndarray,
        y_axis_m: np.ndarray,
        entry_name: str,
    ) -> list[dict[str, Any]]:
        times = _parse_wrf_times(ds)
        u = _destagger_x(_read_var(ds, "U"))
        v = _destagger_y(_read_var(ds, "V"))
        w = _destagger_z(_read_var(ds, "W"))
        ph = _read_var(ds, "PH")
        phb = _read_var(ds, "PHB")
        hgt = _read_var(ds, "HGT")
        height_full = (ph + phb) / config.gravity_mps2
        height_mass = _destagger_z(height_full)
        if hgt.ndim == 3:
            hgt_t = hgt
        else:
            hgt_t = np.repeat(hgt[None, :, :], height_mass.shape[0], axis=0)
        height_agl = np.maximum(height_mass - hgt_t[:, None, :, :], 0.0)

        target_heights = np.asarray(config.height_levels_m, dtype=float)
        u_low = _interp_vertical_profiles(u, height_agl, target_heights)
        v_low = _interp_vertical_profiles(v, height_agl, target_heights)
        w_low = _interp_vertical_profiles(w, height_agl, target_heights)
        qrain_low = _interp_vertical_profiles(_optional_3d(ds, "QRAIN", u.shape), height_agl, target_heights)
        qcloud_low = _interp_vertical_profiles(_optional_3d(ds, "QCLOUD", u.shape), height_agl, target_heights)
        cldfra_low = _interp_vertical_profiles(_optional_3d(ds, "CLDFRA", u.shape), height_agl, target_heights)

        u10 = _optional_2d(ds, "U10", u.shape[0], y_axis_m.size, x_axis_m.size)
        v10 = _optional_2d(ds, "V10", u.shape[0], y_axis_m.size, x_axis_m.size)
        t2 = _optional_2d(ds, "T2", u.shape[0], y_axis_m.size, x_axis_m.size, default=293.15)
        q2 = _optional_2d(ds, "Q2", u.shape[0], y_axis_m.size, x_axis_m.size, default=0.008)
        psfc = _optional_2d(ds, "PSFC", u.shape[0], y_axis_m.size, x_axis_m.size, default=95000.0)
        rainc = _optional_2d(ds, "RAINC", u.shape[0], y_axis_m.size, x_axis_m.size)
        rainnc = _optional_2d(ds, "RAINNC", u.shape[0], y_axis_m.size, x_axis_m.size)
        rain_cumulative = np.clip(rainc + rainnc, 0.0, None)
        rh2 = _relative_humidity_from_q2(q2, t2, psfc)
        ceiling = _ceiling_from_cloud(cldfra_low, target_heights)
        records = []
        for t_idx, valid_time in enumerate(times):
            surface_wind = np.sqrt(u10[t_idx] ** 2 + v10[t_idx] ** 2)
            low_wind = np.sqrt(u_low[t_idx] ** 2 + v_low[t_idx] ** 2)
            gust = np.maximum(low_wind, surface_wind[None, :, :] + 1.8 * np.sqrt(np.clip(cldfra_low[t_idx], 0.0, 1.0)))
            rain_proxy = np.clip(qrain_low[t_idx] * 3500.0, 0.0, 25.0)
            cloud_water = np.clip(qcloud_low[t_idx] * 1000.0, 0.0, 3.0)
            updraft = np.clip(w_low[t_idx], 0.0, None)
            convection = np.clip(0.55 * cldfra_low[t_idx] + 0.25 * np.clip(qrain_low[t_idx] / 0.0015, 0.0, 1.0) + 0.20 * np.clip(updraft / 4.0, 0.0, 1.0), 0.0, 1.0)
            rh_b = _broadcast_2d(rh2[t_idx], target_heights.size)
            records.append(
                {
                    "entry_name": entry_name,
                    "valid_time": valid_time,
                    "u_wind": u_low[t_idx],
                    "v_wind": v_low[t_idx],
                    "w_wind": w_low[t_idx],
                    "gust": gust,
                    "rain_rate": rain_proxy,
                    "rain_cumulative": rain_cumulative[t_idx],
                    "visibility": np.clip(config.visibility_clear_km - 2.2 * rain_proxy - 1.3 * cloud_water - 0.018 * np.maximum(rh_b - 88.0, 0.0), 0.15, config.visibility_clear_km),
                    "ceiling": _broadcast_2d(ceiling[t_idx], target_heights.size),
                    "cloud_liquid_water": cloud_water,
                    "reflectivity": _reflectivity_proxy(rain_proxy[None], cloud_water[None], updraft[None])[0],
                    "convection_probability": convection,
                    "updraft_speed": updraft,
                    "relative_humidity": rh_b,
                    "dewpoint_spread": np.clip(14.0 * (1.0 - rh_b / 100.0), 0.0, 20.0),
                    "temperature_2m": _broadcast_2d(t2[t_idx] - 273.15, target_heights.size),
                    "surface_pressure": _broadcast_2d(psfc[t_idx], target_heights.size),
                }
            )
        return records


def _wrf_entries(path: Path, config: WRFLoaderConfig) -> list[tuple[str, bytes]]:
    if path.suffix.lower() == ".zip":
        with zipfile.ZipFile(path) as zf:
            names = [
                name
                for name in zf.namelist()
                if not name.endswith("/") and Path(name).name.startswith(config.member_prefix)
            ]
            names = sorted(names)
            if config.max_files is not None:
                names = names[: config.max_files]
            return [(name, zf.read(name)) for name in names]
    return [(path.name, path.read_bytes())]


def _read_var(ds: Any, name: str) -> np.ndarray:
    if name not in ds.variables:
        raise WeatherDataError(f"WRF variable missing: {name}")
    return np.asarray(ds.variables[name].data).copy()


def _optional_3d(ds: Any, name: str, shape: tuple[int, int, int, int]) -> np.ndarray:
    if name not in ds.variables:
        return np.zeros(shape, dtype=float)
    arr = _read_var(ds, name)
    if arr.shape == shape:
        return arr
    return np.broadcast_to(arr, shape).copy()


def _optional_2d(ds: Any, name: str, t_size: int, y_size: int, x_size: int, default: float = 0.0) -> np.ndarray:
    if name not in ds.variables:
        return np.full((t_size, y_size, x_size), default, dtype=float)
    arr = _read_var(ds, name)
    if arr.ndim == 2:
        return np.repeat(arr[None, :, :], t_size, axis=0)
    return arr.astype(float)


def _parse_wrf_times(ds: Any) -> list[np.datetime64]:
    if "Times" not in ds.variables:
        xtime = _read_var(ds, "XTIME") if "XTIME" in ds.variables else np.arange(_read_var(ds, "U").shape[0])
        base = np.datetime64("1970-01-01T00:00:00")
        return [base + np.timedelta64(int(round(float(value))), "m") for value in xtime]
    raw = np.asarray(ds.variables["Times"].data).copy()
    result = []
    for row in raw:
        if row.dtype.kind in {"S", "a"}:
            text = b"".join(row.tolist()).decode("ascii", errors="ignore")
        elif row.dtype.kind == "U":
            text = "".join(row.tolist())
        else:
            text = bytes(np.asarray(row, dtype=np.uint8).tolist()).decode("ascii", errors="ignore")
        text = text.strip().replace("_", " ")
        try:
            dt = datetime.strptime(text, "%Y-%m-%d %H:%M:%S")
        except ValueError:
            dt = datetime.fromisoformat(text)
        result.append(np.datetime64(dt, "s"))
    return result


def _destagger_x(arr: np.ndarray) -> np.ndarray:
    return 0.5 * (arr[..., :-1] + arr[..., 1:])


def _destagger_y(arr: np.ndarray) -> np.ndarray:
    return 0.5 * (arr[..., :-1, :] + arr[..., 1:, :])


def _destagger_z(arr: np.ndarray) -> np.ndarray:
    return 0.5 * (arr[:, :-1, :, :] + arr[:, 1:, :, :])


def _interp_vertical_profiles(arr: np.ndarray, height_agl: np.ndarray, target_heights: np.ndarray) -> np.ndarray:
    t_size, _, y_size, x_size = arr.shape
    out = np.zeros((t_size, target_heights.size, y_size, x_size), dtype=float)
    for t in range(t_size):
        for y in range(y_size):
            for x in range(x_size):
                z_profile = np.asarray(height_agl[t, :, y, x], dtype=float)
                v_profile = np.asarray(arr[t, :, y, x], dtype=float)
                order = np.argsort(z_profile)
                z_sorted = z_profile[order]
                v_sorted = v_profile[order]
                keep = np.isfinite(z_sorted) & np.isfinite(v_sorted)
                if np.count_nonzero(keep) < 2:
                    out[t, :, y, x] = v_sorted[0] if v_sorted.size else 0.0
                else:
                    out[t, :, y, x] = np.interp(target_heights, z_sorted[keep], v_sorted[keep], left=v_sorted[keep][0], right=v_sorted[keep][-1])
    return out


def _local_axes_from_latlon(lats: np.ndarray, lons: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    lat_center = float(np.nanmean(lats))
    lon_center = float(np.nanmean(lons))
    y_axis = (np.nanmean(lats, axis=1) - np.nanmin(np.nanmean(lats, axis=1))) * 111_320.0
    x_axis = (np.nanmean(lons, axis=0) - np.nanmin(np.nanmean(lons, axis=0))) * 111_320.0 * np.cos(np.deg2rad(lat_center))
    if y_axis[0] > y_axis[-1]:
        y_axis = y_axis[::-1]
    if x_axis[0] > x_axis[-1]:
        x_axis = x_axis[::-1]
    if np.isclose(np.ptp(y_axis), 0.0):
        y_axis = np.arange(lats.shape[0], dtype=float)
    if np.isclose(np.ptp(x_axis), 0.0):
        x_axis = np.arange(lons.shape[1], dtype=float)
    _ = lon_center
    return x_axis.astype(float), y_axis.astype(float)


def _broadcast_2d(arr: np.ndarray, z_size: int) -> np.ndarray:
    return np.repeat(np.asarray(arr, dtype=float)[None, :, :], z_size, axis=0)


def _relative_humidity_from_q2(q2: np.ndarray, t2: np.ndarray, psfc: np.ndarray) -> np.ndarray:
    epsilon = 0.622
    vapor_pressure = np.maximum(q2 * psfc / (epsilon + q2), 0.0)
    temp_c = t2 - 273.15
    saturation = 611.2 * np.exp((17.67 * temp_c) / np.maximum(temp_c + 243.5, 1.0))
    return np.clip(100.0 * vapor_pressure / np.maximum(saturation, 1.0), 0.0, 100.0)


def _ceiling_from_cloud(cldfra_low: np.ndarray, target_heights: np.ndarray) -> np.ndarray:
    t_size, _, y_size, x_size = cldfra_low.shape
    ceiling = np.full((t_size, y_size, x_size), 1000.0, dtype=float)
    for z_idx, height in enumerate(target_heights):
        mask = (ceiling >= 999.0) & (cldfra_low[:, z_idx] >= 0.35)
        ceiling[mask] = float(height)
    return ceiling


def _rain_rate_from_cumulative(records: list[dict[str, Any]], fallback: np.ndarray, time_axis: np.ndarray) -> np.ndarray:
    cumulative = np.stack([record["rain_cumulative"] for record in records], axis=0).astype(float)
    out2d = np.zeros_like(cumulative)
    if len(time_axis) <= 1:
        out2d[:] = np.nanmean(fallback, axis=1)
    else:
        for idx in range(1, len(time_axis)):
            dt_h = max(float((time_axis[idx] - time_axis[idx - 1]).astype("timedelta64[s]").astype(float) / 3600.0), 1e-6)
            out2d[idx] = np.clip((cumulative[idx] - cumulative[idx - 1]) / dt_h, 0.0, None)
        out2d[0] = out2d[1]
    return np.repeat(out2d[:, None, :, :], fallback.shape[1], axis=1)


def _reflectivity_proxy(rain_rate: np.ndarray, cloud_liquid: np.ndarray, updraft: np.ndarray) -> np.ndarray:
    return np.clip(12.0 + 18.0 * np.log1p(np.maximum(rain_rate, 0.0)) + 5.0 * np.clip(cloud_liquid, 0.0, 3.0) + 2.2 * np.clip(updraft, 0.0, 5.0), 0.0, 65.0)


def _wrf_confidence_array(time_axis: np.ndarray, shape: tuple[int, int, int, int], source_grid: dict[str, Any]) -> np.ndarray:
    spacing = []
    for key in ("x_axis_m", "y_axis_m"):
        axis = np.asarray(source_grid.get(key, []), dtype=float)
        if axis.size > 1:
            spacing.append(float(np.nanmedian(np.abs(np.diff(axis)))))
    spacing_km = (float(np.nanmean(spacing)) / 1000.0) if spacing else 3.0
    base = max(0.45, 0.88 - min(0.22, 0.025 * spacing_km))
    lead_hours = np.asarray([(value - time_axis[0]).astype("timedelta64[s]").astype(float) / 3600.0 for value in time_axis], dtype=float)
    lead_penalty = np.clip(0.015 * lead_hours, 0.0, 0.12)
    confidence = np.zeros(shape, dtype=float)
    for idx, penalty in enumerate(lead_penalty):
        confidence[idx] = max(0.35, base - float(penalty))
    return confidence


def _dedupe_sorted_records(records: list[dict[str, Any]]) -> list[dict[str, Any]]:
    by_time: dict[str, dict[str, Any]] = {}
    for record in records:
        by_time[str(record["valid_time"])] = record
    return [by_time[key] for key in sorted(by_time.keys())]


def _jsonable_metadata(value: Any) -> Any:
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, dict):
        return {key: _jsonable_metadata(item) for key, item in value.items()}
    if isinstance(value, list):
        return [_jsonable_metadata(item) for item in value]
    if isinstance(value, tuple):
        return [_jsonable_metadata(item) for item in value]
    return value
