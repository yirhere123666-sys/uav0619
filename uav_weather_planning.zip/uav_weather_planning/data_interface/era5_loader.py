from __future__ import annotations

from pathlib import Path

import numpy as np

from uav_weather_planning.preprocessing import build_local_grid_from_bbox

from .weather_cache import WeatherCache, WeatherDependencyError, WeatherRequest
from .weather_cube import WeatherCube, WeatherDataError


class ERA5Loader:
    """ERA5 CDS API loader producing the unified WeatherCube interface."""

    DEFAULT_VARIABLES = (
        "u_component_of_wind",
        "v_component_of_wind",
        "vertical_velocity",
        "total_precipitation",
        "temperature",
        "relative_humidity",
        "specific_cloud_liquid_water_content",
    )

    def __init__(self, cache_root: str | Path = "data/cache") -> None:
        self.cache = WeatherCache(cache_root)

    def load(self, request: WeatherRequest) -> WeatherCube:
        if request.cache_policy in {"reuse", "cache_only"} and self.cache.exists(request):
            return self.cache.load(request)
        if request.cache_policy == "cache_only":
            raise FileNotFoundError(f"ERA5 cache not found: {self.cache.path_for(request)}")
        cube = self.download(request)
        self.cache.save(request, cube)
        return cube

    def download(self, request: WeatherRequest) -> WeatherCube:
        try:
            import cdsapi  # type: ignore
        except ImportError as exc:
            raise WeatherDependencyError(
                "ERA5 download requires cdsapi and a configured CDS API key. "
                "Install cdsapi and configure ~/.cdsapirc, or use cache_only with a prepared cache."
            ) from exc

        # The request object is intentionally explicit so the generated code is auditable.
        if not request.bbox:
            raise WeatherDataError("ERA5 request requires bbox=(north, west, south, east)")
        if not request.levels:
            raise WeatherDataError("ERA5 request requires pressure levels, e.g. (1000, 975, 950, 925)")

        target = self.cache.path_for(request, suffix=".nc")
        target.parent.mkdir(parents=True, exist_ok=True)
        client = cdsapi.Client()
        variables = list(request.variables or self.DEFAULT_VARIABLES)
        date = request.start_time.split("T")[0]
        hour = request.start_time.split("T")[1][:2] if "T" in request.start_time else "00"
        client.retrieve(
            "reanalysis-era5-pressure-levels",
            {
                "product_type": "reanalysis",
                "format": "netcdf",
                "variable": variables,
                "pressure_level": [str(v) for v in request.levels],
                "date": date,
                "time": f"{hour}:00",
                "area": list(request.bbox),
            },
            str(target),
        )
        return self.open_netcdf(target, request)

    def open_netcdf(self, path: str | Path, request: WeatherRequest | None = None) -> WeatherCube:
        try:
            import xarray as xr
        except ImportError as exc:
            raise WeatherDependencyError("xarray is required to open ERA5 NetCDF files") from exc
        try:
            ds = xr.open_dataset(path)
        except Exception as exc:
            raise WeatherDependencyError(
                "Opening ERA5 NetCDF requires a NetCDF backend such as netCDF4 or h5netcdf."
            ) from exc

        # Minimal conversion: callers can preprocess to y/x/height before production use.
        time = ds["time"].values if "time" in ds.coords else np.arange(ds.sizes.get("time", 1))
        levels = ds["level"].values if "level" in ds.coords else np.arange(ds.sizes.get("level", 1))
        lat = ds["latitude"].values if "latitude" in ds.coords else np.arange(ds.sizes.get("latitude", 1))
        lon = ds["longitude"].values if "longitude" in ds.coords else np.arange(ds.sizes.get("longitude", 1))
        target_shape = (len(time), len(levels), len(lat), len(lon))
        bbox = request.bbox if request and request.bbox else (float(np.nanmax(lat)), float(np.nanmin(lon)), float(np.nanmin(lat)), float(np.nanmax(lon)))
        geo_grid = build_local_grid_from_bbox(bbox, len(lat), len(lon))

        def get_var(*names: str, default: float = 0.0):
            for name in names:
                if name in ds:
                    arr = ds[name].values
                    return np.asarray(arr).reshape(target_shape)
            return np.full(target_shape, default, dtype=float)

        variables = {
            "u_wind": get_var("u", "u_component_of_wind"),
            "v_wind": get_var("v", "v_component_of_wind"),
            "w_wind": get_var("w", "vertical_velocity"),
            "rain_rate": get_var("tp", "total_precipitation") * 1000.0,
            "gust": np.sqrt(get_var("u", "u_component_of_wind") ** 2 + get_var("v", "v_component_of_wind") ** 2) * 1.25,
            "temperature": get_var("t", "temperature", default=291.15) - 273.15,
            "relative_humidity": get_var("r", "relative_humidity", default=70.0),
            "cloud_liquid_water": get_var("clwc", "specific_cloud_liquid_water_content", default=0.0) * 1000.0,
            "reflectivity": np.zeros(target_shape),
            "convection_probability": np.zeros(target_shape),
            "visibility": np.full(target_shape, 7.5),
            "ceiling": np.full(target_shape, 500.0),
        }
        variables["dewpoint_spread"] = np.clip(12.0 * (1.0 - variables["relative_humidity"] / 100.0), 0.0, 12.0)
        variables["pressure"] = np.broadcast_to(np.asarray(levels, dtype=float)[None, :, None, None], target_shape)
        variables["updraft_speed"] = np.maximum(variables["w_wind"], 0.0)
        source_metadata = {
            "source": "ERA5",
            "path": str(path),
            "request": request.cache_key() if request else None,
            "bbox": bbox,
            "geospatial_grid": geo_grid.as_metadata(),
            "native_latitude_deg": [float(v) for v in np.asarray(lat, dtype=float).tolist()],
            "native_longitude_deg": [float(v) for v in np.asarray(lon, dtype=float).tolist()],
            "grid": "era5_latlon_subset_projected_to_local_meter_grid",
        }
        return WeatherCube(
            time=time,
            height=_pressure_to_height(levels),
            y=geo_grid.y_m,
            x=geo_grid.x_m,
            variables=variables,
            source_metadata=source_metadata,
            confidence=0.78,
        )


def _pressure_to_height(level_hpa) -> np.ndarray:
    p = np.asarray(level_hpa, dtype=float)
    return 44330.0 * (1.0 - (p / 1013.25) ** 0.1903)
