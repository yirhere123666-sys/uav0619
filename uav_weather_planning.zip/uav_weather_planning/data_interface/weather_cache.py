from __future__ import annotations

from dataclasses import dataclass
import hashlib
from pathlib import Path

from .weather_cube import WeatherCube


class WeatherDependencyError(RuntimeError):
    """Raised when an optional real-data dependency is missing."""


@dataclass
class WeatherRequest:
    source: str
    start_time: str
    end_time: str | None = None
    bbox: tuple[float, float, float, float] | None = None  # north, west, south, east
    variables: tuple[str, ...] = ()
    levels: tuple[int, ...] = ()
    forecast_hours: tuple[int, ...] = ()
    cache_policy: str = "reuse"

    def cache_key(self) -> str:
        parts = [
            self.source,
            self.start_time.replace(":", "").replace("-", "").replace(" ", "T"),
            "bbox" + "_".join(f"{v:.2f}" for v in self.bbox) if self.bbox else "global",
            "vars" + "_".join(self.variables or ("default",)),
            "lev" + "_".join(str(v) for v in self.levels or ("default",)),
            "fxx" + "_".join(str(v) for v in self.forecast_hours or ("analysis",)),
        ]
        return "__".join(parts).replace("/", "-")


class WeatherCache:
    def __init__(self, root: str | Path = "data/cache") -> None:
        self.root = Path(root)

    def path_for(self, request: WeatherRequest, suffix: str = ".npz") -> Path:
        key = request.cache_key()
        if len(key) > 120:
            digest = hashlib.sha1(key.encode("utf-8")).hexdigest()[:16]
            key = f"{request.source}__{request.start_time.replace(':', '').replace('-', '')}__{digest}"
        return self.root / request.source.lower() / f"{key}{suffix}"

    def exists(self, request: WeatherRequest) -> bool:
        return self.path_for(request).exists()

    def load(self, request: WeatherRequest) -> WeatherCube:
        return WeatherCube.from_npz(self.path_for(request))

    def save(self, request: WeatherRequest, cube: WeatherCube) -> Path:
        path = self.path_for(request)
        cube.to_npz(path)
        return path
