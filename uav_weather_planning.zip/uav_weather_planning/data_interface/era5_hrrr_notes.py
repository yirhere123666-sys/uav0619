"""Real-data integration notes.

The runnable midterm package now has two real-data paths:

- LOCAL_GFS_REPLAY: offline reproducible replay from cached repository
  NetCDF4/HDF5 files. This path requires no network and is used by
  historical_weather_replay.py.
- ERA5: historical/statistical background and uncertainty ranges.
- HRRR: short-horizon dynamic weather input.
- Required optional dependencies for download paths: cdsapi,
  cfgrib/eccodes, netCDF4 or h5netcdf.
"""
