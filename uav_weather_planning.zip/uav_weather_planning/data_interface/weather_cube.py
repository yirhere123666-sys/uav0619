from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import numpy as np


class WeatherDataError(RuntimeError):
    """Raised when a weather data source cannot produce a valid cube."""


@dataclass
class WeatherCube:
    """Unified weather tensor before risk conversion.

    Every variable is stored as a 4D array with shape (time, height, y, x).
    The coordinate arrays may represent projected grid indices in synthetic
    experiments or real lat/lon-derived local coordinates after preprocessing.
    """

    time: np.ndarray
    height: np.ndarray
    y: np.ndarray
    x: np.ndarray
    variables: dict[str, np.ndarray]
    source_metadata: dict[str, Any] = field(default_factory=dict)
    confidence: np.ndarray | float = 1.0

    def __post_init__(self) -> None:
        self.time = np.asarray(self.time)
        self.height = np.asarray(self.height)
        self.y = np.asarray(self.y)
        self.x = np.asarray(self.x)
        expected_shape = (len(self.time), len(self.height), len(self.y), len(self.x))
        for name, value in list(self.variables.items()):
            arr = np.asarray(value, dtype=float)
            if arr.shape != expected_shape:
                raise WeatherDataError(f"{name} shape {arr.shape} does not match {expected_shape}")
            self.variables[name] = arr
        if isinstance(self.confidence, np.ndarray):
            if self.confidence.shape != expected_shape:
                raise WeatherDataError("confidence array must match weather variable shape")

    @property
    def shape(self) -> tuple[int, int, int, int]:
        return (len(self.time), len(self.height), len(self.y), len(self.x))

    def get(self, name: str, default: float = 0.0) -> np.ndarray:
        if name in self.variables:
            return self.variables[name]
        return np.full(self.shape, default, dtype=float)

    def slice_time(self, time_index: int, keep_time_dim: bool = True) -> "WeatherCube":
        index = int(np.clip(time_index, 0, len(self.time) - 1))
        time = self.time[index : index + 1] if keep_time_dim else np.asarray([self.time[index]])
        variables = {name: value[index : index + 1].copy() for name, value in self.variables.items()}
        if isinstance(self.confidence, np.ndarray):
            confidence: np.ndarray | float = self.confidence[index : index + 1].copy()
        else:
            confidence = self.confidence
        metadata = {
            **self.source_metadata,
            "slice_time_index": index,
            "slice_valid_time": _jsonable_time_value(self.time[index]),
        }
        return WeatherCube(
            time=time,
            height=self.height.copy(),
            y=self.y.copy(),
            x=self.x.copy(),
            variables=variables,
            source_metadata=metadata,
            confidence=confidence,
        )

    def query_time(self, requested_time: Any, method: str = "nearest") -> "WeatherCube":
        """Return a one-step WeatherCube for the nearest or linearly interpolated time."""

        numeric_axis = _numeric_time_axis(self.time)
        target = _numeric_time_value(requested_time, self.time)
        if method == "nearest" or len(numeric_axis) <= 1:
            return self.slice_time(int(np.argmin(np.abs(numeric_axis - target))))
        if method != "linear":
            raise WeatherDataError(f"unsupported query_time method: {method}")
        if target <= numeric_axis[0]:
            return self.slice_time(0)
        if target >= numeric_axis[-1]:
            return self.slice_time(len(numeric_axis) - 1)
        right = int(np.searchsorted(numeric_axis, target, side="right"))
        left = right - 1
        span = max(float(numeric_axis[right] - numeric_axis[left]), 1e-9)
        alpha = float((target - numeric_axis[left]) / span)
        variables = {
            name: ((1.0 - alpha) * value[left : left + 1] + alpha * value[right : right + 1])
            for name, value in self.variables.items()
        }
        if isinstance(self.confidence, np.ndarray):
            confidence: np.ndarray | float = (1.0 - alpha) * self.confidence[left : left + 1] + alpha * self.confidence[right : right + 1]
        else:
            confidence = self.confidence
        metadata = {
            **self.source_metadata,
            "query_time_method": "linear",
            "query_left_index": left,
            "query_right_index": right,
            "query_alpha": alpha,
            "query_requested_time": _jsonable_time_value(requested_time),
        }
        return WeatherCube(
            time=np.asarray([requested_time]),
            height=self.height.copy(),
            y=self.y.copy(),
            x=self.x.copy(),
            variables=variables,
            source_metadata=metadata,
            confidence=confidence,
        )

    def require(self, *names: str) -> None:
        missing = [name for name in names if name not in self.variables]
        if missing:
            raise WeatherDataError(f"missing weather variables: {', '.join(missing)}")

    def to_npz(self, path: str | Path) -> None:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        payload: dict[str, Any] = {
            "time": self.time,
            "height": self.height,
            "y": self.y,
            "x": self.x,
            "confidence": self.confidence,
            "variable_names": np.array(list(self.variables.keys()), dtype=object),
            "source_metadata": np.array([self.source_metadata], dtype=object),
        }
        for name, arr in self.variables.items():
            payload[f"var__{name}"] = arr
        np.savez_compressed(path, **payload)

    @classmethod
    def from_npz(cls, path: str | Path) -> "WeatherCube":
        data = np.load(Path(path), allow_pickle=True)
        variable_names = [str(v) for v in data["variable_names"].tolist()]
        variables = {name: data[f"var__{name}"] for name in variable_names}
        metadata = data["source_metadata"][0].item() if hasattr(data["source_metadata"][0], "item") else data["source_metadata"][0]
        return cls(
            time=data["time"],
            height=data["height"],
            y=data["y"],
            x=data["x"],
            variables=variables,
            source_metadata=metadata,
            confidence=data["confidence"],
        )

    @classmethod
    def from_xarray(
        cls,
        dataset: Any,
        variable_map: dict[str, str],
        source_metadata: dict[str, Any] | None = None,
    ) -> "WeatherCube":
        """Create a WeatherCube from an xarray Dataset after preprocessing.

        The dataset must already use dimensions named time, height, y, x.
        """

        expected_dims = {"time", "height", "y", "x"}
        if not expected_dims.issubset(set(dataset.dims)):
            raise WeatherDataError("xarray dataset must have time/height/y/x dimensions")
        variables = {}
        for cube_name, ds_name in variable_map.items():
            if ds_name not in dataset:
                raise WeatherDataError(f"{ds_name} not found in dataset")
            variables[cube_name] = dataset[ds_name].transpose("time", "height", "y", "x").values
        return cls(
            time=dataset["time"].values,
            height=dataset["height"].values,
            y=dataset["y"].values,
            x=dataset["x"].values,
            variables=variables,
            source_metadata=source_metadata or {},
        )


def _numeric_time_axis(axis: np.ndarray) -> np.ndarray:
    axis = np.asarray(axis)
    if np.issubdtype(axis.dtype, np.datetime64):
        return (axis - axis[0]).astype("timedelta64[s]").astype(float)
    try:
        return axis.astype(float)
    except (TypeError, ValueError):
        return np.arange(len(axis), dtype=float)


def _numeric_time_value(value: Any, reference_axis: np.ndarray) -> float:
    axis = np.asarray(reference_axis)
    if np.issubdtype(axis.dtype, np.datetime64):
        value64 = np.datetime64(value)
        return float((value64 - axis[0]).astype("timedelta64[s]").astype(float))
    try:
        return float(value)
    except (TypeError, ValueError):
        return 0.0


def _jsonable_time_value(value: Any) -> Any:
    if isinstance(value, np.generic):
        value = value.item()
    if isinstance(value, np.datetime64):
        return str(value)
    return value
