from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Sequence

import numpy as np

from uav_weather_planning.data_interface.weather_cube import WeatherCube


@dataclass(frozen=True)
class WeatherEnsemble:
    """Weather ensemble container inspired by pySTEPS nowcast members.

    The project does not require pySTEPS at import time. When pySTEPS is
    available, callers can pass its precipitation nowcast members through
    ``build_weather_ensemble``. Otherwise the same structure can be populated
    by deterministic or stochastic local perturbations.
    """

    members: list[WeatherCube]
    source: str = "member_cubes"
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def member_count(self) -> int:
        return len(self.members)

    @property
    def shape(self) -> tuple[int, int, int, int]:
        if not self.members:
            raise ValueError("WeatherEnsemble has no members")
        return self.members[0].shape


def pysteps_available() -> bool:
    try:
        import pysteps  # type: ignore  # noqa: F401

        return True
    except Exception:
        return False


def build_weather_member(
    base_cube: WeatherCube,
    *,
    variable_overrides: dict[str, np.ndarray] | None = None,
    member_id: str | int = 0,
    confidence_scale: float = 1.0,
    metadata: dict[str, Any] | None = None,
) -> WeatherCube:
    variables = {name: value.copy() for name, value in base_cube.variables.items()}
    for name, value in (variable_overrides or {}).items():
        arr = np.asarray(value, dtype=float)
        if arr.shape != base_cube.shape:
            raise ValueError(f"{name} member shape {arr.shape} does not match {base_cube.shape}")
        variables[name] = arr.copy()
    if isinstance(base_cube.confidence, np.ndarray):
        confidence: np.ndarray | float = np.clip(base_cube.confidence * confidence_scale, 0.0, 1.0)
    else:
        confidence = float(np.clip(float(base_cube.confidence) * confidence_scale, 0.0, 1.0))
    return WeatherCube(
        time=base_cube.time.copy(),
        height=base_cube.height.copy(),
        y=base_cube.y.copy(),
        x=base_cube.x.copy(),
        variables=variables,
        confidence=confidence,
        source_metadata={
            **base_cube.source_metadata,
            "ensemble_member_id": str(member_id),
            "ensemble_member_metadata": metadata or {},
        },
    )


def build_weather_ensemble(
    base_cube: WeatherCube,
    *,
    precipitation_members: Sequence[np.ndarray] | None = None,
    wind_u_members: Sequence[np.ndarray] | None = None,
    wind_v_members: Sequence[np.ndarray] | None = None,
    gust_members: Sequence[np.ndarray] | None = None,
    source: str = "pysteps_like_members",
) -> WeatherEnsemble:
    member_count = max(
        1,
        len(precipitation_members or []),
        len(wind_u_members or []),
        len(wind_v_members or []),
        len(gust_members or []),
    )
    members: list[WeatherCube] = []
    for idx in range(member_count):
        overrides: dict[str, np.ndarray] = {}
        if precipitation_members:
            overrides["rain_rate"] = np.asarray(precipitation_members[idx % len(precipitation_members)], dtype=float)
        if wind_u_members:
            overrides["u_wind"] = np.asarray(wind_u_members[idx % len(wind_u_members)], dtype=float)
        if wind_v_members:
            overrides["v_wind"] = np.asarray(wind_v_members[idx % len(wind_v_members)], dtype=float)
        if gust_members:
            overrides["gust"] = np.asarray(gust_members[idx % len(gust_members)], dtype=float)
        members.append(
            build_weather_member(
                base_cube,
                variable_overrides=overrides,
                member_id=idx,
                metadata={"source": source},
            )
        )
    return WeatherEnsemble(
        members=members,
        source=source,
        metadata={
            "pysteps_available": pysteps_available(),
            "member_count": member_count,
            "note": (
                "pySTEPS-style ensemble hook: precipitation/wind members are converted "
                "to WeatherCube members before risk mapping and noncompensatory fusion."
            ),
        },
    )


def make_stochastic_weather_ensemble(
    base_cube: WeatherCube,
    *,
    member_count: int = 16,
    seed: int = 20260617,
    rain_sigma: float = 0.18,
    wind_sigma_mps: float = 0.8,
    gust_sigma_mps: float = 1.2,
) -> WeatherEnsemble:
    """Fallback member generator using weather-space perturbations.

    This is intentionally kept outside the risk model. It perturbs weather
    variables first, then each member goes through the same explicit risk
    mapping as real pySTEPS/HRRR/ERA5 members.
    """

    rng = np.random.default_rng(seed)
    members: list[WeatherCube] = []
    for idx in range(int(member_count)):
        overrides: dict[str, np.ndarray] = {}
        if "rain_rate" in base_cube.variables:
            factor = np.maximum(rng.normal(1.0, rain_sigma, size=base_cube.shape), 0.0)
            overrides["rain_rate"] = base_cube.variables["rain_rate"] * factor
        for name in ("u_wind", "v_wind"):
            if name in base_cube.variables:
                overrides[name] = base_cube.variables[name] + rng.normal(0.0, wind_sigma_mps, size=base_cube.shape)
        if "gust" in base_cube.variables:
            overrides["gust"] = np.maximum(
                base_cube.variables["gust"] + rng.normal(0.0, gust_sigma_mps, size=base_cube.shape),
                0.0,
            )
        members.append(
            build_weather_member(
                base_cube,
                variable_overrides=overrides,
                member_id=idx,
                confidence_scale=0.98,
                metadata={"source": "stochastic_weather_ensemble", "seed": seed},
            )
        )
    return WeatherEnsemble(
        members=members,
        source="stochastic_weather_ensemble",
        metadata={
            "pysteps_available": pysteps_available(),
            "member_count": int(member_count),
            "seed": seed,
            "rain_sigma": rain_sigma,
            "wind_sigma_mps": wind_sigma_mps,
            "gust_sigma_mps": gust_sigma_mps,
            "fallback_role": "weather-space ensemble fallback until pySTEPS nowcast members are provided",
        },
    )
