from __future__ import annotations

from typing import Any

import numpy as np

from uav_weather_planning.risk_field.risk_field_4d import State4D


def compute_cvar(samples: np.ndarray, alpha: float = 0.9, axis: int = 0) -> np.ndarray:
    """Return the conditional value-at-risk of sample losses."""

    samples = np.asarray(samples, dtype=float)
    if samples.size == 0:
        return np.asarray(np.nan)
    alpha = float(np.clip(alpha, 0.0, 0.999))
    var = np.quantile(samples, alpha, axis=axis, keepdims=True)
    tail = np.where(samples >= var, samples, np.nan)
    return np.nanmean(tail, axis=axis)


def build_risk_samples(
    base_risk: np.ndarray | float,
    uncertainty: np.ndarray | float,
    *,
    n_samples: int = 64,
    seed: int = 7,
    perturbation_scale: float = 0.55,
    base_sigma: float = 0.02,
) -> np.ndarray:
    """Generate Monte Carlo risk samples using uncertainty as width.

    sigma(x,t) = sigma0 + beta * U(x,t)
    R_m(x,t) = clip(R(x,t) + sigma(x,t) * epsilon_m, 0, 1)
    """

    base = np.asarray(base_risk, dtype=float)
    uncertainty_arr = np.asarray(uncertainty, dtype=float)
    rng = np.random.default_rng(seed)
    perturb = rng.normal(loc=0.0, scale=1.0, size=(int(n_samples), *base.shape))
    sigma = float(base_sigma) + float(perturbation_scale) * uncertainty_arr
    samples = base[None, ...] + sigma[None, ...] * perturb
    return np.clip(samples, 0.0, 1.0)


def compute_cvar_field(
    base_risk: np.ndarray,
    uncertainty: np.ndarray,
    *,
    alpha: float = 0.9,
    n_samples: int = 64,
    seed: int = 7,
    perturbation_scale: float = 0.55,
    base_sigma: float = 0.02,
    return_excess: bool = True,
    chunk_voxels: int | None = None,
    dtype: np.dtype | str = np.float32,
) -> np.ndarray:
    """Compute field-level CVaR or CVaR excess for a 4D risk tensor.

    For large 4D fields the full sample tensor can be several gigabytes.
    When chunk_voxels is set, samples are generated for flattened voxel
    blocks and the CVaR is computed block by block. The random draw order is
    not byte-identical to build_risk_samples(), but it follows the same
    distribution and keeps the memory footprint bounded for paper-scale runs.
    """

    base = np.asarray(base_risk, dtype=float)
    if chunk_voxels is not None and int(chunk_voxels) > 0:
        return compute_cvar_field_chunked(
            base,
            uncertainty,
            alpha=alpha,
            n_samples=n_samples,
            seed=seed,
            perturbation_scale=perturbation_scale,
            base_sigma=base_sigma,
            return_excess=return_excess,
            chunk_voxels=int(chunk_voxels),
            dtype=dtype,
        )
    samples = build_risk_samples(
        base,
        uncertainty,
        n_samples=n_samples,
        seed=seed,
        perturbation_scale=perturbation_scale,
        base_sigma=base_sigma,
    )
    cvar = compute_cvar(samples, alpha=alpha, axis=0)
    if not return_excess:
        return np.asarray(cvar, dtype=float)
    excess_ratio = np.clip((cvar - base) / np.maximum(base, 1e-6), 0.0, 1.0)
    return excess_ratio * base


def compute_cvar_field_chunked(
    base_risk: np.ndarray,
    uncertainty: np.ndarray,
    *,
    alpha: float = 0.9,
    n_samples: int = 64,
    seed: int = 7,
    perturbation_scale: float = 0.55,
    base_sigma: float = 0.02,
    return_excess: bool = True,
    chunk_voxels: int = 200_000,
    dtype: np.dtype | str = np.float32,
) -> np.ndarray:
    """Chunked CVaR computation for large 4D risk fields."""

    base = np.asarray(base_risk, dtype=dtype)
    uncertainty_arr = np.asarray(uncertainty, dtype=dtype)
    if base.shape != uncertainty_arr.shape:
        raise ValueError("base_risk and uncertainty must have the same shape")
    n_samples = max(1, int(n_samples))
    chunk_voxels = max(1, int(chunk_voxels))
    alpha = float(np.clip(alpha, 0.0, 0.999))
    rng = np.random.default_rng(seed)
    flat_base = base.reshape(-1)
    flat_unc = uncertainty_arr.reshape(-1)
    flat_out = np.empty_like(flat_base, dtype=np.float32)
    for start in range(0, flat_base.size, chunk_voxels):
        stop = min(start + chunk_voxels, flat_base.size)
        block_base = flat_base[start:stop].astype(np.float32, copy=False)
        block_unc = flat_unc[start:stop].astype(np.float32, copy=False)
        perturb = rng.normal(0.0, 1.0, size=(n_samples, stop - start)).astype(np.float32)
        sigma = np.float32(base_sigma) + np.float32(perturbation_scale) * block_unc
        samples = np.clip(block_base[None, :] + sigma[None, :] * perturb, 0.0, 1.0)
        var = np.quantile(samples, alpha, axis=0, keepdims=True)
        tail = np.where(samples >= var, samples, np.nan)
        cvar = np.nanmean(tail, axis=0).astype(np.float32)
        if return_excess:
            excess_ratio = np.clip((cvar - block_base) / np.maximum(block_base, 1e-6), 0.0, 1.0)
            flat_out[start:stop] = excess_ratio * block_base
        else:
            flat_out[start:stop] = cvar
    return flat_out.reshape(base.shape)


def audit_path_risk(path: list[State4D], risk_field: Any) -> dict[str, float | int | None]:
    """Summarize expected/CVaR/violation risk along a 4D path."""

    if not path:
        return {
            "path_expected_risk_sum": None,
            "path_expected_risk_mean": None,
            "path_cvar_sum": None,
            "path_cvar_mean": None,
            "max_segment_cvar": None,
            "max_violation_probability": None,
            "path_total_cost_sum": None,
            "path_total_cost_mean": None,
            "sample_count": 0,
        }

    expected_values: list[float] = []
    cvar_values: list[float] = []
    total_values: list[float] = []
    violation_values: list[float] = []
    for state in path:
        t, z, y, x = state
        t = risk_field.clamp_time(t)
        risk = risk_field.query_risk_at(
            position_m=_state_position_m(risk_field, (t, z, y, x)),
            time_s=_state_time_s(risk_field, (t, z, y, x)),
            return_channels=False,
        )
        expected_values.append(float(risk["expected_risk"]))
        cvar_values.append(float(risk["cvar_risk"]))
        total_values.append(float(risk["total_cost"]))
        violation_values.append(float(risk["violation_probability"]))

    expected = np.asarray(expected_values, dtype=float)
    cvar = np.asarray(cvar_values, dtype=float)
    total = np.asarray(total_values, dtype=float)
    violation = np.asarray(violation_values, dtype=float)
    return {
        "path_expected_risk_sum": _round(float(np.sum(expected))),
        "path_expected_risk_mean": _round(float(np.mean(expected))),
        "path_cvar_sum": _round(float(np.sum(cvar))),
        "path_cvar_mean": _round(float(np.mean(cvar))),
        "max_segment_cvar": _round(float(np.max(cvar))),
        "max_violation_probability": _round(float(np.max(violation))),
        "path_total_cost_sum": _round(float(np.sum(total))),
        "path_total_cost_mean": _round(float(np.mean(total))),
        "sample_count": len(path),
    }


def _state_position_m(risk_field: Any, state: State4D) -> tuple[float, float, float]:
    _, z, y, x = state
    x_axis = np.asarray(risk_field.coords.get("x", np.arange(risk_field.x_size)), dtype=float)
    y_axis = np.asarray(risk_field.coords.get("y", np.arange(risk_field.y_size)), dtype=float)
    z_axis = np.asarray(risk_field.coords.get("height", np.arange(risk_field.z_size)), dtype=float)
    return float(x_axis[x]), float(y_axis[y]), float(z_axis[z])


def _state_time_s(risk_field: Any, state: State4D) -> float:
    t = int(state[0])
    axis = np.asarray(risk_field.coords.get("time", np.arange(risk_field.t_size)))
    if np.issubdtype(axis.dtype, np.datetime64):
        return float((axis[t] - axis[0]).astype("timedelta64[ms]").astype(float) / 1000.0)
    try:
        return float(axis[t])
    except (TypeError, ValueError):
        return float(t)


def _round(value: float, digits: int = 3) -> float:
    if not np.isfinite(value):
        return value
    return round(value, digits)
