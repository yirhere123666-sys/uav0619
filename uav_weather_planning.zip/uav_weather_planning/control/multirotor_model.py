from __future__ import annotations

from dataclasses import asdict, dataclass

import numpy as np


@dataclass(frozen=True)
class MultirotorState:
    x_m: float
    y_m: float
    z_m: float
    vx_mps: float = 0.0
    vy_mps: float = 0.0
    vz_mps: float = 0.0
    yaw_rad: float = 0.0

    def as_vector(self) -> np.ndarray:
        return np.asarray([self.x_m, self.y_m, self.z_m, self.vx_mps, self.vy_mps, self.vz_mps, self.yaw_rad], dtype=float)

    @classmethod
    def from_vector(cls, vector: np.ndarray) -> "MultirotorState":
        values = np.asarray(vector, dtype=float)
        return cls(*[float(value) for value in values[:7]])

    def as_dict(self) -> dict[str, float]:
        return asdict(self)


@dataclass(frozen=True)
class MultirotorControl:
    ax_mps2: float = 0.0
    ay_mps2: float = 0.0
    az_mps2: float = 0.0
    yaw_rate_radps: float = 0.0

    def as_vector(self) -> np.ndarray:
        return np.asarray([self.ax_mps2, self.ay_mps2, self.az_mps2, self.yaw_rate_radps], dtype=float)

    @classmethod
    def from_vector(cls, vector: np.ndarray) -> "MultirotorControl":
        values = np.asarray(vector, dtype=float)
        return cls(*[float(value) for value in values[:4]])

    def as_dict(self) -> dict[str, float]:
        return asdict(self)


@dataclass(frozen=True)
class MultirotorControlLimits:
    max_horizontal_speed_mps: float = 15.0
    max_vertical_speed_mps: float = 3.0
    max_horizontal_accel_mps2: float = 4.0
    max_vertical_accel_mps2: float = 3.0
    max_yaw_rate_radps: float = 0.7853981633974483

    def as_dict(self) -> dict[str, float]:
        return asdict(self)


class MultirotorDynamicsModel:
    """Simplified low-speed multirotor dynamics for trajectory-layer NMPC design."""

    state_variables = ("x", "y", "z", "vx", "vy", "vz", "yaw")
    control_variables = ("ax_cmd", "ay_cmd", "az_cmd", "yaw_rate_cmd")

    def __init__(self, limits: MultirotorControlLimits | None = None) -> None:
        self.limits = limits or MultirotorControlLimits()

    def step(
        self,
        state: MultirotorState,
        control: MultirotorControl,
        dt_s: float,
        wind_velocity_mps: tuple[float, float, float] | None = None,
    ) -> MultirotorState:
        dt = max(float(dt_s), 1e-6)
        u = self.clip_control(control)
        wind = np.asarray(wind_velocity_mps or (0.0, 0.0, 0.0), dtype=float)
        s = state.as_vector()
        accel = u.as_vector()[:3]
        velocity = s[3:6] + accel * dt
        velocity = self._clip_velocity(velocity)
        position = s[:3] + (velocity + wind) * dt
        yaw = s[6] + float(u.yaw_rate_radps) * dt
        return MultirotorState(
            x_m=float(position[0]),
            y_m=float(position[1]),
            z_m=float(position[2]),
            vx_mps=float(velocity[0]),
            vy_mps=float(velocity[1]),
            vz_mps=float(velocity[2]),
            yaw_rad=float(yaw),
        )

    def clip_control(self, control: MultirotorControl) -> MultirotorControl:
        limits = self.limits
        horizontal = np.asarray([control.ax_mps2, control.ay_mps2], dtype=float)
        norm = float(np.linalg.norm(horizontal))
        if norm > limits.max_horizontal_accel_mps2 > 0.0:
            horizontal *= limits.max_horizontal_accel_mps2 / norm
        az = float(np.clip(control.az_mps2, -limits.max_vertical_accel_mps2, limits.max_vertical_accel_mps2))
        yaw_rate = float(np.clip(control.yaw_rate_radps, -limits.max_yaw_rate_radps, limits.max_yaw_rate_radps))
        return MultirotorControl(float(horizontal[0]), float(horizontal[1]), az, yaw_rate)

    def _clip_velocity(self, velocity: np.ndarray) -> np.ndarray:
        limits = self.limits
        clipped = np.asarray(velocity, dtype=float).copy()
        horizontal_norm = float(np.linalg.norm(clipped[:2]))
        if horizontal_norm > limits.max_horizontal_speed_mps > 0.0:
            clipped[:2] *= limits.max_horizontal_speed_mps / horizontal_norm
        clipped[2] = float(np.clip(clipped[2], -limits.max_vertical_speed_mps, limits.max_vertical_speed_mps))
        return clipped

    def metadata(self) -> dict:
        return {
            "model": "low-speed multirotor double-integrator with wind disturbance",
            "state_variables": self.state_variables,
            "control_variables": self.control_variables,
            "limits": self.limits.as_dict(),
            "role": "trajectory-layer NMPC design interface; not a full attitude-level flight controller",
        }
