from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any

import numpy as np

from uav_weather_planning.trajectory import ContinuousTrajectory
from .multirotor_model import (
    MultirotorControl,
    MultirotorControlLimits,
    MultirotorDynamicsModel,
    MultirotorState,
)


@dataclass(frozen=True)
class NMPCConfig:
    horizon_steps: int = 12
    dt_s: float = 0.5
    position_weight: float = 1.0
    velocity_weight: float = 0.25
    control_weight: float = 0.08
    control_rate_weight: float = 0.05
    risk_weight: float = 0.35
    terminal_weight: float = 2.0
    robustness_margin_m: float = 3.0

    def as_dict(self) -> dict[str, float | int]:
        return asdict(self)


@dataclass
class NMPCProblemDefinition:
    state_variables: tuple[str, ...]
    control_variables: tuple[str, ...]
    constraints: dict[str, Any]
    objective_terms: dict[str, float]
    disturbance_channels: tuple[str, ...]
    horizon_steps: int
    dt_s: float
    notes: str

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class NMPCRollout:
    states: list[MultirotorState]
    controls: list[MultirotorControl]
    tracking_error_m: list[float]
    metadata: dict[str, Any]

    def as_summary(self) -> dict[str, Any]:
        errors = np.asarray(self.tracking_error_m, dtype=float)
        return {
            "steps": len(self.controls),
            "max_tracking_error_m": round(float(np.nanmax(errors)), 3) if errors.size else 0.0,
            "mean_tracking_error_m": round(float(np.nanmean(errors)), 3) if errors.size else 0.0,
            "final_state": self.states[-1].as_dict() if self.states else None,
            "metadata": self.metadata,
        }


class RobustNMPCInterface:
    """NMPC design interface and deterministic reference-tracking simulator.

    This is intentionally not a nonlinear optimizer yet. It defines the
    state, controls, constraints, objective terms, disturbance channels, and
    provides a bounded feedback rollout so the trajectory layer has a clear
    control-facing contract before the full NMPC solver is introduced.
    """

    def __init__(
        self,
        dynamics: MultirotorDynamicsModel | None = None,
        config: NMPCConfig | None = None,
    ) -> None:
        self.dynamics = dynamics or MultirotorDynamicsModel()
        self.config = config or NMPCConfig()

    def build_problem_definition(self) -> NMPCProblemDefinition:
        limits = self.dynamics.limits
        return NMPCProblemDefinition(
            state_variables=self.dynamics.state_variables,
            control_variables=self.dynamics.control_variables,
            constraints={
                "max_horizontal_speed_mps": limits.max_horizontal_speed_mps,
                "max_vertical_speed_mps": limits.max_vertical_speed_mps,
                "max_horizontal_accel_mps2": limits.max_horizontal_accel_mps2,
                "max_vertical_accel_mps2": limits.max_vertical_accel_mps2,
                "max_yaw_rate_radps": limits.max_yaw_rate_radps,
                "robustness_margin_m": self.config.robustness_margin_m,
            },
            objective_terms={
                "position_tracking": self.config.position_weight,
                "velocity_tracking": self.config.velocity_weight,
                "control_effort": self.config.control_weight,
                "control_rate": self.config.control_rate_weight,
                "weather_risk_exposure": self.config.risk_weight,
                "terminal_error": self.config.terminal_weight,
            },
            disturbance_channels=("wind_u", "wind_v", "wind_w", "risk_uncertainty"),
            horizon_steps=self.config.horizon_steps,
            dt_s=self.config.dt_s,
            notes="Design-stage robust NMPC contract for B-spline trajectory tracking; full nonlinear optimizer remains future work.",
        )

    def simulate_tracking(
        self,
        reference: ContinuousTrajectory,
        initial_state: MultirotorState | None = None,
        wind_sequence_mps: np.ndarray | None = None,
    ) -> NMPCRollout:
        if len(reference.time_s) < 2:
            state = initial_state or _state_from_reference(reference, 0)
            return NMPCRollout([state], [], [], {"mode": "empty_reference"})
        state = initial_state or _state_from_reference(reference, 0)
        states = [state]
        controls: list[MultirotorControl] = []
        errors: list[float] = []
        previous_control = MultirotorControl()
        for idx in range(len(reference.time_s) - 1):
            dt = float(reference.time_s[idx + 1] - reference.time_s[idx])
            target_pos = reference.position_m[idx + 1]
            target_vel = reference.velocity_mps[idx + 1]
            control = self._tracking_control(state, target_pos, target_vel, previous_control, dt)
            wind = tuple(wind_sequence_mps[idx]) if wind_sequence_mps is not None and idx < len(wind_sequence_mps) else None
            state = self.dynamics.step(state, control, dt, wind_velocity_mps=wind)
            error = float(np.linalg.norm(state.as_vector()[:3] - target_pos))
            states.append(state)
            controls.append(control)
            errors.append(error)
            previous_control = control
        return NMPCRollout(
            states=states,
            controls=controls,
            tracking_error_m=errors,
            metadata={
                "mode": "bounded_pd_reference_tracking_placeholder",
                "problem_definition": self.build_problem_definition().as_dict(),
            },
        )

    def _tracking_control(
        self,
        state: MultirotorState,
        target_position_m: np.ndarray,
        target_velocity_mps: np.ndarray,
        previous_control: MultirotorControl,
        dt_s: float,
    ) -> MultirotorControl:
        pos = state.as_vector()[:3]
        vel = state.as_vector()[3:6]
        position_error = np.asarray(target_position_m, dtype=float) - pos
        velocity_error = np.asarray(target_velocity_mps, dtype=float) - vel
        commanded_accel = 0.85 * position_error + 0.65 * velocity_error
        raw = MultirotorControl(
            ax_mps2=float(commanded_accel[0]),
            ay_mps2=float(commanded_accel[1]),
            az_mps2=float(commanded_accel[2]),
            yaw_rate_radps=_yaw_rate_command(state, previous_control, commanded_accel, target_velocity_mps, dt_s),
        )
        return self.dynamics.clip_control(raw)


def _state_from_reference(reference: ContinuousTrajectory, idx: int) -> MultirotorState:
    pos = reference.position_m[idx]
    vel = reference.velocity_mps[idx]
    yaw = float(np.arctan2(vel[1], vel[0])) if np.linalg.norm(vel[:2]) > 1e-9 else 0.0
    return MultirotorState(
        x_m=float(pos[0]),
        y_m=float(pos[1]),
        z_m=float(pos[2]),
        vx_mps=float(vel[0]),
        vy_mps=float(vel[1]),
        vz_mps=float(vel[2]),
        yaw_rad=yaw,
    )


def _yaw_rate_command(
    state: MultirotorState,
    previous_control: MultirotorControl,
    commanded_accel: np.ndarray,
    target_velocity_mps: np.ndarray,
    dt_s: float,
) -> float:
    horizontal = np.asarray(target_velocity_mps[:2], dtype=float)
    if np.linalg.norm(horizontal) <= 1e-9:
        horizontal = commanded_accel[:2]
    if np.linalg.norm(horizontal) <= 1e-9:
        return float(previous_control.yaw_rate_radps)
    desired_yaw = float(np.arctan2(horizontal[1], horizontal[0]))
    yaw_error = _wrap_angle(desired_yaw - state.yaw_rad)
    return float(yaw_error / max(dt_s, 1e-6))


def _wrap_angle(angle_rad: float) -> float:
    return float((angle_rad + np.pi) % (2.0 * np.pi) - np.pi)


def default_multirotor_limits_from_speed(max_speed_mps: float = 15.0) -> MultirotorControlLimits:
    return MultirotorControlLimits(max_horizontal_speed_mps=max_speed_mps)
