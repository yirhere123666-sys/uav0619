from __future__ import annotations

from dataclasses import dataclass
import math

from .constraints import FlightConstraints
from .energy_model import MultirotorEnergyModel
from uav_weather_planning.risk_field import RiskField4D
from uav_weather_planning.risk_field.risk_field_4d import State4D


@dataclass
class PathMetrics:
    name: str
    success: bool
    path_length: int
    geometric_length: float
    cumulative_expected_risk: float
    cumulative_cvar_risk: float
    no_fly_violations: int
    turn_count: int
    nodes_expanded: int
    elapsed_ms: float
    replan_count: int = 0
    constraint_violations: int = 0
    max_ground_speed_mps: float | None = None
    max_vertical_rate_mps: float | None = None
    max_turn_angle_deg: float | None = None
    max_yaw_rate_deg_s: float | None = None
    max_acceleration_mps2: float | None = None
    min_safety_margin_cells: float | None = None
    min_safety_margin_m: float | None = None
    cumulative_energy_kj: float | None = None
    mean_power_w: float | None = None
    max_power_w: float | None = None
    max_energy_penalty: float | None = None
    arrival_time_step: int | None = None
    duration_steps: int | None = None
    cumulative_total_cost: float | None = None
    max_total_cost: float | None = None
    mean_expected_risk: float | None = None
    max_expected_risk: float | None = None
    mean_cvar_risk: float | None = None
    max_cvar_risk: float | None = None
    cvar_to_expected_ratio: float | None = None
    risk_density_per_grid: float | None = None
    mean_violation_probability: float | None = None
    max_violation_probability: float | None = None
    mean_safety_margin_cells: float | None = None
    near_no_fly_count: int | None = None
    cumulative_wind_risk: float | None = None
    cumulative_gust_risk: float | None = None
    cumulative_shear_risk: float | None = None
    cumulative_turbulence_risk: float | None = None
    cumulative_convection_risk: float | None = None
    cumulative_precipitation_risk: float | None = None
    cumulative_visibility_risk: float | None = None
    cumulative_epistemic_uncertainty: float | None = None
    planning_throughput_nodes_per_ms: float | None = None
    airspace_violations: int | None = None
    max_corridor_deviation_m: float | None = None
    mean_corridor_deviation_m: float | None = None
    max_corridor_deviation_ratio: float | None = None
    corridor_segments_used: str | None = None
    alternate_landing_points: str | None = None

    def as_row(self) -> dict[str, float | int | str | bool | None]:
        return {
            "name": self.name,
            "success": self.success,
            "path_length": self.path_length,
            "geometric_length": round(self.geometric_length, 3),
            "expected_risk": round(self.cumulative_expected_risk, 3),
            "cvar_risk": round(self.cumulative_cvar_risk, 3),
            "path_expected_risk_sum": round(self.cumulative_expected_risk, 3),
            "path_expected_risk_mean": self._round_optional(self.mean_expected_risk),
            "path_cvar_sum": round(self.cumulative_cvar_risk, 3),
            "path_cvar_mean": self._round_optional(self.mean_cvar_risk),
            "max_segment_cvar": self._round_optional(self.max_cvar_risk),
            "no_fly_violations": self.no_fly_violations,
            "turn_count": self.turn_count,
            "nodes_expanded": self.nodes_expanded,
            "elapsed_ms": round(self.elapsed_ms, 3),
            "replan_count": self.replan_count,
            "constraint_violations": self.constraint_violations,
            "max_ground_speed_mps": self.max_ground_speed_mps,
            "max_vertical_rate_mps": self.max_vertical_rate_mps,
            "max_turn_angle_deg": self.max_turn_angle_deg,
            "max_yaw_rate_deg_s": self.max_yaw_rate_deg_s,
            "max_acceleration_mps2": self.max_acceleration_mps2,
            "min_safety_margin_cells": self.min_safety_margin_cells,
            "min_safety_margin_m": self.min_safety_margin_m,
            "cumulative_energy_kj": self.cumulative_energy_kj,
            "mean_power_w": self.mean_power_w,
            "max_power_w": self.max_power_w,
            "max_energy_penalty": self.max_energy_penalty,
            "arrival_time_step": self.arrival_time_step,
            "duration_steps": self.duration_steps,
            "total_cost": self._round_optional(self.cumulative_total_cost),
            "max_total_cost": self._round_optional(self.max_total_cost),
            "mean_expected_risk": self._round_optional(self.mean_expected_risk),
            "max_expected_risk": self._round_optional(self.max_expected_risk),
            "mean_cvar_risk": self._round_optional(self.mean_cvar_risk),
            "max_cvar_risk": self._round_optional(self.max_cvar_risk),
            "cvar_to_expected_ratio": self._round_optional(self.cvar_to_expected_ratio),
            "risk_density_per_grid": self._round_optional(self.risk_density_per_grid),
            "mean_violation_probability": self._round_optional(self.mean_violation_probability),
            "max_violation_probability": self._round_optional(self.max_violation_probability),
            "mean_safety_margin_cells": self._round_optional(self.mean_safety_margin_cells),
            "near_no_fly_count": self.near_no_fly_count,
            "wind_exposure": self._round_optional(self.cumulative_wind_risk),
            "gust_exposure": self._round_optional(self.cumulative_gust_risk),
            "shear_exposure": self._round_optional(self.cumulative_shear_risk),
            "turbulence_exposure": self._round_optional(self.cumulative_turbulence_risk),
            "convection_exposure": self._round_optional(self.cumulative_convection_risk),
            "precipitation_exposure": self._round_optional(self.cumulative_precipitation_risk),
            "visibility_exposure": self._round_optional(self.cumulative_visibility_risk),
            "epistemic_uncertainty_exposure": self._round_optional(self.cumulative_epistemic_uncertainty),
            "uncertainty_exposure": self._round_optional(self.cumulative_epistemic_uncertainty),
            "planning_throughput_nodes_per_ms": self._round_optional(self.planning_throughput_nodes_per_ms),
            "airspace_violations": self.airspace_violations,
            "max_corridor_deviation_m": self._round_optional(self.max_corridor_deviation_m),
            "mean_corridor_deviation_m": self._round_optional(self.mean_corridor_deviation_m),
            "max_corridor_deviation_ratio": self._round_optional(self.max_corridor_deviation_ratio),
            "corridor_segments_used": self.corridor_segments_used,
            "alternate_landing_points": self.alternate_landing_points,
        }

    @staticmethod
    def _round_optional(value: float | None, digits: int = 3) -> float | None:
        if value is None:
            return None
        if not math.isfinite(value):
            return value
        return round(value, digits)


def evaluate_path(
    name: str,
    path: list[State4D],
    risk_field: RiskField4D,
    nodes_expanded: int = 0,
    elapsed_ms: float = 0.0,
    replan_count: int = 0,
    constraints: FlightConstraints | None = None,
) -> PathMetrics:
    if not path:
        audit = constraints.audit_path([], risk_field) if constraints is not None else {}
        return PathMetrics(
            name,
            False,
            0,
            0.0,
            float("inf"),
            float("inf"),
            0,
            0,
            nodes_expanded,
            elapsed_ms,
            replan_count,
            constraint_violations=int(audit.get("constraint_violations", 0)),
            max_ground_speed_mps=audit.get("max_ground_speed_mps"),  # type: ignore[arg-type]
            max_vertical_rate_mps=audit.get("max_vertical_rate_mps"),  # type: ignore[arg-type]
            max_turn_angle_deg=audit.get("max_turn_angle_deg"),  # type: ignore[arg-type]
            max_yaw_rate_deg_s=audit.get("max_yaw_rate_deg_s"),  # type: ignore[arg-type]
            max_acceleration_mps2=audit.get("max_acceleration_mps2"),  # type: ignore[arg-type]
            min_safety_margin_cells=audit.get("min_safety_margin_cells"),  # type: ignore[arg-type]
            min_safety_margin_m=audit.get("min_safety_margin_m"),  # type: ignore[arg-type]
            airspace_violations=int(audit.get("airspace_violations", 0)),
            max_corridor_deviation_m=audit.get("max_corridor_deviation_m"),  # type: ignore[arg-type]
            mean_corridor_deviation_m=audit.get("mean_corridor_deviation_m"),  # type: ignore[arg-type]
            max_corridor_deviation_ratio=audit.get("max_corridor_deviation_ratio"),  # type: ignore[arg-type]
            corridor_segments_used=";".join(audit.get("corridor_segments_used", [])),  # type: ignore[arg-type]
            alternate_landing_points=";".join(audit.get("alternate_landing_points", [])),  # type: ignore[arg-type]
        )

    expected = 0.0
    cvar = 0.0
    total = 0.0
    no_fly = 0
    max_expected = 0.0
    max_cvar = 0.0
    max_total = 0.0
    violation_values = []
    margin_values = []
    channel_sums = {
        "wind": 0.0,
        "gust": 0.0,
        "shear": 0.0,
        "turbulence": 0.0,
        "convection": 0.0,
        "precipitation": 0.0,
        "visibility": 0.0,
        "epistemic_uncertainty": 0.0,
    }
    for state in path:
        t, z, y, x = state
        t = risk_field.clamp_time(t)
        if risk_field.no_fly_mask[t, z, y, x]:
            no_fly += 1
        expected_value = float(risk_field.expected_cost[t, z, y, x])
        cvar_value = float(risk_field.cvar_cost[t, z, y, x])
        total_value = float(risk_field.total_cost[t, z, y, x])
        expected += expected_value
        cvar += cvar_value
        total += total_value
        max_expected = max(max_expected, expected_value)
        max_cvar = max(max_cvar, cvar_value)
        max_total = max(max_total, total_value)
        violation_values.append(float(risk_field.violation_probability[t, z, y, x]))
        margin_values.append(risk_field.safety_margin((t, z, y, x)))
        channel_sums["wind"] += float(risk_field.wind_risk[t, z, y, x])
        channel_sums["gust"] += float(risk_field.gust_risk[t, z, y, x])
        channel_sums["shear"] += float(risk_field.shear_risk[t, z, y, x])
        channel_sums["turbulence"] += float(risk_field.turbulence_risk[t, z, y, x])
        channel_sums["convection"] += float(risk_field.convection_risk[t, z, y, x])
        channel_sums["precipitation"] += float(risk_field.precipitation_risk[t, z, y, x])
        channel_sums["visibility"] += float(risk_field.visibility_risk[t, z, y, x])
        channel_sums["epistemic_uncertainty"] += float(risk_field.uncertainty[t, z, y, x])

    geometric = 0.0
    turn_count = 0
    prev_move = None
    for a, b in zip(path[:-1], path[1:]):
        _, z0, y0, x0 = a
        _, z1, y1, x1 = b
        move = (z1 - z0, y1 - y0, x1 - x0)
        geometric += math.sqrt(move[2] ** 2 + move[1] ** 2 + 1.35 * move[0] ** 2)
        if prev_move is not None and move != prev_move:
            turn_count += 1
        prev_move = move

    audit = constraints.audit_path(path, risk_field) if constraints is not None else {}
    energy = MultirotorEnergyModel(risk_field).path_energy(path)
    path_count = max(len(path), 1)
    near_no_fly_count = sum(1 for value in margin_values if value <= 1.0)
    throughput = nodes_expanded / elapsed_ms if elapsed_ms > 0.0 else None

    return PathMetrics(
        name=name,
        success=no_fly == 0 and int(audit.get("constraint_violations", 0)) == 0,
        path_length=len(path),
        geometric_length=geometric,
        cumulative_expected_risk=expected,
        cumulative_cvar_risk=cvar,
        no_fly_violations=no_fly,
        turn_count=turn_count,
        nodes_expanded=nodes_expanded,
        elapsed_ms=elapsed_ms,
        replan_count=replan_count,
        constraint_violations=int(audit.get("constraint_violations", 0)),
        max_ground_speed_mps=audit.get("max_ground_speed_mps"),  # type: ignore[arg-type]
        max_vertical_rate_mps=audit.get("max_vertical_rate_mps"),  # type: ignore[arg-type]
        max_turn_angle_deg=audit.get("max_turn_angle_deg"),  # type: ignore[arg-type]
        max_yaw_rate_deg_s=audit.get("max_yaw_rate_deg_s"),  # type: ignore[arg-type]
        max_acceleration_mps2=audit.get("max_acceleration_mps2"),  # type: ignore[arg-type]
        min_safety_margin_cells=audit.get("min_safety_margin_cells"),  # type: ignore[arg-type]
        min_safety_margin_m=audit.get("min_safety_margin_m"),  # type: ignore[arg-type]
        cumulative_energy_kj=energy.get("cumulative_energy_kj"),  # type: ignore[arg-type]
        mean_power_w=energy.get("mean_power_w"),  # type: ignore[arg-type]
        max_power_w=energy.get("max_power_w"),  # type: ignore[arg-type]
        max_energy_penalty=energy.get("max_energy_penalty"),  # type: ignore[arg-type]
        arrival_time_step=int(path[-1][0]),
        duration_steps=int(path[-1][0] - path[0][0]),
        cumulative_total_cost=total,
        max_total_cost=max_total,
        mean_expected_risk=expected / path_count,
        max_expected_risk=max_expected,
        mean_cvar_risk=cvar / path_count,
        max_cvar_risk=max_cvar,
        cvar_to_expected_ratio=cvar / expected if expected > 0.0 and math.isfinite(expected) else None,
        risk_density_per_grid=expected / geometric if geometric > 0.0 and math.isfinite(expected) else None,
        mean_violation_probability=sum(violation_values) / path_count if violation_values else None,
        max_violation_probability=max(violation_values) if violation_values else None,
        mean_safety_margin_cells=sum(margin_values) / path_count if margin_values else None,
        near_no_fly_count=near_no_fly_count,
        cumulative_wind_risk=channel_sums["wind"],
        cumulative_gust_risk=channel_sums["gust"],
        cumulative_shear_risk=channel_sums["shear"],
        cumulative_turbulence_risk=channel_sums["turbulence"],
        cumulative_convection_risk=channel_sums["convection"],
        cumulative_precipitation_risk=channel_sums["precipitation"],
        cumulative_visibility_risk=channel_sums["visibility"],
        cumulative_epistemic_uncertainty=channel_sums["epistemic_uncertainty"],
        planning_throughput_nodes_per_ms=throughput,
        airspace_violations=int(audit.get("airspace_violations", 0)),
        max_corridor_deviation_m=audit.get("max_corridor_deviation_m"),  # type: ignore[arg-type]
        mean_corridor_deviation_m=audit.get("mean_corridor_deviation_m"),  # type: ignore[arg-type]
        max_corridor_deviation_ratio=audit.get("max_corridor_deviation_ratio"),  # type: ignore[arg-type]
        corridor_segments_used=";".join(audit.get("corridor_segments_used", [])),  # type: ignore[arg-type]
        alternate_landing_points=";".join(audit.get("alternate_landing_points", [])),  # type: ignore[arg-type]
    )
