from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import numpy as np

from uav_weather_planning.risk import audit_path_risk
from uav_weather_planning.risk_field import RiskField4D
from uav_weather_planning.risk_field.risk_field_4d import SpatialNode, State4D

from .constraints import FlightConstraints
from .incremental_lpa_star import IncrementalLPAStar
from .time_dependent_astar import TimeDependentAStar


@dataclass
class IncrementalRepairAdapterConfig:
    heuristic_weight: float = 4.0
    safety_fallback: bool = True


@dataclass
class IncrementalRepairAdapterResult:
    path: list[State4D]
    total_cost: float
    nodes_expanded: int
    elapsed_ms: float
    success: bool
    reason: str = ""
    replan_events: list[dict[str, Any]] = field(default_factory=list)
    repair_mode: str = "lpa_incremental_repair"
    affected_nodes: int = 0
    raw_changed_voxel_ratio: float | None = None
    significant_changed_voxel_ratio: float | None = None
    g_rhs_reused: bool = False
    queue_reused: bool = False
    edge_updates: int = 0
    vertex_updates: int = 0
    fallback_used: bool = False
    fallback_reason: str = ""
    path_expected_risk: float | None = None
    path_cvar: float | None = None
    max_segment_cvar: float | None = None
    initial_nodes_expanded: int = 0
    repair_nodes_expanded: int = 0
    initial_elapsed_ms: float = 0.0
    repair_elapsed_ms: float = 0.0


class IncrementalRepairAdapter:
    """Benchmark adapter for the LPA*/D* Lite-family incremental planner."""

    def __init__(
        self,
        risk_field: RiskField4D,
        constraints: FlightConstraints | None = None,
        config: IncrementalRepairAdapterConfig | None = None,
    ) -> None:
        self.risk_field = risk_field
        self.constraints = constraints or FlightConstraints()
        self.config = config or IncrementalRepairAdapterConfig()
        self.lpa: IncrementalLPAStar | None = None
        self.initialized = False
        self.start: SpatialNode | None = None
        self.goal: SpatialNode | None = None
        self.start_time = 0
        self.initial_nodes_expanded = 0
        self.initial_elapsed_ms = 0.0

    def plan_initial(
        self,
        start: SpatialNode,
        goal: SpatialNode,
        start_time: int = 0,
    ) -> IncrementalRepairAdapterResult:
        self.start = start
        self.goal = goal
        self.start_time = start_time
        self.lpa = IncrementalLPAStar(
            risk_field=self.risk_field,
            constraints=self.constraints,
            start=start,
            goal=goal,
            start_time=start_time,
            heuristic_weight=self.config.heuristic_weight,
        )
        result = self.lpa.run()
        self.initialized = True
        self.initial_nodes_expanded = result.nodes_expanded
        self.initial_elapsed_ms = result.elapsed_ms
        return self._make_result(
            path=result.path,
            success=result.success,
            nodes_expanded=result.nodes_expanded,
            elapsed_ms=result.elapsed_ms,
            risk_field=self.risk_field,
            reason="" if result.success else "initial LPA* search failed",
            repair_mode="initial_lpa_search",
            repair_nodes_expanded=result.nodes_expanded,
            repair_elapsed_ms=result.elapsed_ms,
        )

    def repair_after_update(
        self,
        updated_risk_field: RiskField4D,
        changed_voxels: np.ndarray | None = None,
        current_state: State4D | None = None,
        goal: SpatialNode | None = None,
    ) -> IncrementalRepairAdapterResult:
        if not self.initialized or self.lpa is None or self.start is None or self.goal is None:
            raise RuntimeError("IncrementalRepairAdapter.plan_initial() must be called before repair_after_update().")
        goal = goal or self.goal
        self.risk_field = updated_risk_field
        self.lpa.update_risk_field(updated_risk_field)
        result = self.lpa.run()
        update_event = self._merged_update_event()
        path = result.path
        repair_nodes = self.lpa.last_compute_nodes_expanded
        repair_elapsed = self.lpa.last_compute_elapsed_ms
        fallback_used = False
        fallback_reason = ""
        success = result.success
        reason = "" if result.success else "incremental LPA* repair failed"
        if current_state is not None and path:
            if current_state in path:
                path = path[path.index(current_state) :]
            else:
                fallback_used = True
                fallback_reason = "LPA* repaired path does not connect to current flight state"
        if self.config.safety_fallback and (fallback_used or self._needs_fallback(path, updated_risk_field)):
            fallback_start = current_state or self._normalized_start()
            fallback = TimeDependentAStar(
                updated_risk_field,
                constraints=self.constraints,
                heuristic_weight=self.config.heuristic_weight,
            ).plan(
                fallback_start,
                goal,
                start_time=fallback_start[0],
            )
            fallback_used = True
            fallback_reason = fallback_reason or "LPA* repair safety audit failed; fallback to full time-dependent A*"
            path = fallback.path
            repair_nodes += fallback.nodes_expanded
            repair_elapsed += fallback.elapsed_ms
            success = fallback.success
            reason = fallback_reason if not fallback.success else ""
        return self._make_result(
            path=path,
            success=success,
            nodes_expanded=self.initial_nodes_expanded + repair_nodes,
            elapsed_ms=self.initial_elapsed_ms + repair_elapsed,
            risk_field=updated_risk_field,
            reason=reason,
            repair_mode="lpa_incremental_repair",
            replan_events=list(self.lpa.replan_events),
            update_event=update_event,
            fallback_used=fallback_used,
            fallback_reason=fallback_reason,
            repair_nodes_expanded=repair_nodes,
            repair_elapsed_ms=repair_elapsed,
        )

    def _map_voxels_to_nodes(self, changed_voxels: np.ndarray) -> set[State4D]:
        if self.lpa is None:
            return set()
        indices = np.argwhere(changed_voxels) if changed_voxels.dtype == bool else np.asarray(changed_voxels)
        return self.lpa._affected_nodes_from_changes(indices)  # noqa: SLF001 - adapter exposes the research primitive.

    def _needs_fallback(self, path: list[State4D], risk_field: RiskField4D) -> bool:
        audit = self.constraints.audit_path(path, risk_field)
        return (
            not path
            or int(audit.get("constraint_violations", 0) or 0) > 0
            or int(audit.get("airspace_violations", 0) or 0) > 0
            or any(risk_field.is_no_fly((risk_field.clamp_time(state[0]), state[1], state[2], state[3])) for state in path)
        )

    def _normalized_start(self) -> State4D:
        assert self.start is not None
        return (self.start_time, self.start[0], self.start[1], self.start[2])

    def _merged_update_event(self) -> dict[str, Any]:
        if self.lpa is None or not self.lpa.replan_events:
            return {}
        merged: dict[str, Any] = {}
        for event in self.lpa.replan_events:
            merged.update(event)
        return merged

    def _make_result(
        self,
        *,
        path: list[State4D],
        success: bool,
        nodes_expanded: int,
        elapsed_ms: float,
        risk_field: RiskField4D,
        reason: str = "",
        repair_mode: str,
        replan_events: list[dict[str, Any]] | None = None,
        update_event: dict[str, Any] | None = None,
        fallback_used: bool = False,
        fallback_reason: str = "",
        repair_nodes_expanded: int = 0,
        repair_elapsed_ms: float = 0.0,
    ) -> IncrementalRepairAdapterResult:
        update_event = update_event or {}
        path_stats = _path_risk_stats(path, risk_field)
        return IncrementalRepairAdapterResult(
            path=path,
            total_cost=path_stats["total_cost"],
            nodes_expanded=int(nodes_expanded),
            elapsed_ms=float(elapsed_ms),
            success=bool(success),
            reason=reason,
            replan_events=replan_events or [],
            repair_mode=repair_mode,
            affected_nodes=int(update_event.get("affected_nodes", 0) or 0),
            raw_changed_voxel_ratio=update_event.get("raw_changed_voxel_ratio"),
            significant_changed_voxel_ratio=update_event.get("significant_changed_voxel_ratio"),
            g_rhs_reused=bool(update_event.get("g_rhs_reused", False)),
            queue_reused=bool(update_event.get("queue_reused", False)),
            edge_updates=int(update_event.get("edge_updates", 0) or 0),
            vertex_updates=int(update_event.get("vertex_updates", 0) or 0),
            fallback_used=bool(fallback_used),
            fallback_reason=fallback_reason,
            path_expected_risk=path_stats["expected_risk"],
            path_cvar=path_stats["cvar_risk"],
            max_segment_cvar=path_stats["max_segment_cvar"],
            initial_nodes_expanded=int(self.initial_nodes_expanded),
            repair_nodes_expanded=int(repair_nodes_expanded),
            initial_elapsed_ms=round(float(self.initial_elapsed_ms), 3),
            repair_elapsed_ms=round(float(repair_elapsed_ms), 3),
        )


def _path_risk_stats(path: list[State4D], risk_field: RiskField4D) -> dict[str, float | None]:
    if not path:
        return {"expected_risk": None, "cvar_risk": None, "max_segment_cvar": None, "total_cost": float("inf")}
    audit = audit_path_risk(path, risk_field)
    return {
        "expected_risk": audit["path_expected_risk_sum"],
        "cvar_risk": audit["path_cvar_sum"],
        "max_segment_cvar": audit["max_segment_cvar"],
        "total_cost": audit["path_total_cost_sum"],
    }
