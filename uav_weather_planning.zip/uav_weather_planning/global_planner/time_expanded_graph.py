from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Any

import numpy as np

from uav_weather_planning.risk_field import RiskField4D
from uav_weather_planning.risk_field.risk_field_4d import SpatialNode, State4D

from .constraints import FlightConstraints


VIRTUAL_GOAL: State4D = (-1, -1, -1, -1)


@dataclass(frozen=True)
class TimeExpandedGraphConfig:
    allow_wait: bool = True
    vertical_weight: float = 1.35
    distance_weight: float = 1.0
    time_weight: float = 0.18
    expected_weight: float = 1.0
    cvar_weight: float = 0.55
    violation_probability_weight: float = 2.0
    uncertainty_weight: float = 0.05
    energy_weight: float = 0.35
    safety_weight: float = 0.20
    edge_change_eps: float = 1e-6


class TimeExpandedGraph:
    """Time-expanded graph facade for online D* Lite repair."""

    def __init__(
        self,
        risk_field: RiskField4D,
        goal: SpatialNode,
        constraints: FlightConstraints | None = None,
        config: TimeExpandedGraphConfig | None = None,
        start_time: int = 0,
        max_time: int | None = None,
    ) -> None:
        self.risk_field = risk_field
        self.goal = goal
        self.constraints = constraints or FlightConstraints()
        self.config = config or TimeExpandedGraphConfig()
        self.start_time = int(start_time)
        self.max_time = int(max_time if max_time is not None else risk_field.t_size - 1)
        self.edge_cost_cache: dict[tuple[State4D, State4D], float] = {}
        self.previous_edge_cost_cache: dict[tuple[State4D, State4D], float] = {}
        self._successor_cache: dict[State4D, list[State4D]] = {}
        self._predecessor_cache: dict[State4D, list[State4D]] = {}

    def set_risk_field(self, risk_field: RiskField4D) -> None:
        self.previous_edge_cost_cache = dict(self.edge_cost_cache)
        self.edge_cost_cache.clear()
        self.risk_field = risk_field

    def successors(self, state: State4D) -> list[State4D]:
        cached = self._successor_cache.get(state)
        if cached is not None:
            return cached
        if state == VIRTUAL_GOAL or state[0] >= self.max_time:
            self._successor_cache[state] = []
            return []
        if self.spatial(state) == self.goal:
            self._successor_cache[state] = [VIRTUAL_GOAL]
            return [VIRTUAL_GOAL]

        t, z, y, x = state
        nt = t + 1
        moves = []
        for dz in (-1, 0, 1):
            for dy in (-1, 0, 1):
                for dx in (-1, 0, 1):
                    if dz == 0 and dy == 0 and dx == 0:
                        continue
                    moves.append((dz, dy, dx))
        if self.config.allow_wait:
            moves.append((0, 0, 0))
        out: list[State4D] = []
        for dz, dy, dx in moves:
            candidate = (nt, z + dz, y + dy, x + dx)
            if self.risk_field.in_bounds(candidate):
                out.append(candidate)
        self._successor_cache[state] = out
        return out

    def predecessors(self, state: State4D) -> list[State4D]:
        cached = self._predecessor_cache.get(state)
        if cached is not None:
            return cached
        if state == VIRTUAL_GOAL:
            out = [
                (t, self.goal[0], self.goal[1], self.goal[2])
                for t in range(self.start_time, self.max_time + 1)
                if self.risk_field.in_bounds((t, self.goal[0], self.goal[1], self.goal[2]))
            ]
            self._predecessor_cache[state] = out
            return out
        t, z, y, x = state
        if t <= self.start_time:
            self._predecessor_cache[state] = []
            return []
        out = []
        for dz in (-1, 0, 1):
            for dy in (-1, 0, 1):
                for dx in (-1, 0, 1):
                    predecessor = (t - 1, z + dz, y + dy, x + dx)
                    if self.risk_field.in_bounds(predecessor):
                        out.append(predecessor)
        if self.config.allow_wait:
            predecessor = (t - 1, z, y, x)
            if self.risk_field.in_bounds(predecessor) and predecessor not in out:
                out.append(predecessor)
        self._predecessor_cache[state] = out
        return out

    def edge_cost(self, u: State4D, v: State4D) -> float:
        key = (u, v)
        cached = self.edge_cost_cache.get(key)
        if cached is not None:
            return cached
        value = self._compute_edge_cost(u, v)
        self.edge_cost_cache[key] = value
        return value

    def previous_edge_cost(self, u: State4D, v: State4D) -> float | None:
        return self.previous_edge_cost_cache.get((u, v))

    def map_changed_voxels_to_edges(self, changed_voxels: np.ndarray) -> list[tuple[State4D, State4D]]:
        indices = np.argwhere(changed_voxels) if changed_voxels.dtype == bool else np.asarray(changed_voxels)
        edges: set[tuple[State4D, State4D]] = set()
        for raw in indices:
            state = tuple(int(value) for value in raw)  # type: ignore[assignment]
            if not self.risk_field.in_bounds(state):
                continue
            if state[0] < self.start_time or state[0] > self.max_time:
                continue
            for pred in self.predecessors(state):
                edges.add((pred, state))
            for succ in self.successors(state):
                edges.add((state, succ))
            if self.spatial(state) == self.goal:
                edges.add((state, VIRTUAL_GOAL))
        return sorted(edges)

    def heuristic(self, a: State4D, b: State4D) -> float:
        if a == VIRTUAL_GOAL or b == VIRTUAL_GOAL:
            return 0.0
        _, za, ya, xa = a
        _, zb, yb, xb = b
        return math.sqrt((xb - xa) ** 2 + (yb - ya) ** 2 + self.config.vertical_weight * (zb - za) ** 2)

    def state_to_position(self, state: State4D) -> tuple[float, float, float]:
        _, z, y, x = state
        x_axis = np.asarray(self.risk_field.coords.get("x", np.arange(self.risk_field.x_size)), dtype=float)
        y_axis = np.asarray(self.risk_field.coords.get("y", np.arange(self.risk_field.y_size)), dtype=float)
        z_axis = np.asarray(self.risk_field.coords.get("height", np.arange(self.risk_field.z_size)), dtype=float)
        return float(x_axis[x]), float(y_axis[y]), float(z_axis[z])

    def state_to_time_s(self, state: State4D) -> float:
        t = int(np.clip(state[0], 0, self.risk_field.t_size - 1))
        axis = np.asarray(self.risk_field.coords.get("time", np.arange(self.risk_field.t_size)))
        if np.issubdtype(axis.dtype, np.datetime64):
            return float((axis[t] - axis[0]).astype("timedelta64[ms]").astype(float) / 1000.0)
        try:
            return float(axis[t])
        except (TypeError, ValueError):
            return float(t)

    @staticmethod
    def spatial(state: State4D) -> SpatialNode:
        return state[1], state[2], state[3]

    def _compute_edge_cost(self, u: State4D, v: State4D) -> float:
        if v == VIRTUAL_GOAL:
            return 0.0 if self.spatial(u) == self.goal else float("inf")
        if u == VIRTUAL_GOAL:
            return float("inf")
        if not self.risk_field.in_bounds(u) or not self.risk_field.in_bounds(v):
            return float("inf")
        if not self.constraints.is_feasible(u, v, self.risk_field, previous=None):
            return float("inf")
        q = self.risk_field.query_risk_at(
            self.state_to_position(v),
            self.state_to_time_s(v),
            return_channels=True,
            include_resolution_metadata=False,
        )
        if q["no_fly"] or not q["is_feasible"]:
            return float("inf")
        _, z0, y0, x0 = u
        _, z1, y1, x1 = v
        dz = z1 - z0
        dy = y1 - y0
        dx = x1 - x0
        distance = math.sqrt(dx * dx + dy * dy + self.config.vertical_weight * dz * dz)
        if distance == 0.0:
            distance = 0.45
        safety_margin = max(float(q["safety_margin"]), 1e-6)
        safety_penalty = 1.0 / (1.0 + safety_margin)
        return (
            self.config.distance_weight * distance
            + self.config.time_weight
            + self.config.expected_weight * float(q["expected_risk"])
            + self.config.cvar_weight * float(q["cvar_risk"])
            + self.config.violation_probability_weight * float(q["violation_probability"])
            + self.config.uncertainty_weight * float(q["epistemic_uncertainty"])
            + self.config.energy_weight * float(q["energy_penalty"])
            + self.config.safety_weight * safety_penalty
            + self.constraints.penalty(None, u, v)
            + self.constraints.metric_penalty(None, u, v, self.risk_field)
        )
