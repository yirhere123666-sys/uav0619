from __future__ import annotations

from dataclasses import dataclass, field
import heapq
import math
import time
from typing import Any

import numpy as np

from uav_weather_planning.risk_field.risk_field_4d import State4D

from .time_expanded_graph import TimeExpandedGraph, VIRTUAL_GOAL


INF = float("inf")


@dataclass
class DStarLiteResult:
    path: list[State4D]
    success: bool
    nodes_expanded: int
    elapsed_ms: float
    km_final: float
    start_updates: int
    affected_edges: int = 0
    affected_vertices: int = 0
    edge_updates: int = 0
    vertex_updates: int = 0
    g_rhs_reused: bool = True
    queue_reused: bool = True
    reverse_search_from_goal: bool = True
    moving_start_enabled: bool = True
    km_enabled: bool = True
    replan_events: list[dict[str, Any]] = field(default_factory=list)
    reason: str = ""


class PriorityQueue:
    def __init__(self) -> None:
        self.heap: list[tuple[tuple[float, float], State4D]] = []
        self.entries: dict[State4D, tuple[float, float]] = {}
        self.last_popped_key: tuple[float, float] = (INF, INF)

    def insert(self, state: State4D, key: tuple[float, float]) -> None:
        self.entries[state] = key
        heapq.heappush(self.heap, (key, state))

    def remove(self, state: State4D) -> None:
        self.entries.pop(state, None)

    def pop(self) -> tuple[State4D, tuple[float, float]]:
        while self.heap:
            key, state = heapq.heappop(self.heap)
            if self.entries.get(state) == key:
                self.entries.pop(state, None)
                self.last_popped_key = key
                return state, key
        self.last_popped_key = (INF, INF)
        return VIRTUAL_GOAL, (INF, INF)

    def top_key(self) -> tuple[float, float]:
        while self.heap:
            key, state = self.heap[0]
            if self.entries.get(state) == key:
                return key
            heapq.heappop(self.heap)
        return INF, INF

    def size(self) -> int:
        return len(self.entries)

    def clear(self) -> None:
        self.heap.clear()
        self.entries.clear()


class DStarLitePlanner:
    """D* Lite on a finite time-expanded 4D risk graph.

    The planner follows the D* Lite primitives: reverse search from the goal,
    g/rhs consistency, UpdateVertex, ComputeShortestPath, moving start, and
    key modifier km for online replanning.
    """

    def __init__(self, graph: TimeExpandedGraph) -> None:
        self.graph = graph
        self.g: dict[State4D, float] = {}
        self.rhs: dict[State4D, float] = {}
        self.U = PriorityQueue()
        self.s_start: State4D | None = None
        self.s_goal: State4D = VIRTUAL_GOAL
        self.s_last: State4D | None = None
        self.km = 0.0
        self.nodes_expanded = 0
        self.last_compute_nodes_expanded = 0
        self.last_compute_elapsed_ms = 0.0
        self.start_updates = 0
        self.replan_events: list[dict[str, Any]] = []

    def initialize(self, s_start: State4D, s_goal: State4D = VIRTUAL_GOAL) -> DStarLiteResult:
        start = time.perf_counter()
        self.s_start = s_start
        self.s_goal = s_goal
        self.s_last = s_start
        self.km = 0.0
        self.g.clear()
        self.rhs.clear()
        self.U.clear()
        self.rhs[self.s_goal] = 0.0
        self.U.insert(self.s_goal, self.calculate_key(self.s_goal))
        self.compute_shortest_path()
        path = self.extract_path()
        return DStarLiteResult(
            path=path,
            success=bool(path),
            nodes_expanded=self.nodes_expanded,
            elapsed_ms=(time.perf_counter() - start) * 1000.0,
            km_final=self.km,
            start_updates=self.start_updates,
            replan_events=list(self.replan_events),
            reason="" if path else "initial D* Lite search failed",
        )

    def calculate_key(self, state: State4D) -> tuple[float, float]:
        value = min(self._g(state), self._rhs(state))
        assert self.s_start is not None
        return value + self.graph.heuristic(self.s_start, state) + self.km, value

    def update_vertex(self, state: State4D) -> None:
        if state != self.s_goal:
            best = INF
            for succ in self.graph.successors(state):
                cost = self.graph.edge_cost(state, succ)
                if not math.isinf(cost):
                    best = min(best, cost + self._g(succ))
            self.rhs[state] = best
        self.U.remove(state)
        if self._g(state) != self._rhs(state):
            self.U.insert(state, self.calculate_key(state))

    def compute_shortest_path(self) -> None:
        assert self.s_start is not None
        before_nodes = self.nodes_expanded
        start = time.perf_counter()
        while self.U.top_key() < self.calculate_key(self.s_start) or self._rhs(self.s_start) != self._g(self.s_start):
            u, k_old = self.U.pop()
            if k_old == (INF, INF):
                break
            k_new = self.calculate_key(u)
            if k_old < k_new:
                self.U.insert(u, k_new)
            elif self._g(u) > self._rhs(u):
                self.g[u] = self._rhs(u)
                for pred in self.graph.predecessors(u):
                    self.update_vertex(pred)
            else:
                self.g[u] = INF
                self.update_vertex(u)
                for pred in self.graph.predecessors(u):
                    self.update_vertex(pred)
            self.nodes_expanded += 1
        self.last_compute_nodes_expanded = self.nodes_expanded - before_nodes
        self.last_compute_elapsed_ms = (time.perf_counter() - start) * 1000.0

    def move_start(self, new_start: State4D) -> None:
        if self.s_start is None:
            raise RuntimeError("DStarLitePlanner.initialize() must be called before move_start().")
        old_start = self.s_start
        self.s_start = new_start
        self.km += self.graph.heuristic(self.s_last or old_start, self.s_start)
        self.s_last = self.s_start
        self.start_updates += 1

    def update_risk_field(self, new_risk_field: Any, changed_voxels: np.ndarray) -> DStarLiteResult:
        if self.s_start is None:
            raise RuntimeError("DStarLitePlanner.initialize() must be called before update_risk_field().")
        start = time.perf_counter()
        raw_changed = self.graph.risk_field.raw_changed_voxels(new_risk_field)
        significant = changed_voxels if changed_voxels is not None else self.graph.risk_field.significant_changed_voxels(new_risk_field)
        affected_edges = self.graph.map_changed_voxels_to_edges(significant)
        self.graph.set_risk_field(new_risk_field)
        affected_vertices: set[State4D] = set()
        edge_updates = 0
        for u, v in affected_edges:
            old = self.graph.previous_edge_cost(u, v)
            new = self.graph.edge_cost(u, v)
            if old is None or math.isinf(old) != math.isinf(new) or abs(old - new) > self.graph.config.edge_change_eps:
                affected_vertices.add(u)
                edge_updates += 1
        for vertex in affected_vertices:
            self.update_vertex(vertex)
        self.compute_shortest_path()
        path = self.extract_path()
        elapsed = (time.perf_counter() - start) * 1000.0
        event = {
            "algorithm": "strict_dstar_lite_online_repair",
            "reverse_search_from_goal": True,
            "moving_start_enabled": True,
            "km_enabled": True,
            "km_final": round(float(self.km), 6),
            "start_updates": int(self.start_updates),
            "raw_changed_voxels": int(np.sum(raw_changed)),
            "raw_changed_voxel_ratio": round(float(np.mean(raw_changed)), 6),
            "significant_changed_voxels": int(np.sum(significant)),
            "significant_changed_voxel_ratio": round(float(np.mean(significant)), 6),
            "affected_edges": int(len(affected_edges)),
            "affected_vertices": int(len(affected_vertices)),
            "edge_updates": int(edge_updates),
            "vertex_updates": int(len(affected_vertices)),
            "queue_size": int(self.U.size()),
            "nodes_expanded": int(self.last_compute_nodes_expanded),
            "elapsed_ms": round(float(elapsed), 3),
            "g_rhs_reused": True,
            "queue_reused": True,
        }
        self.replan_events.append(event)
        return DStarLiteResult(
            path=path,
            success=bool(path),
            nodes_expanded=self.nodes_expanded,
            elapsed_ms=elapsed,
            km_final=self.km,
            start_updates=self.start_updates,
            affected_edges=len(affected_edges),
            affected_vertices=len(affected_vertices),
            edge_updates=edge_updates,
            vertex_updates=len(affected_vertices),
            replan_events=list(self.replan_events),
            reason="" if path else "D* Lite repair failed",
        )

    def extract_path(self, max_steps: int | None = None) -> list[State4D]:
        if self.s_start is None or math.isinf(self._rhs(self.s_start)):
            return []
        max_steps = max_steps or max(8, self.graph.risk_field.t_size * 4)
        path = [self.s_start]
        state = self.s_start
        visited = {state}
        for _ in range(max_steps):
            if state == self.s_goal or self.graph.spatial(state) == self.graph.goal:
                return path
            candidates = self.graph.successors(state)
            if not candidates:
                return []
            next_state = min(candidates, key=lambda succ: self.graph.edge_cost(state, succ) + self._g(succ))
            if next_state == VIRTUAL_GOAL:
                return path
            if math.isinf(self._g(next_state)) or next_state in visited:
                return []
            path.append(next_state)
            visited.add(next_state)
            state = next_state
        return []

    def _g(self, state: State4D) -> float:
        return self.g.get(state, INF)

    def _rhs(self, state: State4D) -> float:
        return self.rhs.get(state, INF)
