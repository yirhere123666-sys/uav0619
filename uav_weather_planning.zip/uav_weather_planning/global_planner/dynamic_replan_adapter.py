from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import numpy as np

from uav_weather_planning.risk import audit_path_risk
from uav_weather_planning.risk_field import RiskField4D
from uav_weather_planning.risk_field.risk_field_4d import SpatialNode, State4D

from .constraints import FlightConstraints
from .dstar_lite import DStarLitePlanner
from .time_dependent_astar import TimeDependentAStar
from .time_expanded_graph import TimeExpandedGraph, TimeExpandedGraphConfig, VIRTUAL_GOAL


@dataclass
class DStarLiteRepairAdapterConfig:
    graph_config: TimeExpandedGraphConfig = field(default_factory=TimeExpandedGraphConfig)
    safety_fallback: bool = True
    simulated_progress_step: int = 2
    fallback_heuristic_weight: float = 4.0


@dataclass
class DStarLiteRepairResult:
    path: list[State4D]
    total_cost: float | None
    nodes_expanded: int
    elapsed_ms: float
    success: bool
    reason: str = ""
    repair_mode: str = "dstar_lite_repair"
    replan_events: list[dict[str, Any]] = field(default_factory=list)
    reverse_search_from_goal: bool = True
    moving_start_enabled: bool = True
    km_enabled: bool = True
    km_final: float = 0.0
    start_updates: int = 0
    g_rhs_reused: bool = True
    queue_reused: bool = True
    affected_edges: int = 0
    affected_nodes: int = 0
    affected_vertices: int = 0
    edge_updates: int = 0
    vertex_updates: int = 0
    raw_changed_voxel_ratio: float | None = None
    significant_changed_voxel_ratio: float | None = None
    fallback_used: bool = False
    fallback_reason: str = ""
    path_expected_risk: float | None = None
    path_cvar: float | None = None
    max_segment_cvar: float | None = None
    initial_nodes_expanded: int = 0
    repair_nodes_expanded: int = 0
    initial_elapsed_ms: float = 0.0
    repair_elapsed_ms: float = 0.0


class DStarLiteRepairAdapter:
    """Adapter that exposes strict D* Lite as benchmark/replay repair mode."""

    def __init__(
        self,
        risk_field: RiskField4D,
        constraints: FlightConstraints | None = None,
        config: DStarLiteRepairAdapterConfig | None = None,
    ) -> None:
        self.risk_field = risk_field
        self.constraints = constraints or FlightConstraints()
        self.config = config or DStarLiteRepairAdapterConfig()
        self.graph: TimeExpandedGraph | None = None
        self.planner: DStarLitePlanner | None = None
        self.start: SpatialNode | None = None
        self.goal: SpatialNode | None = None
        self.initial_path: list[State4D] = []
        self.initial_nodes_expanded = 0
        self.initial_elapsed_ms = 0.0

    def plan_initial(self, start: SpatialNode, goal: SpatialNode, start_time: int = 0) -> DStarLiteRepairResult:
        self.start = start
        self.goal = goal
        start_state = (start_time, start[0], start[1], start[2])
        self.graph = TimeExpandedGraph(
            self.risk_field,
            goal=goal,
            constraints=self.constraints,
            config=self.config.graph_config,
            start_time=start_time,
        )
        self.planner = DStarLitePlanner(self.graph)
        result = self.planner.initialize(start_state, VIRTUAL_GOAL)
        self.initial_path = result.path
        self.initial_nodes_expanded = result.nodes_expanded
        self.initial_elapsed_ms = result.elapsed_ms
        return self._make_result(result.path, result.success, result, self.risk_field, repair_nodes=result.nodes_expanded)

    def move_start(self, current_state: State4D) -> None:
        self._require_planner().move_start(current_state)

    def repair_after_update(
        self,
        updated_risk_field: RiskField4D,
        changed_voxels: np.ndarray,
        current_state: State4D | None = None,
        goal: SpatialNode | None = None,
    ) -> DStarLiteRepairResult:
        planner = self._require_planner()
        goal = goal or self.goal
        if goal is None:
            raise RuntimeError("DStarLiteRepairAdapter.plan_initial() must be called before repair_after_update().")
        if current_state is None:
            current_state = self._simulated_current_state()
        if planner.s_start != current_state:
            planner.move_start(current_state)
        before_nodes = planner.nodes_expanded
        before_events = len(planner.replan_events)
        result = planner.update_risk_field(updated_risk_field, changed_voxels)
        path = result.path
        fallback_used = False
        fallback_reason = ""
        if self.config.safety_fallback and self._needs_fallback(path, updated_risk_field):
            fallback = TimeDependentAStar(
                updated_risk_field,
                constraints=self.constraints,
                heuristic_weight=self.config.fallback_heuristic_weight,
            ).plan(current_state, goal, start_time=current_state[0])
            path = fallback.path
            fallback_used = True
            fallback_reason = "D* Lite repair safety audit failed; fallback to full time-dependent A*"
            result.nodes_expanded += fallback.nodes_expanded
            result.elapsed_ms += fallback.elapsed_ms
            result.success = fallback.success
            result.reason = "" if fallback.success else fallback_reason
        if path and current_state in path:
            repaired_path = path[path.index(current_state) :]
        else:
            repaired_path = path
        full_path = self._merge_prefix(current_state, repaired_path)
        if self.config.safety_fallback and self._needs_fallback(full_path, updated_risk_field):
            assert self.start is not None
            full_restart = TimeDependentAStar(
                updated_risk_field,
                constraints=self.constraints,
                heuristic_weight=self.config.fallback_heuristic_weight,
            ).plan(self.start, goal, start_time=0)
            full_path = full_restart.path
            fallback_used = True
            fallback_reason = "D* Lite repaired display path failed full-path audit; fallback to full time-dependent A* from mission start"
            result.nodes_expanded += full_restart.nodes_expanded
            result.elapsed_ms += full_restart.elapsed_ms
            result.success = full_restart.success
            result.reason = "" if full_restart.success else fallback_reason
        event = result.replan_events[-1] if len(result.replan_events) > before_events else {}
        out = self._make_result(
            full_path,
            bool(full_path) and result.success,
            result,
            updated_risk_field,
            fallback_used=fallback_used,
            fallback_reason=fallback_reason,
            repair_nodes=result.nodes_expanded - before_nodes,
            update_event=event,
        )
        self.risk_field = updated_risk_field
        return out

    def _require_planner(self) -> DStarLitePlanner:
        if self.planner is None:
            raise RuntimeError("DStarLiteRepairAdapter.plan_initial() must be called first.")
        return self.planner

    def _simulated_current_state(self) -> State4D:
        if not self.initial_path:
            assert self.start is not None
            return (0, self.start[0], self.start[1], self.start[2])
        idx = min(max(0, self.config.simulated_progress_step), len(self.initial_path) - 1)
        return self.initial_path[idx]

    def _merge_prefix(self, current_state: State4D, repaired_path: list[State4D]) -> list[State4D]:
        if not self.initial_path:
            return repaired_path
        if current_state in self.initial_path:
            prefix = self.initial_path[: self.initial_path.index(current_state) + 1]
            if repaired_path and repaired_path[0] == current_state:
                return prefix[:-1] + repaired_path
            return prefix + repaired_path
        return repaired_path

    def _needs_fallback(self, path: list[State4D], risk_field: RiskField4D) -> bool:
        audit = self.constraints.audit_path(path, risk_field)
        return (
            not path
            or int(audit.get("constraint_violations", 0) or 0) > 0
            or int(audit.get("airspace_violations", 0) or 0) > 0
            or any(risk_field.is_no_fly((risk_field.clamp_time(state[0]), state[1], state[2], state[3])) for state in path)
        )

    def _make_result(
        self,
        path: list[State4D],
        success: bool,
        result: Any,
        risk_field: RiskField4D,
        *,
        fallback_used: bool = False,
        fallback_reason: str = "",
        repair_nodes: int = 0,
        update_event: dict[str, Any] | None = None,
    ) -> DStarLiteRepairResult:
        update_event = update_event or {}
        risk = audit_path_risk(path, risk_field)
        return DStarLiteRepairResult(
            path=path,
            total_cost=risk.get("path_total_cost_sum"),
            nodes_expanded=int(result.nodes_expanded),
            elapsed_ms=float(result.elapsed_ms),
            success=bool(success),
            reason=getattr(result, "reason", ""),
            replan_events=list(getattr(result, "replan_events", [])),
            km_final=float(getattr(result, "km_final", 0.0)),
            start_updates=int(getattr(result, "start_updates", 0)),
            affected_edges=int(update_event.get("affected_edges", getattr(result, "affected_edges", 0)) or 0),
            affected_nodes=int(update_event.get("affected_vertices", getattr(result, "affected_vertices", 0)) or 0),
            affected_vertices=int(update_event.get("affected_vertices", getattr(result, "affected_vertices", 0)) or 0),
            edge_updates=int(update_event.get("edge_updates", getattr(result, "edge_updates", 0)) or 0),
            vertex_updates=int(update_event.get("vertex_updates", getattr(result, "vertex_updates", 0)) or 0),
            raw_changed_voxel_ratio=update_event.get("raw_changed_voxel_ratio"),
            significant_changed_voxel_ratio=update_event.get("significant_changed_voxel_ratio"),
            fallback_used=fallback_used,
            fallback_reason=fallback_reason,
            path_expected_risk=risk.get("path_expected_risk_sum"),
            path_cvar=risk.get("path_cvar_sum"),
            max_segment_cvar=risk.get("max_segment_cvar"),
            initial_nodes_expanded=int(self.initial_nodes_expanded),
            repair_nodes_expanded=int(repair_nodes),
            initial_elapsed_ms=round(float(self.initial_elapsed_ms), 3),
            repair_elapsed_ms=round(float(getattr(result, "elapsed_ms", 0.0)), 3),
        )
