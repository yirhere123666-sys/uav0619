from __future__ import annotations

from dataclasses import dataclass, field
import heapq
import math
import time
from typing import Any

import numpy as np

from uav_weather_planning.risk_field import RiskField4D
from uav_weather_planning.risk_field.risk_field_4d import SpatialNode, State4D

from .constraints import FlightConstraints
from .energy_model import MultirotorEnergyConfig
from .time_dependent_astar import TimeDependentAStar


INF = float("inf")
VIRTUAL_GOAL_4D: State4D = (-1, -1, -1, -1)


@dataclass(frozen=True)
class DStarLite4DConfig:
    allow_wait: bool = True
    use_cvar: bool = True
    vertical_weight: float = 1.35
    risk_weight: float = 2.3
    time_weight: float = 0.18
    cvar_weight: float = 1.1
    energy_weight: float = 0.25
    safety_weight: float = 0.18
    heuristic_weight: float = 10.0
    total_cost_change_threshold: float = 0.3
    convection_change_threshold: float = 0.15
    cvar_change_threshold: float = 0.2
    violation_probability_change_threshold: float = 0.1
    max_compute_iterations: int = 1_500_000
    update_changed_state: bool = True
    update_changed_predecessors: bool = True
    update_changed_successors: bool = False
    update_second_order_predecessors: bool = False
    skip_unseen_states_for_risk_increase: bool = True
    min_frontier_update_vertices: int = 1
    max_frontier_update_vertices: int = 4
    search_bounds: dict[str, tuple[int, int]] | None = None
    max_repair_horizon_steps: int | None = None


@dataclass
class DStarLite4DResult:
    path: list[State4D]
    success: bool
    nodes_expanded: int
    elapsed_ms: float
    total_cost: float
    reason: str = ""
    planner_name: str = "dstar_lite_4d"
    repair_mode: str = "incremental_dstar_lite"
    g_rhs_reused: bool = True
    queue_reused: bool = True
    incremental_reuse_valid: bool = True
    reinitialize_reason: str = ""
    km_final: float = 0.0
    start_updates: int = 0
    changed_voxel_count: int = 0
    raw_changed_voxel_count: int = 0
    raw_changed_voxel_ratio: float = 0.0
    significant_changed_voxel_ratio: float = 0.0
    affected_state_count: int = 0
    update_vertex_count: int = 0
    compute_shortest_path_iterations: int = 0
    nodes_expanded_incremental: int = 0
    elapsed_ms_incremental: float = 0.0
    edge_cache_invalidated: int = 0
    open_queue_size: int = 0
    replan_events: list[dict[str, Any]] = field(default_factory=list)


class _PriorityQueue:
    def __init__(self) -> None:
        self.heap: list[tuple[tuple[float, float], State4D]] = []
        self.keys: dict[State4D, tuple[float, float]] = {}

    def insert(self, state: State4D, key: tuple[float, float]) -> None:
        self.keys[state] = key
        heapq.heappush(self.heap, (key, state))

    def remove(self, state: State4D) -> None:
        self.keys.pop(state, None)

    def pop(self) -> tuple[State4D, tuple[float, float]]:
        while self.heap:
            key, state = heapq.heappop(self.heap)
            if self.keys.get(state) == key:
                self.keys.pop(state, None)
                return state, key
        return VIRTUAL_GOAL_4D, (INF, INF)

    def top_key(self) -> tuple[float, float]:
        while self.heap:
            key, state = self.heap[0]
            if self.keys.get(state) == key:
                return key
            heapq.heappop(self.heap)
        return INF, INF

    def clear(self) -> None:
        self.heap.clear()
        self.keys.clear()

    def __len__(self) -> int:
        return len(self.keys)


class DStarLite4DPlanner:
    """D* Lite on the project 4D time-expanded risk graph.

    State4D is (time_index, height_index, y_index, x_index). The planner
    performs reverse search from a virtual goal, keeps g/rhs/open_queue
    across risk updates, and uses TimeDependentAStar.edge_cost as its edge
    cost kernel so the A* baseline and D* Lite repair are cost-compatible.
    """

    def __init__(
        self,
        risk_field: RiskField4D | None = None,
        constraints: FlightConstraints | None = None,
        config: DStarLite4DConfig | None = None,
        energy_config: MultirotorEnergyConfig | None = None,
    ) -> None:
        self.risk_field = risk_field
        self.constraints = constraints or FlightConstraints()
        self.config = config or DStarLite4DConfig()
        self.energy_config = energy_config
        self.astar_cost: TimeDependentAStar | None = None
        self.g: dict[State4D, float] = {}
        self.rhs: dict[State4D, float] = {}
        self.open_queue = _PriorityQueue()
        self.km = 0.0
        self.current_start: State4D | None = None
        self.last_start: State4D | None = None
        self.goal: SpatialNode | None = None
        self.goal_states: set[State4D] = set()
        self.virtual_goal: State4D = VIRTUAL_GOAL_4D
        self.max_time = 0
        self.nodes_expanded = 0
        self.last_compute_iterations = 0
        self.last_compute_elapsed_ms = 0.0
        self.start_updates = 0
        self.update_vertex_count = 0
        self.last_update_vertex_count = 0
        self.last_affected_state_count = 0
        self.last_changed_voxel_count = 0
        self.last_raw_changed_voxel_count = 0
        self.last_raw_changed_voxel_ratio = 0.0
        self.last_significant_changed_voxel_ratio = 0.0
        self.last_edge_cache_invalidated = 0
        self.incremental_reuse_valid = True
        self.reinitialize_reason = ""
        self.replan_events: list[dict[str, Any]] = []
        self._edge_cost_cache: dict[tuple[State4D, State4D], float] = {}
        self._successor_cache: dict[State4D, list[State4D]] = {}
        self._predecessor_cache: dict[State4D, list[State4D]] = {}

    def initialize(
        self,
        start: SpatialNode | State4D,
        goal: SpatialNode | State4D,
        risk_field: RiskField4D | None = None,
    ) -> DStarLite4DResult:
        if risk_field is not None:
            self.risk_field = risk_field
        if self.risk_field is None:
            raise RuntimeError("risk_field is required for DStarLite4DPlanner.initialize().")
        start_clock = time.perf_counter()
        self.current_start = self._normalize_start(start)
        self.last_start = self.current_start
        self.goal = self._normalize_goal(goal)
        full_max_time = self.risk_field.t_size - 1
        if self.config.max_repair_horizon_steps is None:
            self.max_time = full_max_time
        else:
            self.max_time = min(full_max_time, self.current_start[0] + int(self.config.max_repair_horizon_steps))
        self.km = 0.0
        self.nodes_expanded = 0
        self.start_updates = 0
        self.g.clear()
        self.rhs.clear()
        self.open_queue.clear()
        self.replan_events.clear()
        self._clear_graph_caches()
        self.astar_cost = self._make_astar_cost(self.risk_field)
        self.goal_states = self._build_goal_states()
        self.rhs[self.virtual_goal] = 0.0
        self.open_queue.insert(self.virtual_goal, self.calculate_key(self.virtual_goal))
        self.compute_shortest_path()
        path = self.extract_path(self.current_start)
        elapsed = (time.perf_counter() - start_clock) * 1000.0
        return self._make_result(path, elapsed, reason="" if path else "initial D* Lite 4D search failed")

    def initialize_from_path(
        self,
        path: list[State4D],
        goal: SpatialNode | State4D,
        risk_field: RiskField4D | None = None,
    ) -> DStarLite4DResult:
        """Warm-start g/rhs/open state from an existing time-expanded path.

        This is used by large 10 km paper experiments where a complete
        reverse initialization over the full 4D graph is unnecessarily
        expensive. The subsequent risk update still calls UpdateVertex and
        ComputeShortestPath on affected vertices, preserving the D* Lite/LPA*
        repair mechanics while making the demonstration tractable.
        """

        if risk_field is not None:
            self.risk_field = risk_field
        if self.risk_field is None:
            raise RuntimeError("risk_field is required for DStarLite4DPlanner.initialize_from_path().")
        if not path:
            raise ValueError("path must contain at least one State4D")
        start_clock = time.perf_counter()
        self.current_start = path[0]
        self.last_start = self.current_start
        self.goal = self._normalize_goal(goal)
        full_max_time = self.risk_field.t_size - 1
        if self.config.max_repair_horizon_steps is None:
            self.max_time = full_max_time
        else:
            self.max_time = min(full_max_time, self.current_start[0] + int(self.config.max_repair_horizon_steps))
        self.km = 0.0
        self.nodes_expanded = 0
        self.start_updates = 0
        self.g.clear()
        self.rhs.clear()
        self.open_queue.clear()
        self.replan_events.clear()
        self._clear_graph_caches()
        self.astar_cost = self._make_astar_cost(self.risk_field)
        self.goal_states = self._build_goal_states()
        self.g[self.virtual_goal] = 0.0
        self.rhs[self.virtual_goal] = 0.0
        usable_path = [state for state in path if state[0] <= self.max_time and self.risk_field.in_bounds(state)]
        if not usable_path:
            usable_path = [path[0]]
        if self._spatial(usable_path[-1]) != self.goal:
            goal_candidates = sorted(self.goal_states)
            if goal_candidates:
                usable_path = usable_path + [goal_candidates[0]]
        next_state = self.virtual_goal
        next_cost_to_go = 0.0
        for state in reversed(usable_path):
            if state == next_state:
                continue
            edge = self.edge_cost(state, next_state)
            cost_to_go = edge + next_cost_to_go if not math.isinf(edge) else INF
            self.g[state] = cost_to_go
            self.rhs[state] = cost_to_go
            next_state = state
            next_cost_to_go = cost_to_go
        self.last_compute_iterations = 0
        self.last_compute_elapsed_ms = 0.0
        elapsed = (time.perf_counter() - start_clock) * 1000.0
        result_path = self.extract_path(self.current_start) or usable_path
        result = self._make_result(result_path, elapsed, reason="" if result_path else "path warm-start failed")
        result.replan_events.append(
            {
                "planner_name": "dstar_lite_4d",
                "initialization": "warm_start_from_initial_path",
                "seeded_state_count": len(usable_path),
                "g_rhs_reused": True,
                "queue_reused": True,
            }
        )
        return result

    def calculate_key(self, state: State4D) -> tuple[float, float]:
        if self.current_start is None:
            raise RuntimeError("DStarLite4DPlanner.initialize() must be called first.")
        value = min(self._g(state), self._rhs(state))
        return value + self.config.heuristic_weight * self.heuristic(self.current_start, state) + self.km, value

    def heuristic(self, a: State4D, b: State4D) -> float:
        if b == self.virtual_goal:
            if self.goal is None:
                return 0.0
            _, za, ya, xa = a
            gz, gy, gx = self.goal
            return math.sqrt((gx - xa) ** 2 + (gy - ya) ** 2 + self.config.vertical_weight * (gz - za) ** 2)
        if a == self.virtual_goal:
            return 0.0
        _, za, ya, xa = a
        _, zb, yb, xb = b
        return math.sqrt((xb - xa) ** 2 + (yb - ya) ** 2 + self.config.vertical_weight * (zb - za) ** 2)

    def successors(self, state: State4D) -> list[State4D]:
        cached = self._successor_cache.get(state)
        if cached is not None:
            return cached
        if self.risk_field is None:
            return []
        if state == self.virtual_goal or state[0] >= self.max_time:
            self._successor_cache[state] = []
            return []
        if self._spatial(state) == self.goal:
            self._successor_cache[state] = [self.virtual_goal]
            return [self.virtual_goal]

        t, z, y, x = state
        nt = t + 1
        moves: list[tuple[int, int, int]] = []
        for dz in (-1, 0, 1):
            for dy in (-1, 0, 1):
                for dx in (-1, 0, 1):
                    if dz == 0 and dy == 0 and dx == 0:
                        continue
                    moves.append((dz, dy, dx))
        if self.config.allow_wait:
            moves.append((0, 0, 0))
        out: list[State4D] = []
        for dz, dy, dx in moves:
            candidate = (nt, z + dz, y + dy, x + dx)
            if self.risk_field.in_bounds(candidate) and self._within_search_bounds(candidate):
                out.append(candidate)
        self._successor_cache[state] = out
        return out

    def predecessors(self, state: State4D) -> list[State4D]:
        cached = self._predecessor_cache.get(state)
        if cached is not None:
            return cached
        if self.risk_field is None or self.current_start is None:
            return []
        if state == self.virtual_goal:
            out = sorted(self.goal_states)
            self._predecessor_cache[state] = out
            return out
        t, z, y, x = state
        if t <= self.current_start[0]:
            self._predecessor_cache[state] = []
            return []
        out: list[State4D] = []
        for dz in (-1, 0, 1):
            for dy in (-1, 0, 1):
                for dx in (-1, 0, 1):
                    predecessor = (t - 1, z + dz, y + dy, x + dx)
                    if self.risk_field.in_bounds(predecessor) and self._within_search_bounds(predecessor):
                        out.append(predecessor)
        if self.config.allow_wait:
            predecessor = (t - 1, z, y, x)
            if self.risk_field.in_bounds(predecessor) and self._within_search_bounds(predecessor) and predecessor not in out:
                out.append(predecessor)
        self._predecessor_cache[state] = out
        return out

    def edge_cost(self, a: State4D, b: State4D) -> float:
        key = (a, b)
        cached = self._edge_cost_cache.get(key)
        if cached is not None:
            return cached
        if self.risk_field is None or self.astar_cost is None:
            return INF
        if b == self.virtual_goal:
            value = 0.0 if self._spatial(a) == self.goal and not self.risk_field.is_no_fly(a) else INF
            self._edge_cost_cache[key] = value
            return value
        if a == self.virtual_goal:
            self._edge_cost_cache[key] = INF
            return INF
        if not self.risk_field.in_bounds(a) or not self.risk_field.in_bounds(b):
            self._edge_cost_cache[key] = INF
            return INF
        if self.risk_field.is_no_fly(a):
            self._edge_cost_cache[key] = INF
            return INF
        if not self.constraints.is_feasible(a, b, self.risk_field, previous=None):
            self._edge_cost_cache[key] = INF
            return INF
        value = self.astar_cost.edge_cost(a, b, previous=None)
        self._edge_cost_cache[key] = value
        return value

    def update_vertex(self, state: State4D) -> None:
        self.update_vertex_count += 1
        self.last_update_vertex_count += 1
        if state != self.virtual_goal:
            best = INF
            for succ in self.successors(state):
                cost = self.edge_cost(state, succ)
                if not math.isinf(cost):
                    best = min(best, cost + self._g(succ))
            self.rhs[state] = best
        self.open_queue.remove(state)
        if self._g(state) != self._rhs(state):
            self.open_queue.insert(state, self.calculate_key(state))

    def compute_shortest_path(self) -> None:
        if self.current_start is None:
            raise RuntimeError("DStarLite4DPlanner.initialize() must be called first.")
        start_clock = time.perf_counter()
        before_nodes = self.nodes_expanded
        iterations = 0
        while (
            self.open_queue.top_key() < self.calculate_key(self.current_start)
            or self._rhs(self.current_start) != self._g(self.current_start)
        ):
            u, old_key = self.open_queue.pop()
            if old_key == (INF, INF):
                break
            new_key = self.calculate_key(u)
            if old_key < new_key:
                self.open_queue.insert(u, new_key)
            elif self._g(u) > self._rhs(u):
                self.g[u] = self._rhs(u)
                for pred in self.predecessors(u):
                    self.update_vertex(pred)
            else:
                self.g[u] = INF
                self.update_vertex(u)
                for pred in self.predecessors(u):
                    self.update_vertex(pred)
            iterations += 1
            self.nodes_expanded += 1
            if iterations >= self.config.max_compute_iterations:
                break
        self.last_compute_iterations = self.nodes_expanded - before_nodes
        self.last_compute_elapsed_ms = (time.perf_counter() - start_clock) * 1000.0

    def extract_path(self, start: State4D | None = None) -> list[State4D]:
        if self.current_start is None:
            return []
        current = start or self.current_start
        if math.isinf(self._rhs(current)) and math.isinf(self._g(current)):
            return []
        path = [current]
        visited = {current}
        guard = 0
        max_steps = max(8, (self.risk_field.t_size if self.risk_field is not None else 0) * 3)
        while guard < max_steps:
            guard += 1
            if self._spatial(current) == self.goal:
                return path
            candidates = self.successors(current)
            best_state = None
            best_value = INF
            for succ in candidates:
                cost = self.edge_cost(current, succ)
                value = cost + self._g(succ)
                if value < best_value:
                    best_value = value
                    best_state = succ
            if best_state is None or math.isinf(best_value):
                return []
            if best_state == self.virtual_goal:
                return path
            if best_state in visited:
                return []
            path.append(best_state)
            visited.add(best_state)
            current = best_state
        return []

    def update_start(self, new_start: State4D) -> None:
        if self.current_start is None:
            raise RuntimeError("DStarLite4DPlanner.initialize() must be called first.")
        old_start = self.current_start
        self.current_start = new_start
        self.km += self.heuristic(self.last_start or old_start, new_start)
        self.last_start = new_start
        self.start_updates += 1
        self.goal_states = self._build_goal_states()
        self._predecessor_cache.pop(self.virtual_goal, None)

    def update_risk_field(self, new_risk_field: RiskField4D, changed_voxels: np.ndarray | None = None) -> dict[str, Any]:
        if self.risk_field is None or self.current_start is None or self.goal is None:
            raise RuntimeError("DStarLite4DPlanner.initialize() must be called before update_risk_field().")
        if self.risk_field.shape != new_risk_field.shape or not self._coords_compatible(self.risk_field, new_risk_field):
            reason = "risk field shape or coordinate axis changed"
            self.incremental_reuse_valid = False
            self.reinitialize_reason = reason
            start = self.current_start
            goal = self.goal
            self.initialize(start, goal, new_risk_field)
            event = {
                "incremental_reuse_valid": False,
                "reinitialize_reason": reason,
                "g_rhs_reused": False,
                "queue_reused": False,
            }
            self.replan_events.append(event)
            return event

        significant = self._normalize_changed_voxels(changed_voxels)
        explicit_changed_voxels = significant is not None
        if significant is None:
            significant = self._detect_significant_changes(self.risk_field, new_risk_field)
        raw_changed = significant if explicit_changed_voxels else self.risk_field.raw_changed_voxels(new_risk_field)
        changed_indices = np.argwhere(significant)
        self.last_raw_changed_voxel_count = int(np.sum(raw_changed))
        self.last_changed_voxel_count = int(len(changed_indices))
        self.last_raw_changed_voxel_ratio = round(float(np.mean(raw_changed)), 6)
        self.last_significant_changed_voxel_ratio = round(float(np.mean(significant)), 6)
        risk_increase_only = self._is_risk_increase_only(self.risk_field, new_risk_field, significant)
        affected = self._affected_states_from_changes(changed_indices)
        affected_before_frontier_filter = len(affected)
        if self.config.skip_unseen_states_for_risk_increase and risk_increase_only:
            affected = self._filter_to_seen_frontier(affected)
        self.last_update_vertex_count = 0
        self.risk_field = new_risk_field
        if self.astar_cost is None:
            self.astar_cost = self._make_astar_cost(new_risk_field)
        else:
            self.astar_cost.risk_field = new_risk_field
        self.goal_states = self._build_goal_states()
        self._predecessor_cache.pop(self.virtual_goal, None)
        self.last_edge_cache_invalidated = self._invalidate_edge_cost_cache(changed_indices, affected)
        self.last_affected_state_count = len(affected)
        for state in affected:
            self.update_vertex(state)
        event = {
            "planner_name": "dstar_lite_4d",
            "repair_mode": "incremental_dstar_lite",
            "incremental_reuse_valid": True,
            "g_rhs_reused": True,
            "queue_reused": True,
            "raw_changed_voxels": self.last_raw_changed_voxel_count,
            "raw_changed_voxel_ratio": self.last_raw_changed_voxel_ratio,
            "raw_changed_source": "caller_provided_changed_voxels" if explicit_changed_voxels else "full_field_diff",
            "changed_voxel_count": self.last_changed_voxel_count,
            "significant_changed_voxels": self.last_changed_voxel_count,
            "significant_changed_voxel_ratio": self.last_significant_changed_voxel_ratio,
            "affected_state_count": self.last_affected_state_count,
            "affected_state_count_before_frontier_filter": affected_before_frontier_filter,
            "update_vertex_count": self.last_update_vertex_count,
            "risk_increase_only": bool(risk_increase_only),
            "frontier_filter_enabled": bool(self.config.skip_unseen_states_for_risk_increase and risk_increase_only),
            "edge_cache_invalidated": self.last_edge_cache_invalidated,
            "open_queue_size": len(self.open_queue),
            "km_final": round(float(self.km), 6),
            "start_updates": self.start_updates,
            "changed_detection": {
                "no_fly_mask": "boolean change",
                "total_cost_delta": self.config.total_cost_change_threshold,
                "convection_risk_delta": self.config.convection_change_threshold,
                "cvar_cost_delta": self.config.cvar_change_threshold,
                "violation_probability_delta": self.config.violation_probability_change_threshold,
            },
        }
        self.replan_events.append(event)
        return event

    def plan_or_repair(
        self,
        current_start: State4D,
        new_risk_field: RiskField4D | None = None,
        changed_voxels: np.ndarray | None = None,
    ) -> DStarLite4DResult:
        start_clock = time.perf_counter()
        if self.current_start != current_start:
            self.update_start(current_start)
        if new_risk_field is not None:
            self.update_risk_field(new_risk_field, changed_voxels=changed_voxels)
        before_nodes = self.nodes_expanded
        before_updates = self.update_vertex_count
        self.compute_shortest_path()
        path = self.extract_path(current_start)
        elapsed = (time.perf_counter() - start_clock) * 1000.0
        result = self._make_result(path, elapsed, reason="" if path else "D* Lite 4D repair failed")
        result.nodes_expanded_incremental = self.nodes_expanded - before_nodes
        result.compute_shortest_path_iterations = self.last_compute_iterations
        result.update_vertex_count = self.update_vertex_count - before_updates + self.last_update_vertex_count
        result.elapsed_ms_incremental = self.last_compute_elapsed_ms
        return result

    def _make_result(self, path: list[State4D], elapsed_ms: float, *, reason: str) -> DStarLite4DResult:
        return DStarLite4DResult(
            path=path,
            success=bool(path),
            nodes_expanded=self.nodes_expanded,
            elapsed_ms=elapsed_ms,
            total_cost=self._path_field_cost(path),
            reason=reason,
            g_rhs_reused=self.incremental_reuse_valid,
            queue_reused=self.incremental_reuse_valid,
            incremental_reuse_valid=self.incremental_reuse_valid,
            reinitialize_reason=self.reinitialize_reason,
            km_final=self.km,
            start_updates=self.start_updates,
            changed_voxel_count=self.last_changed_voxel_count,
            raw_changed_voxel_count=self.last_raw_changed_voxel_count,
            raw_changed_voxel_ratio=self.last_raw_changed_voxel_ratio,
            significant_changed_voxel_ratio=self.last_significant_changed_voxel_ratio,
            affected_state_count=self.last_affected_state_count,
            update_vertex_count=self.last_update_vertex_count,
            compute_shortest_path_iterations=self.last_compute_iterations,
            nodes_expanded_incremental=self.last_compute_iterations,
            elapsed_ms_incremental=self.last_compute_elapsed_ms,
            edge_cache_invalidated=self.last_edge_cache_invalidated,
            open_queue_size=len(self.open_queue),
            replan_events=list(self.replan_events),
        )

    def _make_astar_cost(self, risk_field: RiskField4D) -> TimeDependentAStar:
        return TimeDependentAStar(
            risk_field,
            allow_wait=self.config.allow_wait,
            use_cvar=self.config.use_cvar,
            vertical_weight=self.config.vertical_weight,
            risk_weight=self.config.risk_weight,
            time_weight=self.config.time_weight,
            cvar_weight=self.config.cvar_weight,
            energy_weight=self.config.energy_weight,
            safety_weight=self.config.safety_weight,
            heuristic_weight=self.config.heuristic_weight,
            constraints=self.constraints,
            energy_config=self.energy_config,
        )

    def _normalize_start(self, start: SpatialNode | State4D) -> State4D:
        if len(start) == 4:
            return start  # type: ignore[return-value]
        z, y, x = start  # type: ignore[misc]
        return 0, z, y, x

    @staticmethod
    def _normalize_goal(goal: SpatialNode | State4D) -> SpatialNode:
        if len(goal) == 4:
            return goal[1], goal[2], goal[3]  # type: ignore[index]
        return goal  # type: ignore[return-value]

    @staticmethod
    def _spatial(state: State4D) -> SpatialNode:
        return state[1], state[2], state[3]

    def _build_goal_states(self) -> set[State4D]:
        if self.risk_field is None or self.current_start is None or self.goal is None:
            return set()
        gz, gy, gx = self.goal
        _, z, y, x = self.current_start
        min_steps = int(math.ceil(max(abs(gz - z), abs(gy - y), abs(gx - x))))
        earliest = min(self.max_time, self.current_start[0] + min_steps)
        return {
            (t, gz, gy, gx)
            for t in range(earliest, self.max_time + 1)
            if self.risk_field.in_bounds((t, gz, gy, gx))
        }

    def _affected_states_from_changes(self, changed_indices: np.ndarray) -> set[State4D]:
        affected: set[State4D] = set()
        if self.risk_field is None or self.current_start is None:
            return affected
        for raw in changed_indices:
            state = tuple(int(v) for v in raw)  # type: ignore[assignment]
            if not self.risk_field.in_bounds(state):
                continue
            if not self._within_search_bounds(state):
                continue
            if state[0] < self.current_start[0] or state[0] > self.max_time:
                continue
            if self.config.update_changed_state:
                affected.add(state)
            if self.config.update_changed_predecessors:
                affected.update(self.predecessors(state))
            if self.config.update_changed_successors:
                affected.update(self.successors(state))
            if self.config.update_second_order_predecessors:
                for pred in self.predecessors(state):
                    affected.update(self.predecessors(pred))
            if self._spatial(state) == self.goal:
                affected.add(self.virtual_goal)
        return affected

    def _filter_to_seen_frontier(self, affected: set[State4D]) -> set[State4D]:
        if self.current_start is None:
            return affected
        seen = set(self.g) | set(self.rhs) | set(self.open_queue.keys)
        seen.add(self.current_start)
        seen.add(self.virtual_goal)
        filtered = {state for state in affected if state in seen}
        min_vertices = max(0, int(self.config.min_frontier_update_vertices))
        max_vertices = max(min_vertices, int(self.config.max_frontier_update_vertices))
        if len(filtered) >= min_vertices or not affected:
            return set(sorted(filtered, key=lambda state: self.heuristic(self.current_start, state))[:max_vertices])
        needed = min(max_vertices - len(filtered), len(affected))
        nearest = sorted(affected - filtered, key=lambda state: self.heuristic(self.current_start, state))[:needed]
        return filtered | set(nearest)

    @staticmethod
    def _is_risk_increase_only(old: RiskField4D, new: RiskField4D, changed: np.ndarray) -> bool:
        if not np.any(changed):
            return True
        removed_no_fly = np.any(old.no_fly_mask[changed] & ~new.no_fly_mask[changed])
        if removed_no_fly:
            return False
        eps = 1e-9
        cost_decreased = np.any(new.total_cost[changed] < old.total_cost[changed] - eps)
        cvar_decreased = np.any(new.cvar_cost[changed] < old.cvar_cost[changed] - eps)
        expected_decreased = np.any(new.expected_cost[changed] < old.expected_cost[changed] - eps)
        violation_decreased = np.any(new.violation_probability[changed] < old.violation_probability[changed] - eps)
        return not (cost_decreased or cvar_decreased or expected_decreased or violation_decreased)

    def _invalidate_edge_cost_cache(self, changed_indices: np.ndarray, affected: set[State4D]) -> int:
        if not self._edge_cost_cache:
            return 0
        changed_states = {
            tuple(int(value) for value in raw)  # type: ignore[misc]
            for raw in changed_indices
        }
        touched = changed_states
        if not touched:
            return 0
        stale_keys = [
            key
            for key in self._edge_cost_cache
            if key[0] in touched or key[1] in touched
        ]
        for key in stale_keys:
            self._edge_cost_cache.pop(key, None)
        return len(stale_keys)

    def _detect_significant_changes(self, old: RiskField4D, new: RiskField4D) -> np.ndarray:
        total_changed = np.abs(old.total_cost - new.total_cost) > self.config.total_cost_change_threshold
        convection_changed = np.abs(old.convection_risk - new.convection_risk) > self.config.convection_change_threshold
        mask_changed = old.no_fly_mask != new.no_fly_mask
        cvar_changed = np.abs(old.cvar_cost - new.cvar_cost) > self.config.cvar_change_threshold
        violation_changed = (
            np.abs(old.violation_probability - new.violation_probability)
            > self.config.violation_probability_change_threshold
        )
        return total_changed | convection_changed | mask_changed | cvar_changed | violation_changed

    def _normalize_changed_voxels(self, changed_voxels: np.ndarray | None) -> np.ndarray | None:
        if changed_voxels is None:
            return None
        if self.risk_field is None:
            return None
        arr = np.asarray(changed_voxels)
        if arr.dtype == bool:
            if arr.shape == self.risk_field.shape:
                return arr
            if arr.shape == self.risk_field.shape[1:]:
                out = np.zeros(self.risk_field.shape, dtype=bool)
                t = self.current_start[0] if self.current_start is not None else 0
                out[t] = arr
                return out
            raise ValueError(f"changed_voxels shape {arr.shape} does not match risk field shape")
        out = np.zeros(self.risk_field.shape, dtype=bool)
        for raw in arr:
            values = [int(v) for v in raw]
            if len(values) == 3:
                t = self.current_start[0] if self.current_start is not None else 0
                z, y, x = values
            elif len(values) == 4:
                t, z, y, x = values
            else:
                raise ValueError("changed voxel indices must have 3 or 4 columns")
            if self.risk_field.in_bounds((t, z, y, x)):
                out[t, z, y, x] = True
        return out

    @staticmethod
    def _coords_compatible(a: RiskField4D, b: RiskField4D) -> bool:
        for name in ("time", "height", "y", "x"):
            left = np.asarray(a.coords.get(name, []))
            right = np.asarray(b.coords.get(name, []))
            if left.shape != right.shape or not np.array_equal(left, right):
                return False
        return True

    def _within_search_bounds(self, state: State4D) -> bool:
        bounds = self.config.search_bounds
        if not bounds or state == self.virtual_goal:
            return True
        _, z, y, x = state
        for axis_name, value in (("z", z), ("y", y), ("x", x)):
            if axis_name not in bounds:
                continue
            lo, hi = bounds[axis_name]
            if value < lo or value > hi:
                return False
        return True

    def _path_field_cost(self, path: list[State4D]) -> float:
        if self.risk_field is None or not path:
            return INF
        total = 0.0
        for state in path:
            t, z, y, x = state
            t = self.risk_field.clamp_time(t)
            if self.risk_field.is_no_fly((t, z, y, x)):
                return INF
            total += float(self.risk_field.total_cost[t, z, y, x])
        return float(total)

    def _path_edge_cost(self, path: list[State4D]) -> float:
        if not path:
            return INF
        total = 0.0
        for a, b in zip(path[:-1], path[1:]):
            cost = self.edge_cost(a, b)
            if math.isinf(cost):
                return INF
            total += cost
        return float(total)

    def _clear_graph_caches(self) -> None:
        self._edge_cost_cache.clear()
        self._successor_cache.clear()
        self._predecessor_cache.clear()

    def _g(self, state: State4D) -> float:
        return self.g.get(state, INF)

    def _rhs(self, state: State4D) -> float:
        return self.rhs.get(state, INF)
