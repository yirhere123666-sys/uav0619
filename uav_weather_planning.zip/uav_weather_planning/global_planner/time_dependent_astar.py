from __future__ import annotations

from dataclasses import dataclass
import heapq
import math
import time

from uav_weather_planning.risk_field import RiskField4D
from uav_weather_planning.risk_field.risk_field_4d import SpatialNode, State4D
from .constraints import FlightConstraints
from .energy_model import MultirotorEnergyConfig, MultirotorEnergyModel


@dataclass
class PlanningResult:
    path: list[State4D]
    total_cost: float
    nodes_expanded: int
    elapsed_ms: float
    success: bool
    reason: str = ""


class TimeDependentAStar:
    """A* on a 4D time-expanded grid.

    State format is (time, height, y, x). Every edge advances time by one
    step, so the planner can query weather at the future arrival time.
    """

    def __init__(
        self,
        risk_field: RiskField4D,
        allow_wait: bool = True,
        use_cvar: bool = True,
        vertical_weight: float = 1.35,
        risk_weight: float = 1.0,
        time_weight: float = 0.18,
        cvar_weight: float = 0.55,
        energy_weight: float = 0.35,
        safety_weight: float = 0.20,
        heuristic_weight: float = 1.35,
        max_time: int | None = None,
        constraints: FlightConstraints | None = None,
        energy_config: MultirotorEnergyConfig | None = None,
        search_bounds: dict[str, tuple[int, int]] | None = None,
    ) -> None:
        self.risk_field = risk_field
        self.allow_wait = allow_wait
        self.use_cvar = use_cvar
        self.vertical_weight = vertical_weight
        self.risk_weight = risk_weight
        self.time_weight = time_weight
        self.cvar_weight = cvar_weight
        self.energy_weight = energy_weight
        self.safety_weight = safety_weight
        self.heuristic_weight = heuristic_weight
        self.max_time = max_time if max_time is not None else risk_field.t_size - 1
        self.constraints = constraints or FlightConstraints()
        self.energy_config = energy_config
        self._energy_model = MultirotorEnergyModel(risk_field, energy_config)
        self.search_bounds = search_bounds

    def plan(
        self,
        start: SpatialNode | State4D,
        goal: SpatialNode,
        start_time: int = 0,
    ) -> PlanningResult:
        start_clock = time.perf_counter()
        start_state = self._normalize_start(start, start_time)
        if not self.risk_field.in_bounds(start_state):
            return PlanningResult([], float("inf"), 0, 0.0, False, "start out of bounds")

        open_heap: list[tuple[float, float, State4D]] = []
        heapq.heappush(open_heap, (self._heuristic(start_state, goal), 0.0, start_state))
        came_from: dict[State4D, State4D | None] = {start_state: None}
        g_score: dict[State4D, float] = {start_state: 0.0}
        visited: set[State4D] = set()
        nodes_expanded = 0

        while open_heap:
            _, current_g, current = heapq.heappop(open_heap)
            if current in visited:
                continue
            visited.add(current)
            nodes_expanded += 1

            if self._spatial(current) == goal:
                elapsed_ms = (time.perf_counter() - start_clock) * 1000.0
                return PlanningResult(
                    path=self._reconstruct(came_from, current),
                    total_cost=current_g,
                    nodes_expanded=nodes_expanded,
                    elapsed_ms=elapsed_ms,
                    success=True,
                )

            if current[0] >= self.max_time:
                continue

            for neighbor in self.neighbors(current):
                if not self._within_search_bounds(neighbor):
                    continue
                previous = came_from[current]
                if not self.constraints.is_feasible(current, neighbor, self.risk_field, previous):
                    continue
                if self.risk_field.is_no_fly(neighbor):
                    continue
                step_cost = self.edge_cost(current, neighbor, previous=previous)
                if math.isinf(step_cost):
                    continue
                tentative = current_g + step_cost
                if tentative < g_score.get(neighbor, float("inf")):
                    g_score[neighbor] = tentative
                    came_from[neighbor] = current
                    priority = tentative + self.heuristic_weight * self._heuristic(neighbor, goal)
                    heapq.heappush(open_heap, (priority, tentative, neighbor))

        elapsed_ms = (time.perf_counter() - start_clock) * 1000.0
        return PlanningResult([], float("inf"), nodes_expanded, elapsed_ms, False, "no path")

    def neighbors(self, state: State4D) -> list[State4D]:
        t, z, y, x = state
        nt = t + 1
        neighbors: list[State4D] = []
        moves = []
        for dz in (-1, 0, 1):
            for dy in (-1, 0, 1):
                for dx in (-1, 0, 1):
                    if dz == 0 and dy == 0 and dx == 0:
                        continue
                    moves.append((dz, dy, dx))
        if self.allow_wait:
            moves.append((0, 0, 0))

        for dz, dy, dx in moves:
            candidate = (nt, z + dz, y + dy, x + dx)
            if self.risk_field.in_bounds(candidate):
                neighbors.append(candidate)
        return neighbors

    def _within_search_bounds(self, state: State4D) -> bool:
        if not self.search_bounds:
            return True
        _, z, y, x = state
        for axis_name, value in (("z", z), ("y", y), ("x", x)):
            if axis_name not in self.search_bounds:
                continue
            lo, hi = self.search_bounds[axis_name]
            if value < lo or value > hi:
                return False
        return True

    def edge_cost(self, current: State4D, neighbor: State4D, previous: State4D | None = None) -> float:
        _, z0, y0, x0 = current
        _, z1, y1, x1 = neighbor
        dz = z1 - z0
        dy = y1 - y0
        dx = x1 - x0
        distance = math.sqrt(dx * dx + dy * dy + self.vertical_weight * dz * dz)
        if distance == 0:
            distance = 0.45
        risk = self.risk_field.query_risk(neighbor)
        if risk["no_fly"]:
            return float("inf")
        weather_cost = risk["total_cost"] if self.use_cvar else risk["expected_risk"]
        if math.isinf(weather_cost):
            return float("inf")
        cvar = risk["cvar_risk"] if self.use_cvar else 0.0
        edge_energy = self._edge_energy_model().edge_energy(current, neighbor, previous)
        energy = max(float(risk["energy_penalty"]), float(edge_energy["energy_penalty"]))
        safety_margin = max(float(risk["safety_margin"]), 1e-6)
        safety_penalty = 1.0 / (1.0 + safety_margin)
        return (
            distance
            + self.time_weight
            + self.risk_weight * weather_cost
            + self.cvar_weight * cvar
            + self.energy_weight * energy
            + self.safety_weight * safety_penalty
            + self.constraints.penalty(previous, current, neighbor)
            + self.constraints.metric_penalty(previous, current, neighbor, self.risk_field)
        )

    def _edge_energy_model(self) -> MultirotorEnergyModel:
        if self._energy_model.risk_field is not self.risk_field:
            self._energy_model = MultirotorEnergyModel(self.risk_field, self.energy_config)
        return self._energy_model

    def _heuristic(self, state: State4D, goal: SpatialNode) -> float:
        _, z, y, x = state
        gz, gy, gx = goal
        return math.sqrt((gx - x) ** 2 + (gy - y) ** 2 + self.vertical_weight * (gz - z) ** 2)

    @staticmethod
    def _spatial(state: State4D) -> SpatialNode:
        return state[1], state[2], state[3]

    @staticmethod
    def _normalize_start(start: SpatialNode | State4D, start_time: int) -> State4D:
        if len(start) == 4:
            return start  # type: ignore[return-value]
        z, y, x = start  # type: ignore[misc]
        return start_time, z, y, x

    @staticmethod
    def _reconstruct(came_from: dict[State4D, State4D | None], end: State4D) -> list[State4D]:
        path = [end]
        current = end
        while came_from[current] is not None:
            current = came_from[current]  # type: ignore[assignment]
            path.append(current)
        path.reverse()
        return path
