from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any

import math
import numpy as np

from uav_weather_planning.risk_field import RiskField4D
from uav_weather_planning.risk_field.risk_field_4d import State4D


@dataclass(frozen=True)
class MultirotorEnergyConfig:
    mass_kg: float = 2.5
    hover_power_w: float = 240.0
    nominal_airspeed_mps: float = 10.0
    max_modeled_airspeed_mps: float = 22.0
    reference_power_w: float = 950.0
    propulsive_efficiency: float = 0.72
    descent_power_fraction: float = 0.28
    parasitic_power_fraction: float = 0.18
    induced_power_fraction: float = 0.35
    crosswind_control_fraction: float = 0.06
    gust_power_fraction: float = 0.08
    turbulence_power_fraction: float = 0.07
    precipitation_power_fraction: float = 0.04
    uncertainty_power_fraction: float = 0.04

    def as_dict(self) -> dict[str, float]:
        return asdict(self)


class MultirotorEnergyModel:
    """Path-dependent multirotor energy proxy on a 4D risk field."""

    def __init__(self, risk_field: RiskField4D, config: MultirotorEnergyConfig | None = None) -> None:
        self.risk_field = risk_field
        self.config = config or MultirotorEnergyConfig()
        self._context = self._build_context(risk_field)

    def edge_energy(self, current: State4D, neighbor: State4D, previous: State4D | None = None) -> dict[str, float]:
        cfg = self.config
        dt = self._dt(current, neighbor)
        gx, gy, gz = self._ground_velocity(current, neighbor, dt)
        t, z, y, x = neighbor
        t = self.risk_field.clamp_time(t)

        wind_x = float(self.risk_field.wind_u[t, z, y, x])
        wind_y = -float(self.risk_field.wind_v[t, z, y, x])
        wind_z = float(self.risk_field.wind_w[t, z, y, x])
        air_x = gx - wind_x
        air_y = gy - wind_y
        air_z = gz - wind_z
        horizontal_air_speed = math.sqrt(air_x * air_x + air_y * air_y)
        airspeed = math.sqrt(horizontal_air_speed * horizontal_air_speed + air_z * air_z)
        travel_norm = math.sqrt(gx * gx + gy * gy)
        if travel_norm > 1e-9:
            along_wind = (wind_x * gx + wind_y * gy) / travel_norm
            crosswind = math.sqrt(max(wind_x * wind_x + wind_y * wind_y - along_wind * along_wind, 0.0))
        else:
            along_wind = 0.0
            crosswind = math.sqrt(wind_x * wind_x + wind_y * wind_y)
        headwind = max(-along_wind, 0.0)
        tailwind = max(along_wind, 0.0)

        modeled_airspeed = min(airspeed, cfg.max_modeled_airspeed_mps)
        speed_ratio = max(modeled_airspeed / max(cfg.nominal_airspeed_mps, 1e-6), 0.05)
        hover_power = cfg.hover_power_w
        induced_power = hover_power * cfg.induced_power_fraction / math.sqrt(speed_ratio + 0.25)
        parasitic_power = hover_power * cfg.parasitic_power_fraction * speed_ratio**3
        base_power = hover_power * 0.62 + induced_power + parasitic_power

        if gz >= 0.0:
            vertical_power = cfg.mass_kg * 9.80665 * gz / max(cfg.propulsive_efficiency, 1e-6)
        else:
            vertical_power = hover_power * cfg.descent_power_fraction * min(abs(gz) / 2.0, 1.0)

        gust_risk = float(self.risk_field.gust_risk[t, z, y, x])
        turbulence_risk = float(self.risk_field.turbulence_risk[t, z, y, x])
        precipitation_risk = float(self.risk_field.precipitation_risk[t, z, y, x])
        uncertainty = float(self.risk_field.uncertainty[t, z, y, x])
        crosswind_ratio = crosswind / max(cfg.nominal_airspeed_mps, 1e-6)
        control_power = hover_power * (
            cfg.crosswind_control_fraction * crosswind_ratio * crosswind_ratio
            + cfg.gust_power_fraction * gust_risk
            + cfg.turbulence_power_fraction * turbulence_risk
            + cfg.precipitation_power_fraction * precipitation_risk
            + cfg.uncertainty_power_fraction * uncertainty
        )
        power_w = max(base_power + vertical_power + control_power, hover_power * 0.35)
        energy_j = power_w * dt
        speed_excess = max(airspeed - cfg.max_modeled_airspeed_mps, 0.0) / max(cfg.max_modeled_airspeed_mps, 1e-6)
        energy_penalty = float(
            np.clip((power_w - hover_power) / max(cfg.reference_power_w - hover_power, 1e-6) + 0.25 * speed_excess, 0.0, 1.0)
        )
        return {
            "power_w": power_w,
            "energy_j": energy_j,
            "energy_penalty": energy_penalty,
            "airspeed_mps": airspeed,
            "modeled_airspeed_mps": modeled_airspeed,
            "headwind_mps": headwind,
            "tailwind_mps": tailwind,
            "crosswind_mps": crosswind,
            "vertical_rate_mps": gz,
        }

    def path_energy(self, path: list[State4D]) -> dict[str, float | None]:
        if len(path) < 2:
            return {
                "cumulative_energy_kj": 0.0,
                "mean_power_w": 0.0,
                "max_power_w": 0.0,
                "max_energy_penalty": 0.0,
            }
        total_energy = 0.0
        total_time = 0.0
        max_power = 0.0
        max_penalty = 0.0
        for idx, (current, neighbor) in enumerate(zip(path[:-1], path[1:])):
            previous = path[idx - 1] if idx > 0 else None
            edge = self.edge_energy(current, neighbor, previous)
            total_energy += edge["energy_j"]
            total_time += self._dt(current, neighbor)
            max_power = max(max_power, edge["power_w"])
            max_penalty = max(max_penalty, edge["energy_penalty"])
        return {
            "cumulative_energy_kj": round(total_energy / 1000.0, 3),
            "mean_power_w": round(total_energy / max(total_time, 1e-6), 3),
            "max_power_w": round(max_power, 3),
            "max_energy_penalty": round(max_penalty, 3),
        }

    def metadata(self) -> dict[str, Any]:
        return {
            "model": "path-dependent multirotor energy proxy",
            "wind_coordinate_note": "wind_u is eastward; wind_v is northward and converted to south-positive y when the local grid uses y southward",
            "config": self.config.as_dict(),
        }

    def _ground_velocity(self, current: State4D, neighbor: State4D, dt: float) -> tuple[float, float, float]:
        _, z0, y0, x0 = current
        _, z1, y1, x1 = neighbor
        context = self._context
        if context["metric"]:
            x_axis = context["x_axis"]
            y_axis = context["y_axis"]
            z_axis = context["z_axis"]
            return (
                float(x_axis[x1] - x_axis[x0]) / dt,
                float(y_axis[y1] - y_axis[y0]) / dt,
                float(z_axis[z1] - z_axis[z0]) / dt,
            )
        return float(x1 - x0), float(y1 - y0), float(z1 - z0)

    def _dt(self, current: State4D, neighbor: State4D) -> float:
        time_axis = self._context["time_axis"]
        t0, t1 = current[0], neighbor[0]
        if self._context["metric_time"] and t0 < len(time_axis) and t1 < len(time_axis):
            if np.issubdtype(time_axis.dtype, np.datetime64):
                dt = float((time_axis[t1] - time_axis[t0]).astype("timedelta64[ms]").astype(float) / 1000.0)
            else:
                dt = float(time_axis[t1] - time_axis[t0])
            return max(dt, 1e-6)
        return 1.0

    @staticmethod
    def _build_context(risk_field: RiskField4D) -> dict[str, Any]:
        x_axis = np.asarray(risk_field.coords.get("x", np.arange(risk_field.x_size)), dtype=float)
        y_axis = np.asarray(risk_field.coords.get("y", np.arange(risk_field.y_size)), dtype=float)
        z_axis = np.asarray(risk_field.coords.get("height", np.arange(risk_field.z_size)), dtype=float)
        time_axis = np.asarray(risk_field.coords.get("time", np.arange(risk_field.t_size)))
        grid = risk_field.source_metadata.get("geospatial_grid", {})
        metric = isinstance(grid, dict) and "LOCAL" in str(grid.get("crs", "")).upper()
        time_unit = str(risk_field.source_metadata.get("time_axis_unit", "")).lower()
        metric_time = "second" in time_unit or np.issubdtype(time_axis.dtype, np.datetime64)
        return {
            "x_axis": x_axis,
            "y_axis": y_axis,
            "z_axis": z_axis,
            "time_axis": time_axis,
            "metric": metric,
            "metric_time": metric_time,
        }
