from __future__ import annotations

from dataclasses import dataclass, field, fields
from typing import Any
import math

import numpy as np

from uav_weather_planning.risk_field import RiskField4D
from uav_weather_planning.risk_field.risk_field_4d import State4D


@dataclass
class FlightConstraints:
    """Global-path trajectory feasibility constraints for multirotor planning.

    The graph state remains (time, height, y, x), but feasibility can be
    checked in either grid units or real metric units when the risk cube
    provides x/y/height/time coordinates.
    """

    max_horizontal_step_cells: float = 1.5
    max_vertical_step_layers: int = 1
    min_safety_margin_cells: float = 0.0
    max_turn_angle_deg: float = 135.0
    min_altitude_m: float | None = None
    max_altitude_m: float | None = None
    enforce_metric_limits: bool = False
    max_ground_speed_mps: float | None = None
    max_climb_rate_mps: float | None = None
    max_descent_rate_mps: float | None = None
    max_yaw_rate_deg_s: float | None = None
    max_acceleration_mps2: float | None = None
    min_safety_margin_m: float | None = None
    turn_penalty_weight: float = 0.18
    climb_penalty_weight: float = 0.22
    wait_penalty: float = 0.10
    speed_penalty_weight: float = 0.18
    vertical_rate_penalty_weight: float = 0.14
    yaw_rate_penalty_weight: float = 0.10
    acceleration_penalty_weight: float = 0.10
    clearance_penalty_weight: float = 0.12
    airspace: Any | None = field(default=None, repr=False)
    corridor_required: bool = True
    corridor_penalty_weight: float = 0.65
    _context_cache: dict[int, dict[str, Any]] = field(default_factory=dict, init=False, repr=False)
    _corridor_model_cache: dict[int, Any] = field(default_factory=dict, init=False, repr=False)

    def is_feasible(
        self,
        current: State4D,
        neighbor: State4D,
        risk_field: RiskField4D,
        previous: State4D | None = None,
    ) -> bool:
        _, z0, y0, x0 = current
        _, z1, y1, x1 = neighbor
        dz = z1 - z0
        dy = y1 - y0
        dx = x1 - x0
        horizontal_step = math.sqrt(dx * dx + dy * dy)
        if horizontal_step > self.max_horizontal_step_cells:
            return False
        if abs(dz) > self.max_vertical_step_layers:
            return False
        altitude = self.altitude_m(risk_field, neighbor)
        if self.min_altitude_m is not None and altitude is not None and altitude < self.min_altitude_m:
            return False
        if self.max_altitude_m is not None and altitude is not None and altitude > self.max_altitude_m:
            return False
        if risk_field.safety_margin(neighbor) < self.min_safety_margin_cells:
            return False
        clearance_m = self.safety_margin_m(risk_field, neighbor)
        if self.min_safety_margin_m is not None and clearance_m is not None and clearance_m < self.min_safety_margin_m:
            return False
        if previous is not None and self.turn_angle_deg(previous, current, neighbor) > self.max_turn_angle_deg:
            return False
        if self.enforce_metric_limits and not self._metric_segment_feasible(previous, current, neighbor, risk_field):
            return False
        if self.airspace is not None:
            corridor_eval = self._corridor_model().evaluate_edge(current, neighbor, risk_field)
            if not corridor_eval.allowed:
                return False
        return True

    def penalty(self, previous: State4D | None, current: State4D, neighbor: State4D) -> float:
        _, z0, y0, x0 = current
        _, z1, y1, x1 = neighbor
        dz = z1 - z0
        dy = y1 - y0
        dx = x1 - x0
        wait = 1.0 if (dz, dy, dx) == (0, 0, 0) else 0.0
        climb = abs(dz)
        turn = 0.0
        if previous is not None:
            turn = self.turn_angle_deg(previous, current, neighbor) / 180.0
        metric = self.segment_kinematics(previous, current, neighbor, None)
        speed_ratio = self._ratio(metric.get("ground_speed_mps"), self.max_ground_speed_mps)
        vertical_ratio = max(
            self._ratio(metric.get("climb_rate_mps"), self.max_climb_rate_mps),
            self._ratio(metric.get("descent_rate_mps"), self.max_descent_rate_mps),
        )
        yaw_ratio = self._ratio(metric.get("yaw_rate_deg_s"), self.max_yaw_rate_deg_s)
        acceleration_ratio = self._ratio(metric.get("acceleration_mps2"), self.max_acceleration_mps2)
        return (
            self.wait_penalty * wait
            + self.climb_penalty_weight * climb
            + self.turn_penalty_weight * turn
            + self.speed_penalty_weight * speed_ratio
            + self.vertical_rate_penalty_weight * vertical_ratio
            + self.yaw_rate_penalty_weight * yaw_ratio
            + self.acceleration_penalty_weight * acceleration_ratio
        )

    def metric_penalty(
        self,
        previous: State4D | None,
        current: State4D,
        neighbor: State4D,
        risk_field: RiskField4D,
    ) -> float:
        metric = self.segment_kinematics(previous, current, neighbor, risk_field)
        speed_ratio = self._ratio(metric.get("ground_speed_mps"), self.max_ground_speed_mps)
        vertical_ratio = max(
            self._ratio(metric.get("climb_rate_mps"), self.max_climb_rate_mps),
            self._ratio(metric.get("descent_rate_mps"), self.max_descent_rate_mps),
        )
        yaw_ratio = self._ratio(metric.get("yaw_rate_deg_s"), self.max_yaw_rate_deg_s)
        acceleration_ratio = self._ratio(metric.get("acceleration_mps2"), self.max_acceleration_mps2)
        clearance_m = self.safety_margin_m(risk_field, neighbor)
        clearance_penalty = 0.0
        if self.min_safety_margin_m is not None and clearance_m is not None:
            clearance_penalty = max(0.0, (self.min_safety_margin_m - clearance_m) / max(self.min_safety_margin_m, 1e-6))
        corridor_penalty = 0.0
        if self.airspace is not None:
            evaluation = self._corridor_model().evaluate_edge(current, neighbor, risk_field)
            corridor_penalty = evaluation.penalty if evaluation.allowed else float("inf")
        return (
            self.speed_penalty_weight * speed_ratio
            + self.vertical_rate_penalty_weight * vertical_ratio
            + self.yaw_rate_penalty_weight * yaw_ratio
            + self.acceleration_penalty_weight * acceleration_ratio
            + self.clearance_penalty_weight * clearance_penalty
            + corridor_penalty
        )

    def audit_path(self, path: list[State4D], risk_field: RiskField4D) -> dict[str, float | int | bool | None]:
        if not path:
            return {
                "constraint_violations": 1,
                "metric_constraints_available": self.metric_constraints_available(risk_field),
                "max_ground_speed_mps": None,
                "max_vertical_rate_mps": None,
                "max_turn_angle_deg": None,
                "max_yaw_rate_deg_s": None,
                "max_acceleration_mps2": None,
                "min_safety_margin_cells": None,
                "min_safety_margin_m": None,
                "airspace_violations": 1 if self.airspace is not None else 0,
                "max_corridor_deviation_m": None,
                "mean_corridor_deviation_m": None,
                "max_corridor_deviation_ratio": None,
                "corridor_segments_used": [],
                "alternate_landing_points": [],
            }
        violations = 0
        max_ground_speed = 0.0
        max_vertical_rate = 0.0
        max_turn = 0.0
        max_yaw_rate = 0.0
        max_accel = 0.0
        min_margin_cells = float("inf")
        min_margin_m = float("inf")
        for idx, state in enumerate(path):
            margin = risk_field.safety_margin(state)
            min_margin_cells = min(min_margin_cells, margin)
            margin_m = self.safety_margin_m(risk_field, state)
            if margin_m is not None:
                min_margin_m = min(min_margin_m, margin_m)
            if risk_field.is_no_fly((risk_field.clamp_time(state[0]), state[1], state[2], state[3])):
                violations += 1
            if idx == 0:
                continue
            previous = path[idx - 2] if idx >= 2 else None
            current = path[idx - 1]
            neighbor = state
            if not self.is_feasible(current, neighbor, risk_field, previous):
                violations += 1
            kin = self.segment_kinematics(previous, current, neighbor, risk_field)
            max_ground_speed = max(max_ground_speed, kin.get("ground_speed_mps") or 0.0)
            max_vertical_rate = max(max_vertical_rate, abs(kin.get("vertical_rate_mps") or 0.0))
            max_turn = max(max_turn, kin.get("turn_angle_deg") or 0.0)
            max_yaw_rate = max(max_yaw_rate, kin.get("yaw_rate_deg_s") or 0.0)
            max_accel = max(max_accel, kin.get("acceleration_mps2") or 0.0)
        corridor_audit = self._corridor_model().evaluate_path(path, risk_field) if self.airspace is not None else {}
        return {
            "constraint_violations": int(violations),
            "metric_constraints_available": self.metric_constraints_available(risk_field),
            "max_ground_speed_mps": round(max_ground_speed, 3) if max_ground_speed else 0.0,
            "max_vertical_rate_mps": round(max_vertical_rate, 3) if max_vertical_rate else 0.0,
            "max_turn_angle_deg": round(max_turn, 3),
            "max_yaw_rate_deg_s": round(max_yaw_rate, 3) if max_yaw_rate else 0.0,
            "max_acceleration_mps2": round(max_accel, 3) if max_accel else 0.0,
            "min_safety_margin_cells": round(min_margin_cells, 3) if math.isfinite(min_margin_cells) else None,
            "min_safety_margin_m": round(min_margin_m, 3) if math.isfinite(min_margin_m) else None,
            "airspace_violations": corridor_audit.get("airspace_violations", 0),
            "max_corridor_deviation_m": corridor_audit.get("max_corridor_deviation_m"),
            "mean_corridor_deviation_m": corridor_audit.get("mean_corridor_deviation_m"),
            "max_corridor_deviation_ratio": corridor_audit.get("max_corridor_deviation_ratio"),
            "corridor_segments_used": corridor_audit.get("corridor_segments_used", []),
            "alternate_landing_points": corridor_audit.get("alternate_landing_points", []),
        }

    def metric_constraints_available(self, risk_field: RiskField4D) -> bool:
        context = self._metric_context(risk_field)
        return bool(context["metric_space"] and context["metric_time"])

    def segment_kinematics(
        self,
        previous: State4D | None,
        current: State4D,
        neighbor: State4D,
        risk_field: RiskField4D | None,
    ) -> dict[str, float | None]:
        turn_angle = self.turn_angle_deg(previous, current, neighbor) if previous is not None else 0.0
        if risk_field is None:
            return {
                "ground_speed_mps": None,
                "vertical_rate_mps": None,
                "climb_rate_mps": None,
                "descent_rate_mps": None,
                "turn_angle_deg": turn_angle,
                "yaw_rate_deg_s": None,
                "acceleration_mps2": None,
            }
        context = self._metric_context(risk_field)
        if not (context["metric_space"] and context["metric_time"]):
            return {
                "ground_speed_mps": None,
                "vertical_rate_mps": None,
                "climb_rate_mps": None,
                "descent_rate_mps": None,
                "turn_angle_deg": turn_angle,
                "yaw_rate_deg_s": None,
                "acceleration_mps2": None,
            }
        dt = self.dt_seconds(risk_field, current, neighbor)
        if dt is None or dt <= 0.0:
            return {
                "ground_speed_mps": None,
                "vertical_rate_mps": None,
                "climb_rate_mps": None,
                "descent_rate_mps": None,
                "turn_angle_deg": turn_angle,
                "yaw_rate_deg_s": None,
                "acceleration_mps2": None,
            }
        x0, y0, z0 = self.xyz_m(risk_field, current)
        x1, y1, z1 = self.xyz_m(risk_field, neighbor)
        vx = (x1 - x0) / dt
        vy = (y1 - y0) / dt
        vz = (z1 - z0) / dt
        ground_speed = math.sqrt(vx * vx + vy * vy)
        vertical_rate = vz
        yaw_rate = turn_angle / dt if previous is not None else 0.0
        acceleration = 0.0
        if previous is not None:
            px, py, pz = self.xyz_m(risk_field, previous)
            pdt = self.dt_seconds(risk_field, previous, current) or dt
            pv = ((x0 - px) / pdt, (y0 - py) / pdt, (z0 - pz) / pdt)
            acceleration = math.sqrt((vx - pv[0]) ** 2 + (vy - pv[1]) ** 2 + (vz - pv[2]) ** 2) / dt
        return {
            "ground_speed_mps": ground_speed,
            "vertical_rate_mps": vertical_rate,
            "climb_rate_mps": max(vertical_rate, 0.0),
            "descent_rate_mps": max(-vertical_rate, 0.0),
            "turn_angle_deg": turn_angle,
            "yaw_rate_deg_s": yaw_rate,
            "acceleration_mps2": acceleration,
        }

    def xyz_m(self, risk_field: RiskField4D, state: State4D) -> tuple[float, float, float]:
        _, z, y, x = state
        context = self._metric_context(risk_field)
        x_axis = context["x_axis"]
        y_axis = context["y_axis"]
        z_axis = context["z_axis"]
        return float(x_axis[x]), float(y_axis[y]), float(z_axis[z])

    def altitude_m(self, risk_field: RiskField4D, state: State4D) -> float | None:
        try:
            return self.xyz_m(risk_field, state)[2]
        except (IndexError, TypeError, ValueError):
            return None

    def safety_margin_m(self, risk_field: RiskField4D, state: State4D) -> float | None:
        resolution = self.nominal_xy_resolution_m(risk_field)
        if resolution is None:
            return None
        return risk_field.safety_margin(state) * resolution

    def nominal_xy_resolution_m(self, risk_field: RiskField4D) -> float | None:
        context = self._metric_context(risk_field)
        return context["xy_resolution_m"] if context["metric_space"] else None

    def dt_seconds(self, risk_field: RiskField4D, current: State4D, neighbor: State4D) -> float | None:
        time_axis = self._metric_context(risk_field)["time_axis"]
        t0, t1 = current[0], neighbor[0]
        if t0 >= len(time_axis) or t1 >= len(time_axis):
            return None
        v0 = time_axis[t0]
        v1 = time_axis[t1]
        if np.issubdtype(time_axis.dtype, np.datetime64):
            return float((v1 - v0).astype("timedelta64[ms]").astype(float) / 1000.0)
        try:
            return float(v1 - v0)
        except (TypeError, ValueError):
            return None

    @staticmethod
    def turn_angle_deg(previous: State4D, current: State4D, neighbor: State4D) -> float:
        if previous is None:
            return 0.0
        _, z_prev, y_prev, x_prev = previous
        _, z0, y0, x0 = current
        _, z1, y1, x1 = neighbor
        a = (z0 - z_prev, y0 - y_prev, x0 - x_prev)
        b = (z1 - z0, y1 - y0, x1 - x0)
        norm_a = math.sqrt(a[0] ** 2 + a[1] ** 2 + a[2] ** 2)
        norm_b = math.sqrt(b[0] ** 2 + b[1] ** 2 + b[2] ** 2)
        if norm_a == 0.0 or norm_b == 0.0:
            return 0.0
        cosine = max(min((a[0] * b[0] + a[1] * b[1] + a[2] * b[2]) / (norm_a * norm_b), 1.0), -1.0)
        return math.degrees(math.acos(cosine))

    def as_dict(self) -> dict[str, Any]:
        data = {item.name: getattr(self, item.name) for item in fields(self) if item.init and item.name != "airspace"}
        data["airspace_enabled"] = self.airspace is not None
        if self.airspace is not None and hasattr(self.airspace, "as_summary"):
            data["airspace_network"] = self.airspace.as_summary()
        return data

    def _metric_segment_feasible(
        self,
        previous: State4D | None,
        current: State4D,
        neighbor: State4D,
        risk_field: RiskField4D,
    ) -> bool:
        metric = self.segment_kinematics(previous, current, neighbor, risk_field)
        if self.max_ground_speed_mps is not None and self._exceeds(metric.get("ground_speed_mps"), self.max_ground_speed_mps):
            return False
        if self.max_climb_rate_mps is not None and self._exceeds(metric.get("climb_rate_mps"), self.max_climb_rate_mps):
            return False
        if self.max_descent_rate_mps is not None and self._exceeds(metric.get("descent_rate_mps"), self.max_descent_rate_mps):
            return False
        if self.max_yaw_rate_deg_s is not None and self._exceeds(metric.get("yaw_rate_deg_s"), self.max_yaw_rate_deg_s):
            return False
        if self.max_acceleration_mps2 is not None and self._exceeds(metric.get("acceleration_mps2"), self.max_acceleration_mps2):
            return False
        return True

    @staticmethod
    def _exceeds(value: float | None, limit: float) -> bool:
        return value is not None and value > limit + 1e-9

    @staticmethod
    def _ratio(value: float | None, limit: float | None) -> float:
        if value is None or limit is None or limit <= 0.0:
            return 0.0
        return max(0.0, value / limit)

    def _has_metric_space(self, risk_field: RiskField4D) -> bool:
        grid = risk_field.source_metadata.get("geospatial_grid", {})
        if isinstance(grid, dict) and "LOCAL" in str(grid.get("crs", "")).upper():
            return True
        axis = grid.get("axis_definition", {}) if isinstance(grid, dict) else {}
        return "meter" in str(axis.get("x", "")).lower() and "meter" in str(axis.get("y", "")).lower()

    def _has_metric_time(self, risk_field: RiskField4D) -> bool:
        unit = str(risk_field.source_metadata.get("time_axis_unit", "")).lower()
        if "second" in unit:
            return True
        axis = risk_field.source_metadata.get("geospatial_grid", {}).get("axis_definition", {})
        if "second" in str(axis.get("time", "")).lower():
            return True
        time_axis = np.asarray(risk_field.coords.get("time", []))
        return bool(time_axis.size > 1 and np.issubdtype(time_axis.dtype, np.datetime64))

    def _metric_context(self, risk_field: RiskField4D) -> dict[str, Any]:
        key = id(risk_field)
        cached = self._context_cache.get(key)
        if cached is not None:
            return cached
        x_axis = np.asarray(risk_field.coords.get("x", np.arange(risk_field.x_size)), dtype=float)
        y_axis = np.asarray(risk_field.coords.get("y", np.arange(risk_field.y_size)), dtype=float)
        z_axis = np.asarray(risk_field.coords.get("height", np.arange(risk_field.z_size)), dtype=float)
        time_axis = np.asarray(risk_field.coords.get("time", np.arange(risk_field.t_size)))
        spacings = []
        if x_axis.size > 1:
            spacings.append(float(np.nanmedian(np.abs(np.diff(x_axis)))))
        if y_axis.size > 1:
            spacings.append(float(np.nanmedian(np.abs(np.diff(y_axis)))))
        positive_spacings = [value for value in spacings if value > 0.0]
        context = {
            "x_axis": x_axis,
            "y_axis": y_axis,
            "z_axis": z_axis,
            "time_axis": time_axis,
            "metric_space": self._has_metric_space(risk_field),
            "metric_time": self._has_metric_time(risk_field),
            "xy_resolution_m": min(positive_spacings) if positive_spacings else None,
        }
        self._context_cache[key] = context
        return context

    def _corridor_model(self):
        key = id(self.airspace)
        cached = self._corridor_model_cache.get(key)
        if cached is not None:
            return cached
        from uav_weather_planning.airspace import CorridorCostConfig, CorridorCostModel

        model = CorridorCostModel(
            self.airspace,
            CorridorCostConfig(
                required=self.corridor_required,
                penalty_weight=self.corridor_penalty_weight,
                enforce_segment_speed_limit=True,
            ),
        )
        self._corridor_model_cache[key] = model
        return model
