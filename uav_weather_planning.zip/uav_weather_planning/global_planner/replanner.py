from __future__ import annotations

from dataclasses import dataclass
import time

import numpy as np

from .constraints import FlightConstraints
from .time_dependent_astar import PlanningResult, TimeDependentAStar
from uav_weather_planning.risk_field import RiskField4D
from uav_weather_planning.risk_field.risk_field_4d import SpatialNode, State4D


@dataclass
class ReplanEvent:
    event_time: int
    reason: str
    affected_voxels: int
    repaired_from: State4D
    nodes_expanded: int
    elapsed_ms: float


@dataclass
class ReplanResult:
    path: list[State4D]
    events: list[ReplanEvent]
    nodes_expanded: int
    elapsed_ms: float
    success: bool
    fallback_used: bool = False
    fallback_reason: str = ""


class EventTriggeredRepairReplanner:
    """Event-triggered path-prefix repair baseline for demos.

    This class detects changed risk voxels, preserves the executed path
    prefix, and repairs only from the current state when future path
    feasibility is affected. It is kept as a fast visualization baseline.
    The stricter g/rhs/open incremental-search implementation is
    IncrementalLPAStar.
    """

    def __init__(
        self,
        initial_field: RiskField4D,
        updated_field: RiskField4D,
        update_time: int,
        risk_threshold: float = 18.0,
        corridor_radius: int = 1,
        constraints: FlightConstraints | None = None,
    ) -> None:
        self.initial_field = initial_field
        self.updated_field = updated_field
        self.update_time = update_time
        self.risk_threshold = risk_threshold
        self.corridor_radius = max(0, int(corridor_radius))
        self.constraints = constraints or FlightConstraints()
        self.changed = self._significant_changes()

    def plan_and_repair(
        self,
        start: SpatialNode,
        goal: SpatialNode,
        start_time: int = 0,
    ) -> ReplanResult:
        total_start = time.perf_counter()
        planner = TimeDependentAStar(self.initial_field, constraints=self.constraints)
        initial = planner.plan(start, goal, start_time=start_time)
        if not initial.success:
            elapsed = (time.perf_counter() - total_start) * 1000.0
            return ReplanResult([], [], initial.nodes_expanded, elapsed, False)

        path = initial.path
        events: list[ReplanEvent] = []
        total_nodes = initial.nodes_expanded
        fallback_used = False
        fallback_reason = ""

        trigger_idx = self._find_trigger_index(path)
        if trigger_idx is not None:
            repair_state = path[max(0, trigger_idx - 1)]
            reason = "forecast update affects future path"
            repair_planner = TimeDependentAStar(self.updated_field, constraints=self.constraints)
            repaired: PlanningResult = repair_planner.plan(repair_state, goal, start_time=repair_state[0])
            total_nodes += repaired.nodes_expanded
            if repaired.success:
                path = path[: max(0, trigger_idx - 1)] + repaired.path
            events.append(
                ReplanEvent(
                    event_time=repair_state[0],
                    reason=reason,
                    affected_voxels=int(np.sum(self.changed)),
                    repaired_from=repair_state,
                    nodes_expanded=repaired.nodes_expanded,
                    elapsed_ms=repaired.elapsed_ms,
                )
            )

        if not self._path_safe(path):
            fallback_reason = "repair safety audit failed; fallback to full time-dependent A*"
            fallback_used = True
            fallback_start = time.perf_counter()
            fallback_planner = TimeDependentAStar(self.updated_field, constraints=self.constraints)
            fallback = fallback_planner.plan(start, goal, start_time=start_time)
            total_nodes += fallback.nodes_expanded
            if fallback.success:
                path = fallback.path
            events.append(
                ReplanEvent(
                    event_time=start_time,
                    reason=fallback_reason,
                    affected_voxels=int(np.sum(self.changed)),
                    repaired_from=(start_time, start[0], start[1], start[2]),
                    nodes_expanded=fallback.nodes_expanded,
                    elapsed_ms=(time.perf_counter() - fallback_start) * 1000.0,
                )
            )

        elapsed = (time.perf_counter() - total_start) * 1000.0
        return ReplanResult(path, events, total_nodes, elapsed, self._path_safe(path), fallback_used, fallback_reason)

    def _find_trigger_index(self, path: list[State4D]) -> int | None:
        for idx, state in enumerate(path):
            t, z, y, x = state
            if t < self.update_time:
                continue
            probe = (self.updated_field.clamp_time(t), z, y, x)
            if self._changed_near(probe):
                return idx
            if self.updated_field.is_no_fly(probe):
                return idx
            if self.updated_field.cost_at(probe) >= self.risk_threshold:
                return idx
        return None

    def _changed_near(self, state: State4D) -> bool:
        t, z, y, x = state
        radius = self.corridor_radius
        y0 = max(0, y - radius)
        y1 = min(self.updated_field.y_size, y + radius + 1)
        x0 = max(0, x - radius)
        x1 = min(self.updated_field.x_size, x + radius + 1)
        return bool(np.any(self.changed[t, z, y0:y1, x0:x1]))

    def _significant_changes(self) -> np.ndarray:
        return self.initial_field.significant_changed_voxels(self.updated_field)

    def _path_safe(self, path: list[State4D]) -> bool:
        if not path:
            return False
        audit = self.constraints.audit_path(path, self.updated_field)
        if int(audit.get("constraint_violations", 0) or 0) > 0:
            return False
        return not any(
            self.updated_field.is_no_fly((self.updated_field.clamp_time(t), z, y, x))
            for t, z, y, x in path
        )
