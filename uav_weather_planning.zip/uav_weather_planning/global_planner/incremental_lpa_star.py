from __future__ import annotations

from dataclasses import dataclass
import heapq
import math
import time

import numpy as np

from uav_weather_planning.risk_field import RiskField4D
from uav_weather_planning.risk_field.risk_field_4d import SpatialNode, State4D
from .constraints import FlightConstraints
from .time_dependent_astar import TimeDependentAStar


VIRTUAL_GOAL: State4D = (-1, -1, -1, -1)


@dataclass
class IncrementalSearchResult:
    path: list[State4D]
    success: bool
    nodes_expanded: int
    elapsed_ms: float
    replan_events: list[dict]


class IncrementalLPAStar:
    """LPA*/D* Lite-family incremental search on a time-expanded risk graph.

    This implementation exposes the research primitives expected by the
    proposal: g, rhs, priority queue, UpdateVertex, and ComputeShortestPath.
    It uses a virtual goal connected from any spatial goal state, so arrival
    time is selected by the search rather than fixed in advance.
    """

    def __init__(
        self,
        risk_field: RiskField4D,
        start: SpatialNode,
        goal: SpatialNode,
        start_time: int = 0,
        max_time: int | None = None,
        constraints: FlightConstraints | None = None,
        heuristic_weight: float = 1.35,
    ) -> None:
        self.risk_field = risk_field
        self.start: State4D = (start_time, start[0], start[1], start[2])
        self.goal = goal
        self.max_time = max_time if max_time is not None else risk_field.t_size - 1
        self.constraints = constraints or FlightConstraints()
        self.heuristic_weight = heuristic_weight
        self.astar_cost = TimeDependentAStar(
            risk_field,
            max_time=self.max_time,
            constraints=self.constraints,
            heuristic_weight=self.heuristic_weight,
        )
        self.g: dict[State4D, float] = {}
        self.rhs: dict[State4D, float] = {self.start: 0.0}
        self.open_heap: list[tuple[tuple[float, float], State4D]] = []
        self.open_keys: dict[State4D, tuple[float, float]] = {}
        self.nodes_expanded = 0
        self.last_compute_nodes_expanded = 0
        self.last_compute_elapsed_ms = 0.0
        self.replan_events: list[dict] = []
        self._edge_cost_cache: dict[tuple[State4D, State4D], float] = {}
        self._successor_cache: dict[State4D, list[State4D]] = {}
        self._predecessor_cache: dict[State4D, list[State4D]] = {}
        self._push(self.start)

    def compute_shortest_path(self) -> None:
        before_nodes = self.nodes_expanded
        start_clock = time.perf_counter()
        while self.open_heap:
            key, u = heapq.heappop(self.open_heap)
            if self.open_keys.get(u) != key:
                continue
            goal_key = self.calculate_key(VIRTUAL_GOAL)
            if key > goal_key and self._virtual_goal_consistent():
                break
            self.open_keys.pop(u, None)
            self.nodes_expanded += 1
            if self._g(u) > self._rhs(u):
                self.g[u] = self._rhs(u)
                for succ in self.successors(u):
                    self.update_vertex(succ)
            else:
                self.g[u] = float("inf")
                self.update_vertex(u)
                for succ in self.successors(u):
                    self.update_vertex(succ)
        self.last_compute_nodes_expanded = self.nodes_expanded - before_nodes
        self.last_compute_elapsed_ms = (time.perf_counter() - start_clock) * 1000.0

    def update_risk_field(self, new_field: RiskField4D) -> None:
        raw_changed = self.risk_field.raw_changed_voxels(new_field)
        changed = self.risk_field.significant_changed_voxels(new_field)
        invalidated_edge_cache_entries = len(self._edge_cost_cache)
        self.risk_field = new_field
        self.astar_cost.risk_field = new_field
        self._edge_cost_cache.clear()
        changed_indices = np.argwhere(changed)
        affected = self._affected_nodes_from_changes(changed_indices)
        for node in affected:
            self.update_vertex(node)
        self.replan_events.append(
            {
                "event_time": int(changed_indices[:, 0].min()) if len(changed_indices) else None,
                "raw_changed_voxels": int(np.sum(raw_changed)),
                "raw_changed_voxel_ratio": round(float(np.mean(raw_changed)), 6),
                "significant_changed_voxels": int(len(changed_indices)),
                "significant_changed_voxel_ratio": round(float(np.mean(changed)), 6),
                "affected_voxels": int(len(changed_indices)),
                "affected_nodes": int(len(affected)),
                "edge_updates": int(invalidated_edge_cache_entries),
                "vertex_updates": int(len(affected)),
                "algorithm": "LPA*/D* Lite-family incremental update",
                "queue_reused": True,
                "g_rhs_reused": True,
                "update_policy": "UpdateVertex on significant changed voxels plus predecessor neighborhood; successors are updated by g/rhs propagation",
                "significant_change_thresholds": {
                    "total_cost_delta": 0.3,
                    "cvar_delta": 0.2,
                    "violation_probability_delta": 0.1,
                    "no_fly_mask": "any boolean change",
                },
            }
        )

    def update_affected_vertices(self, affected_nodes: set[State4D]) -> None:
        for node in affected_nodes:
            self.update_vertex(node)
        self.replan_events.append(
            {
                "affected_nodes": int(len(affected_nodes)),
                "edge_updates": 0,
                "vertex_updates": int(len(affected_nodes)),
                "algorithm": "LPA*/D* Lite-family explicit affected-vertex update",
                "queue_reused": True,
                "g_rhs_reused": True,
                "update_policy": "caller-provided affected nodes passed to UpdateVertex",
            }
        )

    def update_vertex(self, u: State4D) -> None:
        if u != self.start:
            best = float("inf")
            for pred in self.predecessors(u):
                cost = self.edge_cost(pred, u)
                if not math.isinf(cost):
                    best = min(best, self._g(pred) + cost)
            self.rhs[u] = best
        if u in self.open_keys:
            self.open_keys.pop(u, None)
        if self._g(u) != self._rhs(u):
            self._push(u)

    def extract_path(self) -> list[State4D]:
        if math.isinf(self._rhs(VIRTUAL_GOAL)):
            return []
        path = []
        current = VIRTUAL_GOAL
        guard = 0
        while current != self.start and guard < self.risk_field.t_size * 4:
            guard += 1
            pred = self._best_predecessor(current)
            if pred is None:
                return []
            if current != VIRTUAL_GOAL:
                path.append(current)
            current = pred
        path.append(self.start)
        path.reverse()
        return path

    def run(self) -> IncrementalSearchResult:
        start = time.perf_counter()
        self.compute_shortest_path()
        elapsed = (time.perf_counter() - start) * 1000.0
        path = self.extract_path()
        return IncrementalSearchResult(path, bool(path), self.nodes_expanded, elapsed, list(self.replan_events))

    def successors(self, u: State4D) -> list[State4D]:
        cached = self._successor_cache.get(u)
        if cached is not None:
            return cached
        if u == VIRTUAL_GOAL:
            self._successor_cache[u] = []
            return []
        if (u[1], u[2], u[3]) == self.goal:
            self._successor_cache[u] = [VIRTUAL_GOAL]
            return [VIRTUAL_GOAL]
        result = self.astar_cost.neighbors(u)
        self._successor_cache[u] = result
        return result

    def predecessors(self, u: State4D) -> list[State4D]:
        cached = self._predecessor_cache.get(u)
        if cached is not None:
            return cached
        if u == self.start:
            self._predecessor_cache[u] = []
            return []
        if u == VIRTUAL_GOAL:
            result = [
                (t, self.goal[0], self.goal[1], self.goal[2])
                for t in range(self.start[0], self.max_time + 1)
                if self.risk_field.in_bounds((t, self.goal[0], self.goal[1], self.goal[2]))
            ]
            self._predecessor_cache[u] = result
            return result
        t, z, y, x = u
        if t <= self.start[0]:
            self._predecessor_cache[u] = []
            return []
        preds = []
        for dz in (-1, 0, 1):
            for dy in (-1, 0, 1):
                for dx in (-1, 0, 1):
                    p = (t - 1, z + dz, y + dy, x + dx)
                    if self.risk_field.in_bounds(p):
                        preds.append(p)
        # wait predecessor
        p = (t - 1, z, y, x)
        if self.risk_field.in_bounds(p) and p not in preds:
            preds.append(p)
        self._predecessor_cache[u] = preds
        return preds

    def edge_cost(self, a: State4D, b: State4D) -> float:
        key = (a, b)
        cached = self._edge_cost_cache.get(key)
        if cached is not None:
            return cached
        if b == VIRTUAL_GOAL:
            self._edge_cost_cache[key] = 0.0
            return 0.0
        if a == VIRTUAL_GOAL:
            self._edge_cost_cache[key] = float("inf")
            return float("inf")
        cost = self.astar_cost.edge_cost(a, b)
        self._edge_cost_cache[key] = cost
        return cost

    def calculate_key(self, u: State4D) -> tuple[float, float]:
        value = min(self._g(u), self._rhs(u))
        return value + self.heuristic_weight * self.heuristic_to_virtual_goal(u), value

    def heuristic_to_virtual_goal(self, u: State4D) -> float:
        if u == VIRTUAL_GOAL:
            return 0.0
        _, z, y, x = u
        gz, gy, gx = self.goal
        return math.sqrt((gx - x) ** 2 + (gy - y) ** 2 + 1.35 * (gz - z) ** 2)

    def _best_predecessor(self, u: State4D) -> State4D | None:
        best_state = None
        best_value = float("inf")
        for pred in self.predecessors(u):
            cost = self.edge_cost(pred, u)
            value = self._g(pred) + cost
            if value < best_value:
                best_state = pred
                best_value = value
        return best_state

    def _virtual_goal_consistent(self) -> bool:
        return self._g(VIRTUAL_GOAL) == self._rhs(VIRTUAL_GOAL)

    def _push(self, u: State4D) -> None:
        key = self.calculate_key(u)
        self.open_keys[u] = key
        heapq.heappush(self.open_heap, (key, u))

    def _affected_nodes_from_changes(self, changed_indices: np.ndarray) -> set[State4D]:
        affected: set[State4D] = set()
        if len(changed_indices) == 0:
            return affected
        for raw in changed_indices:
            state = tuple(int(v) for v in raw)  # type: ignore[assignment]
            if not self.risk_field.in_bounds(state):
                continue
            t, z, y, x = state
            if t < self.start[0] or t > self.max_time:
                continue
            affected.add(state)
            affected.update(self.predecessors(state))
            if (z, y, x) == self.goal:
                affected.add(VIRTUAL_GOAL)
        return affected

    def _g(self, u: State4D) -> float:
        return self.g.get(u, float("inf"))

    def _rhs(self, u: State4D) -> float:
        return self.rhs.get(u, float("inf"))
