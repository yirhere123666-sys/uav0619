from __future__ import annotations

import numpy as np

from uav_weather_planning.data_interface.weather_cube import WeatherCube
from uav_weather_planning.risk_field import RiskField4D
from uav_weather_planning.risk_models import build_risk_field_from_weather


def build_weather_cube(
    variables: dict[str, np.ndarray],
    t_size: int,
    z_size: int,
    y_size: int,
    x_size: int,
    source: str,
    confidence: float | np.ndarray = 0.86,
) -> WeatherCube:
    return WeatherCube(
        time=np.arange(t_size),
        height=np.linspace(0.0, 500.0, z_size),
        y=np.arange(y_size),
        x=np.arange(x_size),
        variables=variables,
        source_metadata={
            "source": source,
            "grid": "local_synthetic",
            "unit": "planning_grid",
            "variables": sorted(variables.keys()),
        },
        confidence=confidence,
    )


def make_multi_risk_weather_cube(
    t_size: int = 56,
    z_size: int = 6,
    y_size: int = 42,
    x_size: int = 42,
    include_dynamic_convection: bool = True,
    include_extreme_tail: bool = True,
) -> WeatherCube:
    """Generate a complete controlled weather sample library case.

    Variables are physically inspired but deterministic, so experiments are
    repeatable and each risk layer can be defended in a midterm review.
    """

    t = np.arange(t_size)[:, None, None, None]
    z = np.arange(z_size)[None, :, None, None]
    yy = np.arange(y_size)[None, None, :, None]
    xx = np.arange(x_size)[None, None, None, :]
    shape = (t_size, z_size, y_size, x_size)

    y_mid = (y_size - 1) / 2.0
    x_mid = (x_size - 1) / 2.0

    base_u = 4.0 + 1.2 * np.sin(t / 8.0) + 0.05 * (xx - x_mid)
    base_v = 1.4 * np.cos(t / 9.0) + 5.5 * np.exp(-((yy - y_mid) ** 2) / (2.0 * 6.0**2))
    base_w = 0.15 * z + 1.1 * np.exp(-((yy - (12 + 0.35 * t)) ** 2) / (2.0 * 5.5**2))
    u = np.broadcast_to(base_u + 0.18 * z, shape).copy()
    v = np.broadcast_to(base_v, shape).copy()
    w = np.broadcast_to(base_w, shape).copy()

    gust_center_y = 8.0 + 0.48 * t
    gust_center_x = 7.0 + 0.52 * t
    gust_patch = np.exp(-(((yy - gust_center_y) ** 2) + ((xx - gust_center_x) ** 2)) / (2.0 * 4.5**2))
    gust = np.broadcast_to(2.5 + 11.0 * gust_patch + 1.0 * np.sin(t / 3.0), shape).copy()

    reflectivity = np.zeros(shape, dtype=float)
    convection_probability = np.zeros(shape, dtype=float)
    rain_rate = np.broadcast_to(0.4 + 3.0 * np.exp(-((xx - 0.65 * x_size) ** 2) / (2.0 * 7.0**2)), shape).copy()
    if include_dynamic_convection:
        for ti in range(t_size):
            # Cross the nominal diagonal route, then move away from the goal.
            # This gives a defensible dynamic-replanning case instead of an
            # impossible mission where the terminal cell becomes permanently
            # no-fly.
            cy = 0.25 * y_size + 0.52 * ti
            cx = 0.66 * x_size - 0.25 * ti
            dist = np.sqrt((np.arange(y_size)[:, None] - cy) ** 2 + (np.arange(x_size)[None, :] - cx) ** 2)
            core = np.exp(-(dist**2) / (2.0 * 4.0**2))
            shield = np.exp(-(dist**2) / (2.0 * 8.0**2))
            for zi in range(z_size):
                vertical_scale = 1.0 - 0.06 * zi
                reflectivity[ti, zi] = np.maximum(reflectivity[ti, zi], 46.0 * core * vertical_scale + 10.0 * shield)
                convection_probability[ti, zi] = np.maximum(convection_probability[ti, zi], 0.92 * core + 0.35 * shield)
                rain_rate[ti, zi] += 22.0 * core + 6.0 * shield

    fog_center_y = 0.72 * y_size - 0.10 * t
    fog_center_x = 0.28 * x_size + 0.08 * t
    fog = np.exp(-(((yy - fog_center_y) ** 2) + ((xx - fog_center_x) ** 2)) / (2.0 * 7.0**2))
    visibility = np.broadcast_to(7.5 - 6.4 * fog, shape).copy()
    ceiling = np.broadcast_to(520.0 - 260.0 * fog + 8.0 * z, shape).copy()
    temperature = np.broadcast_to(18.0 - 0.0065 * (z * 250.0) - 2.5 * fog - 3.5 * (reflectivity > 25), shape).copy()
    relative_humidity = np.clip(np.broadcast_to(62.0 + 34.0 * fog + 22.0 * (reflectivity > 18), shape), 20.0, 100.0)
    pressure = np.broadcast_to(1013.25 * np.exp(-(z * 250.0) / 8434.0), shape).copy()
    dewpoint_spread = np.clip(12.0 * (1.0 - relative_humidity / 100.0), 0.0, 12.0)
    cloud_liquid_water = np.clip(0.08 * fog + 0.65 * (reflectivity / 55.0) + 0.02 * rain_rate, 0.0, 1.6)
    updraft_speed = np.maximum(w, 0.0) + 2.2 * np.clip(convection_probability, 0.0, 1.0)

    if include_extreme_tail:
        # A short-lived tail event used to test CVaR sensitivity.
        event_t = (t >= int(0.55 * t_size)) & (t <= int(0.68 * t_size))
        tail_blob = np.exp(-(((yy - 0.56 * y_size) ** 2) + ((xx - 0.74 * x_size) ** 2)) / (2.0 * 4.0**2))
        gust += np.broadcast_to(event_t * 7.0 * tail_blob, shape)
        visibility -= np.broadcast_to(event_t * 1.7 * tail_blob, shape)

    model_spread = np.broadcast_to(0.10 + 0.22 * gust_patch + 0.25 * (reflectivity > 20), shape).copy()
    confidence = np.clip(1.0 - model_spread, 0.35, 0.95)

    return build_weather_cube(
        variables={
            "u_wind": u,
            "v_wind": v,
            "w_wind": w,
            "gust": gust,
            "reflectivity": reflectivity,
            "convection_probability": convection_probability,
            "rain_rate": rain_rate,
            "visibility": visibility,
            "ceiling": ceiling,
            "temperature": temperature,
            "relative_humidity": relative_humidity,
            "pressure": pressure,
            "dewpoint_spread": dewpoint_spread,
            "cloud_liquid_water": cloud_liquid_water,
            "updraft_speed": updraft_speed,
        },
        t_size=t_size,
        z_size=z_size,
        y_size=y_size,
        x_size=x_size,
        source="synthetic_multi_weather_risk_library",
        confidence=confidence,
    )


def make_multi_risk_risk_field(**kwargs) -> RiskField4D:
    return build_risk_field_from_weather(make_multi_risk_weather_cube(**kwargs))


def make_dynamic_convection_update_pair(**kwargs) -> tuple[RiskField4D, RiskField4D]:
    initial_cube = make_multi_risk_weather_cube(include_dynamic_convection=False, **kwargs)
    updated_cube = make_multi_risk_weather_cube(include_dynamic_convection=True, **kwargs)
    return build_risk_field_from_weather(initial_cube), build_risk_field_from_weather(updated_cube)
