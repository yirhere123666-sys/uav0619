"""Midterm-ready UAV weather-aware path planning package."""

