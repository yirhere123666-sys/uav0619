from __future__ import annotations

from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any


DEFAULT_GRID_HIERARCHY_PATH = Path("configs/grid_hierarchy.yaml")


@dataclass(frozen=True)
class GridLayerSpec:
    role: str
    nominal_xy_resolution_m: float | None = None
    nominal_height_resolution_m: float | None = None
    nominal_time_resolution_s: float | None = None
    altitude_min_m: float | None = None
    altitude_max_m: float | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "GridLayerSpec":
        known = {
            "role",
            "nominal_xy_resolution_m",
            "nominal_height_resolution_m",
            "nominal_time_resolution_s",
            "altitude_min_m",
            "altitude_max_m",
        }
        return cls(
            role=str(data.get("role", "unspecified")),
            nominal_xy_resolution_m=_maybe_float(data.get("nominal_xy_resolution_m")),
            nominal_height_resolution_m=_maybe_float(data.get("nominal_height_resolution_m")),
            nominal_time_resolution_s=_maybe_float(data.get("nominal_time_resolution_s")),
            altitude_min_m=_maybe_float(data.get("altitude_min_m")),
            altitude_max_m=_maybe_float(data.get("altitude_max_m")),
            metadata={key: value for key, value in data.items() if key not in known},
        )

    def as_dict(self) -> dict[str, Any]:
        data = asdict(self)
        metadata = data.pop("metadata")
        return {**data, **metadata}


@dataclass(frozen=True)
class GridHierarchy:
    weather_risk_grid: GridLayerSpec
    global_planning_graph: GridLayerSpec
    motion_validation_grid: GridLayerSpec
    risk_transfer: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "GridHierarchy":
        return cls(
            weather_risk_grid=GridLayerSpec.from_dict(data.get("weather_risk_grid", {})),
            global_planning_graph=GridLayerSpec.from_dict(data.get("global_planning_graph", {})),
            motion_validation_grid=GridLayerSpec.from_dict(data.get("motion_validation_grid", {})),
            risk_transfer=dict(data.get("risk_transfer", {})),
        )

    def as_dict(self) -> dict[str, Any]:
        return {
            "weather_risk_grid": self.weather_risk_grid.as_dict(),
            "global_planning_graph": self.global_planning_graph.as_dict(),
            "motion_validation_grid": self.motion_validation_grid.as_dict(),
            "risk_transfer": dict(self.risk_transfer),
        }


def load_grid_hierarchy(path: str | Path = DEFAULT_GRID_HIERARCHY_PATH) -> GridHierarchy:
    path = Path(path)
    if not path.exists():
        return GridHierarchy.from_dict(_default_hierarchy())
    text = path.read_text(encoding="utf-8")
    return GridHierarchy.from_dict(_load_mapping(text))


def _load_mapping(text: str) -> dict[str, Any]:
    try:
        import yaml
    except ImportError:
        yaml = None
    if yaml is not None:
        data = yaml.safe_load(text) or {}
        if not isinstance(data, dict):
            raise ValueError("grid hierarchy YAML must contain a mapping")
        return data
    return _parse_simple_yaml(text)


def _parse_simple_yaml(text: str) -> dict[str, Any]:
    root: dict[str, Any] = {}
    stack: list[tuple[int, dict[str, Any]]] = [(-1, root)]
    for raw_line in text.splitlines():
        line = raw_line.split("#", 1)[0].rstrip()
        if not line.strip():
            continue
        indent = len(line) - len(line.lstrip(" "))
        key, _, value = line.strip().partition(":")
        while stack and indent <= stack[-1][0]:
            stack.pop()
        parent = stack[-1][1]
        if value.strip():
            parent[key] = _parse_scalar(value.strip())
        else:
            child: dict[str, Any] = {}
            parent[key] = child
            stack.append((indent, child))
    return root


def _parse_scalar(value: str) -> Any:
    if value.lower() in {"true", "false"}:
        return value.lower() == "true"
    try:
        return float(value) if "." in value else int(value)
    except ValueError:
        return value.strip('"').strip("'")


def _maybe_float(value: Any) -> float | None:
    if value is None:
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _default_hierarchy() -> dict[str, Any]:
    return {
        "weather_risk_grid": {
            "role": "regional_background_weather_risk_grid",
            "nominal_xy_resolution_m": 3529.0,
            "nominal_height_resolution_m": 375.0,
            "nominal_time_resolution_s": 3600.0,
            "claim_boundary": "Not a meter-level multirotor control grid.",
        },
        "global_planning_graph": {
            "role": "local_low_altitude_route_graph",
            "nominal_xy_resolution_m": 100.0,
            "nominal_height_resolution_m": 20.0,
            "nominal_time_resolution_s": 15.0,
            "altitude_min_m": 80.0,
            "altitude_max_m": 120.0,
            "max_ground_speed_mps": 15.0,
            "max_climb_rate_mps": 2.0,
            "max_descent_rate_mps": 2.0,
        },
        "motion_validation_grid": {
            "role": "local_trajectory_feasibility_grid",
            "nominal_xy_resolution_m": 20.0,
            "nominal_height_resolution_m": 5.0,
            "control_dt_s": 0.5,
            "horizon_s": 5.0,
            "status": "interface_ready_pre_nmpc",
        },
        "risk_transfer": {},
    }
