from uav_weather_planning.experiments.benchmarks.incremental_search_validation import *  # noqa: F401,F403
from uav_weather_planning.experiments.benchmarks.incremental_search_validation import main as _main
from uav_weather_planning.experiments._compat import run_compat_main


if __name__ == "__main__":
    run_compat_main("uav_weather_planning.experiments.incremental_search_validation", "uav_weather_planning.experiments.benchmarks.incremental_search_validation", _main)
