﻿from __future__ import annotations

from typing import Any

import numpy as np


def coordinate_summary(
    *,
    time: Any,
    height: Any,
    y: Any,
    x: Any,
    source_metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Return a JSON-safe coordinate and resolution summary."""

    source_metadata = source_metadata or {}
    time_arr = np.asarray(time)
    height_arr = np.asarray(height, dtype=float)
    y_arr = np.asarray(y, dtype=float)
    x_arr = np.asarray(x, dtype=float)
    return {
        "shape_order": "(time, height, y, x)",
        "axis_definition": source_metadata.get("geospatial_grid", {}).get(
            "axis_definition",
            {
                "time": source_metadata.get("time_axis_unit", "planning time index"),
                "height": "height coordinate",
                "y": "planning grid y coordinate",
                "x": "planning grid x coordinate",
            },
        ),
        "time": _axis_summary(time_arr, unit=source_metadata.get("time_axis_unit", "index")),
        "height_m": _axis_summary(height_arr, unit="m"),
        "y": _axis_summary(y_arr, unit="m" if _has_metric_grid(source_metadata) else "grid"),
        "x": _axis_summary(x_arr, unit="m" if _has_metric_grid(source_metadata) else "grid"),
        "geospatial_grid": source_metadata.get("geospatial_grid"),
    }


def coordinate_summary_from_cube(cube: Any) -> dict[str, Any]:
    return coordinate_summary(
        time=cube.time,
        height=cube.height,
        y=cube.y,
        x=cube.x,
        source_metadata=getattr(cube, "source_metadata", {}),
    )


def coordinate_summary_from_risk_field(risk_field: Any) -> dict[str, Any]:
    coords = getattr(risk_field, "coords", {})
    return coordinate_summary(
        time=coords.get("time", np.arange(risk_field.t_size)),
        height=coords.get("height", np.arange(risk_field.z_size)),
        y=coords.get("y", np.arange(risk_field.y_size)),
        x=coords.get("x", np.arange(risk_field.x_size)),
        source_metadata=getattr(risk_field, "source_metadata", {}),
    )


def _axis_summary(values: np.ndarray, unit: str) -> dict[str, Any]:
    if values.size == 0:
        return {"count": 0, "unit": unit, "start": None, "end": None, "resolution": None}
    resolution = _resolution(values)
    return {
        "count": int(values.size),
        "unit": unit,
        "start": _json_value(values[0]),
        "end": _json_value(values[-1]),
        "resolution": resolution,
        "sample": [_json_value(v) for v in values[: min(5, values.size)]],
    }


def _resolution(values: np.ndarray) -> Any:
    if values.size <= 1:
        return None
    if np.issubdtype(values.dtype, np.datetime64):
        diffs = np.diff(values).astype("timedelta64[s]").astype(float)
        return float(np.nanmean(diffs))
    try:
        diffs = np.diff(values.astype(float))
    except (TypeError, ValueError):
        return None
    return float(np.nanmean(diffs))


def _json_value(value: Any) -> Any:
    if isinstance(value, np.generic):
        value = value.item()
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace")
    if hasattr(value, "isoformat"):
        return value.isoformat()
    try:
        return float(value)
    except (TypeError, ValueError):
        return str(value)


def _has_metric_grid(source_metadata: dict[str, Any]) -> bool:
    grid = source_metadata.get("geospatial_grid")
    if not isinstance(grid, dict):
        return False
    crs = str(grid.get("crs", "")).upper()
    return "LOCAL" in crs or "METER" in str(grid.get("grid", "")).upper()
