"""Shared utilities for experiment modules."""

