from uav_weather_planning.experiments.smoke.trajectory_control_smoke import *  # noqa: F401,F403
from uav_weather_planning.experiments.smoke.trajectory_control_smoke import main as _main
from uav_weather_planning.experiments._compat import run_compat_main


if __name__ == "__main__":
    run_compat_main("uav_weather_planning.experiments.trajectory_control_smoke", "uav_weather_planning.experiments.smoke.trajectory_control_smoke", _main)
