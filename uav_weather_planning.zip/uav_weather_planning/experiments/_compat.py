from __future__ import annotations

from collections.abc import Callable


def run_compat_main(old_module: str, new_module: str, main: Callable[[], None]) -> None:
    print(f"[compat] {old_module} has moved to {new_module}; forwarding to the new entrypoint.")
    main()

