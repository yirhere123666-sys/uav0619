from uav_weather_planning.experiments.benchmarks.risk_calibration_evidence import *  # noqa: F401,F403
from uav_weather_planning.experiments.benchmarks.risk_calibration_evidence import main as _main
from uav_weather_planning.experiments._compat import run_compat_main


if __name__ == "__main__":
    run_compat_main("uav_weather_planning.experiments.risk_calibration_evidence", "uav_weather_planning.experiments.benchmarks.risk_calibration_evidence", _main)
