from uav_weather_planning.experiments.smoke.paper_10km_smoke_test import *  # noqa: F401,F403
from uav_weather_planning.experiments.smoke.paper_10km_smoke_test import main as _main
from uav_weather_planning.experiments._compat import run_compat_main


if __name__ == "__main__":
    run_compat_main("uav_weather_planning.experiments.paper_10km_smoke_test", "uav_weather_planning.experiments.smoke.paper_10km_smoke_test", _main)
