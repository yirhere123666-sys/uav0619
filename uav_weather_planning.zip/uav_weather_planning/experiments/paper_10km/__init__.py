"""Paper-oriented 10 km 4D risk-field experiment entrypoints."""

