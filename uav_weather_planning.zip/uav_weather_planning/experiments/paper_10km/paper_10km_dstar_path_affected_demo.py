from __future__ import annotations

import argparse
from dataclasses import replace
import json
from pathlib import Path
import time
from typing import Any

import numpy as np

from uav_weather_planning.global_planner import (
    DStarLite4DConfig,
    DStarLite4DPlanner,
    TimeDependentAStar,
    evaluate_path,
)
from uav_weather_planning.preprocessing import PathTargetedWindShearConfig, apply_path_targeted_wind_shear_perturbation
from uav_weather_planning.risk_field.metric_coords import get_time_seconds
from uav_weather_planning.risk_models import build_risk_field_from_weather
from uav_weather_planning.visualization import (
    plot_2d_dstar_path_affected_demo,
    plot_3d_dstar_path_affected_demo,
    plot_changed_voxels_3d,
)

from .paper_common_10km import (
    DEFAULT_CACHE_DIR,
    GOAL_XYZ_M,
    START_XYZ_M,
    cache_key,
    dry_wrf_boundary_note,
    load_or_build_local_cube,
    load_or_build_risk_field,
    local_perturbation_note,
    make_constraints,
    make_fusion_config,
    make_grid_config,
    merge_prefix,
    mission_distance_m,
    mode_settings,
    nearest_feasible_spatial_node,
    nearest_node_by_metric,
    path_from_payload,
    path_intersects_changed,
    path_risk_summary,
    path_to_payload,
    search_bounds_for_mission,
    state_at_or_before,
    write_json,
)


def run_paper_10km_dstar_path_affected_demo(
    *,
    wrf_zip: str | Path,
    output_dir: str | Path = "outputs/paper_figures/dstar_path_affected",
    mode: str = "paper_fast",
    make_plots: bool = True,
    use_cache: bool = False,
    force_rebuild: bool = False,
    cache_dir: str | Path = DEFAULT_CACHE_DIR,
    event_time_s: float = 300.0,
) -> dict[str, Any]:
    start_total = time.perf_counter()
    settings = mode_settings(mode)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    cache_dir = Path(cache_dir)
    grid_config = make_grid_config(settings.name)
    fusion_config = make_fusion_config(settings)
    cube, cube_cache = load_or_build_local_cube(
        wrf_zip=wrf_zip,
        grid_config=grid_config,
        cache_dir=cache_dir,
        use_cache=use_cache,
        force_rebuild=force_rebuild,
    )
    risk_field, risk_cache = load_or_build_risk_field(
        cube=cube,
        fusion_config=fusion_config,
        cache_dir=cache_dir,
        use_cache=use_cache,
        force_rebuild=force_rebuild,
        scenario_tag="paper_10km_dstar_initial",
    )
    start = nearest_feasible_spatial_node(risk_field, nearest_node_by_metric(risk_field, *START_XYZ_M))
    goal = nearest_feasible_spatial_node(risk_field, nearest_node_by_metric(risk_field, *GOAL_XYZ_M))
    constraints = make_constraints()
    mission_distance = mission_distance_m(risk_field, start, goal)
    search_bounds = search_bounds_for_mission(risk_field, start, goal, margin_cells=settings.search_margin_cells)

    original_result = _load_or_plan_path(
        cache_dir=cache_dir,
        cache_tag="dstar_path_affected_original",
        cache_payload={
            "risk_cache": risk_cache["cache_path"],
            "mode": settings.name,
            "start": start,
            "goal": goal,
            "search_bounds": search_bounds,
            "risk_weight": 2.3,
            "cvar_weight": 1.1,
        },
        use_cache=use_cache,
        force_rebuild=force_rebuild,
        planner_factory=lambda: TimeDependentAStar(
            risk_field,
            use_cvar=True,
            risk_weight=2.3,
            cvar_weight=1.1,
            energy_weight=0.25,
            safety_weight=0.18,
            constraints=constraints,
            heuristic_weight=settings.heuristic_weight_risk,
            search_bounds=search_bounds,
        ),
        start=start,
        goal=goal,
    )
    if not original_result.success:
        raise RuntimeError(f"initial path planning failed: {original_result.reason}")
    original_path = original_result.path
    event_index = int(round(event_time_s / float(risk_field.source_metadata.get("time_step_s", 10.0))))
    event_index = int(np.clip(event_index, 0, risk_field.t_size - 1))

    updated_risk_field, changed_voxels, perturbation_metadata, construction = _build_path_affected_update(
        cube=cube,
        initial_risk_field=risk_field,
        original_path=original_path,
        fusion_config=fusion_config,
        event_time_s=event_time_s,
        use_cache=use_cache,
        force_rebuild=force_rebuild,
        cache_dir=cache_dir,
    )
    repair_start = _select_repair_start_from_changed_path(
        original_path,
        changed_voxels,
        default_event_index=event_index,
    )
    repair_changed_voxels = _changed_voxels_near_path(
        changed_voxels,
        original_path,
        start_time_index=repair_start[0],
        radius_cells=3,
        horizon_steps=70,
    )
    dstar_planner = DStarLite4DPlanner(
        risk_field=risk_field,
        constraints=constraints,
        config=DStarLite4DConfig(
            risk_weight=1.0,
            cvar_weight=50.0,
            energy_weight=0.25,
            safety_weight=0.18,
            heuristic_weight=settings.heuristic_weight_risk,
            update_changed_state=True,
            update_changed_predecessors=True,
            update_changed_successors=True,
            skip_unseen_states_for_risk_increase=False,
            max_frontier_update_vertices=200_000,
            search_bounds=search_bounds,
            max_repair_horizon_steps=90,
        ),
    )
    dstar_initial = dstar_planner.initialize_from_path(
        [state for state in original_path if state[0] >= repair_start[0]],
        goal,
        risk_field,
    )
    if not dstar_initial.path:
        raise RuntimeError("D* Lite initial tail search failed at the event trigger state.")
    full_restart_result = TimeDependentAStar(
        updated_risk_field,
        use_cvar=True,
        risk_weight=1.0,
        cvar_weight=50.0,
        energy_weight=0.25,
        safety_weight=0.18,
        constraints=constraints,
        heuristic_weight=settings.heuristic_weight_risk,
        search_bounds=search_bounds,
    ).plan(repair_start, goal, start_time=repair_start[0])
    full_restart_path = merge_prefix(original_path, full_restart_result.path, repair_start)

    dstar_result = dstar_planner.plan_or_repair(
        repair_start,
        new_risk_field=updated_risk_field,
        changed_voxels=repair_changed_voxels,
    )
    dstar_repaired_path = merge_prefix(original_path, dstar_result.path, repair_start)
    original_future = path_risk_summary(original_path, updated_risk_field, start_time_index=repair_start[0])
    dstar_future = path_risk_summary(dstar_repaired_path, updated_risk_field, start_time_index=repair_start[0])
    full_future = path_risk_summary(full_restart_path, updated_risk_field, start_time_index=repair_start[0])

    if (
        not dstar_result.success
        or _has_safety_violation(dstar_repaired_path, updated_risk_field, constraints)
        or (
            not _risk_improves(original_future, dstar_future)
            and _risk_improves(original_future, full_future)
        )
    ):
        selected_path = full_restart_path
        fallback_used = True
    else:
        selected_path = dstar_repaired_path
        fallback_used = False

    repaired_future = path_risk_summary(selected_path, updated_risk_field, start_time_index=repair_start[0])
    dstar_metrics = evaluate_path(
        "D* Lite 四维增量修复",
        selected_path,
        updated_risk_field,
        nodes_expanded=dstar_result.nodes_expanded_incremental,
        elapsed_ms=dstar_result.elapsed_ms,
        replan_count=1 if dstar_result.success else 0,
        constraints=constraints,
    ).as_row()
    full_restart_metrics = evaluate_path(
        "全局重搜修复基线",
        full_restart_path,
        updated_risk_field,
        nodes_expanded=full_restart_result.nodes_expanded,
        elapsed_ms=full_restart_result.elapsed_ms,
        replan_count=1 if full_restart_result.success else 0,
        constraints=constraints,
    ).as_row()

    full_restart_elapsed = float(full_restart_result.elapsed_ms)
    incremental_elapsed = float(dstar_result.elapsed_ms)
    speedup_ratio = None if incremental_elapsed <= 0.0 else round(full_restart_elapsed / incremental_elapsed, 6)
    path_affected = path_intersects_changed(original_path, repair_changed_voxels, start_time_index=repair_start[0])

    figure_summaries: dict[str, Any] = {}
    if make_plots:
        figure_summaries["changed_voxels_replanning"] = plot_changed_voxels_3d(
            updated_risk_field,
            repair_changed_voxels,
            output_dir / "paper_3d_changed_voxels_replanning_trigger.png",
            original_path=original_path,
            repaired_path=selected_path,
            trigger_state=repair_start,
            event_reason="路径未来段风切变/阵风风险升高",
            repair_mode="incremental_dstar_lite",
            planner_name="dstar_lite_4d",
            speedup_ratio=speedup_ratio,
            perturbation_metadata=perturbation_metadata,
        )
        figure_summaries["dstar_path_affected_2d"] = plot_2d_dstar_path_affected_demo(
            updated_risk_field,
            repair_changed_voxels,
            output_dir / "paper_2d_dstar_path_affected_demo.png",
            original_path=original_path,
            repaired_path=selected_path,
            trigger_state=repair_start,
            perturbation_metadata=perturbation_metadata,
        )
        figure_summaries["dstar_path_affected_3d"] = plot_3d_dstar_path_affected_demo(
            updated_risk_field,
            repair_changed_voxels,
            output_dir / "paper_3d_dstar_path_affected_demo.png",
            original_path=original_path,
            repaired_path=selected_path,
            trigger_state=repair_start,
            speedup_ratio=speedup_ratio,
            perturbation_metadata=perturbation_metadata,
        )

    total_elapsed_ms = round((time.perf_counter() - start_total) * 1000.0, 3)
    summary = {
        "experiment": "paper_10km_dstar_path_affected_demo",
        "mode": settings.name,
        "validation_level": "正式定量指标" if settings.quantitative else "快速可视化 / 冒烟验证（Smoke Validation）",
        "planner_name": "dstar_lite_4d",
        "repair_mode": "incremental_dstar_lite",
        "wrf_source": str(wrf_zip),
        "wrf_boundary_note": dry_wrf_boundary_note(),
        "local_perturbation_note": local_perturbation_note(),
        "synthetic_local_perturbation": True,
        "perturbation_type": "path_targeted_wind_shear_gust",
        "mission": {
            "start_xyz_m": list(START_XYZ_M),
            "goal_xyz_m": list(GOAL_XYZ_M),
            "start_state": list(start),
            "goal_state": list(goal),
            "mission_distance_m": round(mission_distance, 3),
        },
        "local_planning_grid": risk_field.source_metadata.get("local_planning_grid"),
        "background_weather_grid": risk_field.source_metadata.get("background_weather_grid"),
        "background_valid_times": risk_field.source_metadata.get("background_valid_times"),
        "risk_shape": list(risk_field.shape),
        "constraints": constraints.as_dict(),
        "monte_carlo_samples": settings.monte_carlo_samples,
        "cvar_chunk_size": settings.cvar_chunk_voxels,
        "cvar_elapsed_ms": updated_risk_field.channel_metadata.get("cvar_elapsed_ms"),
        "risk_field_build_elapsed_ms": risk_cache.get("elapsed_ms"),
        "updated_risk_field_build_elapsed_ms": construction.get("updated_risk_field_build_elapsed_ms"),
        "total_no_plots_elapsed_ms": total_elapsed_ms if not make_plots else None,
        "total_elapsed_ms": total_elapsed_ms,
        "planner_search_bounds_enabled": True,
        "search_bounds_cells": search_bounds,
        "search_bounds_m": _bounds_to_meters(updated_risk_field, search_bounds),
        "path_affected": bool(path_affected),
        "changed_voxel_count": int(np.sum(repair_changed_voxels)),
        "changed_voxel_ratio": round(float(np.mean(repair_changed_voxels)), 6),
        "global_significant_changed_voxel_count": int(np.sum(changed_voxels)),
        "global_significant_changed_voxel_ratio": round(float(np.mean(changed_voxels)), 6),
        "repair_local_changed_voxel_count": int(np.sum(repair_changed_voxels)),
        "repair_local_changed_voxel_ratio": round(float(np.mean(repair_changed_voxels)), 6),
        "affected_state_count": int(dstar_result.affected_state_count),
        "update_vertex_count": int(dstar_result.update_vertex_count),
        "compute_shortest_path_iterations": int(dstar_result.compute_shortest_path_iterations),
        "g_rhs_reused": bool(dstar_result.g_rhs_reused),
        "queue_reused": bool(dstar_result.queue_reused),
        "incremental_reuse_valid": bool(dstar_result.incremental_reuse_valid),
        "reinitialize_reason": dstar_result.reinitialize_reason,
        "nodes_expanded_incremental": int(dstar_result.nodes_expanded_incremental),
        "nodes_expanded_full_restart": int(full_restart_result.nodes_expanded),
        "elapsed_ms_incremental": round(incremental_elapsed, 3),
        "elapsed_ms_full_restart": round(full_restart_elapsed, 3),
        "speedup_ratio": speedup_ratio,
        "fallback_used": fallback_used,
        "original_future_expected_risk": original_future["expected_risk"],
        "repaired_expected_risk": repaired_future["expected_risk"],
        "full_restart_expected_risk": full_future["expected_risk"],
        "original_future_cvar_risk": original_future["cvar_risk"],
        "repaired_cvar_risk": repaired_future["cvar_risk"],
        "full_restart_cvar_risk": full_future["cvar_risk"],
        "original_future_max_violation_probability": original_future["max_violation_probability"],
        "repaired_max_violation_probability": repaired_future["max_violation_probability"],
        "full_restart_max_violation_probability": full_future["max_violation_probability"],
        "no_fly_violations_incremental": dstar_metrics.get("no_fly_violations"),
        "constraint_violations_incremental": dstar_metrics.get("constraint_violations"),
        "no_fly_violations_full_restart": full_restart_metrics.get("no_fly_violations"),
        "constraint_violations_full_restart": full_restart_metrics.get("constraint_violations"),
        "event_time_s": get_time_seconds(updated_risk_field.coords, repair_start[0]),
        "repair_start_state": list(repair_start),
        "construction": construction,
        "perturbation": perturbation_metadata,
        "cache": {"local_cube": cube_cache, "initial_risk_field": risk_cache},
        "figure_summaries": figure_summaries,
        "outputs": _expected_outputs(make_plots),
    }
    write_json(output_dir / "paper_summary.json", summary)
    _write_markdown(output_dir / "paper_summary.md", summary)
    _run_acceptance_checks(summary, output_dir if make_plots else None)
    return summary


def _build_path_affected_update(
    *,
    cube,
    initial_risk_field,
    original_path,
    fusion_config,
    event_time_s: float,
    use_cache: bool,
    force_rebuild: bool,
    cache_dir: Path,
) -> tuple[Any, np.ndarray, dict[str, Any], dict[str, Any]]:
    attempts = []
    base_config = PathTargetedWindShearConfig(
        event_time_s=event_time_s,
        perturbation_start_s=event_time_s + 60.0,
        perturbation_end_s=event_time_s + 420.0,
        gust_peak_time_s=event_time_s + 180.0,
        gust_strength_mps=12.0,
        shear_strength_mps=8.2,
        gust_radius_m=1050.0,
        shear_band_width_m=820.0,
        shear_band_length_m=2600.0,
    )
    for attempt in range(4):
        config = replace(
            base_config,
            gust_strength_mps=base_config.gust_strength_mps + 2.0 * attempt,
            shear_strength_mps=base_config.shear_strength_mps + 1.4 * attempt,
            gust_radius_m=base_config.gust_radius_m + 180.0 * attempt,
            shear_band_width_m=base_config.shear_band_width_m + 120.0 * attempt,
        )
        perturbed_cube, metadata = apply_path_targeted_wind_shear_perturbation(
            cube,
            original_path,
            event_time_s=event_time_s,
            config=config,
        )
        start = time.perf_counter()
        tag = cache_key("dstar_path_targeted_update", {"attempt": attempt, "metadata": metadata})
        updated_field, update_cache = load_or_build_risk_field(
            cube=perturbed_cube,
            fusion_config=fusion_config,
            cache_dir=cache_dir,
            use_cache=use_cache,
            force_rebuild=force_rebuild,
            scenario_tag=tag,
        )
        changed = initial_risk_field.significant_changed_voxels(updated_field)
        event_index = int(round(event_time_s / float(initial_risk_field.source_metadata.get("time_step_s", 10.0))))
        affected = path_intersects_changed(original_path, changed, start_time_index=event_index)
        attempts.append(
            {
                "attempt": attempt + 1,
                "path_affected": bool(affected),
                "changed_voxel_count": int(np.sum(changed)),
                "changed_voxel_ratio": round(float(np.mean(changed)), 6),
                "gust_strength_mps": config.gust_strength_mps,
                "shear_strength_mps": config.shear_strength_mps,
                "gust_radius_m": config.gust_radius_m,
                "updated_risk_field_build_elapsed_ms": round((time.perf_counter() - start) * 1000.0, 3),
                "cache": update_cache,
            }
        )
        if affected:
            construction = {
                "success": True,
                "attempts": attempts,
                "updated_risk_field_build_elapsed_ms": attempts[-1]["updated_risk_field_build_elapsed_ms"],
                "path_aware_placement": True,
            }
            return updated_field, changed, metadata, construction
    construction = {
        "success": False,
        "attempts": attempts,
        "updated_risk_field_build_elapsed_ms": attempts[-1]["updated_risk_field_build_elapsed_ms"] if attempts else None,
        "path_aware_placement": True,
    }
    return updated_field, changed, metadata, construction  # type: ignore[possibly-undefined]


def _changed_voxels_near_path(
    changed_voxels: np.ndarray,
    path,
    *,
    start_time_index: int,
    radius_cells: int = 3,
    horizon_steps: int = 70,
) -> np.ndarray:
    changed = np.asarray(changed_voxels, dtype=bool)
    local = np.zeros_like(changed, dtype=bool)
    if not path:
        return local
    end_time = start_time_index + int(horizon_steps)
    radius = max(0, int(radius_cells))
    for state in path:
        t, z, y, x = state
        if t < start_time_index or t > end_time:
            continue
        t0 = max(0, t - 1)
        t1 = min(changed.shape[0], t + 3)
        z0 = max(0, z - 1)
        z1 = min(changed.shape[1], z + 2)
        y0 = max(0, y - radius)
        y1 = min(changed.shape[2], y + radius + 1)
        x0 = max(0, x - radius)
        x1 = min(changed.shape[3], x + radius + 1)
        local[t0:t1, z0:z1, y0:y1, x0:x1] |= changed[t0:t1, z0:z1, y0:y1, x0:x1]
    if not np.any(local):
        # Keep the repair event meaningful even if thresholded changes barely
        # miss the discrete path states.
        for state in path:
            t, z, y, x = state
            if t < start_time_index or t > end_time:
                continue
            if 0 <= t < local.shape[0] and 0 <= z < local.shape[1] and 0 <= y < local.shape[2] and 0 <= x < local.shape[3]:
                local[t, z, y, x] = True
    return local


def _select_repair_start_from_changed_path(
    path,
    changed_voxels: np.ndarray,
    *,
    default_event_index: int,
) -> tuple[int, int, int, int]:
    changed = np.asarray(changed_voxels, dtype=bool)
    changed_states = [
        state
        for state in path
        if state[0] >= default_event_index
        and 0 <= state[0] < changed.shape[0]
        and 0 <= state[1] < changed.shape[1]
        and 0 <= state[2] < changed.shape[2]
        and 0 <= state[3] < changed.shape[3]
        and changed[state]
    ]
    if not changed_states:
        return state_at_or_before(path, default_event_index)
    first_changed = changed_states[0]
    trigger_index = max(default_event_index, first_changed[0] - 1)
    return state_at_or_before(path, trigger_index)


def _load_or_plan_path(
    *,
    cache_dir: Path,
    cache_tag: str,
    cache_payload: dict[str, Any],
    use_cache: bool,
    force_rebuild: bool,
    planner_factory,
    start,
    goal,
):
    key = cache_key(cache_tag, cache_payload)
    path = cache_dir / f"{key}.json"
    if use_cache and not force_rebuild and path.exists():
        payload = json.loads(path.read_text(encoding="utf-8"))
        result = planner_factory().plan(start, goal)
        result.path = path_from_payload(payload["path"])
        result.success = bool(result.path)
        result.nodes_expanded = int(payload.get("nodes_expanded", result.nodes_expanded))
        result.elapsed_ms = float(payload.get("elapsed_ms", result.elapsed_ms))
        result.total_cost = float(payload.get("total_cost", result.total_cost))
        return result
    result = planner_factory().plan(start, goal)
    if use_cache and result.success:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(
            json.dumps(
                {
                    "path": path_to_payload(result.path),
                    "nodes_expanded": result.nodes_expanded,
                    "elapsed_ms": result.elapsed_ms,
                    "total_cost": result.total_cost,
                },
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )
    return result


def _has_safety_violation(path, risk_field, constraints) -> bool:
    metrics = evaluate_path(
        "safety audit",
        path,
        risk_field,
        nodes_expanded=0,
        elapsed_ms=0.0,
        constraints=constraints,
    ).as_row()
    return bool(metrics.get("no_fly_violations", 0) or metrics.get("constraint_violations", 0))


def _risk_improves(original: dict[str, Any], candidate: dict[str, Any], *, tolerance: float = 1e-6) -> bool:
    pairs = [
        ("expected_risk", 0.05),
        ("cvar_risk", 0.01),
        ("max_violation_probability", 0.01),
    ]
    for key, min_delta in pairs:
        left = original.get(key)
        right = candidate.get(key)
        if left is None or right is None:
            continue
        if float(right) < float(left) - max(float(min_delta), tolerance):
            return True
    return False


def _bounds_to_meters(risk_field, bounds: dict[str, tuple[int, int]]) -> dict[str, list[float]]:
    y_axis = np.asarray(risk_field.coords["y"], dtype=float)
    x_axis = np.asarray(risk_field.coords["x"], dtype=float)
    z_axis = np.asarray(risk_field.coords["height"], dtype=float)
    return {
        "x": [float(x_axis[bounds["x"][0]]), float(x_axis[bounds["x"][1]])],
        "y": [float(y_axis[bounds["y"][0]]), float(y_axis[bounds["y"][1]])],
        "height": [float(z_axis[bounds["z"][0]]), float(z_axis[bounds["z"][1]])],
    }


def _expected_outputs(make_plots: bool) -> list[str]:
    base = ["paper_summary.json", "paper_summary.md"]
    if not make_plots:
        return base
    return [
        "paper_3d_changed_voxels_replanning_trigger.png",
        "paper_2d_dstar_path_affected_demo.png",
        "paper_3d_dstar_path_affected_demo.png",
        *base,
    ]


def _write_markdown(path: Path, summary: dict[str, Any]) -> None:
    text = f"""# D* Lite 路径受影响重规划实验摘要

- 实验模式：{summary['mode']}。
- 验证级别：{summary['validation_level']}。
- WRF 边界说明：{summary['wrf_boundary_note']}
- 局地扰动说明：{summary['local_perturbation_note']}
- 主实验最大垂直速度：上升 {summary['constraints'].get('max_climb_rate_mps')} m/s，下降 {summary['constraints'].get('max_descent_rate_mps')} m/s。
- Monte Carlo 样本数：{summary['monte_carlo_samples']}。
- CVaR 分块体素数：{summary['cvar_chunk_size']}。
- 任务距离：{summary['mission']['mission_distance_m']} m。
- 路径是否受影响：{summary['path_affected']}。
- D* Lite 状态复用：g/rhs={summary['g_rhs_reused']}，queue={summary['queue_reused']}。
- compute_shortest_path_iterations：{summary['compute_shortest_path_iterations']}。
- affected_state_count：{summary['affected_state_count']}。
- update_vertex_count：{summary['update_vertex_count']}。
- changed_voxel_count：{summary['changed_voxel_count']}。
- 增量修复耗时：{summary['elapsed_ms_incremental']} ms。
- 全局重搜耗时：{summary['elapsed_ms_full_restart']} ms。
- 加速比：{summary['speedup_ratio']}。

## 风险改善

- 原路径未来段期望风险：{summary['original_future_expected_risk']}。
- 修复路径期望风险：{summary['repaired_expected_risk']}。
- 原路径未来段 CVaR：{summary['original_future_cvar_risk']}。
- 修复路径 CVaR：{summary['repaired_cvar_risk']}。
- 原路径最大违反概率：{summary['original_future_max_violation_probability']}。
- 修复路径最大违反概率：{summary['repaired_max_violation_probability']}。

## 结论口径

WRF 是背景气象场；局地风切变和阵风扰动是 synthetic_local_perturbation。该场景用于验证 D* Lite 动态重规划机制，强降水、强对流、低能见度在当前 WRF 个例中不是主要真实背景证据。
"""
    path.write_text(text, encoding="utf-8")


def _run_acceptance_checks(summary: dict[str, Any], output_dir: Path | None) -> None:
    assert summary["constraints"]["max_climb_rate_mps"] == 2.0
    assert summary["constraints"]["max_descent_rate_mps"] == 2.0
    assert summary["monte_carlo_samples"] in {2, 16, 32}
    assert summary["changed_voxel_count"] > 0
    assert summary["path_affected"] is True
    assert summary["g_rhs_reused"] is True
    assert summary["queue_reused"] is True
    assert summary["affected_state_count"] > 0
    assert summary["update_vertex_count"] > 0
    assert summary["compute_shortest_path_iterations"] > 0
    if summary["original_future_cvar_risk"] is not None and summary["repaired_cvar_risk"] is not None:
        assert summary["original_future_cvar_risk"] >= summary["repaired_cvar_risk"]
    if output_dir is not None:
        for name in [
            "paper_3d_changed_voxels_replanning_trigger.png",
            "paper_2d_dstar_path_affected_demo.png",
            "paper_3d_dstar_path_affected_demo.png",
        ]:
            file_path = output_dir / name
            assert file_path.exists() and file_path.stat().st_size > 0, name


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--wrf-zip", required=True)
    parser.add_argument("--output-dir", default="outputs/paper_figures/dstar_path_affected")
    parser.add_argument("--mode", choices=["smoke", "paper_fast", "paper_quantitative"], default="paper_fast")
    parser.add_argument("--no-plots", action="store_true")
    parser.add_argument("--plots", action="store_true")
    parser.add_argument("--use-cache", action="store_true")
    parser.add_argument("--force-rebuild", action="store_true")
    parser.add_argument("--cache-dir", default=str(DEFAULT_CACHE_DIR))
    args = parser.parse_args()
    make_plots = args.plots or not args.no_plots
    summary = run_paper_10km_dstar_path_affected_demo(
        wrf_zip=args.wrf_zip,
        output_dir=args.output_dir,
        mode=args.mode,
        make_plots=make_plots,
        use_cache=args.use_cache,
        force_rebuild=args.force_rebuild,
        cache_dir=args.cache_dir,
    )
    print("Paper 10 km D* Lite path-affected demo finished.")
    print(
        json.dumps(
            {
                "mode": summary["mode"],
                "path_affected": summary["path_affected"],
                "changed_voxel_count": summary["changed_voxel_count"],
                "compute_shortest_path_iterations": summary["compute_shortest_path_iterations"],
                "elapsed_ms_incremental": summary["elapsed_ms_incremental"],
                "elapsed_ms_full_restart": summary["elapsed_ms_full_restart"],
                "speedup_ratio": summary["speedup_ratio"],
                "original_future_cvar_risk": summary["original_future_cvar_risk"],
                "repaired_cvar_risk": summary["repaired_cvar_risk"],
                "outputs": summary["outputs"],
            },
            ensure_ascii=False,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
