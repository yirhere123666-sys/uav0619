from __future__ import annotations

from dataclasses import asdict, dataclass
import hashlib
import json
from pathlib import Path
import time
from typing import Any

import numpy as np

from uav_weather_planning.data_interface import WRFLoader, WRFLoaderConfig
from uav_weather_planning.data_interface.weather_cube import WeatherCube
from uav_weather_planning.global_planner import FlightConstraints
from uav_weather_planning.preprocessing import LocalPlanningGridConfig, normalize_weather_cube_to_local_planning_grid
from uav_weather_planning.risk_field import RiskField4D
from uav_weather_planning.risk_field.metric_coords import get_time_seconds
from uav_weather_planning.risk_field.risk_field_4d import SpatialNode, State4D
from uav_weather_planning.risk_models import RiskFusionConfig, build_risk_field_from_weather


START_XYZ_M = (1000.0, 1000.0, 100.0)
GOAL_XYZ_M = (10500.0, 4000.0, 120.0)
DEFAULT_CACHE_DIR = Path("_paper_cache")


@dataclass(frozen=True)
class PaperModeSettings:
    name: str
    monte_carlo_samples: int
    cvar_chunk_voxels: int
    heuristic_weight_baseline: float
    heuristic_weight_risk: float
    search_margin_cells: int
    quantitative: bool


MODE_SETTINGS: dict[str, PaperModeSettings] = {
    "smoke": PaperModeSettings(
        name="smoke",
        monte_carlo_samples=2,
        cvar_chunk_voxels=260_000,
        heuristic_weight_baseline=4.8,
        heuristic_weight_risk=10.0,
        search_margin_cells=14,
        quantitative=False,
    ),
    "paper_fast": PaperModeSettings(
        name="paper_fast",
        monte_carlo_samples=16,
        cvar_chunk_voxels=180_000,
        heuristic_weight_baseline=4.8,
        heuristic_weight_risk=10.0,
        search_margin_cells=18,
        quantitative=True,
    ),
    "paper_quantitative": PaperModeSettings(
        name="paper_quantitative",
        monte_carlo_samples=32,
        cvar_chunk_voxels=120_000,
        heuristic_weight_baseline=4.8,
        heuristic_weight_risk=10.0,
        search_margin_cells=22,
        quantitative=True,
    ),
}


def mode_settings(mode: str) -> PaperModeSettings:
    try:
        return MODE_SETTINGS[mode]
    except KeyError as exc:
        raise ValueError(f"unknown mode: {mode}") from exc


def make_grid_config(mode: str | None = None) -> LocalPlanningGridConfig:
    xy_resolution_m = 150.0 if mode == "smoke" else 100.0
    return LocalPlanningGridConfig(
        x_extent_m=12000.0,
        y_extent_m=12000.0,
        xy_resolution_m=xy_resolution_m,
        height_levels_m=(60.0, 80.0, 100.0, 120.0, 140.0, 160.0, 180.0),
        dt_s=10.0,
        horizon_s=1200.0,
    )


def make_fusion_config(settings: PaperModeSettings) -> RiskFusionConfig:
    return RiskFusionConfig(
        monte_carlo_samples=settings.monte_carlo_samples,
        cvar_chunk_voxels=settings.cvar_chunk_voxels,
    )


def make_constraints() -> FlightConstraints:
    return FlightConstraints(
        max_horizontal_step_cells=1.5,
        max_vertical_step_layers=1,
        max_turn_angle_deg=150.0,
        enforce_metric_limits=True,
        max_ground_speed_mps=15.0,
        max_climb_rate_mps=2.0,
        max_descent_rate_mps=2.0,
        max_yaw_rate_deg_s=45.0,
        max_acceleration_mps2=4.0,
        min_altitude_m=60.0,
        max_altitude_m=180.0,
        airspace=None,
        corridor_required=False,
    )


def search_bounds_for_mission(
    risk_field: RiskField4D,
    start: SpatialNode,
    goal: SpatialNode,
    *,
    margin_cells: int,
) -> dict[str, tuple[int, int]]:
    z0, y0, x0 = start
    z1, y1, x1 = goal
    return {
        "z": (0, risk_field.z_size - 1),
        "y": (
            int(max(0, min(y0, y1) - margin_cells)),
            int(min(risk_field.y_size - 1, max(y0, y1) + margin_cells)),
        ),
        "x": (
            int(max(0, min(x0, x1) - margin_cells)),
            int(min(risk_field.x_size - 1, max(x0, x1) + margin_cells)),
        ),
    }


def load_or_build_local_cube(
    *,
    wrf_zip: str | Path,
    grid_config: LocalPlanningGridConfig,
    cache_dir: str | Path = DEFAULT_CACHE_DIR,
    use_cache: bool = False,
    force_rebuild: bool = False,
) -> tuple[WeatherCube, dict[str, Any]]:
    cache_dir = Path(cache_dir)
    key = cache_key(
        "local_cube",
        {
            "wrf": _file_fingerprint(wrf_zip),
            "grid": grid_config.as_dict(),
        },
    )
    path = cache_dir / f"{key}.npz"
    start = time.perf_counter()
    if use_cache and not force_rebuild and path.exists():
        cube = WeatherCube.from_npz(path)
        return cube, {"cache_hit": True, "cache_path": str(path), "elapsed_ms": _elapsed_ms(start)}
    raw_cube = WRFLoader().load(WRFLoaderConfig(path=wrf_zip))
    cube = normalize_weather_cube_to_local_planning_grid(raw_cube, grid_config)
    if use_cache:
        cube.to_npz(path)
    return cube, {"cache_hit": False, "cache_path": str(path), "elapsed_ms": _elapsed_ms(start)}


def load_or_build_risk_field(
    *,
    cube: WeatherCube,
    fusion_config: RiskFusionConfig,
    cache_dir: str | Path = DEFAULT_CACHE_DIR,
    use_cache: bool = False,
    force_rebuild: bool = False,
    scenario_tag: str = "paper_10km",
) -> tuple[RiskField4D, dict[str, Any]]:
    cache_dir = Path(cache_dir)
    key = cache_key(
        "risk_field",
        {
            "scenario_tag": scenario_tag,
            "local_grid": cube.source_metadata.get("local_planning_grid"),
            "background_source": cube.source_metadata.get("background_source"),
            "background_valid_times": cube.source_metadata.get("background_valid_times"),
            "perturbation_config_hash": cache_key("perturbation", cube.source_metadata.get("local_short_time_perturbation", {})),
            "risk_fusion_config_hash": cache_key("risk_fusion", asdict(fusion_config)),
            "monte_carlo_samples": fusion_config.monte_carlo_samples,
            "cvar_chunk_voxels": fusion_config.cvar_chunk_voxels,
        },
    )
    path = cache_dir / f"{key}.npz"
    start = time.perf_counter()
    if use_cache and not force_rebuild and path.exists():
        field = load_risk_field_npz(path)
        return field, {"cache_hit": True, "cache_path": str(path), "elapsed_ms": _elapsed_ms(start)}
    field = build_risk_field_from_weather(cube, fusion_config)
    if use_cache:
        save_risk_field_npz(field, path)
    return field, {"cache_hit": False, "cache_path": str(path), "elapsed_ms": _elapsed_ms(start)}


def save_risk_field_npz(field: RiskField4D, path: str | Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    arrays = {
        "expected_cost": field.expected_cost.astype(np.float32),
        "no_fly_mask": field.no_fly_mask.astype(np.bool_),
        "uncertainty": field.uncertainty.astype(np.float32),
        "cvar_cost": field.cvar_cost.astype(np.float32),
        "wind_risk": field.wind_risk.astype(np.float32),
        "gust_risk": field.gust_risk.astype(np.float32),
        "shear_risk": field.shear_risk.astype(np.float32),
        "turbulence_risk": field.turbulence_risk.astype(np.float32),
        "shear_turbulence_risk": field.shear_turbulence_risk.astype(np.float32),
        "convection_risk": field.convection_risk.astype(np.float32),
        "visibility_risk": field.visibility_risk.astype(np.float32),
        "precipitation_risk": field.precipitation_risk.astype(np.float32),
        "total_cost": field.total_cost.astype(np.float32),
        "wind_u": field.wind_u.astype(np.float32),
        "wind_v": field.wind_v.astype(np.float32),
        "wind_w": field.wind_w.astype(np.float32),
        "ground_speed_effect": field.ground_speed_effect.astype(np.float32),
        "energy_penalty": field.energy_penalty.astype(np.float32),
        "violation_probability": field.violation_probability.astype(np.float32),
        "joint_risk": field.joint_risk.astype(np.float32),
        "fatal_score": field.fatal_score.astype(np.float32),
        "cumulative_score": field.cumulative_score.astype(np.float32),
        "weighted_soft_cost": field.weighted_soft_cost.astype(np.float32),
        "time": np.asarray(field.coords["time"]),
        "height": np.asarray(field.coords["height"], dtype=np.float32),
        "y": np.asarray(field.coords["y"], dtype=np.float32),
        "x": np.asarray(field.coords["x"], dtype=np.float32),
        "confidence": field.confidence.astype(np.float32) if isinstance(field.confidence, np.ndarray) else np.asarray(field.confidence),
        "metadata_json": np.asarray(json.dumps(field.metadata, ensure_ascii=False)),
        "source_metadata_json": np.asarray(json.dumps(_jsonable(field.source_metadata), ensure_ascii=False)),
        "channel_metadata_json": np.asarray(json.dumps(_jsonable(field.channel_metadata), ensure_ascii=False)),
    }
    np.savez_compressed(path, **arrays)


def load_risk_field_npz(path: str | Path) -> RiskField4D:
    data = np.load(Path(path), allow_pickle=True)
    return RiskField4D(
        expected_cost=data["expected_cost"],
        no_fly_mask=data["no_fly_mask"].astype(bool),
        uncertainty=data["uncertainty"],
        cvar_cost=data["cvar_cost"],
        wind_risk=data["wind_risk"],
        gust_risk=data["gust_risk"],
        shear_risk=data["shear_risk"],
        turbulence_risk=data["turbulence_risk"],
        shear_turbulence_risk=data["shear_turbulence_risk"],
        convection_risk=data["convection_risk"],
        visibility_risk=data["visibility_risk"],
        precipitation_risk=data["precipitation_risk"],
        total_cost=data["total_cost"],
        wind_u=data["wind_u"],
        wind_v=data["wind_v"],
        wind_w=data["wind_w"],
        ground_speed_effect=data["ground_speed_effect"],
        energy_penalty=data["energy_penalty"],
        violation_probability=data["violation_probability"],
        joint_risk=data["joint_risk"],
        fatal_score=data["fatal_score"],
        cumulative_score=data["cumulative_score"],
        weighted_soft_cost=data["weighted_soft_cost"],
        coords={"time": data["time"], "height": data["height"], "y": data["y"], "x": data["x"]},
        confidence=data["confidence"],
        metadata=json.loads(str(data["metadata_json"])),
        source_metadata=json.loads(str(data["source_metadata_json"])),
        channel_metadata=json.loads(str(data["channel_metadata_json"])),
    )


def cache_key(prefix: str, payload: Any) -> str:
    text = json.dumps(_jsonable(payload), sort_keys=True, ensure_ascii=False)
    return f"{prefix}_{hashlib.sha256(text.encode('utf-8')).hexdigest()[:16]}"


def nearest_node_by_metric(risk_field: RiskField4D, x_m: float, y_m: float, z_m: float) -> SpatialNode:
    heights = np.asarray(risk_field.coords.get("height", np.arange(risk_field.z_size)), dtype=float)
    y_axis = np.asarray(risk_field.coords.get("y", np.arange(risk_field.y_size)), dtype=float)
    x_axis = np.asarray(risk_field.coords.get("x", np.arange(risk_field.x_size)), dtype=float)
    return (
        int(np.argmin(np.abs(heights - z_m))),
        int(np.argmin(np.abs(y_axis - y_m))),
        int(np.argmin(np.abs(x_axis - x_m))),
    )


def nearest_feasible_spatial_node(risk_field: RiskField4D, node: SpatialNode, max_radius: int = 4) -> SpatialNode:
    if risk_field.in_bounds((0, *node)) and not risk_field.is_no_fly((0, *node)):
        return node
    z0, y0, x0 = node
    for radius in range(1, max_radius + 1):
        for dz in range(-1, 2):
            for dy in range(-radius, radius + 1):
                for dx in range(-radius, radius + 1):
                    z = int(np.clip(z0 + dz, 0, risk_field.z_size - 1))
                    y = int(np.clip(y0 + dy, 0, risk_field.y_size - 1))
                    x = int(np.clip(x0 + dx, 0, risk_field.x_size - 1))
                    candidate = (z, y, x)
                    if not risk_field.is_no_fly((0, *candidate)):
                        return candidate
    return node


def mission_distance_m(risk_field: RiskField4D, start: SpatialNode, goal: SpatialNode) -> float:
    x_axis = np.asarray(risk_field.coords["x"], dtype=float)
    y_axis = np.asarray(risk_field.coords["y"], dtype=float)
    z_axis = np.asarray(risk_field.coords["height"], dtype=float)
    z0, y0, x0 = start
    z1, y1, x1 = goal
    return float(np.sqrt((x_axis[x1] - x_axis[x0]) ** 2 + (y_axis[y1] - y_axis[y0]) ** 2 + (z_axis[z1] - z_axis[z0]) ** 2))


def copy_risk_field(field: RiskField4D) -> RiskField4D:
    return RiskField4D(
        expected_cost=field.expected_cost.copy(),
        no_fly_mask=field.no_fly_mask.copy(),
        uncertainty=field.uncertainty.copy(),
        cvar_cost=field.cvar_cost.copy(),
        wind_risk=field.wind_risk.copy(),
        shear_turbulence_risk=field.shear_turbulence_risk.copy(),
        convection_risk=field.convection_risk.copy(),
        visibility_risk=field.visibility_risk.copy(),
        precipitation_risk=field.precipitation_risk.copy(),
        gust_risk=field.gust_risk.copy(),
        shear_risk=field.shear_risk.copy(),
        turbulence_risk=field.turbulence_risk.copy(),
        total_cost=field.total_cost.copy(),
        wind_u=field.wind_u.copy(),
        wind_v=field.wind_v.copy(),
        wind_w=field.wind_w.copy(),
        ground_speed_effect=field.ground_speed_effect.copy(),
        energy_penalty=field.energy_penalty.copy(),
        violation_probability=field.violation_probability.copy(),
        joint_risk=field.joint_risk.copy(),
        fatal_score=field.fatal_score.copy(),
        cumulative_score=field.cumulative_score.copy(),
        weighted_soft_cost=field.weighted_soft_cost.copy(),
        coords={name: np.asarray(value).copy() for name, value in field.coords.items()},
        confidence=field.confidence.copy() if isinstance(field.confidence, np.ndarray) else field.confidence,
        source_metadata={**field.source_metadata},
        channel_metadata={**field.channel_metadata},
        metadata={**field.metadata},
    )


def path_risk_summary(
    path: list[State4D],
    risk_field: RiskField4D,
    *,
    start_time_index: int = 0,
    end_time_index: int | None = None,
) -> dict[str, float | int | None]:
    selected = [
        state
        for state in path
        if state[0] >= start_time_index and (end_time_index is None or state[0] <= end_time_index)
    ]
    if not selected:
        return {
            "state_count": 0,
            "expected_risk": None,
            "cvar_risk": None,
            "max_violation_probability": None,
            "total_cost": None,
            "no_fly_violations": None,
        }
    expected = []
    cvar = []
    violation = []
    total = []
    no_fly = 0
    for state in selected:
        t, z, y, x = state
        t = risk_field.clamp_time(t)
        expected.append(float(risk_field.expected_cost[t, z, y, x]))
        cvar.append(float(risk_field.cvar_cost[t, z, y, x]))
        violation.append(float(risk_field.violation_probability[t, z, y, x]))
        total.append(float(risk_field.total_cost[t, z, y, x]))
        no_fly += int(risk_field.no_fly_mask[t, z, y, x])
    return {
        "state_count": len(selected),
        "expected_risk": _round(float(np.mean(expected))),
        "cvar_risk": _round(float(np.mean(cvar))),
        "max_violation_probability": _round(float(np.max(violation))),
        "total_cost": _round(float(np.mean(total))),
        "no_fly_violations": int(no_fly),
    }


def path_intersects_changed(path: list[State4D], changed_voxels: np.ndarray, *, start_time_index: int = 0) -> bool:
    changed = np.asarray(changed_voxels, dtype=bool)
    for state in path:
        if state[0] < start_time_index:
            continue
        t, z, y, x = state
        if 0 <= t < changed.shape[0] and 0 <= z < changed.shape[1] and 0 <= y < changed.shape[2] and 0 <= x < changed.shape[3]:
            if changed[t, z, y, x]:
                return True
    return False


def state_at_or_before(path: list[State4D], step: int) -> State4D:
    candidates = [state for state in path if state[0] <= step]
    return candidates[-1] if candidates else (0, 2, 10, 10)


def merge_prefix(initial_path: list[State4D], repaired_tail: list[State4D], repair_start: State4D) -> list[State4D]:
    if not initial_path:
        return repaired_tail
    prefix = [state for state in initial_path if state[0] <= repair_start[0]]
    if repaired_tail and prefix and repaired_tail[0] == prefix[-1]:
        return prefix[:-1] + repaired_tail
    return prefix + repaired_tail


def path_to_payload(path: list[State4D]) -> list[list[int]]:
    return [[int(v) for v in state] for state in path]


def path_from_payload(payload: Any) -> list[State4D]:
    return [tuple(int(v) for v in state) for state in payload]


def write_json(path: str | Path, data: dict[str, Any]) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(_jsonable(data), ensure_ascii=False, indent=2), encoding="utf-8")


def dry_wrf_boundary_note() -> str:
    return (
        "WRF 是背景气象场。当前 WRF 个例主要支撑风场、风切变和能耗风险实验；"
        "强降水、强对流和低能见度通道在该样本中较弱，相关动态主要由局地扰动模型补充，"
        "用于验证风险场和动态重规划机制。"
    )


def local_perturbation_note() -> str:
    return (
        "局地风切变和阵风扰动标记为 synthetic_local_perturbation，"
        "用于补足公开模式资料难以解析的低空秒级扰动。"
    )


def _file_fingerprint(path: str | Path) -> dict[str, Any]:
    p = Path(path)
    stat = p.stat()
    return {"path": str(p), "size": stat.st_size, "mtime_ns": stat.st_mtime_ns}


def _elapsed_ms(start: float) -> float:
    return round((time.perf_counter() - start) * 1000.0, 3)


def _round(value: float, digits: int = 3) -> float:
    if not np.isfinite(value):
        return value
    return round(float(value), digits)


def _jsonable(value: Any) -> Any:
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, dict):
        return {str(key): _jsonable(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_jsonable(item) for item in value]
    return value
