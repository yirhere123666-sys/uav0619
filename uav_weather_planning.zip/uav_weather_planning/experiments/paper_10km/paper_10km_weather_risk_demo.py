from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import numpy as np

from uav_weather_planning.data_interface import WRFLoader, WRFLoaderConfig
from uav_weather_planning.global_planner import (
    DStarLite4DConfig,
    DStarLite4DPlanner,
    FlightConstraints,
    TimeDependentAStar,
    evaluate_path,
)
from uav_weather_planning.preprocessing import LocalPlanningGridConfig, normalize_weather_cube_to_local_planning_grid
from uav_weather_planning.risk_field import RiskField4D
from uav_weather_planning.risk_field.metric_coords import get_time_seconds
from uav_weather_planning.risk_field.risk_field_4d import SpatialNode, State4D
from uav_weather_planning.risk_models import RiskFusionConfig, build_risk_field_from_weather
from uav_weather_planning.visualization import (
    plot_2d_path_comparison_weather_risk,
    plot_3d_path_comparison,
    plot_3d_risk_field_main,
    plot_3d_risk_snapshots,
    plot_changed_voxels_3d,
    plot_low_altitude_wind_structure_3d,
)
from .paper_common_10km import (
    DEFAULT_CACHE_DIR,
    GOAL_XYZ_M,
    START_XYZ_M,
    dry_wrf_boundary_note,
    load_or_build_local_cube,
    load_or_build_risk_field,
    local_perturbation_note,
    make_constraints,
    make_fusion_config,
    make_grid_config,
    mode_settings,
    search_bounds_for_mission,
)


def run_paper_10km_weather_risk_demo(
    *,
    wrf_zip: str | Path,
    output_dir: str | Path = "outputs/paper_figures",
    make_plots: bool = True,
    repair_mode: str = "incremental_dstar_lite",
    mode: str = "paper_fast",
    use_cache: bool = False,
    force_rebuild: bool = False,
    cache_dir: str | Path = DEFAULT_CACHE_DIR,
) -> dict[str, Any]:
    import time

    total_start = time.perf_counter()
    settings = mode_settings(mode)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    grid_config = make_grid_config(settings.name)
    cube, cube_cache = load_or_build_local_cube(
        wrf_zip=wrf_zip,
        grid_config=grid_config,
        cache_dir=cache_dir,
        use_cache=use_cache,
        force_rebuild=force_rebuild,
    )
    cube = _apply_paper_10km_high_risk_scenario(cube)
    fusion_config = make_fusion_config(settings)
    risk_field, risk_cache = load_or_build_risk_field(
        cube=cube,
        fusion_config=fusion_config,
        cache_dir=cache_dir,
        use_cache=use_cache,
        force_rebuild=force_rebuild,
        scenario_tag="paper_10km_weather_risk_demo",
    )

    start = _nearest_node_by_metric(risk_field, *START_XYZ_M)
    goal = _nearest_node_by_metric(risk_field, *GOAL_XYZ_M)
    start = _nearest_feasible_spatial_node(risk_field, start)
    goal = _nearest_feasible_spatial_node(risk_field, goal)
    mission_distance_m = _mission_distance_m(risk_field, start, goal)

    constraints = make_constraints()
    search_bounds = search_bounds_for_mission(risk_field, start, goal, margin_cells=settings.search_margin_cells)

    baseline_result = TimeDependentAStar(
        risk_field,
        use_cvar=False,
        risk_weight=0.0,
        cvar_weight=0.0,
        energy_weight=0.0,
        safety_weight=0.0,
        constraints=constraints,
        heuristic_weight=settings.heuristic_weight_baseline,
        search_bounds=search_bounds,
    ).plan(start, goal)
    risk_aware_result = TimeDependentAStar(
        risk_field,
        use_cvar=True,
        risk_weight=2.3,
        cvar_weight=1.1,
        energy_weight=0.25,
        safety_weight=0.18,
        constraints=constraints,
        heuristic_weight=settings.heuristic_weight_risk,
        search_bounds=search_bounds,
    ).plan(start, goal)
    if not risk_aware_result.success:
        risk_aware_result = TimeDependentAStar(
            risk_field,
            use_cvar=True,
            risk_weight=1.7,
            cvar_weight=0.75,
            constraints=constraints,
            heuristic_weight=settings.heuristic_weight_risk,
            search_bounds=search_bounds,
        ).plan(start, goal)

    initial_static_result = TimeDependentAStar(
        risk_field.as_static_snapshot(0),
        use_cvar=True,
        risk_weight=2.0,
        cvar_weight=0.9,
        constraints=constraints,
        heuristic_weight=settings.heuristic_weight_risk,
        search_bounds=search_bounds,
    ).plan(start, goal)
    event = _select_replanning_event(risk_field, risk_aware_result.path or initial_static_result.path)
    updated_risk_field, changed_voxels = _build_incremental_update_field(
        risk_field,
        risk_aware_result.path or initial_static_result.path,
        event["repair_start_state"],
    )

    dstar_planner = DStarLite4DPlanner(
        risk_field=risk_field,
        constraints=constraints,
        config=DStarLite4DConfig(
            risk_weight=2.3,
            cvar_weight=1.1,
            energy_weight=0.25,
            safety_weight=0.18,
            heuristic_weight=settings.heuristic_weight_risk,
            search_bounds=search_bounds,
            max_repair_horizon_steps=90,
        ),
    )
    initial_path_for_repair = risk_aware_result.path or initial_static_result.path
    dstar_current_state = _state_at_or_before(initial_path_for_repair, event["event_time_index"])
    dstar_initial = dstar_planner.initialize_from_path(
        [state for state in initial_path_for_repair if state[0] >= dstar_current_state[0]],
        goal,
        risk_field,
    )
    full_restart_result = TimeDependentAStar(
        updated_risk_field,
        use_cvar=True,
        risk_weight=2.3,
        cvar_weight=1.1,
        constraints=constraints,
        heuristic_weight=settings.heuristic_weight_risk,
        search_bounds=search_bounds,
    ).plan(dstar_current_state, goal, start_time=dstar_current_state[0])
    full_restart_path = _merge_prefix(dstar_initial.path or risk_aware_result.path, full_restart_result.path, dstar_current_state)
    dstar_result = dstar_planner.plan_or_repair(
        dstar_current_state,
        new_risk_field=updated_risk_field,
        changed_voxels=changed_voxels,
    )
    dstar_repaired_path = _merge_prefix(dstar_initial.path or risk_aware_result.path, dstar_result.path, dstar_current_state)

    if repair_mode == "full_restart":
        selected_repaired_path = full_restart_path
        selected_planner_name = "restart_full_search"
        selected_repair_mode = "full_restart"
        selected_success = full_restart_result.success
        selected_nodes = full_restart_result.nodes_expanded
        selected_elapsed_ms = full_restart_result.elapsed_ms
    elif repair_mode == "incremental_dstar_lite":
        selected_repaired_path = dstar_repaired_path
        selected_planner_name = "dstar_lite_4d"
        selected_repair_mode = "incremental_dstar_lite"
        selected_success = dstar_result.success
        selected_nodes = dstar_result.nodes_expanded_incremental
        selected_elapsed_ms = dstar_result.elapsed_ms
    else:
        raise ValueError("repair_mode must be 'incremental_dstar_lite' or 'full_restart'")

    baseline_metrics = evaluate_path(
        "baseline distance-only/no-weather A*",
        baseline_result.path,
        risk_field,
        nodes_expanded=baseline_result.nodes_expanded,
        elapsed_ms=baseline_result.elapsed_ms,
        constraints=constraints,
    ).as_row()
    risk_aware_metrics = evaluate_path(
        "risk-aware time-dependent A*",
        risk_aware_result.path,
        risk_field,
        nodes_expanded=risk_aware_result.nodes_expanded,
        elapsed_ms=risk_aware_result.elapsed_ms,
        constraints=constraints,
    ).as_row()
    repaired_metrics = evaluate_path(
        "D* Lite incremental repair" if selected_repair_mode == "incremental_dstar_lite" else "event-triggered full-restart repair",
        selected_repaired_path,
        updated_risk_field,
        nodes_expanded=selected_nodes,
        elapsed_ms=selected_elapsed_ms,
        replan_count=1 if selected_success else 0,
        constraints=constraints,
    ).as_row()
    full_restart_metrics = evaluate_path(
        "event-triggered full-restart repair baseline",
        full_restart_path,
        updated_risk_field,
        nodes_expanded=full_restart_result.nodes_expanded,
        elapsed_ms=full_restart_result.elapsed_ms,
        replan_count=1 if full_restart_result.success else 0,
        constraints=constraints,
    ).as_row()
    dstar_metrics = evaluate_path(
        "D* Lite incremental repair",
        dstar_repaired_path,
        updated_risk_field,
        nodes_expanded=dstar_result.nodes_expanded_incremental,
        elapsed_ms=dstar_result.elapsed_ms,
        replan_count=1 if dstar_result.success else 0,
        constraints=constraints,
    ).as_row()

    figure_summaries: dict[str, Any] = {}
    if make_plots:
        figure_summaries["low_altitude_wind_structure"] = plot_low_altitude_wind_structure_3d(
            risk_field,
            output_dir / "paper_3d_low_altitude_wind_structure.png",
            time_index=30,
            risk_channel="shear_turbulence_risk",
        )
        figure_summaries["risk_field_total_cost"] = plot_3d_risk_field_main(
            risk_field,
            output_dir / "paper_3d_risk_field_total_cost.png",
            time_index=30,
            channel="total_cost",
            path=risk_aware_result.path,
        )
        figure_summaries["risk_field_cvar"] = plot_3d_risk_field_main(
            risk_field,
            output_dir / "paper_3d_risk_field_cvar.png",
            time_index=30,
            channel="cvar_cost",
            path=risk_aware_result.path,
        )
        figure_summaries["risk_snapshots"] = plot_3d_risk_snapshots(
            risk_field,
            output_dir / "paper_3d_risk_snapshots_t0_t300_t600.png",
            time_indices=(0, 30, 60),
            channel="total_cost",
        )
        figure_summaries["path_comparison_3d"] = plot_3d_path_comparison(
            updated_risk_field,
            output_dir / "paper_3d_path_comparison_weather_risk.png",
            baseline_path=baseline_result.path,
            risk_aware_path=risk_aware_result.path,
            repaired_path=selected_repaired_path,
            time_index=30,
            channel="cvar_cost",
        )
        figure_summaries["changed_voxels_replanning"] = plot_changed_voxels_3d(
            updated_risk_field,
            changed_voxels,
            output_dir / "paper_3d_changed_voxels_replanning_trigger.png",
            original_path=dstar_initial.path or risk_aware_result.path,
            repaired_path=selected_repaired_path,
            trigger_state=dstar_current_state,
            event_reason=event["event_reason"],
            repair_mode=selected_repair_mode,
            planner_name=selected_planner_name,
            speedup_ratio=_speedup_ratio(full_restart_result.elapsed_ms, dstar_result.elapsed_ms),
        )
        figure_summaries["path_comparison_2d"] = plot_2d_path_comparison_weather_risk(
            risk_field,
            output_dir / "paper_2d_path_comparison_weather_risk.png",
            baseline_path=baseline_result.path,
            risk_aware_path=risk_aware_result.path,
            time_index=30,
            height_index=start[0],
            channel="total_cost",
        )

    full_restart_elapsed = float(full_restart_result.elapsed_ms)
    incremental_elapsed = float(dstar_result.elapsed_ms)
    speedup_ratio = _speedup_ratio(full_restart_elapsed, incremental_elapsed)
    changed_voxel_count = int(np.sum(changed_voxels))
    changed_voxel_ratio = round(float(np.mean(changed_voxels)), 6)
    total_elapsed_ms = round((time.perf_counter() - total_start) * 1000.0, 3)

    summary = {
        "experiment": "paper_10km_weather_risk_demo",
        "mode": settings.name,
        "validation_level": "正式定量指标" if settings.quantitative else "快速可视化 / 冒烟验证（Smoke Validation）",
        "scenario_type": "high_risk_avoidance",
        "claim_boundary": {
            "background_weather": "WRF 是区域背景气象场，不直接等同于 100 m / 10 s 的多旋翼控制网格。",
            "local_risk_grid": "100 m / 10 s 是插值和局地扰动后的局地路径规划风险网格。",
            "dynamic_repair": (
                "D* Lite is reported only when repair_mode=incremental_dstar_lite; "
                "full restart remains a baseline."
            ),
            "nmpc": "B-spline/NMPC trajectory optimization is not part of this paper figure demo.",
        },
        "wrf_boundary_note": dry_wrf_boundary_note(),
        "local_perturbation_note": local_perturbation_note(),
        "wrf_source": str(wrf_zip),
        "background_source": risk_field.source_metadata.get("background_source"),
        "background_resolution_m": risk_field.source_metadata.get("background_resolution_m"),
        "background_valid_times": risk_field.source_metadata.get("background_valid_times"),
        "local_grid_extent_m": risk_field.source_metadata.get("local_grid_extent_m"),
        "local_grid_resolution_m": risk_field.source_metadata.get("local_grid_resolution_m"),
        "local_planning_time_s": {
            "start": float(risk_field.coords["time"][0]),
            "end": float(risk_field.coords["time"][-1]),
            "step": float(np.diff(risk_field.coords["time"][:2])[0]),
            "count": int(len(risk_field.coords["time"])),
        },
        "time_step_s": risk_field.source_metadata.get("time_step_s"),
        "height_levels_m": risk_field.source_metadata.get("height_levels_m"),
        "synthetic_local_perturbation": risk_field.source_metadata.get("synthetic_local_perturbation"),
        "monte_carlo_samples": settings.monte_carlo_samples,
        "cvar_chunk_size": settings.cvar_chunk_voxels,
        "cvar_elapsed_ms": risk_field.channel_metadata.get("cvar_elapsed_ms"),
        "risk_tensor_dtype": risk_field.channel_metadata.get("risk_tensor_dtype"),
        "risk_field_build_elapsed_ms": risk_cache.get("elapsed_ms"),
        "weather_cube_build_elapsed_ms": cube_cache.get("elapsed_ms"),
        "total_no_plots_elapsed_ms": total_elapsed_ms if not make_plots else None,
        "total_elapsed_ms": total_elapsed_ms,
        "planner_search_bounds_enabled": True,
        "search_bounds_cells": search_bounds,
        "search_bounds_m": _bounds_to_meters(risk_field, search_bounds),
        "nodes_expanded_baseline": int(baseline_result.nodes_expanded),
        "nodes_expanded_risk_aware": int(risk_aware_result.nodes_expanded),
        "elapsed_ms_baseline": round(float(baseline_result.elapsed_ms), 3),
        "elapsed_ms_risk_aware": round(float(risk_aware_result.elapsed_ms), 3),
        "cache": {
            "local_cube": cube_cache,
            "risk_field": risk_cache,
        },
        "mission": {
            "start_xyz_m": list(START_XYZ_M),
            "goal_xyz_m": list(GOAL_XYZ_M),
            "start_state": list(start),
            "goal_state": list(goal),
            "mission_distance_m": round(mission_distance_m, 3),
        },
        "risk_shape": list(risk_field.shape),
        "constraints": constraints.as_dict(),
        "paths": {
            "baseline_path": _path_summary(baseline_metrics, baseline_result.path),
            "risk_aware_path": _path_summary(risk_aware_metrics, risk_aware_result.path),
            "repaired_path": _path_summary(repaired_metrics, selected_repaired_path),
            "full_restart_repaired_path": _path_summary(full_restart_metrics, full_restart_path),
            "dstar_lite_repaired_path": _path_summary(dstar_metrics, dstar_repaired_path),
        },
        "replanning": {
            "event_time_s": get_time_seconds(updated_risk_field.coords, dstar_current_state[0]),
            "event_time_index": dstar_current_state[0],
            "event_reason": event["event_reason"],
            "changed_voxel_count": changed_voxel_count,
            "changed_voxel_ratio": changed_voxel_ratio,
            "repair_mode": selected_repair_mode,
            "planner_name": selected_planner_name,
            "title_policy": (
                "D* Lite incremental replanning under changed risk voxels"
                if selected_repair_mode == "incremental_dstar_lite"
                else "event-triggered full-restart repair"
            ),
            "repair_start_state": list(dstar_current_state),
            "repair_success": selected_success,
            "state_format": "(time_index, height_index, y_index, x_index)",
            "dstar_lite_4d": {
                "planner_name": "dstar_lite_4d",
                "repair_mode": "incremental_dstar_lite",
                "g_rhs_reused": bool(dstar_result.g_rhs_reused),
                "queue_reused": bool(dstar_result.queue_reused),
                "incremental_reuse_valid": bool(dstar_result.incremental_reuse_valid),
                "reinitialize_reason": dstar_result.reinitialize_reason,
                "changed_voxel_count": int(dstar_result.changed_voxel_count),
                "raw_changed_voxel_count": int(dstar_result.raw_changed_voxel_count),
                "raw_changed_voxel_ratio": dstar_result.raw_changed_voxel_ratio,
                "raw_changed_source": (
                    dstar_result.replan_events[-1].get("raw_changed_source")
                    if dstar_result.replan_events
                    else None
                ),
                "significant_changed_voxel_ratio": dstar_result.significant_changed_voxel_ratio,
                "affected_state_count": int(dstar_result.affected_state_count),
                "update_vertex_count": int(dstar_result.update_vertex_count),
                "compute_shortest_path_iterations": int(dstar_result.compute_shortest_path_iterations),
                "nodes_expanded_incremental": int(dstar_result.nodes_expanded_incremental),
                "nodes_expanded_total_after_repair": int(dstar_result.nodes_expanded),
                "elapsed_ms_incremental": round(incremental_elapsed, 3),
                "compute_elapsed_ms_incremental": round(float(dstar_result.elapsed_ms_incremental), 3),
                "path_cost_incremental": dstar_metrics.get("total_cost"),
                "expected_risk_incremental": dstar_metrics.get("expected_risk"),
                "cvar_risk_incremental": dstar_metrics.get("cvar_risk"),
                "no_fly_violations_incremental": dstar_metrics.get("no_fly_violations"),
                "constraint_violations_incremental": dstar_metrics.get("constraint_violations"),
                "km_final": round(float(dstar_result.km_final), 6),
                "start_updates": int(dstar_result.start_updates),
                "open_queue_size": int(dstar_result.open_queue_size),
            },
            "full_restart_baseline": {
                "planner_name": "restart_full_search",
                "repair_mode": "event_triggered_full_restart",
                "nodes_expanded_full_restart": int(full_restart_result.nodes_expanded),
                "elapsed_ms_full_restart": round(full_restart_elapsed, 3),
                "path_cost_full_restart": full_restart_metrics.get("total_cost"),
                "expected_risk_full_restart": full_restart_metrics.get("expected_risk"),
                "cvar_risk_full_restart": full_restart_metrics.get("cvar_risk"),
                "no_fly_violations_full_restart": full_restart_metrics.get("no_fly_violations"),
                "constraint_violations_full_restart": full_restart_metrics.get("constraint_violations"),
            },
            "nodes_expanded_incremental": int(dstar_result.nodes_expanded_incremental),
            "nodes_expanded_full_restart": int(full_restart_result.nodes_expanded),
            "elapsed_ms_incremental": round(incremental_elapsed, 3),
            "elapsed_ms_full_restart": round(full_restart_elapsed, 3),
            "speedup_ratio": speedup_ratio,
            "path_cost_incremental": dstar_metrics.get("total_cost"),
            "path_cost_full_restart": full_restart_metrics.get("total_cost"),
            "expected_risk_incremental": dstar_metrics.get("expected_risk"),
            "cvar_risk_incremental": dstar_metrics.get("cvar_risk"),
            "no_fly_violations_incremental": dstar_metrics.get("no_fly_violations"),
        },
        "figure_summaries": figure_summaries,
        "outputs": _expected_outputs(make_plots),
        "todo": [
            "B-spline/NMPC local trajectory optimization remains a later layer and is not reported as completed here.",
            "Additional real-case batches are still needed before claiming broad runtime dominance over full restart.",
        ],
    }
    _write_json(output_dir / "paper_summary.json", summary)
    _write_markdown(output_dir / "paper_summary.md", summary)
    _run_acceptance_checks(summary, output_dir if make_plots else None)
    return summary


def _apply_paper_10km_high_risk_scenario(cube):
    time_s = np.asarray(cube.time, dtype=float)[:, None, None, None]
    height = np.asarray(cube.height, dtype=float)[None, :, None, None]
    y = np.asarray(cube.y, dtype=float)[None, None, :, None]
    x = np.asarray(cube.x, dtype=float)[None, None, None, :]
    y_on_route = 1000.0 + (x - 1000.0) * (3000.0 / 9500.0)
    corridor_blob = np.exp(-((y - y_on_route) ** 2) / (2.0 * 520.0**2)) * np.exp(-((x - 5400.0) ** 2) / (2.0 * 1750.0**2))
    temporal = np.clip((time_s - 60.0) / 180.0, 0.0, 1.0) * np.clip((660.0 - time_s) / 220.0, 0.0, 1.0)
    vertical = np.exp(-((height - 120.0) ** 2) / (2.0 * 38.0**2))
    signal = np.clip(corridor_blob * temporal * vertical, 0.0, 1.0)

    variables = {name: value.copy() for name, value in cube.variables.items()}
    if "gust" in variables:
        variables["gust"] = np.minimum(variables["gust"] + 3.2 * signal, 16.5)
    if "u_wind" in variables:
        variables["u_wind"] = variables["u_wind"] + 2.2 * signal * np.tanh((height - 110.0) / 30.0)
    if "v_wind" in variables:
        variables["v_wind"] = variables["v_wind"] - 1.7 * signal * np.tanh((height - 110.0) / 30.0)
    if "w_wind" in variables:
        variables["w_wind"] = variables["w_wind"] + 0.45 * signal
    if "reflectivity" in variables:
        variables["reflectivity"] = np.minimum(variables["reflectivity"] + 4.0 * signal, 38.0)
    if "convection_probability" in variables:
        variables["convection_probability"] = np.minimum(variables["convection_probability"] + 0.08 * signal, 0.72)
    if "visibility" in variables:
        variables["visibility"] = np.maximum(variables["visibility"] - 0.35 * signal, 2.0)
    if isinstance(cube.confidence, np.ndarray):
        confidence = np.clip(cube.confidence - 0.24 * signal, 0.24, 0.96)
    else:
        confidence = np.clip(np.full(cube.shape, float(cube.confidence)) - 0.24 * signal, 0.24, 0.96)
    metadata = {
        **cube.source_metadata,
        "paper_10km_scenario": {
            "scenario_type": "high_risk_avoidance",
            "description": "A moving high-CVaR gust/shear band is placed near the start-goal straight route for paper path-comparison figures.",
            "risk_band_center_x_m": 5400.0,
            "risk_band_width_y_m": 520.0,
            "risk_active_time_s": [60.0, 600.0],
            "no_fly_forced": False,
        },
    }
    from uav_weather_planning.data_interface.weather_cube import WeatherCube

    return WeatherCube(
        time=cube.time.copy(),
        height=cube.height.copy(),
        y=cube.y.copy(),
        x=cube.x.copy(),
        variables=variables,
        source_metadata=metadata,
        confidence=confidence,
    )


def _nearest_node_by_metric(risk_field: RiskField4D, x_m: float, y_m: float, z_m: float) -> SpatialNode:
    heights = np.asarray(risk_field.coords.get("height", np.arange(risk_field.z_size)), dtype=float)
    y_axis = np.asarray(risk_field.coords.get("y", np.arange(risk_field.y_size)), dtype=float)
    x_axis = np.asarray(risk_field.coords.get("x", np.arange(risk_field.x_size)), dtype=float)
    return (
        int(np.argmin(np.abs(heights - z_m))),
        int(np.argmin(np.abs(y_axis - y_m))),
        int(np.argmin(np.abs(x_axis - x_m))),
    )


def _nearest_feasible_spatial_node(risk_field: RiskField4D, node: SpatialNode, max_radius: int = 4) -> SpatialNode:
    if risk_field.in_bounds((0, *node)) and not risk_field.is_no_fly((0, *node)):
        return node
    z0, y0, x0 = node
    for radius in range(1, max_radius + 1):
        for dz in range(-1, 2):
            for dy in range(-radius, radius + 1):
                for dx in range(-radius, radius + 1):
                    z = int(np.clip(z0 + dz, 0, risk_field.z_size - 1))
                    y = int(np.clip(y0 + dy, 0, risk_field.y_size - 1))
                    x = int(np.clip(x0 + dx, 0, risk_field.x_size - 1))
                    candidate = (z, y, x)
                    if not risk_field.is_no_fly((0, *candidate)):
                        return candidate
    return node


def _mission_distance_m(risk_field: RiskField4D, start: SpatialNode, goal: SpatialNode) -> float:
    x_axis = np.asarray(risk_field.coords["x"], dtype=float)
    y_axis = np.asarray(risk_field.coords["y"], dtype=float)
    z_axis = np.asarray(risk_field.coords["height"], dtype=float)
    z0, y0, x0 = start
    z1, y1, x1 = goal
    return float(np.sqrt((x_axis[x1] - x_axis[x0]) ** 2 + (y_axis[y1] - y_axis[y0]) ** 2 + (z_axis[z1] - z_axis[z0]) ** 2))


def _select_replanning_event(risk_field: RiskField4D, path: list[State4D]) -> dict[str, Any]:
    max_path_t = max([state[0] for state in path] or [60])
    upper = int(min(max_path_t, 60, risk_field.t_size - 1))
    best = {"ratio": -1.0, "index": 30, "mask": np.zeros(risk_field.shape[1:], dtype=bool)}
    for idx in range(6, max(7, upper + 1)):
        mask = _significant_changed_between(risk_field, idx - 1, idx)
        ratio = float(np.mean(mask))
        if ratio > best["ratio"]:
            best = {"ratio": ratio, "index": idx, "mask": mask}
    repair_start = _state_at_or_before(path, int(best["index"]))
    return {
        "event_time_index": int(best["index"]),
        "event_reason": "expected_risk_increase",
        "changed_voxels": best["mask"],
        "changed_voxel_count": int(np.sum(best["mask"])),
        "changed_voxel_ratio": round(float(best["ratio"]), 6),
        "repair_start_state": repair_start,
    }


def _significant_changed_between(risk_field: RiskField4D, left: int, right: int) -> np.ndarray:
    left = risk_field.clamp_time(left)
    right = risk_field.clamp_time(right)
    significant_cost_changed = np.abs(risk_field.total_cost[right] - risk_field.total_cost[left]) > 0.3
    mask_changed = risk_field.no_fly_mask[right] != risk_field.no_fly_mask[left]
    cvar_changed = np.abs(risk_field.cvar_cost[right] - risk_field.cvar_cost[left]) > 0.2
    violation_changed = np.abs(risk_field.violation_probability[right] - risk_field.violation_probability[left]) > 0.1
    return significant_cost_changed | mask_changed | cvar_changed | violation_changed


def _build_incremental_update_field(
    risk_field: RiskField4D,
    path: list[State4D],
    trigger_state: State4D,
) -> tuple[RiskField4D, np.ndarray]:
    """Create a local post-forecast-update risk field for D* Lite repair."""

    updated = _copy_risk_field(risk_field)
    changed = np.zeros(risk_field.shape, dtype=bool)
    if not path:
        return updated, changed
    event_t = risk_field.clamp_time(trigger_state[0])
    future = [state for state in path if event_t + 2 <= state[0] <= min(event_t + 10, risk_field.t_size - 1)]
    if not future:
        future = [trigger_state]
    future = future[:8]
    radius = 1
    for state in future:
        t, z, y, x = state
        for dt in range(0, 3):
            tt = risk_field.clamp_time(t + dt)
            z0 = max(0, z - 1)
            z1 = min(risk_field.z_size, z + 2)
            y0 = max(0, y - radius)
            y1 = min(risk_field.y_size, y + radius + 1)
            x0 = max(0, x - radius)
            x1 = min(risk_field.x_size, x + radius + 1)
            changed[tt, z0:z1, y0:y1, x0:x1] = True
    soft_ring = changed.copy()
    core = np.zeros_like(changed)
    for state in future[:: max(1, len(future) // 3)]:
        t, z, y, x = state
        tt = risk_field.clamp_time(t)
        z0 = max(0, z - 1)
        z1 = min(risk_field.z_size, z + 2)
        y0 = max(0, y - 1)
        y1 = min(risk_field.y_size, y + 2)
        x0 = max(0, x - 1)
        x1 = min(risk_field.x_size, x + 2)
        core[tt : min(risk_field.t_size, tt + 5), z0:z1, y0:y1, x0:x1] = True
    changed |= core

    updated.expected_cost[soft_ring] = np.minimum(updated.expected_cost[soft_ring] + 6.0, 48.0)
    updated.cvar_cost[soft_ring] = np.minimum(updated.cvar_cost[soft_ring] + 4.5, 36.0)
    updated.total_cost[soft_ring] = np.minimum(updated.total_cost[soft_ring] + 12.0, 80.0)
    updated.violation_probability[soft_ring] = np.maximum(updated.violation_probability[soft_ring], 0.72)
    updated.convection_risk[soft_ring] = np.maximum(updated.convection_risk[soft_ring], 0.74)
    updated.gust_risk[soft_ring] = np.maximum(updated.gust_risk[soft_ring], 0.76)
    updated.shear_risk[soft_ring] = np.maximum(updated.shear_risk[soft_ring], 0.72)
    updated.shear_turbulence_risk[soft_ring] = np.maximum(updated.shear_turbulence_risk[soft_ring], 0.72)
    updated.no_fly_mask[core] = True
    updated.expected_cost[core] = 1e6
    updated.cvar_cost[core] = 1e6
    updated.total_cost[core] = 1e6
    updated.violation_probability[core] = 1.0
    updated.metadata = {
        **updated.metadata,
        "incremental_update": {
            "type": "local_forecast_risk_update",
            "trigger_state": list(trigger_state),
            "changed_voxel_count": int(np.sum(changed)),
            "note": "Synthetic local risk update used to test D* Lite g/rhs/open_queue reuse.",
        },
    }
    updated.source_metadata = {
        **updated.source_metadata,
        "synthetic_local_incremental_update": {
            "event_time_index": int(event_t),
            "changed_voxel_count": int(np.sum(changed)),
            "core_no_fly_voxel_count": int(np.sum(core)),
        },
    }
    return updated, changed


def _copy_risk_field(field: RiskField4D) -> RiskField4D:
    return RiskField4D(
        expected_cost=field.expected_cost.copy(),
        no_fly_mask=field.no_fly_mask.copy(),
        uncertainty=field.uncertainty.copy(),
        cvar_cost=field.cvar_cost.copy(),
        wind_risk=field.wind_risk.copy(),
        shear_turbulence_risk=field.shear_turbulence_risk.copy(),
        convection_risk=field.convection_risk.copy(),
        visibility_risk=field.visibility_risk.copy(),
        precipitation_risk=field.precipitation_risk.copy(),
        gust_risk=field.gust_risk.copy(),
        shear_risk=field.shear_risk.copy(),
        turbulence_risk=field.turbulence_risk.copy(),
        total_cost=field.total_cost.copy(),
        wind_u=field.wind_u.copy(),
        wind_v=field.wind_v.copy(),
        wind_w=field.wind_w.copy(),
        ground_speed_effect=field.ground_speed_effect.copy(),
        energy_penalty=field.energy_penalty.copy(),
        violation_probability=field.violation_probability.copy(),
        joint_risk=field.joint_risk.copy(),
        fatal_score=field.fatal_score.copy(),
        cumulative_score=field.cumulative_score.copy(),
        weighted_soft_cost=field.weighted_soft_cost.copy(),
        coords={name: np.asarray(value).copy() for name, value in field.coords.items()},
        confidence=field.confidence.copy() if isinstance(field.confidence, np.ndarray) else field.confidence,
        source_metadata={**field.source_metadata},
        channel_metadata={**field.channel_metadata},
        metadata={**field.metadata},
    )


def _state_at_or_before(path: list[State4D], step: int) -> State4D:
    candidates = [state for state in path if state[0] <= step]
    return candidates[-1] if candidates else (0, 2, 10, 10)


def _merge_prefix(initial_path: list[State4D], repaired_tail: list[State4D], repair_start: State4D) -> list[State4D]:
    if not initial_path:
        return repaired_tail
    prefix = [state for state in initial_path if state[0] <= repair_start[0]]
    if repaired_tail and prefix and repaired_tail[0] == prefix[-1]:
        return prefix[:-1] + repaired_tail
    return prefix + repaired_tail


def _path_summary(metrics: dict[str, Any], path: list[State4D]) -> dict[str, Any]:
    return {
        "exists": bool(path),
        "state_count": len(path),
        "path_length": metrics.get("path_length"),
        "expected_risk": metrics.get("expected_risk"),
        "cvar_risk": metrics.get("cvar_risk"),
        "max_violation_probability": metrics.get("max_violation_probability"),
        "no_fly_violations": metrics.get("no_fly_violations"),
        "constraint_violations": metrics.get("constraint_violations"),
        "max_ground_speed_mps": metrics.get("max_ground_speed_mps"),
        "max_vertical_rate_mps": metrics.get("max_vertical_rate_mps"),
    }


def _speedup_ratio(full_restart_elapsed_ms: float, incremental_elapsed_ms: float) -> float | None:
    if incremental_elapsed_ms <= 0.0:
        return None
    return round(float(full_restart_elapsed_ms) / float(incremental_elapsed_ms), 6)


def _bounds_to_meters(risk_field: RiskField4D, bounds: dict[str, tuple[int, int]]) -> dict[str, list[float]]:
    y_axis = np.asarray(risk_field.coords["y"], dtype=float)
    x_axis = np.asarray(risk_field.coords["x"], dtype=float)
    z_axis = np.asarray(risk_field.coords["height"], dtype=float)
    return {
        "x": [float(x_axis[bounds["x"][0]]), float(x_axis[bounds["x"][1]])],
        "y": [float(y_axis[bounds["y"][0]]), float(y_axis[bounds["y"][1]])],
        "height": [float(z_axis[bounds["z"][0]]), float(z_axis[bounds["z"][1]])],
    }


def _expected_outputs(make_plots: bool) -> list[str]:
    base = ["paper_summary.json", "paper_summary.md"]
    if not make_plots:
        return base
    return [
        "paper_3d_low_altitude_wind_structure.png",
        "paper_3d_risk_field_total_cost.png",
        "paper_3d_risk_field_cvar.png",
        "paper_3d_risk_snapshots_t0_t300_t600.png",
        "paper_3d_path_comparison_weather_risk.png",
        "paper_3d_changed_voxels_replanning_trigger.png",
        "paper_2d_path_comparison_weather_risk.png",
        *base,
    ]


def _write_json(path: Path, data: dict[str, Any]) -> None:
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def _write_markdown_legacy(path: Path, summary: dict[str, Any]) -> None:
    text = f"""# 10 km WRF 气象风险场论文图摘要

- 主配置：10 km 任务，12 km × 12 km，100 m，121 × 121，60–180 m，10 s，1200 s。
- WRF 角色：约 1 km 区域背景气象场。
- 局地风险场：WRF 插值映射 + documented synthetic_local_perturbation，不能表述为 WRF 原生 100 m/10 s。
- 动态修正：event-triggered full-restart repair，当前不作为增量搜索效率结果表述。
- 场景类型：{summary['scenario_type']}。
- 任务距离：{summary['mission']['mission_distance_m']} m。
- 风险场 shape：{summary['risk_shape']}。

## 路径指标

- Baseline：expected={summary['paths']['baseline_path']['expected_risk']}，CVaR={summary['paths']['baseline_path']['cvar_risk']}，no-fly={summary['paths']['baseline_path']['no_fly_violations']}。
- Risk-aware：expected={summary['paths']['risk_aware_path']['expected_risk']}，CVaR={summary['paths']['risk_aware_path']['cvar_risk']}，no-fly={summary['paths']['risk_aware_path']['no_fly_violations']}。
- Repair：mode={summary['replanning']['repair_mode']}，planner={summary['replanning']['planner_name']}，event_time={summary['replanning']['event_time_s']} s。
"""
    path.write_text(text, encoding="utf-8")


def _write_markdown(path: Path, summary: dict[str, Any]) -> None:
    replanning = summary["replanning"]
    dstar = replanning["dstar_lite_4d"]
    restart = replanning["full_restart_baseline"]
    text = f"""# 10 km WRF 气象风险场论文图摘要

- 主配置：10 km 任务，12 km x 12 km，100 m 网格，121 x 121，60-180 m，10 s，1200 s。
- WRF 角色：约 1 km 区域背景气象场，不表述为 100 m / 10 s 原生资料。
- 局地风险场：WRF 插值映射 + documented synthetic_local_perturbation，用于低空局地秒级风险演化。
- 动态重规划：当前主输出为 `{replanning['repair_mode']}`，planner=`{replanning['planner_name']}`。
- 任务距离：{summary['mission']['mission_distance_m']} m。
- 风险场 shape：{summary['risk_shape']}。

## 路径指标

- Baseline：Expected={summary['paths']['baseline_path']['expected_risk']}，CVaR={summary['paths']['baseline_path']['cvar_risk']}，no-fly={summary['paths']['baseline_path']['no_fly_violations']}。
- Risk-aware：Expected={summary['paths']['risk_aware_path']['expected_risk']}，CVaR={summary['paths']['risk_aware_path']['cvar_risk']}，no-fly={summary['paths']['risk_aware_path']['no_fly_violations']}。
- D* Lite 修复：Expected={dstar['expected_risk_incremental']}，CVaR={dstar['cvar_risk_incremental']}，no-fly={dstar['no_fly_violations_incremental']}。
- Full restart baseline：Expected={restart['expected_risk_full_restart']}，CVaR={restart['cvar_risk_full_restart']}，no-fly={restart['no_fly_violations_full_restart']}。

## 增量复用证据

- 状态格式：`(time_index, height_index, y_index, x_index)`。
- g/rhs reused：{dstar['g_rhs_reused']}。
- queue reused：{dstar['queue_reused']}。
- changed_voxel_count：{dstar['changed_voxel_count']}。
- affected_state_count：{dstar['affected_state_count']}。
- update_vertex_count：{dstar['update_vertex_count']}。
- compute_shortest_path_iterations：{dstar['compute_shortest_path_iterations']}。
- nodes_expanded_incremental：{replanning['nodes_expanded_incremental']}。
- nodes_expanded_full_restart：{replanning['nodes_expanded_full_restart']}。
- elapsed_ms_incremental：{replanning['elapsed_ms_incremental']}。
- elapsed_ms_full_restart：{replanning['elapsed_ms_full_restart']}。
- speedup_ratio：{replanning['speedup_ratio']}。
"""
    path.write_text(text, encoding="utf-8")


def _write_markdown(path: Path, summary: dict[str, Any]) -> None:
    replanning = summary["replanning"]
    dstar = replanning["dstar_lite_4d"]
    restart = replanning["full_restart_baseline"]
    text = f"""# 10 km WRF 气象风险场论文图摘要

- 实验模式：{summary['mode']}。
- 验证级别：{summary['validation_level']}。
- 主配置：10 km 任务，12 km x 12 km，100 m 网格，121 x 121，60-180 m，10 s，1200 s。
- WRF 边界说明：{summary['wrf_boundary_note']}
- 局地扰动说明：{summary['local_perturbation_note']}
- 动态重规划：当前主输出为 `{replanning['repair_mode']}`，planner=`{replanning['planner_name']}`。
- 主实验最大垂直速度：上升 {summary['constraints'].get('max_climb_rate_mps')} m/s，下降 {summary['constraints'].get('max_descent_rate_mps')} m/s。
- Monte Carlo 样本数：{summary['monte_carlo_samples']}。
- CVaR 分块体素数：{summary['cvar_chunk_size']}。
- 任务距离：{summary['mission']['mission_distance_m']} m。
- 风险场 shape：{summary['risk_shape']}。

## 路径指标

- 无气象约束 A*：Expected={summary['paths']['baseline_path']['expected_risk']}，CVaR={summary['paths']['baseline_path']['cvar_risk']}，no-fly={summary['paths']['baseline_path']['no_fly_violations']}。
- 时间依赖风险 A*：Expected={summary['paths']['risk_aware_path']['expected_risk']}，CVaR={summary['paths']['risk_aware_path']['cvar_risk']}，no-fly={summary['paths']['risk_aware_path']['no_fly_violations']}。
- D* Lite 修复：Expected={dstar['expected_risk_incremental']}，CVaR={dstar['cvar_risk_incremental']}，no-fly={dstar['no_fly_violations_incremental']}。
- 全局重搜基线：Expected={restart['expected_risk_full_restart']}，CVaR={restart['cvar_risk_full_restart']}，no-fly={restart['no_fly_violations_full_restart']}。

## 增量复用证据

- 状态格式：`(time_index, height_index, y_index, x_index)`。
- g/rhs reused：{dstar['g_rhs_reused']}。
- queue reused：{dstar['queue_reused']}。
- changed_voxel_count：{dstar['changed_voxel_count']}。
- affected_state_count：{dstar['affected_state_count']}。
- update_vertex_count：{dstar['update_vertex_count']}。
- compute_shortest_path_iterations：{dstar['compute_shortest_path_iterations']}。
- nodes_expanded_incremental：{replanning['nodes_expanded_incremental']}。
- nodes_expanded_full_restart：{replanning['nodes_expanded_full_restart']}。
- elapsed_ms_incremental：{replanning['elapsed_ms_incremental']}。
- elapsed_ms_full_restart：{replanning['elapsed_ms_full_restart']}。
- speedup_ratio：{replanning['speedup_ratio']}。

## 结论口径

WRF 是背景气象场。当前 WRF 个例主要支撑风场、风切变和能耗风险实验；强降水、强对流和低能见度通道在该样本中较弱，相关动态主要由局地扰动模型补充。正式 CVaR 指标使用 `{summary['mode']}` 模式的样本数；`smoke` 模式只作为快速可视化 / 冒烟验证。
"""
    path.write_text(text, encoding="utf-8")


def _run_acceptance_checks(summary: dict[str, Any], output_dir: Path | None) -> None:
    if summary["mode"] == "smoke":
        assert tuple(summary["risk_shape"]) == (121, 7, 81, 81), summary["risk_shape"]
    else:
        assert tuple(summary["risk_shape"]) == (121, 7, 121, 121), summary["risk_shape"]
    assert abs(float(summary["local_planning_time_s"]["step"]) - 10.0) < 1e-9
    expected_resolution = 150.0 if summary["mode"] == "smoke" else 100.0
    assert abs(float(summary["local_grid_resolution_m"]) - expected_resolution) < 1e-9
    assert summary["height_levels_m"] == [60.0, 80.0, 100.0, 120.0, 140.0, 160.0, 180.0]
    assert 9500.0 <= float(summary["mission"]["mission_distance_m"]) <= 10500.0
    assert summary["constraints"]["max_climb_rate_mps"] == 2.0
    assert summary["constraints"]["max_descent_rate_mps"] == 2.0
    assert summary["monte_carlo_samples"] in {2, 16, 32}
    if summary["mode"] == "paper_fast":
        assert summary["monte_carlo_samples"] == 16
    if summary["mode"] == "paper_quantitative":
        assert summary["monte_carlo_samples"] == 32
    assert summary["paths"]["baseline_path"]["exists"]
    assert summary["paths"]["risk_aware_path"]["exists"]
    replanning = summary["replanning"]
    if replanning["repair_mode"] == "incremental_dstar_lite":
        assert replanning["planner_name"] == "dstar_lite_4d"
        assert "D* Lite" in replanning["title_policy"]
        assert replanning["dstar_lite_4d"]["g_rhs_reused"] is True
        assert replanning["dstar_lite_4d"]["queue_reused"] is True
        assert replanning["dstar_lite_4d"]["changed_voxel_count"] > 0
        assert replanning["dstar_lite_4d"]["update_vertex_count"] > 0
    else:
        assert replanning["repair_mode"] == "full_restart"
        assert "D* Lite" not in replanning["title_policy"]
    if output_dir is not None:
        for name in [
            "paper_3d_low_altitude_wind_structure.png",
            "paper_3d_risk_field_total_cost.png",
            "paper_3d_path_comparison_weather_risk.png",
            "paper_3d_changed_voxels_replanning_trigger.png",
        ]:
            path = output_dir / name
            assert path.exists() and path.stat().st_size > 0, name


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--wrf-zip", required=True)
    parser.add_argument("--output-dir", default="outputs/paper_figures")
    parser.add_argument("--mode", choices=["smoke", "paper_fast", "paper_quantitative"], default="paper_fast")
    parser.add_argument("--no-plots", action="store_true")
    parser.add_argument("--plots", action="store_true")
    parser.add_argument("--use-cache", action="store_true")
    parser.add_argument("--force-rebuild", action="store_true")
    parser.add_argument("--cache-dir", default=str(DEFAULT_CACHE_DIR))
    parser.add_argument("--repair-mode", choices=["incremental_dstar_lite", "full_restart"], default="incremental_dstar_lite")
    args = parser.parse_args()
    make_plots = args.plots or not args.no_plots
    summary = run_paper_10km_weather_risk_demo(
        wrf_zip=args.wrf_zip,
        output_dir=args.output_dir,
        make_plots=make_plots,
        repair_mode=args.repair_mode,
        mode=args.mode,
        use_cache=args.use_cache,
        force_rebuild=args.force_rebuild,
        cache_dir=args.cache_dir,
    )
    print("Paper 10 km weather risk demo finished.")
    print(json.dumps({
        "risk_shape": summary["risk_shape"],
        "mode": summary["mode"],
        "monte_carlo_samples": summary["monte_carlo_samples"],
        "mission_distance_m": summary["mission"]["mission_distance_m"],
        "total_elapsed_ms": summary["total_elapsed_ms"],
        "baseline_path": summary["paths"]["baseline_path"],
        "risk_aware_path": summary["paths"]["risk_aware_path"],
        "replanning": summary["replanning"],
        "outputs": summary["outputs"],
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
