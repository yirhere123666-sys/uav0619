from __future__ import annotations

import argparse
import json
from pathlib import Path


REQUIRED_FIGURES = [
    "paper_3d_low_altitude_wind_structure.png",
    "paper_3d_risk_field_total_cost.png",
    "paper_3d_path_comparison_weather_risk.png",
    "paper_3d_changed_voxels_replanning_trigger.png",
]

PATH_AFFECTED_FIGURES = [
    "paper_3d_changed_voxels_replanning_trigger.png",
    "paper_2d_dstar_path_affected_demo.png",
    "paper_3d_dstar_path_affected_demo.png",
]


def run_paper_10km_smoke_test(output_dir: str | Path = "outputs/paper_figures") -> dict:
    output_dir = Path(output_dir)
    summary_path = output_dir / "paper_summary.json"
    if not summary_path.exists():
        raise FileNotFoundError(f"paper summary not found: {summary_path}")
    summary = json.loads(summary_path.read_text(encoding="utf-8"))
    if summary.get("experiment") == "paper_10km_dstar_path_affected_demo":
        return _check_path_affected_summary(output_dir, summary)
    if summary.get("mode") == "smoke":
        assert tuple(summary["risk_shape"]) == (121, 7, 81, 81), summary["risk_shape"]
        assert abs(float(summary["local_grid_resolution_m"]) - 150.0) < 1e-9
    else:
        assert tuple(summary["risk_shape"]) == (121, 7, 121, 121), summary["risk_shape"]
        assert abs(float(summary["local_grid_resolution_m"]) - 100.0) < 1e-9
    assert summary["local_grid_extent_m"] == [12000.0, 12000.0]
    assert abs(float(summary["local_planning_time_s"]["step"]) - 10.0) < 1e-9
    assert summary["constraints"]["max_climb_rate_mps"] == 2.0
    assert summary["constraints"]["max_descent_rate_mps"] == 2.0
    if summary.get("mode") == "paper_fast":
        assert summary["monte_carlo_samples"] == 16
    if summary.get("mode") == "paper_quantitative":
        assert summary["monte_carlo_samples"] == 32
    assert summary["height_levels_m"] == [60.0, 80.0, 100.0, 120.0, 140.0, 160.0, 180.0]
    assert 9500.0 <= float(summary["mission"]["mission_distance_m"]) <= 10500.0
    assert summary["paths"]["baseline_path"]["exists"]
    assert summary["paths"]["risk_aware_path"]["exists"]
    for key in ("path_length", "expected_risk", "cvar_risk", "max_violation_probability", "no_fly_violations"):
        assert key in summary["paths"]["baseline_path"], key
        assert key in summary["paths"]["risk_aware_path"], key
    assert summary["replanning"]["changed_voxel_count"] > 0
    assert summary["replanning"]["event_time_s"] is not None
    assert summary["replanning"]["repair_mode"] == "incremental_dstar_lite"
    assert summary["replanning"]["planner_name"] == "dstar_lite_4d"
    assert "D* Lite" in summary["replanning"]["title_policy"]
    dstar = summary["replanning"]["dstar_lite_4d"]
    restart = summary["replanning"]["full_restart_baseline"]
    assert dstar["g_rhs_reused"] is True
    assert dstar["queue_reused"] is True
    assert dstar["changed_voxel_count"] > 0
    assert dstar["affected_state_count"] > 0
    assert dstar["update_vertex_count"] > 0
    assert "nodes_expanded_full_restart" in restart
    assert summary["replanning"]["nodes_expanded_incremental"] is not None
    assert summary["replanning"]["elapsed_ms_full_restart"] is not None
    assert summary["replanning"]["elapsed_ms_incremental"] is not None
    if "paper_3d_low_altitude_wind_structure.png" in summary.get("outputs", []):
        for name in REQUIRED_FIGURES:
            path = output_dir / name
            assert path.exists() and path.stat().st_size > 0, name
    return {
        "ok": True,
        "output_dir": str(output_dir),
        "risk_shape": summary["risk_shape"],
        "mission_distance_m": summary["mission"]["mission_distance_m"],
        "checked_figures": REQUIRED_FIGURES,
    }


def _check_path_affected_summary(output_dir: Path, summary: dict) -> dict:
    assert summary["constraints"]["max_climb_rate_mps"] == 2.0
    assert summary["constraints"]["max_descent_rate_mps"] == 2.0
    assert summary["monte_carlo_samples"] in {2, 16, 32}
    assert summary["path_affected"] is True
    assert summary["changed_voxel_count"] > 0
    assert summary["global_significant_changed_voxel_count"] >= summary["changed_voxel_count"]
    assert summary["g_rhs_reused"] is True
    assert summary["queue_reused"] is True
    assert summary["affected_state_count"] > 0
    assert summary["update_vertex_count"] > 0
    assert summary["compute_shortest_path_iterations"] > 0
    assert summary["original_future_cvar_risk"] > summary["repaired_cvar_risk"]
    assert "WRF" in summary["wrf_boundary_note"]
    assert summary["synthetic_local_perturbation"] is True
    if "paper_2d_dstar_path_affected_demo.png" in summary.get("outputs", []):
        for name in PATH_AFFECTED_FIGURES:
            path = output_dir / name
            assert path.exists() and path.stat().st_size > 0, name
    return {
        "ok": True,
        "output_dir": str(output_dir),
        "experiment": summary["experiment"],
        "mode": summary["mode"],
        "risk_shape": summary["risk_shape"],
        "path_affected": summary["path_affected"],
        "changed_voxel_count": summary["changed_voxel_count"],
        "compute_shortest_path_iterations": summary["compute_shortest_path_iterations"],
        "checked_figures": [name for name in PATH_AFFECTED_FIGURES if (output_dir / name).exists()],
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", default="outputs/paper_figures")
    args = parser.parse_args()
    result = run_paper_10km_smoke_test(args.output_dir)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
