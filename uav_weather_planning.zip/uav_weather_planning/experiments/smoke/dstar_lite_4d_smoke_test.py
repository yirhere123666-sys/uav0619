from __future__ import annotations

import argparse
import json

import numpy as np

from uav_weather_planning.global_planner import DStarLite4DConfig, DStarLite4DPlanner, FlightConstraints, TimeDependentAStar
from uav_weather_planning.risk_field import RiskField4D
from uav_weather_planning.risk_field.risk_field_4d import State4D


def run_dstar_lite_4d_smoke_test() -> dict:
    field = RiskField4D.uniform(12, 1, 8, 8, base_cost=1.0)
    start = (0, 0, 0, 0)
    goal = (0, 7, 7)
    constraints = FlightConstraints(max_turn_angle_deg=180.0, corridor_required=False)
    planner = DStarLite4DPlanner(
        field,
        constraints=constraints,
        config=DStarLite4DConfig(heuristic_weight=2.0, risk_weight=1.0, cvar_weight=0.25),
    )
    initial = planner.initialize(start, goal, field)
    if not initial.success:
        raise AssertionError("initial D* Lite 4D search did not produce a path")
    g_size_before = len(planner.g)
    rhs_size_before = len(planner.rhs)
    queue_size_before = len(planner.open_queue)

    updated = _copy_field(field)
    changed = np.zeros(field.shape, dtype=bool)
    # Block a local part of the initial diagonal path after two executed steps.
    for state in initial.path[3:7]:
        t, z, y, x = state
        y0 = max(0, y - 1)
        y1 = min(field.y_size, y + 2)
        x0 = max(0, x - 1)
        x1 = min(field.x_size, x + 2)
        changed[t, z, y0:y1, x0:x1] = True
    updated.no_fly_mask[changed] = True
    updated.expected_cost[changed] = 1e6
    updated.cvar_cost[changed] = 1e6
    updated.total_cost[changed] = 1e6
    updated.violation_probability[changed] = 1.0

    current_state = initial.path[2]
    repaired = planner.plan_or_repair(current_state, new_risk_field=updated, changed_voxels=changed)
    full = TimeDependentAStar(updated, constraints=constraints, heuristic_weight=2.0).plan(
        current_state,
        goal,
        start_time=current_state[0],
    )

    if not repaired.success:
        raise AssertionError("incremental D* Lite 4D repair did not produce a path")
    if any(updated.is_no_fly(state) for state in repaired.path):
        raise AssertionError("incremental repaired path enters no_fly_mask")
    if len(planner.g) == 0 or len(planner.rhs) == 0:
        raise AssertionError("g/rhs were cleared during incremental repair")
    if len(planner.g) < g_size_before or len(planner.rhs) < rhs_size_before:
        raise AssertionError("g/rhs did not preserve the previous search state")
    if not repaired.g_rhs_reused or not repaired.queue_reused:
        raise AssertionError("reuse flags were not set")
    if repaired.changed_voxel_count <= 0:
        raise AssertionError("changed voxels were not detected")
    if repaired.update_vertex_count <= 0:
        raise AssertionError("UpdateVertex was not called for the local update")

    return {
        "ok": True,
        "planner_name": repaired.planner_name,
        "repair_mode": repaired.repair_mode,
        "state_format": "(time_index, height_index, y_index, x_index)",
        "initial_path_len": len(initial.path),
        "repaired_path_len": len(repaired.path),
        "full_restart_path_len": len(full.path),
        "g_size_before": g_size_before,
        "g_size_after": len(planner.g),
        "rhs_size_before": rhs_size_before,
        "rhs_size_after": len(planner.rhs),
        "queue_size_before": queue_size_before,
        "queue_size_after": len(planner.open_queue),
        "g_rhs_reused": repaired.g_rhs_reused,
        "queue_reused": repaired.queue_reused,
        "changed_voxel_count": repaired.changed_voxel_count,
        "affected_state_count": repaired.affected_state_count,
        "update_vertex_count": repaired.update_vertex_count,
        "compute_shortest_path_iterations": repaired.compute_shortest_path_iterations,
        "nodes_expanded_incremental": repaired.nodes_expanded_incremental,
        "nodes_expanded_full_restart": full.nodes_expanded,
        "elapsed_ms_incremental": round(repaired.elapsed_ms, 3),
        "elapsed_ms_full_restart": round(full.elapsed_ms, 3),
    }


def _copy_field(field: RiskField4D) -> RiskField4D:
    return RiskField4D(
        expected_cost=field.expected_cost.copy(),
        no_fly_mask=field.no_fly_mask.copy(),
        uncertainty=field.uncertainty.copy(),
        cvar_cost=field.cvar_cost.copy(),
        wind_risk=field.wind_risk.copy(),
        shear_turbulence_risk=field.shear_turbulence_risk.copy(),
        convection_risk=field.convection_risk.copy(),
        visibility_risk=field.visibility_risk.copy(),
        precipitation_risk=field.precipitation_risk.copy(),
        gust_risk=field.gust_risk.copy(),
        shear_risk=field.shear_risk.copy(),
        turbulence_risk=field.turbulence_risk.copy(),
        total_cost=field.total_cost.copy(),
        wind_u=field.wind_u.copy(),
        wind_v=field.wind_v.copy(),
        wind_w=field.wind_w.copy(),
        ground_speed_effect=field.ground_speed_effect.copy(),
        energy_penalty=field.energy_penalty.copy(),
        violation_probability=field.violation_probability.copy(),
        joint_risk=field.joint_risk.copy(),
        fatal_score=field.fatal_score.copy(),
        cumulative_score=field.cumulative_score.copy(),
        weighted_soft_cost=field.weighted_soft_cost.copy(),
        coords={name: np.asarray(value).copy() for name, value in field.coords.items()},
        confidence=field.confidence.copy() if isinstance(field.confidence, np.ndarray) else field.confidence,
        source_metadata={**field.source_metadata},
        channel_metadata={**field.channel_metadata},
        metadata={**field.metadata, "source": "dstar_lite_4d_smoke_update"},
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.parse_args()
    print(json.dumps(run_dstar_lite_4d_smoke_test(), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

