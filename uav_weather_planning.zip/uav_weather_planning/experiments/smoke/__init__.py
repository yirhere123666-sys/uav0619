"""Small smoke tests for validating key experiment paths."""

