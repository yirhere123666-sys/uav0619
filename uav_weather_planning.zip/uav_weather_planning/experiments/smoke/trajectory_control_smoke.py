﻿from __future__ import annotations

from pathlib import Path
import argparse
import json

import numpy as np

from uav_weather_planning.control import MultirotorDynamicsModel, RobustNMPCInterface
from uav_weather_planning.global_planner import FlightConstraints, TimeDependentAStar
from uav_weather_planning.risk_field import RiskField4D
from uav_weather_planning.trajectory import BSplineSmoother, BSplineSmoothingConfig, KinodynamicTrajectoryChecker


def run_trajectory_control_smoke(output_dir: str | Path = "outputs/trajectory_control_smoke") -> dict:
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    risk_field = _make_metric_test_field()
    constraints = FlightConstraints(
        enforce_metric_limits=True,
        max_ground_speed_mps=15.0,
        max_climb_rate_mps=3.0,
        max_descent_rate_mps=3.0,
        max_acceleration_mps2=4.0,
        max_yaw_rate_deg_s=60.0,
    )
    start = (0, 1, 1)
    goal = (0, 10, 10)
    path_result = TimeDependentAStar(risk_field, constraints=constraints).plan(start, goal)
    if not path_result.success:
        raise RuntimeError(f"global planner failed in trajectory smoke test: {path_result.reason}")

    smoother = BSplineSmoother(
        risk_field,
        constraints=constraints,
        config=BSplineSmoothingConfig(degree=3, sample_dt_s=0.5),
    )
    trajectory = smoother.smooth(path_result.path)
    checker = KinodynamicTrajectoryChecker(risk_field, constraints)
    check_report = checker.check(trajectory)
    nmpc = RobustNMPCInterface(dynamics=MultirotorDynamicsModel())
    rollout = nmpc.simulate_tracking(trajectory)

    summary = {
        "mission": {"start": start, "goal": goal},
        "global_path": {
            "success": path_result.success,
            "path_length": len(path_result.path),
            "nodes_expanded": path_result.nodes_expanded,
            "elapsed_ms": round(path_result.elapsed_ms, 3),
        },
        "bspline_trajectory": trajectory.as_summary(),
        "trajectory_check": check_report.as_dict(),
        "nmpc_problem": nmpc.build_problem_definition().as_dict(),
        "closed_loop_placeholder": rollout.as_summary(),
        "claim_boundary": (
            "This validates the interface from global 4D path planning to B-spline trajectory sampling, "
            "kinodynamic checking, and NMPC problem definition. It is not yet a full nonlinear NMPC solver."
        ),
    }
    with (output_dir / "trajectory_control_summary.json").open("w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)
    return summary


def _make_metric_test_field() -> RiskField4D:
    field = RiskField4D.uniform(18, 1, 12, 12, base_cost=1.0)
    field.coords = {
        "time": np.arange(18, dtype=float),
        "height": np.array([60.0], dtype=float),
        "y": np.arange(12, dtype=float) * 5.0,
        "x": np.arange(12, dtype=float) * 5.0,
    }
    field.source_metadata = {
        "time_axis_unit": "seconds_from_mission_start",
        "geospatial_grid": {
            "crs": "LOCAL_ENU_METERS",
            "axis_definition": {
                "x": "east_m",
                "y": "north_m",
                "height": "altitude_m",
                "time": "seconds_from_mission_start",
            },
        },
    }
    field.metadata = {**field.metadata, "source": "trajectory_control_smoke_metric_grid"}
    return field


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", default="outputs/trajectory_control_smoke")
    args = parser.parse_args()
    summary = run_trajectory_control_smoke(args.output_dir)
    print("Trajectory/control smoke test finished.")
    print(f"Outputs: {args.output_dir}")
    print(json.dumps({"trajectory_valid": summary["trajectory_check"]["valid"], "nmpc": summary["closed_loop_placeholder"]}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
