from uav_weather_planning.experiments.midterm.midterm_simulated_risk_demo import *  # noqa: F401,F403
from uav_weather_planning.experiments.midterm.midterm_simulated_risk_demo import main as _main
from uav_weather_planning.experiments._compat import run_compat_main


if __name__ == "__main__":
    run_compat_main("uav_weather_planning.experiments.midterm_simulated_risk_demo", "uav_weather_planning.experiments.midterm.midterm_simulated_risk_demo", _main)
