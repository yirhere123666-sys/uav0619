from uav_weather_planning.experiments.benchmarks.risk_weight_sensitivity import *  # noqa: F401,F403
from uav_weather_planning.experiments.benchmarks.risk_weight_sensitivity import main as _main
from uav_weather_planning.experiments._compat import run_compat_main


if __name__ == "__main__":
    run_compat_main("uav_weather_planning.experiments.risk_weight_sensitivity", "uav_weather_planning.experiments.benchmarks.risk_weight_sensitivity", _main)
