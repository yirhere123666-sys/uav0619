# Experiment Module Layout

实验入口已分类到子包中，根层模块保留为兼容 wrapper。

## 子包

- `midterm/`：中期检查演示和真实数据小闭环。
- `real_replay/`：历史天气、多时刻真实天气和多案例真实回放。
- `benchmarks/`：benchmark、消融、增量搜索验证、校准证据和敏感性分析。
- `paper_10km/`：10 km 局地风险场、WRF 背景、3D 图和 D* Lite 路径受影响实验。
- `smoke/`：快速运行验证。
- `utils/`：跨实验共享工具。

## 兼容策略

以下旧命令仍可使用：

```powershell
python -m uav_weather_planning.experiments.benchmark_suite
python -m uav_weather_planning.experiments.multi_time_real_weather_replay
python -m uav_weather_planning.experiments.paper_10km_weather_risk_demo
```

新代码优先导入子包实现，例如：

```python
from uav_weather_planning.experiments.paper_10km.paper_10km_weather_risk_demo import run_paper_10km_weather_risk_demo
```

