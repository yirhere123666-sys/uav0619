from uav_weather_planning.experiments.benchmarks.benchmark_suite import *  # noqa: F401,F403
from uav_weather_planning.experiments.benchmarks.benchmark_suite import main as _main
from uav_weather_planning.experiments._compat import run_compat_main


if __name__ == "__main__":
    run_compat_main("uav_weather_planning.experiments.benchmark_suite", "uav_weather_planning.experiments.benchmarks.benchmark_suite", _main)
