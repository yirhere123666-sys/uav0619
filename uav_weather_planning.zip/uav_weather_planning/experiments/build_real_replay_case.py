from uav_weather_planning.experiments.real_replay.build_real_replay_case import *  # noqa: F401,F403
from uav_weather_planning.experiments.real_replay.build_real_replay_case import main as _main
from uav_weather_planning.experiments._compat import run_compat_main


if __name__ == "__main__":
    run_compat_main("uav_weather_planning.experiments.build_real_replay_case", "uav_weather_planning.experiments.real_replay.build_real_replay_case", _main)
