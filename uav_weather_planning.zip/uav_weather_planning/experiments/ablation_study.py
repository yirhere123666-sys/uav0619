from uav_weather_planning.experiments.benchmarks.ablation_study import *  # noqa: F401,F403
from uav_weather_planning.experiments.benchmarks.ablation_study import main as _main
from uav_weather_planning.experiments._compat import run_compat_main


if __name__ == "__main__":
    run_compat_main("uav_weather_planning.experiments.ablation_study", "uav_weather_planning.experiments.benchmarks.ablation_study", _main)
