from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import argparse
import csv
import json
import time
from typing import Any

import numpy as np

from uav_weather_planning.airspace import CorridorGraph
from uav_weather_planning.data_interface import (
    HistoricalReplayConfig,
    HistoricalWeatherReplayLoader,
    LocalGFSReplayConfig,
    LocalGFSReplayLoader,
    WeatherCube,
    WeatherDataError,
    WRFLoader,
    WRFLoaderConfig,
)
from uav_weather_planning.global_planner import (
    DStarLiteRepairAdapter,
    FlightConstraints,
    IncrementalRepairAdapter,
    TimeDependentAStar,
    evaluate_path,
)
from uav_weather_planning.models import load_grid_hierarchy
from uav_weather_planning.preprocessing import LocalPlanningGridConfig, normalize_weather_cube_to_local_planning_grid
from uav_weather_planning.risk import audit_path_risk
from uav_weather_planning.risk_field import RiskField4D
from uav_weather_planning.risk_field.risk_field_4d import SpatialNode, State4D
from uav_weather_planning.risk_models import build_risk_field_from_weather
from uav_weather_planning.visualization import (
    animate_path_over_time,
    animate_path_over_time_3d,
    animate_risk_volume_3d,
    plot_path_on_risk,
    plot_risk_channels_3d,
    plot_risk_volume_3d,
)


@dataclass
class FuturePathStatus:
    need_replan: bool
    path_risk_before_update: float
    path_risk_after_update: float
    nofly_intrusions_after_update: int
    max_total_cost_after_update: float
    future_cvar_risk_after_update: float
    max_segment_cvar_after_update: float
    max_violation_probability_after_update: float
    replan_reason: str


def run_multi_time_real_weather_replay(
    output_dir: str | Path = "outputs/multi_time_real_weather_replay",
    case_dir: str | Path | None = None,
    cube_paths: tuple[str | Path, ...] = (),
    wrf_zip_path: str | Path | None = None,
    allow_nowcast_fallback: bool = False,
    downscale: bool = True,
    make_plots: bool = True,
    make_animations: bool = True,
    enable_airspace: bool = False,
    corridor_required: bool = False,
    corridor_width_cells: float = 3.0,
    xy_resolution_m: float = 100.0,
    altitude_min_m: float = 60.0,
    altitude_max_m: float = 180.0,
    x_extent_m: float = 12000.0,
    y_extent_m: float = 12000.0,
    planning_dt_s: float = 10.0,
    planning_horizon_s: float = 1200.0,
    repair_mode: str = "full_restart",
) -> dict[str, Any]:
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    raw_cube, case_metadata = (
        _load_wrf_cube(wrf_zip_path)
        if wrf_zip_path is not None
        else _load_replay_cube(case_dir, cube_paths, allow_nowcast_fallback)
    )
    height_levels = tuple(np.arange(float(altitude_min_m), float(altitude_max_m) + 1e-6, 20.0, dtype=float))
    local_grid = LocalPlanningGridConfig(
        x_extent_m=float(x_extent_m),
        y_extent_m=float(y_extent_m),
        xy_resolution_m=float(xy_resolution_m),
        height_levels_m=height_levels,
        dt_s=float(planning_dt_s),
        horizon_s=float(planning_horizon_s),
    )
    cube = normalize_weather_cube_to_local_planning_grid(raw_cube, local_grid) if downscale else raw_cube
    risk_field = build_risk_field_from_weather(cube)
    _apply_local_motion_grid(
        risk_field,
        xy_resolution_m=xy_resolution_m,
        altitude_min_m=altitude_min_m,
        altitude_max_m=altitude_max_m,
    )
    base_constraints = FlightConstraints(
        max_horizontal_step_cells=1.5,
        max_vertical_step_layers=1,
        max_turn_angle_deg=135.0,
        enforce_metric_limits=True,
        max_ground_speed_mps=15.0,
        max_climb_rate_mps=2.0,
        max_descent_rate_mps=2.0,
        max_yaw_rate_deg_s=45.0,
        max_acceleration_mps2=4.0,
        min_altitude_m=altitude_min_m,
        max_altitude_m=altitude_max_m,
    )
    start, goal = _select_mission(risk_field, base_constraints)
    airspace = (
        CorridorGraph.from_mission(
            risk_field=risk_field,
            start=start,
            goal=goal,
            corridor_width_cells=corridor_width_cells,
            speed_limit_mps=base_constraints.max_ground_speed_mps or 15.0,
            altitude_min_m=altitude_min_m,
            altitude_max_m=altitude_max_m,
        )
        if enable_airspace
        else None
    )
    constraints = FlightConstraints(
        max_horizontal_step_cells=1.5,
        max_vertical_step_layers=1,
        max_turn_angle_deg=135.0,
        enforce_metric_limits=True,
        max_ground_speed_mps=15.0,
        max_climb_rate_mps=2.0,
        max_descent_rate_mps=2.0,
        max_yaw_rate_deg_s=45.0,
        max_acceleration_mps2=4.0,
        min_altitude_m=altitude_min_m,
        max_altitude_m=altitude_max_m,
        airspace=airspace,
        corridor_required=corridor_required if airspace is not None else False,
    )
    initial_static = risk_field.as_static_snapshot(0)
    initial_plan = TimeDependentAStar(initial_static, constraints=constraints, heuristic_weight=4.0).plan(start, goal)
    if not initial_plan.success:
        initial_plan = TimeDependentAStar(risk_field, constraints=constraints, heuristic_weight=4.0).plan(start, goal)
    if repair_mode == "dstar_lite":
        repair_adapter: Any = DStarLiteRepairAdapter(initial_static, constraints=constraints)
        repair_adapter.plan_initial(start, goal, start_time=0)
        planner_name = "dstar_lite_repair"
    elif repair_mode == "lpa_repair":
        repair_adapter = IncrementalRepairAdapter(initial_static, constraints=constraints)
        repair_adapter.plan_initial(start, goal, start_time=0)
        planner_name = "lpa_incremental_repair"
    elif repair_mode == "full_restart":
        repair_adapter = None
        planner_name = "restart_full_search"
    else:
        repair_adapter = IncrementalRepairAdapter(initial_static, constraints=constraints)
        repair_adapter.plan_initial(start, goal, start_time=0)
        planner_name = "lpa_incremental_repair"
    current_path = initial_plan.path
    current_state: State4D = current_path[0] if current_path else (0, *start)
    executed_path: list[State4D] = [current_state]
    change_rows: list[dict[str, Any]] = []
    replan_rows: list[dict[str, Any]] = []

    for step in range(1, risk_field.t_size):
        previous_slice = _slice_as_static(risk_field, step - 1)
        current_slice = _slice_as_static(risk_field, step)
        raw_changed = previous_slice.raw_changed_voxels(current_slice)
        significant_changed = previous_slice.significant_changed_voxels(current_slice)
        raw_changed_voxel_ratio = float(np.mean(raw_changed))
        significant_changed_voxel_ratio = float(np.mean(significant_changed))
        new_no_fly_voxels = int(np.sum(current_slice.no_fly_mask & ~previous_slice.no_fly_mask))
        removed_no_fly_voxels = int(np.sum(previous_slice.no_fly_mask & ~current_slice.no_fly_mask))
        status = _audit_future_path(current_path, previous_slice, current_slice, horizon=6, current_step=step)
        valid_time = _time_value(cube.time[step])
        forecast_hour = _forecast_hour(cube, step)
        need_replan = status.need_replan
        replan_success = False
        replan_latency_ms = 0.0
        nodes_expanded = 0
        step_repair_mode = "audit_only"
        repair_extra: dict[str, Any] = {
            "planner_name": "",
            "g_rhs_reused": "",
            "queue_reused": "",
            "affected_nodes": "",
            "edge_updates": "",
            "vertex_updates": "",
            "fallback_used": "",
            "fallback_reason": "",
            "path_cvar": "",
            "max_segment_cvar": "",
            "reverse_search_from_goal": "",
            "moving_start_enabled": "",
            "km_enabled": "",
            "km_final": "",
            "start_updates": "",
            "affected_edges": "",
            "affected_vertices": "",
        }
        if need_replan:
            repair_start = time.perf_counter()
            current_state = _state_at_or_before(current_path, step, current_state)
            if repair_mode == "full_restart":
                repaired = TimeDependentAStar(risk_field, constraints=constraints, heuristic_weight=4.0).plan(current_state, goal, start_time=current_state[0])
            else:
                if repair_adapter is None:
                    raise RuntimeError("repair_adapter is required unless repair_mode='full_restart'")
                repaired = repair_adapter.repair_after_update(
                    updated_risk_field=risk_field,
                    changed_voxels=significant_changed,
                    current_state=current_state,
                    goal=goal,
                )
            replan_latency_ms = (time.perf_counter() - repair_start) * 1000.0
            nodes_expanded = repaired.nodes_expanded
            replan_success = repaired.success
            step_repair_mode = getattr(repaired, "repair_mode", repair_mode)
            repair_extra = {
                "planner_name": planner_name,
                "g_rhs_reused": getattr(repaired, "g_rhs_reused", False),
                "queue_reused": getattr(repaired, "queue_reused", False),
                "affected_nodes": getattr(repaired, "affected_nodes", None),
                "edge_updates": getattr(repaired, "edge_updates", None),
                "vertex_updates": getattr(repaired, "vertex_updates", None),
                "fallback_used": getattr(repaired, "fallback_used", False),
                "fallback_reason": getattr(repaired, "fallback_reason", ""),
                "path_cvar": getattr(repaired, "path_cvar", None),
                "max_segment_cvar": getattr(repaired, "max_segment_cvar", None),
                "reverse_search_from_goal": getattr(repaired, "reverse_search_from_goal", False),
                "moving_start_enabled": getattr(repaired, "moving_start_enabled", False),
                "km_enabled": getattr(repaired, "km_enabled", False),
                "km_final": getattr(repaired, "km_final", None),
                "start_updates": getattr(repaired, "start_updates", None),
                "affected_edges": getattr(repaired, "affected_edges", None),
                "affected_vertices": getattr(repaired, "affected_vertices", None),
            }
            if repaired.success:
                current_path = _merge_prefix(executed_path, repaired.path)
        else:
            step_repair_mode = "audit_only"
        airspace_audit = audit_airspace_path(current_path, airspace, constraints, risk_field)
        replan_rows.append(
            {
                "case_id": case_metadata["case_id"],
                "source": case_metadata["source"],
                "forecast_hour": forecast_hour,
                "valid_time": valid_time,
                "raw_changed_voxel_ratio": round(raw_changed_voxel_ratio, 6),
                "significant_changed_voxel_ratio": round(significant_changed_voxel_ratio, 6),
                "changed_voxel_ratio": round(significant_changed_voxel_ratio, 6),
                "raw_changed_voxels": int(np.sum(raw_changed)),
                "significant_changed_voxels": int(np.sum(significant_changed)),
                "new_no_fly_voxels": new_no_fly_voxels,
                "removed_no_fly_voxels": removed_no_fly_voxels,
                "need_replan": need_replan,
                "decision_type": "repair" if need_replan else "audit_only",
                "repair_mode": step_repair_mode,
                "replan_success": replan_success,
                "replan_latency_ms": round(replan_latency_ms, 3),
                "nodes_expanded": nodes_expanded,
                "path_length": len(current_path),
                "repaired_from": current_state if need_replan else "",
                "path_risk_before_update": round(status.path_risk_before_update, 3),
                "path_risk_after_update": round(status.path_risk_after_update, 3),
                "nofly_intrusions_after_update": status.nofly_intrusions_after_update,
                "future_cvar_risk_after_update": round(status.future_cvar_risk_after_update, 3),
                "future_max_segment_cvar": round(status.max_segment_cvar_after_update, 3),
                "future_max_violation_probability": round(status.max_violation_probability_after_update, 3),
                "replan_reason": status.replan_reason,
                **repair_extra,
                **airspace_audit,
            }
        )
        next_state = _next_state_for_step(current_path, step, current_state)
        current_state = next_state
        if not executed_path or executed_path[-1] != current_state:
            executed_path.append(current_state)
        change_rows.append(
            {
                "case_id": case_metadata["case_id"],
                "source": case_metadata["source"],
                "forecast_hour": forecast_hour,
                "valid_time": valid_time,
                "raw_changed_voxel_ratio": round(raw_changed_voxel_ratio, 6),
                "significant_changed_voxel_ratio": round(significant_changed_voxel_ratio, 6),
                "changed_voxel_ratio": round(significant_changed_voxel_ratio, 6),
                "raw_changed_voxels": int(np.sum(raw_changed)),
                "significant_changed_voxels": int(np.sum(significant_changed)),
                "changed_voxels": int(np.sum(significant_changed)),
                "new_no_fly_voxels": new_no_fly_voxels,
                "removed_no_fly_voxels": removed_no_fly_voxels,
                "path_risk_before_update": round(status.path_risk_before_update, 3),
                "path_risk_after_update": round(status.path_risk_after_update, 3),
                "need_replan": need_replan,
                "future_cvar_risk_after_update": round(status.future_cvar_risk_after_update, 3),
                "future_max_segment_cvar": round(status.max_segment_cvar_after_update, 3),
                "future_max_violation_probability": round(status.max_violation_probability_after_update, 3),
                "replan_reason": status.replan_reason,
                "replan_success": replan_success,
                "replan_latency_ms": round(replan_latency_ms, 3),
                "nodes_expanded": nodes_expanded,
                "repair_mode": repair_mode,
                "repair_algorithm": step_repair_mode,
                "path_length": len(current_path),
                **repair_extra,
                **airspace_audit,
            }
        )

    actual_replan_rows = [row for row in replan_rows if bool(row["need_replan"])]
    final_metrics = evaluate_path(
        "Multi-time real-weather replay path",
        executed_path,
        risk_field,
        nodes_expanded=sum(int(row["nodes_expanded"]) for row in actual_replan_rows),
        elapsed_ms=sum(float(row["replan_latency_ms"]) for row in actual_replan_rows),
        replan_count=len(actual_replan_rows),
        constraints=constraints,
    )
    metrics_row = {
        **final_metrics.as_row(),
        **audit_path_risk(executed_path, risk_field),
        "case_id": case_metadata["case_id"],
        "source": case_metadata["source"],
        "strict_historical_sequence": bool(cube.source_metadata.get("strict_historical_sequence", False)),
        "real_valid_times_count": cube.source_metadata.get("real_valid_times_count"),
        "forecast_hours": ";".join(str(_forecast_hour(cube, idx)) for idx in range(cube.shape[0])),
        "airspace_enabled": airspace is not None,
        "corridor_required": constraints.corridor_required,
        "airspace_network": "CorridorGraph" if airspace is not None else "",
        "trajectory_corridor_constraints_removed": airspace is None,
        "repair_mode": repair_mode,
        "planner_name": planner_name,
    }
    if "max_vertical_rate_mps" in metrics_row:
        metrics_row.setdefault("max_climb_rate_mps", metrics_row["max_vertical_rate_mps"])
        metrics_row.setdefault("max_descend_rate_mps", metrics_row["max_vertical_rate_mps"])
    _write_csv(output_dir / "risk_field_change_log.csv", change_rows)
    _write_csv(output_dir / "replan_event_log.csv", replan_rows)
    _write_csv(output_dir / "real_replay_metrics.csv", [metrics_row])
    visual_outputs: list[str] = []
    if make_plots and executed_path:
        middle_time = min(risk_field.t_size // 2, risk_field.t_size - 1)
        plot_path_on_risk(risk_field, executed_path, output_dir / "real_replay_dynamic_path.png", "多时刻真实天气回放路径", time_index=middle_time)
        plot_risk_volume_3d(
            risk_field,
            output_dir / "real_replay_3d_joint_risk_volume.png",
            time_index=middle_time,
            channel="joint_risk",
            path=executed_path,
            title="真实多时刻回放：三维联合风险体与航迹",
        )
        plot_risk_channels_3d(
            risk_field,
            output_dir / "real_replay_3d_weather_channels.png",
            time_index=middle_time,
        )
        visual_outputs.extend(
            [
                "real_replay_dynamic_path.png",
                "real_replay_3d_joint_risk_volume.png",
                "real_replay_3d_weather_channels.png",
            ]
        )
        if make_animations:
            animate_path_over_time(
                risk_field,
                executed_path,
                output_dir / "real_replay_path_over_time.gif",
                height_index=min(1, risk_field.z_size - 1),
                channel="total_cost",
                fps=3,
                frame_step=2,
            )
            animate_risk_volume_3d(
                risk_field,
                output_dir / "real_replay_3d_joint_risk_volume.gif",
                channel="joint_risk",
                path=executed_path,
                fps=3,
                frame_step=5,
            )
            animate_path_over_time_3d(
                risk_field,
                executed_path,
                output_dir / "real_replay_3d_path_over_time.gif",
                channel="joint_risk",
                fps=3,
                frame_step=5,
            )
            visual_outputs.extend(
                [
                    "real_replay_path_over_time.gif",
                    "real_replay_3d_joint_risk_volume.gif",
                    "real_replay_3d_path_over_time.gif",
                ]
            )
    if airspace is not None:
        with (output_dir / "airspace_network.json").open("w", encoding="utf-8") as f:
            json.dump(airspace.as_dict(), f, ensure_ascii=False, indent=2)
    final_airspace_audit = audit_airspace_path(executed_path, airspace, constraints, risk_field)
    forecast_hours = ";".join(str(_forecast_hour(cube, idx)) for idx in range(cube.shape[0]))
    summary = {
        "case": case_metadata,
        "source_metadata": cube.source_metadata,
        "raw_weather_shape": raw_cube.shape,
        "downscaled_weather_shape": cube.shape,
        "risk_shape": risk_field.shape,
        "local_planning_grid": cube.source_metadata.get("local_planning_grid"),
        "background_weather_grid": cube.source_metadata.get("background_weather_grid"),
        "background_valid_times": cube.source_metadata.get("background_valid_times"),
        "background_forecast_hours": raw_cube.source_metadata.get("lead_time_hours"),
        "local_time_axis_s": cube.source_metadata.get("local_time_axis_s"),
        "mission_distance_m": round(_mission_distance_m(risk_field, start, goal), 3),
        "time_step_s": float(planning_dt_s),
        "grid_resolution_m": float(xy_resolution_m),
        "height_levels_m": [float(value) for value in np.asarray(risk_field.coords.get("height", []), dtype=float)],
        "strict_historical_sequence": bool(cube.source_metadata.get("strict_historical_sequence", False)),
        "historical_replay_mode": cube.source_metadata.get("historical_replay_mode"),
        "real_valid_times_count": cube.source_metadata.get("real_valid_times_count"),
        "forecast_hours": forecast_hours,
        "valid_times": [_time_value(value) for value in cube.time],
        "mission": {"start": start, "goal": goal},
        "trajectory_corridor_constraints": {
            "enabled": airspace is not None,
            "removed_for_current_wrf_demo": airspace is None,
            "note": (
                "Structured airway/corridor trajectory constraints are disabled in this run. "
                "Weather no-fly masks, risk costs and multirotor speed/climb limits remain active."
            ),
        },
        "flight_constraints": constraints.as_dict(),
        "airspace_enabled": airspace is not None,
        "corridor_required": constraints.corridor_required,
        "airspace_network": "CorridorGraph" if airspace is not None else None,
        "airspace_network_summary": airspace.as_summary() if airspace is not None else None,
        "airspace_violations": final_airspace_audit["airspace_violations"],
        "corridor_segments_used": final_airspace_audit["corridor_segments_used"],
        "mean_corridor_deviation_m": final_airspace_audit["mean_corridor_deviation_m"],
        "max_corridor_deviation_m": final_airspace_audit["max_corridor_deviation_m"],
        "max_corridor_deviation_ratio": final_airspace_audit["max_corridor_deviation_ratio"],
        "airspace_metrics": final_airspace_audit,
        "grid_hierarchy": load_grid_hierarchy().as_dict(),
        "risk_metrics": audit_path_risk(executed_path, risk_field),
        "risk_model_evidence": {
            "threshold_source": risk_field.channel_metadata.get("threshold_source"),
            "thresholds": risk_field.channel_metadata.get("thresholds"),
            "mapping_evidence": risk_field.channel_metadata.get("risk_mapping_evidence", {}),
            "fusion_policy": risk_field.channel_metadata.get("fusion_policy"),
            "fusion_evidence": risk_field.channel_metadata.get("fusion_evidence"),
            "fatal_channels": risk_field.channel_metadata.get("fatal_channels"),
            "cumulative_weights": risk_field.channel_metadata.get("cumulative_weights"),
            "hard_mask_sources": risk_field.channel_metadata.get("hard_mask_sources"),
            "hard_mask_voxel_count": risk_field.channel_metadata.get("hard_mask_voxel_count"),
            "weights": risk_field.channel_metadata.get("weights"),
            "expected_cost_kernel": risk_field.channel_metadata.get("expected_cost_kernel"),
            "base_cost": risk_field.channel_metadata.get("base_cost"),
            "joint_risk_weight": risk_field.channel_metadata.get("joint_risk_weight"),
            "weighted_soft_cost_role": risk_field.channel_metadata.get("weighted_soft_cost_role"),
            "chance_constraint_limit": risk_field.channel_metadata.get("chance_constraint_limit"),
            "envelope_probability_limit": risk_field.channel_metadata.get("envelope_probability_limit"),
            "uncertainty_role": risk_field.channel_metadata.get("uncertainty_role"),
            "uncertainty_formula": (
                "sigma(x,t)=sigma0+beta*U(x,t); "
                "R_m(x,t)=clip(R(x,t)+sigma(x,t)*epsilon_m,0,1); "
                "C=E[R]+lambda_cvar*CVaR_alpha(R)+lambda_u*U"
            ),
            "uncertainty_alias": risk_field.channel_metadata.get("uncertainty_alias"),
            "uncertainty_conservative_weight": risk_field.channel_metadata.get("uncertainty_conservative_weight"),
            "uncertainty_sigma0": risk_field.channel_metadata.get("uncertainty_sigma0"),
            "uncertainty_beta": risk_field.channel_metadata.get("uncertainty_beta"),
            "ignored_uncertainty_weight_keys": risk_field.channel_metadata.get("ignored_uncertainty_weight_keys"),
        },
        "change_summary": _summarize_change_rows(change_rows),
        "change_detection_policy": {
            "raw_changed_voxels": "any expected/cvar/total/violation/no-fly change larger than 1e-6",
            "significant_changed_voxels": {
                "total_cost_delta": 0.3,
                "cvar_delta": 0.2,
                "violation_probability_delta": 0.1,
                "no_fly_mask": "any boolean change",
            },
            "incremental_update_policy": "LPA*/D* Lite-family updates should use significant_changed_voxels and their predecessor/successor neighborhood.",
        },
        "replan_summary": {
            "decision_count": len(replan_rows),
            "event_count": len(actual_replan_rows),
            "success_count": sum(1 for row in actual_replan_rows if row["replan_success"]),
            "mean_replan_latency_ms": _mean([row["replan_latency_ms"] for row in actual_replan_rows]),
            "planner_name": planner_name,
            "repair_mode": repair_mode,
            "g_rhs_reused": any(str(row.get("g_rhs_reused")).lower() == "true" for row in actual_replan_rows),
            "queue_reused": any(str(row.get("queue_reused")).lower() == "true" for row in actual_replan_rows),
            "reverse_search_from_goal": any(str(row.get("reverse_search_from_goal")).lower() == "true" for row in actual_replan_rows),
            "moving_start_enabled": any(str(row.get("moving_start_enabled")).lower() == "true" for row in actual_replan_rows),
            "km_enabled": any(str(row.get("km_enabled")).lower() == "true" for row in actual_replan_rows),
            "km_final": _last_numeric([row.get("km_final") for row in actual_replan_rows]),
            "start_updates": _last_numeric([row.get("start_updates") for row in actual_replan_rows]),
            "replan_reasons": _count_values([row.get("replan_reason") for row in actual_replan_rows]),
        },
        "metrics": metrics_row,
        "outputs": [
            "real_replay_metrics.csv",
            "real_replay_summary.json",
            "risk_field_change_log.csv",
            "replan_event_log.csv",
            *(["airspace_network.json"] if airspace is not None else []),
            *visual_outputs,
        ],
        "claim_boundary": (
            "Strict multi-time replay is true only when strict_historical_sequence is true. "
            "If false, the run is a documented nowcast fallback for code validation, not evidence of real multi-valid-time dynamics."
        ),
    }
    with (output_dir / "real_replay_summary.json").open("w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)
    return summary


def _load_replay_cube(
    case_dir: str | Path | None,
    cube_paths: tuple[str | Path, ...],
    allow_nowcast_fallback: bool,
) -> tuple[WeatherCube, dict[str, Any]]:
    metadata = _read_case_metadata(case_dir)
    paths = list(cube_paths)
    if case_dir is not None:
        paths.extend(sorted(Path(case_dir).glob("*.npz")))
    if paths:
        cube = HistoricalWeatherReplayLoader().load(
            HistoricalReplayConfig(cube_paths=tuple(paths), allow_single_time_fallback=False)
        )
        metadata.setdefault("case_id", Path(case_dir).name if case_dir else "explicit_cube_paths")
        metadata.setdefault("source", cube.source_metadata.get("source", "cached_weather_cube_sequence"))
        return cube, metadata
    if case_dir is not None:
        nc_paths = sorted(Path(case_dir).glob("*.nc"))
        if nc_paths:
            raise WeatherDataError("NetCDF replay case detected, but convert files to cached WeatherCube .npz first for this runner.")
    if not allow_nowcast_fallback:
        raise WeatherDataError(
            "No multi-time WeatherCube sequence found. Provide --case-dir/--cube-paths or pass --allow-nowcast-fallback for a documented smoke run."
        )
    cube = LocalGFSReplayLoader().load(LocalGFSReplayConfig(t_size=8, z_size=3, y_size=18, x_size=18, cache_policy="reuse"))
    return cube, {
        "case_id": "local_gfs_single_valid_time_nowcast_fallback",
        "source": cube.source_metadata.get("source", "LOCAL_GFS_REPLAY"),
        "forecast_hours": list(range(cube.shape[0])),
        "region": "local_task_region",
        "grid_resolution_note": "regional background field mapped to local planning grid; fallback uses advected single valid time",
    }


def _load_wrf_cube(wrf_zip_path: str | Path) -> tuple[WeatherCube, dict[str, Any]]:
    cube = WRFLoader().load(WRFLoaderConfig(path=wrf_zip_path))
    return cube, {
        "case_id": Path(wrf_zip_path).stem,
        "source": "WRF",
        "forecast_hours": cube.source_metadata.get("lead_time_hours", []),
        "region": "wrf_background_mapped_to_5km_local_task_region",
        "grid_resolution_note": (
            "WRF regional background grid is converted to the canonical local 4D risk grid; "
            "second-scale local perturbations are added after resampling."
        ),
    }


def _read_case_metadata(case_dir: str | Path | None) -> dict[str, Any]:
    if case_dir is None:
        return {}
    path = Path(case_dir) / "metadata.json"
    if not path.exists():
        return {"case_id": Path(case_dir).name}
    return json.loads(path.read_text(encoding="utf-8"))


def _slice_as_static(risk_field: RiskField4D, index: int) -> RiskField4D:
    return risk_field.as_static_snapshot(int(np.clip(index, 0, risk_field.t_size - 1)))


def _audit_future_path(
    path: list[State4D],
    previous_field: RiskField4D,
    current_field: RiskField4D,
    horizon: int,
    current_step: int,
) -> FuturePathStatus:
    future = [state for state in path if state[0] >= current_step][:horizon]
    if not future and path:
        future = [path[-1]]
    before = _path_total_cost(future, previous_field)
    after = _path_total_cost(future, current_field)
    intrusions = sum(1 for state in future if current_field.is_no_fly((0, state[1], state[2], state[3])))
    max_cost = max([current_field.cost_at((0, state[1], state[2], state[3])) for state in future] or [0.0])
    cvar_values = [float(current_field.cvar_cost[0, state[1], state[2], state[3]]) for state in future]
    violation_values = [float(current_field.violation_probability[0, state[1], state[2], state[3]]) for state in future]
    future_cvar = float(sum(cvar_values))
    max_segment_cvar = max(cvar_values or [0.0])
    max_violation = max(violation_values or [0.0])
    risk_increase = after - before
    meaningful_increase = risk_increase > max(0.1, 0.02 * max(before, 1.0))
    cvar_threshold_exceeded = future_cvar >= 12.0 or max_segment_cvar >= 4.5
    violation_threshold_exceeded = max_violation >= 0.86
    need_replan = (
        intrusions > 0
        or meaningful_increase
        or max_cost >= 18.0
        or cvar_threshold_exceeded
        or violation_threshold_exceeded
    )
    if intrusions > 0:
        reason = "no_fly_intrusion"
    elif cvar_threshold_exceeded:
        reason = "cvar_threshold_exceeded"
    elif violation_threshold_exceeded:
        reason = "violation_probability_limit_exceeded"
    elif max_cost >= 18.0:
        reason = "total_cost_threshold_exceeded"
    elif meaningful_increase:
        reason = "expected_risk_increase"
    else:
        reason = "none"
    return FuturePathStatus(
        need_replan=need_replan,
        path_risk_before_update=before,
        path_risk_after_update=after,
        nofly_intrusions_after_update=intrusions,
        max_total_cost_after_update=float(max_cost),
        future_cvar_risk_after_update=future_cvar,
        max_segment_cvar_after_update=float(max_segment_cvar),
        max_violation_probability_after_update=float(max_violation),
        replan_reason=reason,
    )


def _path_total_cost(path: list[State4D], field: RiskField4D) -> float:
    total = 0.0
    for state in path:
        value = field.cost_at((0, state[1], state[2], state[3]))
        total += 1e6 if not np.isfinite(value) else float(value)
    return total


def _apply_local_motion_grid(
    risk_field: RiskField4D,
    xy_resolution_m: float,
    altitude_min_m: float,
    altitude_max_m: float,
) -> None:
    """Define the low-altitude airway decision grid in metric coordinates."""

    risk_field.coords = {
        **risk_field.coords,
        "x": np.arange(risk_field.x_size, dtype=float) * float(xy_resolution_m),
        "y": np.arange(risk_field.y_size, dtype=float) * float(xy_resolution_m),
        "height": np.linspace(float(altitude_min_m), float(altitude_max_m), risk_field.z_size),
    }
    risk_field.source_metadata = {
        **risk_field.source_metadata,
        "time_axis_unit": "seconds",
        "motion_grid": {
            "role": "local low-altitude airway decision grid for multirotor global planning",
            "xy_resolution_m": float(xy_resolution_m),
            "altitude_min_m": float(altitude_min_m),
            "altitude_max_m": float(altitude_max_m),
            "note": (
                "This grid is used for route-level constraints and corridor auditing. "
                "It is not claimed as the final meter-level NMPC control grid."
            ),
        },
        "geospatial_grid": {
            "crs": "LOCAL_METRIC",
            "resolution_m": float(xy_resolution_m),
            "altitude_range_m": [float(altitude_min_m), float(altitude_max_m)],
            "time_axis": "local seconds from mission start",
            "axis_definition": {
                "x": "local east meters on the low-altitude route graph",
                "y": "local north meters on the low-altitude route graph",
                "height": "meters above local ground reference",
                "time": "seconds from mission start",
            },
        },
    }


def audit_airspace_path(
    path: list[State4D],
    airspace: CorridorGraph | None,
    constraints: FlightConstraints,
    risk_field: RiskField4D,
) -> dict[str, Any]:
    audit = constraints.audit_path(path, risk_field) if airspace is not None else {}
    segments = audit.get("corridor_segments_used", [])
    alternates = audit.get("alternate_landing_points", [])
    return {
        "airspace_enabled": airspace is not None,
        "corridor_required": constraints.corridor_required if airspace is not None else False,
        "airspace_network": "CorridorGraph" if airspace is not None else "",
        "airspace_violations": int(audit.get("airspace_violations", 0)),
        "mean_corridor_deviation_m": audit.get("mean_corridor_deviation_m"),
        "max_corridor_deviation_m": audit.get("max_corridor_deviation_m"),
        "max_corridor_deviation_ratio": audit.get("max_corridor_deviation_ratio"),
        "corridor_segments_used": ";".join(segments) if isinstance(segments, list) else str(segments or ""),
        "alternate_landing_points": ";".join(alternates) if isinstance(alternates, list) else str(alternates or ""),
    }


def _select_mission(risk_field: RiskField4D, constraints: FlightConstraints) -> tuple[SpatialNode, SpatialNode]:
    start = _nearest_node_by_metric(risk_field, z_m=100.0, y_m=1000.0, x_m=1000.0)
    goal = _nearest_node_by_metric(risk_field, z_m=120.0, y_m=4000.0, x_m=10500.0)
    start = _nearest_feasible_spatial_node(risk_field, start)
    goal = _nearest_feasible_spatial_node(risk_field, goal)
    return start, goal


def _nearest_node_by_metric(risk_field: RiskField4D, *, z_m: float, y_m: float, x_m: float) -> SpatialNode:
    heights = np.asarray(risk_field.coords.get("height", np.arange(risk_field.z_size)), dtype=float)
    y_axis = np.asarray(risk_field.coords.get("y", np.arange(risk_field.y_size)), dtype=float)
    x_axis = np.asarray(risk_field.coords.get("x", np.arange(risk_field.x_size)), dtype=float)
    z = int(np.argmin(np.abs(heights - z_m)))
    y = int(np.argmin(np.abs(y_axis - y_m)))
    x = int(np.argmin(np.abs(x_axis - x_m)))
    return z, y, x


def _nearest_feasible_spatial_node(risk_field: RiskField4D, node: SpatialNode, max_radius: int = 6) -> SpatialNode:
    z0, y0, x0 = node
    if risk_field.in_bounds((0, z0, y0, x0)) and not risk_field.is_no_fly((0, z0, y0, x0)):
        return node
    best: tuple[float, SpatialNode] | None = None
    for radius in range(1, max_radius + 1):
        for dz in range(-1, 2):
            for dy in range(-radius, radius + 1):
                for dx in range(-radius, radius + 1):
                    if max(abs(dy), abs(dx)) != radius:
                        continue
                    z = int(np.clip(z0 + dz, 0, risk_field.z_size - 1))
                    y = int(np.clip(y0 + dy, 0, risk_field.y_size - 1))
                    x = int(np.clip(x0 + dx, 0, risk_field.x_size - 1))
                    candidate = (z, y, x)
                    if risk_field.is_no_fly((0, *candidate)):
                        continue
                    distance = (z - z0) ** 2 + (y - y0) ** 2 + (x - x0) ** 2
                    if best is None or distance < best[0]:
                        best = (float(distance), candidate)
        if best is not None:
            return best[1]
    return node


def _mission_distance_m(risk_field: RiskField4D, start: SpatialNode, goal: SpatialNode) -> float:
    x_axis = np.asarray(risk_field.coords.get("x", np.arange(risk_field.x_size)), dtype=float)
    y_axis = np.asarray(risk_field.coords.get("y", np.arange(risk_field.y_size)), dtype=float)
    z_axis = np.asarray(risk_field.coords.get("height", np.arange(risk_field.z_size)), dtype=float)
    z0, y0, x0 = start
    z1, y1, x1 = goal
    return float(np.sqrt((x_axis[x1] - x_axis[x0]) ** 2 + (y_axis[y1] - y_axis[y0]) ** 2 + (z_axis[z1] - z_axis[z0]) ** 2))


def _state_at_or_before(path: list[State4D], step: int, fallback: State4D) -> State4D:
    candidates = [state for state in path if state[0] <= step]
    return candidates[-1] if candidates else fallback


def _next_state_for_step(path: list[State4D], step: int, fallback: State4D) -> State4D:
    for state in path:
        if state[0] >= step:
            return state
    return path[-1] if path else fallback


def _merge_prefix(executed_path: list[State4D], repaired_path: list[State4D]) -> list[State4D]:
    if not executed_path:
        return repaired_path
    if repaired_path and repaired_path[0] == executed_path[-1]:
        return executed_path[:-1] + repaired_path
    return executed_path + repaired_path


def _forecast_hour(cube: WeatherCube, index: int) -> Any:
    local_time = cube.source_metadata.get("local_time_axis_s")
    if isinstance(local_time, list) and index < len(local_time):
        return round(float(local_time[index]) / 3600.0, 6)
    lead = cube.source_metadata.get("lead_time_hours")
    if isinstance(lead, list) and index < len(lead):
        return lead[index]
    return index


def _time_value(value: Any) -> Any:
    if isinstance(value, np.generic):
        value = value.item()
    if isinstance(value, np.datetime64):
        return str(value)
    return value


def _write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        rows = [{"empty": True}]
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def _summarize_change_rows(rows: list[dict[str, Any]]) -> dict[str, Any]:
    after_initial = rows[1:] if len(rows) > 1 else rows
    significant_ratios = [float(row["significant_changed_voxel_ratio"]) for row in rows]
    significant_after_initial = [float(row["significant_changed_voxel_ratio"]) for row in after_initial]
    return {
        "steps": len(rows),
        "mean_raw_changed_voxel_ratio": _mean([row["raw_changed_voxel_ratio"] for row in rows]),
        "max_raw_changed_voxel_ratio": max([float(row["raw_changed_voxel_ratio"]) for row in rows], default=0.0),
        "mean_significant_changed_voxel_ratio": _mean([row["significant_changed_voxel_ratio"] for row in rows]),
        "max_significant_changed_voxel_ratio": max([float(row["significant_changed_voxel_ratio"]) for row in rows], default=0.0),
        "mean_significant_changed_voxel_ratio_after_initial": _mean(significant_after_initial),
        "max_significant_changed_voxel_ratio_after_initial": max(significant_after_initial, default=0.0),
        "background_wide_update_steps": int(sum(1 for value in significant_ratios if value > 0.5)),
        "mean_changed_voxel_ratio": _mean([row["changed_voxel_ratio"] for row in rows]),
        "max_changed_voxel_ratio": max([float(row["changed_voxel_ratio"]) for row in rows], default=0.0),
        "total_raw_changed_voxels": int(sum(int(row["raw_changed_voxels"]) for row in rows)),
        "total_significant_changed_voxels": int(sum(int(row["significant_changed_voxels"]) for row in rows)),
        "total_new_no_fly_voxels": int(sum(int(row["new_no_fly_voxels"]) for row in rows)),
        "total_removed_no_fly_voxels": int(sum(int(row["removed_no_fly_voxels"]) for row in rows)),
    }


def _mean(values: list[Any]) -> float | None:
    numeric = [float(value) for value in values if value is not None]
    return round(float(np.mean(numeric)), 3) if numeric else None


def _last_numeric(values: list[Any]) -> float | None:
    for value in reversed(values):
        if value in ("", None):
            continue
        try:
            number = float(value)
        except (TypeError, ValueError):
            continue
        return round(number, 6)
    return None


def _count_values(values: list[Any]) -> dict[str, int]:
    counts: dict[str, int] = {}
    for value in values:
        key = str(value or "none")
        counts[key] = counts.get(key, 0) + 1
    return counts


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", default="outputs/multi_time_real_weather_replay")
    parser.add_argument("--case-dir", default=None)
    parser.add_argument("--cube-paths", nargs="*", default=())
    parser.add_argument("--wrf-zip", default=None, help="Path to a WRF result zip or WRF NetCDF file.")
    parser.add_argument("--no-downscale", action="store_true")
    parser.add_argument("--no-plots", action="store_true")
    parser.add_argument("--no-animations", action="store_true")
    parser.add_argument("--allow-nowcast-fallback", action="store_true")
    parser.add_argument("--enable-airspace", action="store_true", default=False)
    parser.add_argument("--disable-airspace", action="store_true")
    parser.add_argument("--corridor-required", action="store_true", default=False)
    parser.add_argument("--corridor-optional", action="store_true")
    parser.add_argument("--corridor-width-cells", type=float, default=3.0)
    parser.add_argument("--xy-resolution-m", type=float, default=100.0)
    parser.add_argument("--altitude-min-m", type=float, default=60.0)
    parser.add_argument("--altitude-max-m", type=float, default=180.0)
    parser.add_argument("--x-extent-m", type=float, default=12000.0)
    parser.add_argument("--y-extent-m", type=float, default=12000.0)
    parser.add_argument("--planning-dt-s", type=float, default=10.0)
    parser.add_argument("--planning-horizon-s", type=float, default=1200.0)
    parser.add_argument(
        "--repair-mode",
        choices=["full_restart", "lpa_repair", "dstar_lite"],
        default="full_restart",
        help="Dynamic repair backend for weather updates.",
    )
    args = parser.parse_args()
    summary = run_multi_time_real_weather_replay(
        output_dir=args.output_dir,
        case_dir=args.case_dir,
        cube_paths=tuple(args.cube_paths),
        wrf_zip_path=args.wrf_zip,
        allow_nowcast_fallback=args.allow_nowcast_fallback,
        downscale=not args.no_downscale,
        make_plots=not args.no_plots,
        make_animations=not args.no_animations,
        enable_airspace=args.enable_airspace and not args.disable_airspace,
        corridor_required=args.corridor_required and not args.corridor_optional,
        corridor_width_cells=args.corridor_width_cells,
        xy_resolution_m=args.xy_resolution_m,
        altitude_min_m=args.altitude_min_m,
        altitude_max_m=args.altitude_max_m,
        x_extent_m=args.x_extent_m,
        y_extent_m=args.y_extent_m,
        planning_dt_s=args.planning_dt_s,
        planning_horizon_s=args.planning_horizon_s,
        repair_mode=args.repair_mode,
    )
    print("Multi-time real weather replay finished.")
    print(f"Outputs: {args.output_dir}")
    print(json.dumps({k: summary[k] for k in ["strict_historical_sequence", "real_valid_times_count", "airspace_enabled", "corridor_required", "airspace_metrics", "change_summary", "replan_summary"]}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
