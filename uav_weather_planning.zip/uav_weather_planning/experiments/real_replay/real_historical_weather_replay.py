﻿from __future__ import annotations

from pathlib import Path
import argparse
import json

from uav_weather_planning.data_interface import (
    HistoricalReplayConfig,
    HistoricalWeatherReplayLoader,
    LocalGFSReplayConfig,
    WeatherDataError,
)
from uav_weather_planning.experiments.historical_weather_replay import run_historical_weather_replay_from_cube


def run_real_historical_weather_replay(
    output_dir: str | Path = "outputs/real_historical_weather_replay",
    cube_paths: tuple[str | Path, ...] = (),
    cube_dir: str | Path | None = None,
    allow_single_time_fallback: bool = True,
    fallback_config: LocalGFSReplayConfig | None = None,
) -> dict:
    config = HistoricalReplayConfig(
        cube_paths=cube_paths,
        cube_dir=cube_dir,
        allow_single_time_fallback=allow_single_time_fallback,
        fallback_config=fallback_config,
    )
    cube = HistoricalWeatherReplayLoader().load(config)
    summary = run_historical_weather_replay_from_cube(cube, output_dir)
    manifest_path = Path(output_dir) / "historical_replay_manifest.json"
    manifest = {
        "strict_historical_sequence": summary["historical_replay_validation"]["strict_historical_sequence"],
        "historical_replay_mode": summary["historical_replay_validation"]["historical_replay_mode"],
        "real_valid_times_count": summary["historical_replay_validation"]["real_valid_times_count"],
        "fallback_reason": summary["historical_replay_validation"]["fallback_reason"],
        "source": summary["source"],
        "weather_shape": summary["weather_shape"],
        "risk_shape": summary["risk_shape"],
    }
    with manifest_path.open("w", encoding="utf-8") as f:
        json.dump(manifest, f, ensure_ascii=False, indent=2)
    summary["outputs"].append("historical_replay_manifest.json")
    with (Path(output_dir) / "summary.json").open("w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)
    return summary


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", default="outputs/real_historical_weather_replay")
    parser.add_argument("--cube-dir", default=None, help="Directory containing cached WeatherCube .npz files from real valid times.")
    parser.add_argument("--cube-paths", nargs="*", default=(), help="Explicit cached WeatherCube .npz files to concatenate.")
    parser.add_argument("--strict", action="store_true", help="Require at least two real historical valid times; no fallback.")
    parser.add_argument("--t-size", type=int, default=24)
    parser.add_argument("--z-size", type=int, default=4)
    parser.add_argument("--y-size", type=int, default=32)
    parser.add_argument("--x-size", type=int, default=32)
    parser.add_argument("--planning-extent-km", type=float, default=60.0)
    parser.add_argument("--planning-center-lat", type=float, default=None)
    parser.add_argument("--planning-center-lon", type=float, default=None)
    parser.add_argument("--rebuild-cache", action="store_true")
    args = parser.parse_args()
    planning_center = None
    if args.planning_center_lat is not None and args.planning_center_lon is not None:
        planning_center = (args.planning_center_lat, args.planning_center_lon)
    fallback_config = LocalGFSReplayConfig(
        t_size=args.t_size,
        z_size=args.z_size,
        y_size=args.y_size,
        x_size=args.x_size,
        planning_extent_km=args.planning_extent_km,
        planning_center=planning_center,
        cache_policy="refresh" if args.rebuild_cache else "reuse",
    )
    try:
        summary = run_real_historical_weather_replay(
            output_dir=args.output_dir,
            cube_paths=tuple(args.cube_paths),
            cube_dir=args.cube_dir,
            allow_single_time_fallback=not args.strict,
            fallback_config=fallback_config,
        )
    except WeatherDataError as exc:
        print(f"Real historical replay did not run: {exc}")
        print("Provide --cube-dir or --cube-paths with at least two cached real valid-time WeatherCube files.")
        return
    print("Real historical weather replay finished.")
    print(f"Outputs: {args.output_dir}")
    print(json.dumps(summary["historical_replay_validation"], ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
