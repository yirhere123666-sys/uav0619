from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import argparse
import csv
import json
from typing import Any

import numpy as np

from uav_weather_planning.data_interface import WeatherDataError
from uav_weather_planning.experiments.build_real_replay_case import validate_strict_case
from uav_weather_planning.experiments.multi_time_real_weather_replay import run_multi_time_real_weather_replay


RECOMMENDED_REAL_CASES: tuple[dict[str, Any], ...] = (
    {
        "case_id": "case_002_high_wind",
        "weather_process_type": "大风或强阵风过程",
        "minimum_forecast_hours": "0-6",
        "preferred_forecast_hours": "0-12",
        "purpose": "验证平均风、侧风、阵风风险和能耗约束对路径选择的影响。",
    },
    {
        "case_id": "case_003_precip_convection",
        "weather_process_type": "强降水或对流阻断过程",
        "minimum_forecast_hours": "0-6",
        "preferred_forecast_hours": "0-12",
        "purpose": "验证对流硬禁飞、降水软风险和动态绕行/重规划。",
    },
    {
        "case_id": "case_004_low_visibility",
        "weather_process_type": "低能见度或低云底过程",
        "minimum_forecast_hours": "0-6",
        "preferred_forecast_hours": "0-12",
        "purpose": "验证低能见度感知风险、低云底高度约束和保守规划。",
    },
    {
        "case_id": "case_005_compound_weather",
        "weather_process_type": "风-雨-能见度复合天气过程",
        "minimum_forecast_hours": "0-6",
        "preferred_forecast_hours": "0-12",
        "purpose": "验证多通道风险融合、CVaR尾部风险和参数鲁棒性。",
    },
)


@dataclass(frozen=True)
class MultiCaseReplayConfig:
    case_root: str | Path = "data/replay_cases"
    min_paper_case_count: int = 3
    target_case_count: int = 5
    min_valid_times_per_case: int = 6
    make_case_plots: bool = False
    downscale: bool = True


def run_multi_case_real_weather_replay(
    output_dir: str | Path = "outputs/multi-case-real",
    case_root: str | Path = "data/replay_cases",
    case_dirs: tuple[str | Path, ...] = (),
    min_paper_case_count: int = 3,
    target_case_count: int = 5,
    min_valid_times_per_case: int = 6,
    make_case_plots: bool = False,
    downscale: bool = True,
) -> dict[str, Any]:
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    config = MultiCaseReplayConfig(
        case_root=case_root,
        min_paper_case_count=min_paper_case_count,
        target_case_count=target_case_count,
        min_valid_times_per_case=min_valid_times_per_case,
        make_case_plots=make_case_plots,
        downscale=downscale,
    )
    discovered = [Path(path) for path in case_dirs] if case_dirs else discover_replay_cases(case_root)
    inventory_rows: list[dict[str, Any]] = []
    metrics_rows: list[dict[str, Any]] = []
    failures: list[dict[str, Any]] = []

    for case_dir in discovered:
        inventory = audit_replay_case(case_dir, min_valid_times_per_case=min_valid_times_per_case)
        inventory_rows.append(inventory)
        if inventory["status"] != "ready":
            failures.append({"case_id": inventory["case_id"], "reason": inventory["status_reason"]})
            continue
        try:
            case_output = output_dir / inventory["case_id"]
            summary = run_multi_time_real_weather_replay(
                output_dir=case_output,
                case_dir=case_dir,
                allow_nowcast_fallback=False,
                downscale=downscale,
                make_plots=make_case_plots,
            )
            metrics_rows.append(_metrics_row_from_summary(summary, inventory))
        except Exception as exc:  # noqa: BLE001 - batch runner must report every failed case
            failures.append({"case_id": inventory["case_id"], "reason": repr(exc)})
            inventory["status"] = "failed"
            inventory["status_reason"] = repr(exc)

    _write_csv(output_dir / "real_case_inventory.csv", inventory_rows)
    _write_csv(output_dir / "multi_case_real_replay_metrics.csv", metrics_rows)
    summary = _build_summary(config, inventory_rows, metrics_rows, failures)
    with (output_dir / "multi_case_real_replay_summary.json").open("w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)
    return summary


def discover_replay_cases(case_root: str | Path = "data/replay_cases") -> list[Path]:
    root = Path(case_root)
    if not root.exists():
        return []
    return sorted(
        path
        for path in root.iterdir()
        if path.is_dir() and (list(path.glob("weather_*.npz")) or (path / "metadata.json").exists())
    )


def audit_replay_case(case_dir: str | Path, min_valid_times_per_case: int = 6) -> dict[str, Any]:
    case_path = Path(case_dir)
    metadata = _read_json(case_path / "metadata.json")
    case_id = str(metadata.get("case_id") or case_path.name)
    weather_paths = sorted(case_path.glob("weather_*.npz"))
    forecast_hours = metadata.get("forecast_hours") or _forecast_hours_from_paths(weather_paths)
    variables = metadata.get("variables") or []
    weather_process_type = metadata.get("weather_process_type") or _infer_weather_process_type(case_id, variables)
    row: dict[str, Any] = {
        "case_id": case_id,
        "case_dir": str(case_path),
        "source": metadata.get("source", ""),
        "weather_process_type": weather_process_type,
        "snapshot_count": len(weather_paths),
        "forecast_hours": ";".join(str(item) for item in forecast_hours),
        "variables": ";".join(str(item) for item in variables),
        "strict_historical_sequence_expected": bool(metadata.get("strict_historical_sequence_expected", False)),
        "valid_time_count": len(set(metadata.get("valid_times_unix") or [])),
        "status": "ready",
        "status_reason": "",
    }
    if len(weather_paths) < 2:
        row["status"] = "missing_sequence"
        row["status_reason"] = "至少需要两个真实 forecast hour / valid_time 快照。"
        return row
    try:
        validation = validate_strict_case(case_path)
        row["strict_historical_sequence"] = bool(validation.get("strict_historical_sequence", False))
        row["real_valid_times_count"] = int(validation.get("real_valid_times_count") or 0)
        row["historical_replay_mode"] = validation.get("historical_replay_mode", "")
        row["weather_shape"] = str(validation.get("weather_shape"))
    except WeatherDataError as exc:
        row["status"] = "invalid_sequence"
        row["status_reason"] = str(exc)
        return row
    if not row.get("strict_historical_sequence"):
        row["status"] = "not_strict"
        row["status_reason"] = "该案例不是严格真实多时刻序列。"
        return row
    if int(row.get("real_valid_times_count") or 0) < min_valid_times_per_case:
        row["status"] = "too_short"
        row["status_reason"] = f"真实时刻数少于 {min_valid_times_per_case}。"
        return row
    return row


def _metrics_row_from_summary(summary: dict[str, Any], inventory: dict[str, Any]) -> dict[str, Any]:
    metrics = summary.get("metrics", {})
    change_summary = summary.get("change_summary", {})
    replan_summary = summary.get("replan_summary", {})
    return {
        "case_id": inventory["case_id"],
        "source": inventory.get("source", ""),
        "weather_process_type": inventory.get("weather_process_type", ""),
        "forecast_hours": metrics.get("forecast_hours") or inventory.get("forecast_hours", ""),
        "strict_historical_sequence": summary.get("strict_historical_sequence"),
        "real_valid_times_count": summary.get("real_valid_times_count"),
        "airspace_enabled": metrics.get("airspace_enabled") or summary.get("airspace_enabled"),
        "corridor_required": metrics.get("corridor_required") or summary.get("corridor_required"),
        "airspace_network": metrics.get("airspace_network") or summary.get("airspace_network"),
        "airspace_violations": metrics.get("airspace_violations"),
        "corridor_segments_used": metrics.get("corridor_segments_used"),
        "mean_corridor_deviation_m": metrics.get("mean_corridor_deviation_m"),
        "max_corridor_deviation_m": metrics.get("max_corridor_deviation_m"),
        "max_corridor_deviation_ratio": metrics.get("max_corridor_deviation_ratio"),
        "success": metrics.get("success"),
        "path_length": metrics.get("path_length"),
        "expected_risk": metrics.get("expected_risk"),
        "cvar_risk": metrics.get("cvar_risk"),
        "no_fly_violations": metrics.get("no_fly_violations"),
        "constraint_violations": metrics.get("constraint_violations"),
        "replan_count": metrics.get("replan_count"),
        "nodes_expanded": metrics.get("nodes_expanded"),
        "elapsed_ms": metrics.get("elapsed_ms"),
        "max_ground_speed_mps": metrics.get("max_ground_speed_mps"),
        "max_vertical_rate_mps": metrics.get("max_vertical_rate_mps"),
        "cumulative_energy_kj": metrics.get("cumulative_energy_kj"),
        "mean_significant_changed_voxel_ratio": change_summary.get("mean_significant_changed_voxel_ratio"),
        "max_significant_changed_voxel_ratio": change_summary.get("max_significant_changed_voxel_ratio"),
        "new_no_fly_voxels": change_summary.get("total_new_no_fly_voxels"),
        "removed_no_fly_voxels": change_summary.get("total_removed_no_fly_voxels"),
        "replan_event_count": replan_summary.get("event_count"),
        "replan_success_count": replan_summary.get("success_count"),
    }


def _build_summary(
    config: MultiCaseReplayConfig,
    inventory_rows: list[dict[str, Any]],
    metrics_rows: list[dict[str, Any]],
    failures: list[dict[str, Any]],
) -> dict[str, Any]:
    ready_rows = [row for row in inventory_rows if row.get("status") == "ready"]
    strict_metrics = [row for row in metrics_rows if _as_bool(row.get("strict_historical_sequence"))]
    weather_types = sorted({str(row.get("weather_process_type", "")) for row in ready_rows if row.get("weather_process_type")})
    return {
        "experiment": "multi_case_real_weather_replay",
        "protocol": {
            "case_root": str(config.case_root),
            "minimum_paper_case_count": config.min_paper_case_count,
            "target_case_count": config.target_case_count,
            "minimum_valid_times_per_case": config.min_valid_times_per_case,
            "required_case_duration": "每个真实天气过程至少 6 个 forecast hour，论文阶段建议 6-12 个 forecast hour。",
            "weather_process_targets": ["大风/阵风", "降水/对流", "低能见度/低云底", "复合天气"],
        },
        "case_counts": {
            "discovered": len(inventory_rows),
            "ready": len(ready_rows),
            "strict_successful_runs": len(strict_metrics),
            "failed_or_incomplete": len(failures),
        },
        "coverage": {
            "weather_process_types": weather_types,
            "current_case_ids": [row.get("case_id") for row in ready_rows],
            "recommended_missing_cases": RECOMMENDED_REAL_CASES,
        },
        "paper_readiness": {
            "ready": len(strict_metrics) >= config.min_paper_case_count,
            "reason": (
                "真实多时刻案例数量已达到论文最低统计要求。"
                if len(strict_metrics) >= config.min_paper_case_count
                else f"当前严格真实多时刻案例为 {len(strict_metrics)} 个，论文建议至少 {config.min_paper_case_count} 个，目标 {config.target_case_count} 个。"
            ),
        },
        "aggregate_metrics": _aggregate_metrics(metrics_rows),
        "failures": failures,
        "outputs": [
            "real_case_inventory.csv",
            "multi_case_real_replay_metrics.csv",
            "multi_case_real_replay_summary.json",
            "<case_id>/real_replay_summary.json",
            "<case_id>/real_replay_metrics.csv",
        ],
        "claim_boundary": (
            "中期可以展示 1 个严格多时刻真实天气回放案例；最终论文应扩展到 3-5 个真实历史天气过程，"
            "覆盖大风、降水/对流、低能见度或复合天气，避免单案例偶然性。"
        ),
    }


def _aggregate_metrics(rows: list[dict[str, Any]]) -> dict[str, Any]:
    return {
        "case_count": len(rows),
        "success_rate": _mean_bool([row.get("success") for row in rows]),
        "mean_expected_risk": _mean([row.get("expected_risk") for row in rows]),
        "mean_cvar_risk": _mean([row.get("cvar_risk") for row in rows]),
        "mean_no_fly_violations": _mean([row.get("no_fly_violations") for row in rows]),
        "mean_constraint_violations": _mean([row.get("constraint_violations") for row in rows]),
        "mean_replan_count": _mean([row.get("replan_count") for row in rows]),
        "mean_replan_event_count": _mean([row.get("replan_event_count") for row in rows]),
        "max_ground_speed_mps": _max([row.get("max_ground_speed_mps") for row in rows]),
        "mean_energy_kj": _mean([row.get("cumulative_energy_kj") for row in rows]),
        "mean_significant_changed_voxel_ratio": _mean([row.get("mean_significant_changed_voxel_ratio") for row in rows]),
    }


def _read_json(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    return json.loads(path.read_text(encoding="utf-8"))


def _forecast_hours_from_paths(paths: list[Path]) -> list[int]:
    values = []
    for path in paths:
        stem = path.stem
        try:
            values.append(int(stem.split("_f")[-1]))
        except ValueError:
            continue
    return values


def _infer_weather_process_type(case_id: str, variables: list[Any]) -> str:
    lower = case_id.lower()
    variable_text = " ".join(str(item).lower() for item in variables)
    has_wind = any(token in lower for token in ("wind", "gust", "gale"))
    has_precip = any(token in lower for token in ("precip", "rain", "convection", "storm"))
    if has_wind and has_precip:
        return "风和降水复合过程"
    if has_wind:
        return "大风或阵风过程"
    if has_precip:
        return "降水/对流过程"
    if "visibility" in lower or "fog" in lower or "visibility" in variable_text:
        return "低能见度或低云底过程"
    if "reflectivity" in variable_text:
        return "降水/对流或风雨复合过程"
    if "u_wind" in variable_text:
        return "大风或阵风过程"
    return "未分类真实天气过程"


def _write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        rows = [{"empty": True}]
    fieldnames: list[str] = []
    for row in rows:
        for key in row:
            if key not in fieldnames:
                fieldnames.append(key)
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def _as_bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return str(value).lower() in {"true", "1", "yes"}


def _as_float(value: Any) -> float | None:
    if value in (None, ""):
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _mean(values: list[Any]) -> float | None:
    numeric = [value for value in (_as_float(value) for value in values) if value is not None]
    return round(float(np.mean(numeric)), 4) if numeric else None


def _max(values: list[Any]) -> float | None:
    numeric = [value for value in (_as_float(value) for value in values) if value is not None]
    return round(float(np.max(numeric)), 4) if numeric else None


def _mean_bool(values: list[Any]) -> float | None:
    if not values:
        return None
    return round(float(np.mean([1.0 if _as_bool(value) else 0.0 for value in values])), 4)


def main() -> None:
    parser = argparse.ArgumentParser(description="Run and summarize strict multi-case real weather replay experiments.")
    parser.add_argument("--output-dir", default="outputs/multi-case-real")
    parser.add_argument("--case-root", default="data/replay_cases")
    parser.add_argument("--case-dirs", nargs="*", default=())
    parser.add_argument("--min-paper-case-count", type=int, default=3)
    parser.add_argument("--target-case-count", type=int, default=5)
    parser.add_argument("--min-valid-times-per-case", type=int, default=6)
    parser.add_argument("--make-case-plots", action="store_true")
    parser.add_argument("--no-downscale", action="store_true")
    args = parser.parse_args()
    summary = run_multi_case_real_weather_replay(
        output_dir=args.output_dir,
        case_root=args.case_root,
        case_dirs=tuple(args.case_dirs),
        min_paper_case_count=args.min_paper_case_count,
        target_case_count=args.target_case_count,
        min_valid_times_per_case=args.min_valid_times_per_case,
        make_case_plots=args.make_case_plots,
        downscale=not args.no_downscale,
    )
    print("Multi-case real weather replay finished.")
    print(f"Outputs: {args.output_dir}")
    print(json.dumps({k: summary[k] for k in ["case_counts", "coverage", "paper_readiness"]}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
