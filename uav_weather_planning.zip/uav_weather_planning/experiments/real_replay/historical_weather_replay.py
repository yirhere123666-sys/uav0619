﻿from __future__ import annotations

from pathlib import Path
import argparse
import csv
import json

from uav_weather_planning.airspace import CorridorGraph
from uav_weather_planning.data_interface import LocalGFSReplayConfig, LocalGFSReplayLoader, WeatherCube
from uav_weather_planning.experiments.coordinate_summary import coordinate_summary_from_risk_field
from uav_weather_planning.global_planner import (
    EventTriggeredRepairReplanner,
    FlightConstraints,
    MultirotorEnergyModel,
    TimeDependentAStar,
    evaluate_path,
)
from uav_weather_planning.risk_field import RiskField4D
from uav_weather_planning.risk_calibration import (
    build_calibration_evidence,
    plot_calibration_curves,
    plot_calibration_histograms,
    write_calibration_report,
)
from uav_weather_planning.risk_models import build_risk_field_from_weather
from uav_weather_planning.visualization import (
    animate_path_over_time,
    animate_risk_field,
    animate_weather_channels,
    plot_algorithm_comparison,
    plot_metrics,
    plot_path_on_risk,
    plot_replanning,
    plot_risk_channels,
    plot_risk_timeseries,
)


def run_historical_weather_replay(
    output_dir: str | Path = "outputs/historical_weather_replay",
    config: LocalGFSReplayConfig | None = None,
) -> dict:
    config = config or LocalGFSReplayConfig(cache_policy="reuse")
    cube = LocalGFSReplayLoader().load(config)
    return run_historical_weather_replay_from_cube(cube, output_dir)


def run_historical_weather_replay_from_cube(
    cube: WeatherCube,
    output_dir: str | Path = "outputs/historical_weather_replay",
) -> dict:
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    updated_field = build_risk_field_from_weather(cube)
    initial_field = updated_field.as_static_snapshot(0)

    constraints = FlightConstraints(
        max_horizontal_step_cells=1.5,
        max_vertical_step_layers=1,
        min_safety_margin_cells=0.0,
        max_turn_angle_deg=135.0,
        enforce_metric_limits=True,
        max_ground_speed_mps=15.0,
        max_climb_rate_mps=3.0,
        max_descent_rate_mps=3.0,
        max_yaw_rate_deg_s=45.0,
        max_acceleration_mps2=4.0,
    )
    start, goal = _select_mission(updated_field, constraints)
    airspace = CorridorGraph.from_mission(
        updated_field,
        start,
        goal,
        corridor_width_cells=5.0,
        speed_limit_mps=constraints.max_ground_speed_mps or 15.0,
    )
    constraints.airspace = airspace
    no_weather = RiskField4D.uniform(*updated_field.shape)
    no_weather.coords = updated_field.coords
    no_weather.source_metadata = updated_field.source_metadata

    planners = {
        "No-weather A*": TimeDependentAStar(no_weather, use_cvar=False, constraints=constraints),
        "Static-risk A*": TimeDependentAStar(initial_field, use_cvar=True, constraints=constraints),
        "Time-dependent A*": TimeDependentAStar(updated_field, use_cvar=True, constraints=constraints),
    }
    results = {}
    metrics = []
    for name, planner in planners.items():
        result = planner.plan(start, goal)
        results[name] = result
        metrics.append(evaluate_path(name, result.path, updated_field, result.nodes_expanded, result.elapsed_ms, constraints=constraints))

    initial_result = TimeDependentAStar(initial_field, use_cvar=True, constraints=constraints).plan(start, goal)
    restart_result = results["Time-dependent A*"]
    metrics.append(
        evaluate_path(
            "Restart full search",
            restart_result.path,
            updated_field,
            initial_result.nodes_expanded + restart_result.nodes_expanded,
            initial_result.elapsed_ms + restart_result.elapsed_ms,
            replan_count=1,
            constraints=constraints,
        )
    )

    replanner = EventTriggeredRepairReplanner(
        initial_field,
        updated_field,
        update_time=max(3, updated_field.t_size // 4),
        risk_threshold=10.0,
        constraints=constraints,
    )
    repaired = replanner.plan_and_repair(start, goal)
    metrics.append(
        evaluate_path(
            "Incremental dynamic repair",
            repaired.path,
            updated_field,
            repaired.nodes_expanded,
            repaired.elapsed_ms,
            replan_count=len(repaired.events),
            constraints=constraints,
        )
    )
    events = [
        {
            "event_time": event.event_time,
            "reason": event.reason,
            "affected_voxels": event.affected_voxels,
            "repaired_from": event.repaired_from,
            "nodes_expanded": event.nodes_expanded,
            "elapsed_ms": round(event.elapsed_ms, 3),
        }
        for event in repaired.events
    ]

    paths_for_plot = {name: result.path for name, result in results.items()}
    paths_for_plot["Restart full search"] = restart_result.path
    paths_for_plot["Incremental dynamic repair"] = repaired.path

    plot_risk_channels(updated_field, output_dir / "01_realdata_risk_channels.png", time_index=updated_field.t_size // 2, height_index=min(1, updated_field.z_size - 1))
    plot_risk_timeseries(updated_field, output_dir / "02_realdata_4d_risk_timeseries.png", height_index=min(1, updated_field.z_size - 1))
    plot_path_on_risk(updated_field, restart_result.path, output_dir / "03_realdata_dynamic_path.png", "真实天气回放中的时间依赖路径", time_index=updated_field.t_size // 2)
    plot_replanning(updated_field, repaired.path, [_EventProxy(e) for e in events], output_dir / "04_realdata_incremental_replanning.png")
    plot_algorithm_comparison(paths_for_plot, updated_field, output_dir / "05_realdata_algorithm_comparison.png")
    plot_metrics(metrics, output_dir / "06_realdata_metrics_summary.png")
    animate_risk_field(updated_field, output_dir / "07_realdata_dynamic_risk_field.gif", height_index=min(1, updated_field.z_size - 1), channel="total_cost", fps=4)
    animate_path_over_time(updated_field, restart_result.path, output_dir / "08_realdata_time_dependent_path.gif", height_index=min(1, updated_field.z_size - 1), channel="total_cost", fps=4)
    animate_weather_channels(updated_field, output_dir / "09_realdata_weather_channels.gif", height_index=min(1, updated_field.z_size - 1), fps=4)
    calibration_evidence = build_calibration_evidence(cube, updated_field)
    write_calibration_report(calibration_evidence, output_dir / "risk_calibration_report.json")
    plot_calibration_curves(calibration_evidence, output_dir / "10_risk_calibration_curves.png")
    plot_calibration_histograms(calibration_evidence, output_dir / "11_risk_calibration_histograms.png")

    rows = [m.as_row() for m in metrics]
    with (output_dir / "metrics.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    with (output_dir / "airspace_network.json").open("w", encoding="utf-8") as f:
        json.dump(airspace.as_dict(), f, ensure_ascii=False, indent=2)

    summary = {
        "source": cube.source_metadata,
        "weather_shape": cube.shape,
        "risk_shape": updated_field.shape,
        "coordinate_definition": coordinate_summary_from_risk_field(updated_field),
        "historical_replay_validation": {
            "strict_historical_sequence": bool(cube.source_metadata.get("strict_historical_sequence", False)),
            "historical_replay_mode": cube.source_metadata.get("historical_replay_mode", "legacy_local_gfs_replay"),
            "real_valid_times_count": cube.source_metadata.get("real_valid_times_count"),
            "fallback_reason": cube.source_metadata.get("fallback_reason"),
            "data_audit": cube.source_metadata.get("data_audit"),
        },
        "mission": {"start": start, "goal": goal},
        "flight_constraints": constraints.as_dict(),
        "airspace_network": "airspace_network.json",
        "airspace_network_summary": airspace.as_summary(),
        "trajectory_constraint_note": (
            "Metric limits are enforced on the local multirotor planning grid, not on the native coarse GFS/HRRR grid. "
            "Regional weather data provides background risk and is sampled to a local task grid before speed, climb, "
            "turning and acceleration proxies are audited. B-spline/NMPC will later refine the continuous trajectory."
        ),
        "energy_model": MultirotorEnergyModel(updated_field).metadata(),
        "risk_channels": updated_field.metadata.get("channels", []),
        "metrics": rows,
        "replan_events": events,
        "outputs": [
            "01_realdata_risk_channels.png",
            "02_realdata_4d_risk_timeseries.png",
            "03_realdata_dynamic_path.png",
            "04_realdata_incremental_replanning.png",
            "05_realdata_algorithm_comparison.png",
            "06_realdata_metrics_summary.png",
            "07_realdata_dynamic_risk_field.gif",
            "08_realdata_time_dependent_path.gif",
            "09_realdata_weather_channels.gif",
            "10_risk_calibration_curves.png",
            "11_risk_calibration_histograms.png",
            "risk_calibration_report.json",
            "airspace_network.json",
            "metrics.csv",
        ],
    }
    with (output_dir / "summary.json").open("w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)
    return summary


def _select_mission(
    risk_field: RiskField4D,
    constraints: FlightConstraints | None = None,
) -> tuple[tuple[int, int, int], tuple[int, int, int]]:
    constraints = constraints or FlightConstraints()
    z = min(1, risk_field.z_size - 1)
    span = max(3, min(risk_field.t_size - 2, risk_field.y_size - 5, risk_field.x_size - 5))
    candidates = [
        ((z, 2, 2), (z, 2 + span, 2 + span)),
        ((z, 2, 2), (z, risk_field.y_size - 3, risk_field.x_size - 3)),
        ((z, risk_field.y_size - 3, 2), (z, 2, risk_field.x_size - 3)),
        ((z, 2, risk_field.x_size // 2), (z, risk_field.y_size - 3, risk_field.x_size // 2)),
    ]
    for start, goal in candidates:
        if not risk_field.is_no_fly((0, *start)) and not any(risk_field.is_no_fly((t, *goal)) for t in range(risk_field.t_size)):
            result = TimeDependentAStar(risk_field, constraints=constraints).plan(start, goal)
            if result.success:
                return start, goal
    return candidates[0]


class _EventProxy:
    def __init__(self, data: dict) -> None:
        self.event_time = int(data["event_time"])
        self.reason = data["reason"]
        self.affected_voxels = int(data["affected_voxels"])
        self.repaired_from = tuple(data["repaired_from"])
        self.nodes_expanded = int(data["nodes_expanded"])
        self.elapsed_ms = float(data["elapsed_ms"])


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", default="outputs/historical_weather_replay")
    parser.add_argument("--t-size", type=int, default=24)
    parser.add_argument("--z-size", type=int, default=4)
    parser.add_argument("--y-size", type=int, default=32)
    parser.add_argument("--x-size", type=int, default=32)
    parser.add_argument("--planning-extent-km", type=float, default=60.0)
    parser.add_argument("--planning-center-lat", type=float, default=None)
    parser.add_argument("--planning-center-lon", type=float, default=None)
    parser.add_argument("--rebuild-cache", action="store_true")
    args = parser.parse_args()
    planning_center = None
    if args.planning_center_lat is not None and args.planning_center_lon is not None:
        planning_center = (args.planning_center_lat, args.planning_center_lon)
    config = LocalGFSReplayConfig(
        t_size=args.t_size,
        z_size=args.z_size,
        y_size=args.y_size,
        x_size=args.x_size,
        planning_extent_km=args.planning_extent_km,
        planning_center=planning_center,
        cache_policy="refresh" if args.rebuild_cache else "reuse",
    )
    summary = run_historical_weather_replay(args.output_dir, config=config)
    print("Historical weather replay finished.")
    print(f"Outputs: {args.output_dir}")
    print(summary)


if __name__ == "__main__":
    main()
