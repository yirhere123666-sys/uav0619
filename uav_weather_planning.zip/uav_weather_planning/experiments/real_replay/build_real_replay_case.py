from __future__ import annotations

from dataclasses import dataclass, asdict
from pathlib import Path
import argparse
import json
import os
from typing import Any

import numpy as np

from uav_weather_planning.data_interface import (
    HistoricalReplayConfig,
    HistoricalWeatherReplayLoader,
    LocalGFSReplayConfig,
    LocalGFSReplayLoader,
    WeatherCube,
    WeatherDataError,
)


@dataclass(frozen=True)
class RealReplayCaseConfig:
    case_dir: str | Path = "data/replay_cases/case_001_wind_precip"
    source: str = "GFS"
    region: str = "local_task_region"
    z_size: int = 4
    y_size: int = 32
    x_size: int = 32
    planning_extent_km: float = 60.0
    add_local_perturbations: bool = False


def build_case_from_local_forecast_files(
    wind_files: list[str | Path],
    rain_files: list[str | Path],
    config: RealReplayCaseConfig | None = None,
    validate: bool = True,
) -> dict[str, Any]:
    """Build a strict multi-valid-time replay case from native forecast files.

    Each wind/rain pair must represent one real forecast valid time. The output
    is a directory of one-step WeatherCube NPZ snapshots that can be consumed by
    multi_time_real_weather_replay.py. This function refuses duplicate valid
    times so a single valid-time nowcast cannot accidentally become a strict
    historical sequence.
    """

    config = config or RealReplayCaseConfig()
    if len(wind_files) != len(rain_files):
        raise WeatherDataError(f"wind/rain file count mismatch: {len(wind_files)} vs {len(rain_files)}")
    if len(wind_files) < 2:
        raise WeatherDataError("strict replay case requires at least two distinct forecast valid times")

    case_dir = Path(config.case_dir)
    case_dir.mkdir(parents=True, exist_ok=True)
    loader = LocalGFSReplayLoader()
    snapshots: list[tuple[float, int, Path, WeatherCube]] = []
    for index, (wind_path, rain_path) in enumerate(zip(wind_files, rain_files)):
        snapshot_cube = loader.build_cube(
            LocalGFSReplayConfig(
                wind_path=wind_path,
                rain_path=rain_path,
                processed_path=None,
                t_size=1,
                z_size=config.z_size,
                y_size=config.y_size,
                x_size=config.x_size,
                planning_extent_km=config.planning_extent_km,
                add_local_perturbations=config.add_local_perturbations,
                cache_policy="refresh",
            )
        )
        valid_time = _require_float(snapshot_cube.source_metadata.get("valid_time_unix"), f"{wind_path} valid_time_unix")
        initial_time = _optional_float(snapshot_cube.source_metadata.get("initial_time_unix"), valid_time)
        forecast_hour = int(round((valid_time - initial_time) / 3600.0))
        output_name = f"weather_f{forecast_hour:03d}.npz"
        if forecast_hour < 0:
            output_name = f"weather_snapshot_{index:03d}.npz"
        snapshot = _as_real_forecast_snapshot(snapshot_cube, config, valid_time, initial_time, forecast_hour, wind_path, rain_path)
        path = case_dir / output_name
        snapshots.append((valid_time, forecast_hour, path, snapshot))

    snapshots.sort(key=lambda item: item[0])
    valid_times = [item[0] for item in snapshots]
    if len(set(valid_times)) != len(valid_times):
        raise WeatherDataError(
            "Duplicate forecast valid_time values found. This is still a single-valid-time source, not a strict multi-time case."
        )
    for old_path in case_dir.glob("weather_*.npz"):
        old_path.unlink()
    for _, _, path, snapshot in snapshots:
        snapshot.to_npz(path)
    forecast_hours = [item[1] for item in snapshots]
    metadata = {
        "case_id": case_dir.name,
        "source": config.source,
        "start_time_unix": min(valid_times),
        "forecast_hours": forecast_hours,
        "valid_times_unix": valid_times,
        "region": config.region,
        "variables": sorted(next(iter(snapshots))[3].variables.keys()),
        "grid_resolution_note": "regional background field mapped to local low-altitude planning grid",
        "strict_historical_sequence_expected": True,
        "temporal_method": "native consecutive forecast valid times; no single-frame advection fallback",
        "builder_config": asdict(config),
        "input_paths": [
            {"wind": str(wind), "rain": str(rain)}
            for wind, rain in zip(wind_files, rain_files)
        ],
    }
    (case_dir / "metadata.json").write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8")
    validation = validate_strict_case(case_dir) if validate else {}
    return {
        "case_dir": str(case_dir),
        "metadata": metadata,
        "snapshot_count": len(snapshots),
        "snapshot_paths": [str(item[2]) for item in snapshots],
        "validation": validation,
    }


def validate_strict_case(case_dir: str | Path) -> dict[str, Any]:
    paths = sorted(Path(case_dir).glob("*.npz"))
    cube = HistoricalWeatherReplayLoader().load(
        HistoricalReplayConfig(cube_paths=tuple(paths), allow_single_time_fallback=False)
    )
    return {
        "strict_historical_sequence": bool(cube.source_metadata.get("strict_historical_sequence", False)),
        "real_valid_times_count": cube.source_metadata.get("real_valid_times_count"),
        "historical_replay_mode": cube.source_metadata.get("historical_replay_mode"),
        "weather_shape": cube.shape,
        "valid_times_unix": cube.source_metadata.get("valid_times_unix"),
        "input_paths": cube.source_metadata.get("input_paths"),
    }


def download_gfs_sequence_with_herbie(
    config: RealReplayCaseConfig,
    date: str,
    forecast_hours: list[int],
    raw_dir: str | Path | None = None,
    priority: str | list[str] | None = None,
) -> dict[str, Any]:
    """Download a GFS forecast-hour sequence with Herbie, then build the case.

    This requires external network access plus the optional Herbie/cfgrib/eccodes
    stack. The function is intentionally separate from the fallback replay path:
    failure here means no strict real case has been acquired.
    """

    config_path = Path(config.case_dir) / "herbie_config.toml"
    config_path.parent.mkdir(parents=True, exist_ok=True)
    os.environ.setdefault("HERBIE_CONFIG_PATH", str(config_path))
    try:
        from herbie import Herbie  # type: ignore
    except ImportError as exc:
        raise WeatherDataError(
            "Herbie is not installed. Install optional real-data dependencies before downloading: "
            "pip install herbie-data cfgrib eccodes netCDF4 h5netcdf"
        ) from exc

    raw_dir = Path(raw_dir or Path(config.case_dir) / "raw_gfs")
    raw_dir.mkdir(parents=True, exist_ok=True)
    wind_files: list[Path] = []
    rain_files: list[Path] = []
    for fxx in forecast_hours:
        hour_dir = raw_dir / f"f{fxx:03d}"
        hour_dir.mkdir(parents=True, exist_ok=True)
        wind_path = hour_dir / f"gfs_wind_f{fxx:03d}.nc"
        rain_path = hour_dir / f"gfs_rain_f{fxx:03d}.nc"
        if not wind_path.exists():
            h = Herbie(date, model="gfs", product="pgrb2.0p25", fxx=fxx, save_dir=str(raw_dir), priority=priority, verbose=False)
            wind_ds = h.xarray(search=r":(UGRD|VGRD|HGT):\d+ mb", backend_kwargs={"indexpath": ""})
            _save_xarray_result(wind_ds, wind_path)
        if not rain_path.exists():
            h = Herbie(date, model="gfs", product="pgrb2.0p25", fxx=fxx, save_dir=str(raw_dir), priority=priority, verbose=False)
            rain_ds = h.xarray(search=r":REFC:", backend_kwargs={"indexpath": ""})
            _save_xarray_result(rain_ds, rain_path)
        wind_files.append(wind_path)
        rain_files.append(rain_path)
    return build_case_from_local_forecast_files(wind_files, rain_files, config=config, validate=True)


def _save_xarray_result(result: Any, path: Path) -> None:
    if isinstance(result, list):
        if len(result) != 1:
            raise WeatherDataError(f"Expected one xarray dataset for {path.name}, got {len(result)}")
        result = result[0]
    path.parent.mkdir(parents=True, exist_ok=True)
    result.to_netcdf(path)


def _as_real_forecast_snapshot(
    cube: WeatherCube,
    config: RealReplayCaseConfig,
    valid_time: float,
    initial_time: float,
    forecast_hour: int,
    wind_path: str | Path,
    rain_path: str | Path,
) -> WeatherCube:
    metadata = {
        **cube.source_metadata,
        "source": config.source,
        "valid_time_unix": valid_time,
        "initial_time_unix": initial_time,
        "forecast_hour": forecast_hour,
        "historical_replay_mode": "native_forecast_hour_snapshot",
        "strict_historical_sequence": False,
        "snapshot_count": 1,
        "real_valid_times_count": 1,
        "temporal_method": "one native forecast valid time; no advection fallback inside this snapshot",
        "wind_path": str(wind_path),
        "rain_path": str(rain_path),
        "local_perturbation_role": "disabled" if not config.add_local_perturbations else "synthetic_local_perturbation",
    }
    return WeatherCube(
        time=np.asarray([0.0]),
        height=cube.height.copy(),
        y=cube.y.copy(),
        x=cube.x.copy(),
        variables={name: value[:1].copy() for name, value in cube.variables.items()},
        source_metadata=metadata,
        confidence=cube.confidence[:1].copy() if isinstance(cube.confidence, np.ndarray) else cube.confidence,
    )


def _require_float(value: Any, label: str) -> float:
    if value is None:
        raise WeatherDataError(f"missing {label}")
    return float(value)


def _optional_float(value: Any, default: float) -> float:
    return default if value is None else float(value)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--case-dir", default="data/replay_cases/case_001_wind_precip")
    parser.add_argument("--source", default="GFS")
    parser.add_argument("--wind-files", nargs="*", default=())
    parser.add_argument("--rain-files", nargs="*", default=())
    parser.add_argument("--download-gfs", action="store_true")
    parser.add_argument("--date", default=None, help="GFS cycle date accepted by Herbie, e.g. 2026-01-22 00:00")
    parser.add_argument("--forecast-hours", default="0,1,2,3,4,5,6")
    parser.add_argument("--priority", default=None, help="Optional Herbie source priority, e.g. nomads, aws, azure, google")
    parser.add_argument("--z-size", type=int, default=4)
    parser.add_argument("--y-size", type=int, default=32)
    parser.add_argument("--x-size", type=int, default=32)
    parser.add_argument("--planning-extent-km", type=float, default=60.0)
    parser.add_argument("--add-local-perturbations", action="store_true")
    parser.add_argument("--validate-only", action="store_true")
    args = parser.parse_args()
    config = RealReplayCaseConfig(
        case_dir=args.case_dir,
        source=args.source,
        z_size=args.z_size,
        y_size=args.y_size,
        x_size=args.x_size,
        planning_extent_km=args.planning_extent_km,
        add_local_perturbations=args.add_local_perturbations,
    )
    if args.validate_only:
        summary = validate_strict_case(args.case_dir)
    elif args.download_gfs:
        if not args.date:
            raise SystemExit("--date is required with --download-gfs")
        hours = [int(item.strip()) for item in args.forecast_hours.split(",") if item.strip()]
        priority = [item.strip() for item in args.priority.split(",")] if args.priority and "," in args.priority else args.priority
        summary = download_gfs_sequence_with_herbie(config, args.date, hours, priority=priority)
    else:
        summary = build_case_from_local_forecast_files(
            list(args.wind_files),
            list(args.rain_files),
            config=config,
            validate=True,
        )
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
