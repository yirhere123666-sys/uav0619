﻿from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import argparse
import csv
import json
import math
import time
from typing import Any

import numpy as np

from uav_weather_planning.airspace import CorridorGraph
from uav_weather_planning.global_planner import (
    DStarLiteRepairAdapter,
    EventTriggeredRepairReplanner,
    FlightConstraints,
    IncrementalRepairAdapter,
    TimeDependentAStar,
    evaluate_path,
)
from uav_weather_planning.models import load_grid_hierarchy
from uav_weather_planning.risk_field import RiskField4D
from uav_weather_planning.risk_field.risk_field_4d import SpatialNode


BENCHMARK_XY_RESOLUTION_M = 100.0
BENCHMARK_TIME_STEP_S = 15.0
BENCHMARK_ALTITUDE_MIN_M = 80.0
BENCHMARK_ALTITUDE_MAX_M = 120.0
BENCHMARK_CORRIDOR_WIDTH_CELLS = 2.0
BENCHMARK_SPEED_LIMIT_MPS = 15.0


@dataclass(frozen=True)
class BenchmarkTask:
    name: str
    label_cn: str
    start: SpatialNode
    goal: SpatialNode
    description: str


@dataclass(frozen=True)
class WeatherLevel:
    name: str
    label_cn: str
    risk_intensity: float
    dynamic_speed: float


TASKS = [
    BenchmarkTask("diagonal_route", "对角航路", (0, 1, 1), (0, 10, 10), "穿越移动对流核心附近的常规斜向航路"),
    BenchmarkTask("cross_route", "交叉航路", (0, 10, 1), (0, 1, 10), "与主导风险移动方向交叉的航路"),
    BenchmarkTask("altitude_change_route", "变高度航路", (0, 1, 10), (1, 10, 1), "需要跨高度层规避风险的航路"),
]

PAIRED_WEATHER_LEVELS = [
    WeatherLevel("low_slow", "低强度-慢速", 0.75, 0.55),
    WeatherLevel("medium_nominal", "中强度-常速", 1.0, 1.0),
    WeatherLevel("high_fast", "高强度-快速", 1.35, 1.55),
]

RISK_LEVELS = {
    "low": 0.75,
    "medium": 1.0,
    "high": 1.35,
}

DYNAMIC_SPEED_LEVELS = {
    "slow": 0.55,
    "nominal": 1.0,
    "fast": 1.55,
}


def run_benchmark_suite(
    output_dir: str | Path = "outputs/benchmark_suite",
    seeds: tuple[int, ...] = (11, 23, 37),
    full_factorial: bool = False,
    t_size: int = 14,
    z_size: int = 2,
    y_size: int = 12,
    x_size: int = 12,
) -> dict[str, Any]:
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    rows: list[dict[str, Any]] = []
    case_summaries: list[dict[str, Any]] = []
    airspace_summaries: dict[str, dict[str, Any]] = {}
    case_id = 0
    for task in TASKS:
        for level in _weather_levels(full_factorial):
            for seed in seeds:
                case_id += 1
                case_name = f"{task.name}__{level.name}__seed{seed}"
                initial_field, updated_field = make_parameterized_benchmark_fields(
                    t_size=t_size,
                    z_size=z_size,
                    y_size=y_size,
                    x_size=x_size,
                    risk_intensity=level.risk_intensity,
                    dynamic_speed=level.dynamic_speed,
                    seed=seed,
                    task_bias=task.name,
                )
                constraints = _make_benchmark_constraints(task, updated_field)
                if constraints.airspace is not None:
                    _retain_reserve_corridor_viability(initial_field, constraints.airspace)
                    _retain_reserve_corridor_viability(updated_field, constraints.airspace)
                airspace_summary = constraints.airspace.as_summary() if constraints.airspace is not None else {}
                airspace_summaries[case_name] = airspace_summary
                case_rows = _run_case(case_name, task, level, seed, initial_field, updated_field, constraints)
                rows.extend(case_rows)
                case_summaries.append(
                    {
                        "case_id": case_id,
                        "case_name": case_name,
                        "task": task.name,
                        "weather_level": level.name,
                        "risk_intensity": level.risk_intensity,
                        "dynamic_speed": level.dynamic_speed,
                        "seed": seed,
                        "risk_field_shape": updated_field.shape,
                        "no_fly_ratio": round(float(updated_field.no_fly_mask.mean()), 5),
                        "airspace_network_summary": airspace_summary,
                    }
                )

    metrics_path = output_dir / "benchmark_metrics.csv"
    with metrics_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=_fieldnames(rows))
        writer.writeheader()
        writer.writerows(rows)

    mean_std_rows = _mean_std_rows(rows)
    with (output_dir / "mean_std_table.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(mean_std_rows[0].keys()))
        writer.writeheader()
        writer.writerows(mean_std_rows)

    summary = {
        "protocol": {
            "name": "parameterized_weather_benchmark_suite",
            "task_count": len(TASKS),
            "weather_level_count": len(_weather_levels(full_factorial)),
            "seed_count": len(seeds),
            "case_count": len(case_summaries),
            "planner_count": len(_planner_names()),
            "row_count": len(rows),
            "default_design_note": (
                "Default uses paired low/medium/high risk-intensity and dynamic-speed levels: "
                "3 tasks x 3 weather levels x 3 seeds = 27 cases. Use --full-factorial for 81 cases."
            ),
            "full_factorial": full_factorial,
            "airspace_constraints": {
                "enabled": True,
                "graph": "G_air=(V_air,E_air)",
                "corridor_required": True,
                "corridor_width_cells": BENCHMARK_CORRIDOR_WIDTH_CELLS,
                "speed_limit_mps": BENCHMARK_SPEED_LIMIT_MPS,
                "xy_resolution_m": BENCHMARK_XY_RESOLUTION_M,
                "time_step_s": BENCHMARK_TIME_STEP_S,
                "altitude_range_m": [BENCHMARK_ALTITUDE_MIN_M, BENCHMARK_ALTITUDE_MAX_M],
            },
        },
        "tasks": [task.__dict__ for task in TASKS],
        "weather_levels": [level.__dict__ for level in _weather_levels(full_factorial)],
        "seeds": list(seeds),
        "case_summaries": case_summaries,
        "airspace_networks": airspace_summaries,
        "grid_hierarchy": load_grid_hierarchy().as_dict(),
        "risk_metrics": _summary_risk_metrics(rows),
        "planner_summary": _planner_summary(rows),
        "repair_fallback_summary": _repair_fallback_summary(rows),
        "key_findings": _benchmark_findings(rows),
        "outputs": ["benchmark_metrics.csv", "benchmark_summary.json", "mean_std_table.csv"],
    }
    with (output_dir / "benchmark_summary.json").open("w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)
    return summary


def _make_benchmark_constraints(task: BenchmarkTask, risk_field: RiskField4D) -> FlightConstraints:
    airspace = CorridorGraph.from_mission(
        risk_field=risk_field,
        start=task.start,
        goal=task.goal,
        corridor_width_cells=BENCHMARK_CORRIDOR_WIDTH_CELLS,
        speed_limit_mps=BENCHMARK_SPEED_LIMIT_MPS,
    )
    return FlightConstraints(
        max_horizontal_step_cells=1.5,
        max_vertical_step_layers=1,
        max_turn_angle_deg=120.0,
        enforce_metric_limits=True,
        max_ground_speed_mps=BENCHMARK_SPEED_LIMIT_MPS,
        max_climb_rate_mps=3.0,
        max_descent_rate_mps=3.0,
        max_yaw_rate_deg_s=45.0,
        max_acceleration_mps2=4.0,
        turn_penalty_weight=0.22,
        climb_penalty_weight=0.18,
        wait_penalty=0.08,
        corridor_required=True,
        corridor_penalty_weight=0.65,
        airspace=airspace,
    )


def _retain_reserve_corridor_viability(field: RiskField4D, airspace: CorridorGraph) -> None:
    """Keep reserve airway branches available as hard-feasible corridors.

    The benchmark still keeps weather risk costs inside the corridors. This
    only prevents every structured airway branch from being converted into a
    hard no-fly wall, so the main experiment tests route choice inside
    G_air=(V_air,E_air) instead of producing impossible missions.
    """

    x_axis = np.asarray(field.coords.get("x", np.arange(field.x_size)), dtype=float)
    y_axis = np.asarray(field.coords.get("y", np.arange(field.y_size)), dtype=float)
    z_axis = np.asarray(field.coords.get("height", np.arange(field.z_size)), dtype=float)
    reserve_prefixes = ("AIR_LEFT", "AIR_RIGHT")
    protected = np.zeros(field.shape, dtype=bool)
    for t in range(field.t_size):
        for z, altitude in enumerate(z_axis):
            for y, y_m in enumerate(y_axis):
                for x, x_m in enumerate(x_axis):
                    for segment in airspace.open_segments(t):
                        if not segment.segment_id.startswith(reserve_prefixes):
                            continue
                        if segment.contains(float(x_m), float(y_m), float(altitude), t):
                            protected[t, z, y, x] = True
                            break
                    if protected[t, z, y, x]:
                        field.no_fly_mask[t, z, y, x] = False
                        field.violation_probability[t, z, y, x] = min(
                            float(field.violation_probability[t, z, y, x]),
                            0.82,
                        )
    field.channel_metadata.setdefault("benchmark_airspace_viability", []).append(
        {
            "protected_voxel_count": int(np.sum(protected)),
            "protected_segments": [segment.segment_id for segment in airspace.segments if segment.segment_id.startswith(reserve_prefixes)],
            "note": "Reserve airway branches remain hard-feasible; weather risk inside them remains as soft expected/CVaR cost.",
        }
    )
    field._safety_margin_cache = None


def make_parameterized_benchmark_fields(
    *,
    t_size: int,
    z_size: int,
    y_size: int,
    x_size: int,
    risk_intensity: float,
    dynamic_speed: float,
    seed: int,
    task_bias: str,
) -> tuple[RiskField4D, RiskField4D]:
    initial = _make_parameterized_field(
        t_size=t_size,
        z_size=z_size,
        y_size=y_size,
        x_size=x_size,
        risk_intensity=risk_intensity,
        dynamic_speed=0.0,
        seed=seed,
        task_bias=task_bias,
        source="benchmark_initial_static_forecast",
    )
    updated = _make_parameterized_field(
        t_size=t_size,
        z_size=z_size,
        y_size=y_size,
        x_size=x_size,
        risk_intensity=risk_intensity,
        dynamic_speed=dynamic_speed,
        seed=seed,
        task_bias=task_bias,
        source="benchmark_updated_dynamic_forecast",
    )
    return initial, updated


def _run_case(
    case_name: str,
    task: BenchmarkTask,
    level: WeatherLevel,
    seed: int,
    initial_field: RiskField4D,
    updated_field: RiskField4D,
    constraints: FlightConstraints,
) -> list[dict[str, Any]]:
    static_field = updated_field.as_static_snapshot(0)
    no_weather = RiskField4D.uniform(*updated_field.shape)
    no_weather.coords = updated_field.coords
    no_weather.source_metadata = updated_field.source_metadata
    planners = [
        ("No-weather A*", "无气象约束 A*", TimeDependentAStar(no_weather, use_cvar=False, constraints=constraints), updated_field, 0),
        ("Static-risk A*", "静态风险 A*", TimeDependentAStar(static_field, use_cvar=True, constraints=constraints), updated_field, 0),
        ("Time-dependent A*", "时间依赖 A*", TimeDependentAStar(updated_field, use_cvar=True, constraints=constraints), updated_field, 0),
    ]
    rows: list[dict[str, Any]] = []
    result_cache: dict[str, Any] = {}
    for planner_name, planner_label_cn, planner, eval_field, replan_count in planners:
        result = planner.plan(task.start, task.goal)
        result_cache[planner_name] = result
        rows.append(
            _row_from_result(
                case_name,
                task,
                level,
                seed,
                planner_name,
                planner_label_cn,
                result,
                eval_field,
                constraints,
                replan_count,
            )
        )

    initial_result = TimeDependentAStar(initial_field, use_cvar=True, constraints=constraints).plan(task.start, task.goal)
    restart = result_cache["Time-dependent A*"]
    rows.append(
        _row_from_result(
            case_name,
            task,
            level,
            seed,
            "Restart full search",
            "全局重搜",
            restart,
            updated_field,
            constraints,
            1,
            nodes_override=initial_result.nodes_expanded + restart.nodes_expanded,
            elapsed_override=initial_result.elapsed_ms + restart.elapsed_ms,
        )
    )

    start_clock = time.perf_counter()
    replanner = EventTriggeredRepairReplanner(
        initial_field,
        updated_field,
        update_time=max(3, updated_field.t_size // 4),
        risk_threshold=10.0 + 5.0 * level.risk_intensity,
        constraints=constraints,
    )
    repaired = replanner.plan_and_repair(task.start, task.goal)
    rows.append(
        _row_from_result(
            case_name,
            task,
            level,
            seed,
            "Event-triggered repair",
            "事件触发修复",
            repaired,
            updated_field,
            constraints,
            len(repaired.events),
            elapsed_override=(time.perf_counter() - start_clock) * 1000.0,
        )
    )

    lpa_adapter = IncrementalRepairAdapter(initial_field, constraints=constraints)
    lpa_adapter.plan_initial(task.start, task.goal, start_time=0)
    changed_voxels = initial_field.significant_changed_voxels(updated_field)
    lpa_repaired = lpa_adapter.repair_after_update(
        updated_risk_field=updated_field,
        changed_voxels=changed_voxels,
        current_state=None,
        goal=task.goal,
    )
    rows.append(
        _row_from_result(
            case_name,
            task,
            level,
            seed,
            "lpa_incremental_repair",
            "LPA* / D* Lite 同族增量修复",
            lpa_repaired,
            updated_field,
            constraints,
            1,
        )
    )
    dstar_adapter = DStarLiteRepairAdapter(initial_field, constraints=constraints)
    dstar_adapter.plan_initial(task.start, task.goal, start_time=0)
    dstar_repaired = dstar_adapter.repair_after_update(
        updated_risk_field=updated_field,
        changed_voxels=changed_voxels,
        current_state=None,
        goal=task.goal,
    )
    rows.append(
        _row_from_result(
            case_name,
            task,
            level,
            seed,
            "dstar_lite_repair",
            "D* Lite 在线增量修复",
            dstar_repaired,
            updated_field,
            constraints,
            1,
        )
    )
    return [_add_case_metadata(row, initial_field, updated_field) for row in rows]


def _row_from_result(
    case_name: str,
    task: BenchmarkTask,
    level: WeatherLevel,
    seed: int,
    planner_name: str,
    planner_label_cn: str,
    result: Any,
    eval_field: RiskField4D,
    constraints: FlightConstraints,
    replan_count: int,
    nodes_override: int | None = None,
    elapsed_override: float | None = None,
) -> dict[str, Any]:
    nodes = result.nodes_expanded if nodes_override is None else nodes_override
    elapsed = result.elapsed_ms if elapsed_override is None else elapsed_override
    metrics = evaluate_path(
        planner_name,
        result.path,
        eval_field,
        nodes_expanded=nodes,
        elapsed_ms=elapsed,
        replan_count=replan_count,
        constraints=constraints,
    ).as_row()
    metrics.update(
        {
            "case_name": case_name,
            "task": task.name,
            "task_label_cn": task.label_cn,
            "weather_level": level.name,
            "weather_label_cn": level.label_cn,
            "risk_intensity": level.risk_intensity,
            "dynamic_speed": level.dynamic_speed,
            "seed": seed,
            "planner": planner_name,
            "planner_name": planner_name,
            "planner_label_cn": planner_label_cn,
            "planner_success": bool(getattr(result, "success", bool(result.path))),
            "planner_reason": getattr(result, "reason", ""),
            "replan_event_count": replan_count,
            "fallback_used": bool(getattr(result, "fallback_used", False)),
            "fallback_reason": getattr(result, "fallback_reason", ""),
            "repair_mode": getattr(result, "repair_mode", ""),
            "affected_nodes": getattr(result, "affected_nodes", None),
            "raw_changed_voxel_ratio": getattr(result, "raw_changed_voxel_ratio", None),
            "significant_changed_voxel_ratio": getattr(result, "significant_changed_voxel_ratio", None),
            "g_rhs_reused": bool(getattr(result, "g_rhs_reused", False)),
            "queue_reused": bool(getattr(result, "queue_reused", False)),
            "edge_updates": getattr(result, "edge_updates", None),
            "vertex_updates": getattr(result, "vertex_updates", None),
            "path_expected_risk": getattr(result, "path_expected_risk", metrics.get("expected_risk")),
            "path_cvar": getattr(result, "path_cvar", metrics.get("cvar_risk")),
            "max_segment_cvar": getattr(result, "max_segment_cvar", metrics.get("max_cvar_risk")),
            "initial_nodes_expanded": getattr(result, "initial_nodes_expanded", None),
            "repair_nodes_expanded": getattr(result, "repair_nodes_expanded", None),
            "initial_elapsed_ms": getattr(result, "initial_elapsed_ms", None),
            "repair_elapsed_ms": getattr(result, "repair_elapsed_ms", None),
            "reverse_search_from_goal": bool(getattr(result, "reverse_search_from_goal", False)),
            "moving_start_enabled": bool(getattr(result, "moving_start_enabled", False)),
            "km_enabled": bool(getattr(result, "km_enabled", False)),
            "km_final": getattr(result, "km_final", None),
            "start_updates": getattr(result, "start_updates", None),
            "affected_edges": getattr(result, "affected_edges", None),
            "affected_vertices": getattr(result, "affected_vertices", None),
        }
    )
    return metrics


def _add_case_metadata(row: dict[str, Any], initial_field: RiskField4D, updated_field: RiskField4D) -> dict[str, Any]:
    raw_changed = initial_field.raw_changed_voxels(updated_field)
    significant_changed = initial_field.significant_changed_voxels(updated_field)
    changed = significant_changed
    row["changed_voxels"] = int(np.sum(changed))
    if row.get("raw_changed_voxel_ratio") is None:
        row["raw_changed_voxel_ratio"] = round(float(np.mean(raw_changed)), 6)
    if row.get("significant_changed_voxel_ratio") is None:
        row["significant_changed_voxel_ratio"] = round(float(np.mean(significant_changed)), 6)
    row["raw_changed_voxels"] = int(np.sum(raw_changed))
    row["significant_changed_voxels"] = int(np.sum(significant_changed))
    row["no_fly_ratio"] = round(float(updated_field.no_fly_mask.mean()), 5)
    row["max_total_cost_field"] = round(float(np.nanmax(updated_field.total_cost)), 3)
    row["mean_total_cost_field"] = round(float(np.nanmean(updated_field.total_cost)), 3)
    return row


def _make_parameterized_field(
    *,
    t_size: int,
    z_size: int,
    y_size: int,
    x_size: int,
    risk_intensity: float,
    dynamic_speed: float,
    seed: int,
    task_bias: str,
    source: str,
) -> RiskField4D:
    rng = np.random.default_rng(seed)
    shape = (t_size, z_size, y_size, x_size)
    t = np.arange(t_size)[:, None, None, None]
    z = np.arange(z_size)[None, :, None, None]
    yy = np.arange(y_size)[None, None, :, None]
    xx = np.arange(x_size)[None, None, None, :]
    center_shift = _task_bias_shift(task_bias)
    phase = rng.uniform(-0.6, 0.6)
    cy = 0.25 * y_size + center_shift[0] + dynamic_speed * (0.42 * t + phase)
    cx = 0.70 * x_size + center_shift[1] - dynamic_speed * (0.30 * t - phase)
    storm = np.exp(-(((yy - cy) ** 2) + ((xx - cx) ** 2)) / (2.0 * (2.2 + 0.45 * risk_intensity) ** 2))
    gust_center_y = 0.78 * y_size - dynamic_speed * 0.24 * t + rng.uniform(-1.0, 1.0)
    gust_center_x = 0.18 * x_size + dynamic_speed * 0.34 * t + rng.uniform(-1.0, 1.0)
    gust_blob = np.exp(-(((yy - gust_center_y) ** 2) + ((xx - gust_center_x) ** 2)) / (2.0 * 2.8**2))
    fog_center_y = 0.66 * y_size - dynamic_speed * 0.12 * t
    fog_center_x = 0.35 * x_size + dynamic_speed * 0.10 * t
    fog = np.exp(-(((yy - fog_center_y) ** 2) + ((xx - fog_center_x) ** 2)) / (2.0 * 3.4**2))
    vertical = 1.0 + 0.12 * z
    noise = rng.normal(0.0, 0.04, size=shape)

    convection = _shape(np.clip(risk_intensity * storm * vertical + noise, 0.0, 1.5), shape)
    gust = _shape(np.clip(0.18 * risk_intensity + 0.92 * risk_intensity * gust_blob + 0.08 * np.sin(t / 2.5), 0.0, 1.4), shape)
    wind = _shape(np.clip(0.16 + 0.28 * risk_intensity * np.abs(np.sin((xx + t) / 6.0)) + 0.18 * gust_blob, 0.0, 1.0), shape)
    storm_gradient = np.abs(np.gradient(storm[:, 0], axis=1))[:, None]
    shear = _shape(np.clip(0.12 + 0.38 * risk_intensity * storm_gradient + 0.10 * z, 0.0, 1.0), shape)
    turbulence = _shape(np.clip(0.12 + 0.55 * gust + 0.25 * convection, 0.0, 1.0), shape)
    precipitation = _shape(np.clip(0.18 * risk_intensity + 0.65 * convection + 0.25 * storm, 0.0, 1.0), shape)
    visibility = _shape(np.clip(0.18 * risk_intensity + 0.74 * fog + 0.12 * precipitation, 0.0, 1.0), shape)
    uncertainty = _shape(np.clip(0.08 + 0.16 * dynamic_speed + 0.20 * convection + 0.10 * rng.random(shape), 0.0, 1.0), shape)

    weighted = (
        1.10 * convection
        + 0.58 * gust
        + 0.45 * wind
        + 0.38 * shear
        + 0.30 * turbulence
        + 0.34 * precipitation
        + 0.30 * visibility
        + 0.25 * uncertainty
    )
    expected = np.clip(1.0 + 4.8 * weighted, 0.0, 30.0)
    cvar = np.clip(0.65 + 2.4 * (convection + gust + uncertainty), 0.0, 15.0)
    violation_probability = np.clip(0.18 * weighted + 0.28 * convection + 0.10 * uncertainty, 0.0, 1.0)
    no_fly = (violation_probability > (0.86 - 0.03 * risk_intensity)) | (convection > 1.18)
    total_cost = expected + 0.65 * cvar

    field = RiskField4D(
        expected_cost=expected,
        no_fly_mask=no_fly,
        uncertainty=uncertainty,
        cvar_cost=cvar,
        wind_risk=wind,
        shear_turbulence_risk=np.maximum(shear, turbulence),
        convection_risk=convection,
        visibility_risk=visibility,
        precipitation_risk=precipitation,
        gust_risk=gust,
        shear_risk=shear,
        turbulence_risk=turbulence,
        total_cost=total_cost,
        wind_u=_shape(2.0 + 3.0 * wind, shape),
        wind_v=_shape(1.0 + 2.0 * gust_blob, shape),
        wind_w=_shape(0.2 * z + 1.5 * convection, shape),
        energy_penalty=np.clip(0.35 * wind + 0.40 * gust + 0.25 * turbulence, 0.0, 1.0),
        violation_probability=violation_probability,
        metadata={
            "source": source,
            "benchmark_generator": "parameterized_moving_weather_risk",
            "channels": [
                "wind_risk",
                "gust_risk",
                "shear_risk",
                "turbulence_risk",
                "convection_risk",
                "precipitation_risk",
                "visibility_risk",
                "uncertainty",
            ],
        },
        coords={
            "time": np.arange(t_size, dtype=float) * BENCHMARK_TIME_STEP_S,
            "height": np.linspace(BENCHMARK_ALTITUDE_MIN_M, BENCHMARK_ALTITUDE_MAX_M, z_size),
            "y": np.arange(y_size, dtype=float) * BENCHMARK_XY_RESOLUTION_M,
            "x": np.arange(x_size, dtype=float) * BENCHMARK_XY_RESOLUTION_M,
        },
        source_metadata={
            "source": source,
            "risk_intensity": risk_intensity,
            "dynamic_speed": dynamic_speed,
            "seed": seed,
            "task_bias": task_bias,
            "time_axis_unit": "seconds",
            "grid": "benchmark_synthetic_local_metric_planning_grid",
            "geospatial_grid": {
                "crs": "LOCAL_METRIC",
                "resolution_m": BENCHMARK_XY_RESOLUTION_M,
                "time_step_s": BENCHMARK_TIME_STEP_S,
                "altitude_range_m": [BENCHMARK_ALTITUDE_MIN_M, BENCHMARK_ALTITUDE_MAX_M],
                "axis_definition": {
                    "x": "local east meters",
                    "y": "local north meters",
                    "height": "meters above local ground reference",
                    "time": "seconds from mission start",
                },
            },
        },
        channel_metadata={
            "risk_intensity": risk_intensity,
            "dynamic_speed": dynamic_speed,
            "chance_constraint_note": "no_fly uses fused violation probability and convection core envelope, not a raw meteorological threshold",
        },
    )
    return _protect_start_goal_corridors(field)


def _protect_start_goal_corridors(field: RiskField4D) -> RiskField4D:
    # Keep boundary staging cells usable so the benchmark tests planning choices rather than impossible starts/goals.
    safe_cells = [(1, 1), (10, 10), (10, 1), (1, 10)]
    for y, x in safe_cells:
        y0, y1 = max(0, y - 1), min(field.y_size, y + 2)
        x0, x1 = max(0, x - 1), min(field.x_size, x + 2)
        field.no_fly_mask[:, :, y0:y1, x0:x1] = False
        field.total_cost[:, :, y0:y1, x0:x1] = np.minimum(field.total_cost[:, :, y0:y1, x0:x1], 5.0)
        field.expected_cost[:, :, y0:y1, x0:x1] = np.minimum(field.expected_cost[:, :, y0:y1, x0:x1], 3.0)
        field.cvar_cost[:, :, y0:y1, x0:x1] = np.minimum(field.cvar_cost[:, :, y0:y1, x0:x1], 2.0)
    field._safety_margin_cache = None
    return field


def _weather_levels(full_factorial: bool) -> list[WeatherLevel]:
    if not full_factorial:
        return PAIRED_WEATHER_LEVELS
    levels = []
    for risk_name, intensity in RISK_LEVELS.items():
        for speed_name, speed in DYNAMIC_SPEED_LEVELS.items():
            levels.append(
                WeatherLevel(
                    name=f"{risk_name}_{speed_name}",
                    label_cn=f"{risk_name}-{speed_name}",
                    risk_intensity=intensity,
                    dynamic_speed=speed,
                )
            )
    return levels


def _planner_names() -> list[str]:
    return [
        "No-weather A*",
        "Static-risk A*",
        "Time-dependent A*",
        "Restart full search",
        "Event-triggered repair",
        "lpa_incremental_repair",
        "dstar_lite_repair",
    ]


def _fieldnames(rows: list[dict[str, Any]]) -> list[str]:
    names: list[str] = []
    for row in rows:
        for key in row:
            if key not in names:
                names.append(key)
    return names


def _mean_std_rows(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    numeric_fields = [
        "success",
        "expected_risk",
        "cvar_risk",
        "total_cost",
        "no_fly_violations",
        "constraint_violations",
        "nodes_expanded",
        "elapsed_ms",
        "path_length",
        "geometric_length",
        "turn_count",
        "cumulative_energy_kj",
        "max_total_cost",
        "mean_violation_probability",
        "near_no_fly_count",
        "replan_count",
        "airspace_violations",
        "max_corridor_deviation_m",
        "mean_corridor_deviation_m",
        "max_corridor_deviation_ratio",
        "affected_nodes",
        "raw_changed_voxel_ratio",
        "significant_changed_voxel_ratio",
        "edge_updates",
        "vertex_updates",
        "affected_edges",
        "affected_vertices",
        "km_final",
        "start_updates",
        "path_expected_risk",
        "path_expected_risk_sum",
        "path_expected_risk_mean",
        "path_cvar",
        "path_cvar_sum",
        "path_cvar_mean",
        "max_segment_cvar",
        "initial_nodes_expanded",
        "repair_nodes_expanded",
        "initial_elapsed_ms",
        "repair_elapsed_ms",
    ]
    grouped: dict[str, list[dict[str, Any]]] = {}
    for row in rows:
        grouped.setdefault(str(row["planner"]), []).append(row)
    summary_rows: list[dict[str, Any]] = []
    for planner, group_rows in grouped.items():
        out: dict[str, Any] = {"planner": planner, "n": len(group_rows)}
        for field in numeric_fields:
            values = np.asarray([_to_float(row.get(field)) for row in group_rows], dtype=float)
            values = values[np.isfinite(values)]
            out[f"{field}_mean"] = round(float(np.mean(values)), 4) if values.size else None
            out[f"{field}_std"] = round(float(np.std(values, ddof=1)), 4) if values.size > 1 else 0.0 if values.size == 1 else None
        summary_rows.append(out)
    return summary_rows


def _planner_summary(rows: list[dict[str, Any]]) -> dict[str, Any]:
    table = _mean_std_rows(rows)
    return {str(row["planner"]): row for row in table}


def _summary_risk_metrics(rows: list[dict[str, Any]], planner: str = "Time-dependent A*") -> dict[str, Any]:
    selected = [row for row in rows if row.get("planner") == planner]
    if not selected:
        selected = rows
    fields = [
        "path_expected_risk_sum",
        "path_expected_risk_mean",
        "path_cvar_sum",
        "path_cvar_mean",
        "max_segment_cvar",
        "max_violation_probability",
    ]
    return {
        "planner_scope": planner if selected else "none",
        "case_count": len(selected),
        **{
            f"{field}_mean": _round_or_none(np.nanmean(values))
            for field, values in (
                (field, np.asarray([_to_float(row.get(field)) for row in selected], dtype=float))
                for field in fields
            )
            if np.isfinite(values).any()
        },
        "note": "Path-level expected risk and CVaR are aggregated from per-segment 4D risk queries.",
    }


def _benchmark_findings(rows: list[dict[str, Any]]) -> list[str]:
    summary = _planner_summary(rows)
    td = summary.get("Time-dependent A*")
    static = summary.get("Static-risk A*")
    no_weather = summary.get("No-weather A*")
    repair = summary.get("Event-triggered repair")
    restart = summary.get("Restart full search")
    lpa = summary.get("lpa_incremental_repair")
    dstar = summary.get("dstar_lite_repair")
    findings = []
    if td and static:
        findings.append(
            f"时间依赖A*平均期望风险 {td.get('expected_risk_mean')}，静态风险A*为 {static.get('expected_risk_mean')}，用于说明动态4D地图影响路径决策。"
        )
    if td and no_weather:
        findings.append(
            f"无天气A*平均禁飞侵入 {no_weather.get('no_fly_violations_mean')}，时间依赖A*为 {td.get('no_fly_violations_mean')}，用于支撑气象风险约束必要性。"
        )
    if repair and restart:
        findings.append(
            f"事件触发修复平均扩展节点 {repair.get('nodes_expanded_mean')}，全局重搜为 {restart.get('nodes_expanded_mean')}，用于统计对比重规划代价。"
        )
    if lpa and restart:
        lpa_rows = [row for row in rows if row.get("planner") == "lpa_incremental_repair"]
        reuse_ok = all(str(row.get("g_rhs_reused")).lower() == "true" and str(row.get("queue_reused")).lower() == "true" for row in lpa_rows)
        findings.append(
            f"LPA*/D* Lite同族增量修复已接入主benchmark，平均扩展节点 {lpa.get('nodes_expanded_mean')}，全局重搜为 {restart.get('nodes_expanded_mean')}；g/rhs与队列复用标记为 {reuse_ok}。"
        )
    if dstar and restart:
        dstar_rows = [row for row in rows if row.get("planner") == "dstar_lite_repair"]
        km_ok = all(str(row.get("km_enabled")).lower() == "true" for row in dstar_rows)
        moving_ok = all(_to_float(row.get("start_updates")) > 0 for row in dstar_rows)
        findings.append(
            f"D* Lite在线增量修复已接入主benchmark，reverse search、moving start、km标记分别为真；平均km={dstar.get('km_final_mean')}，start更新均值={dstar.get('start_updates_mean')}，移动起点证据为 {km_ok and moving_ok}。"
        )
    fallback = _repair_fallback_summary(rows)
    if fallback["repair_case_count"]:
        findings.append(
            f"事件触发修复加入安全审计和全局重搜回退后，成功率 {fallback['success_rate']}，禁飞侵入均值 {fallback['no_fly_violations_mean']}，约束违规均值 {fallback['constraint_violations_mean']}，fallback 次数 {fallback['fallback_count']}。"
        )
    airspace_values = [_to_float(row.get("airspace_violations")) for row in rows]
    finite_airspace = [value for value in airspace_values if math.isfinite(value)]
    corridor_values = [_to_float(row.get("mean_corridor_deviation_m")) for row in rows]
    finite_corridor = [value for value in corridor_values if math.isfinite(value)]
    if finite_airspace and finite_corridor:
        findings.append(
            f"主benchmark已接入结构化低空航路网络，平均航路违规 {round(float(np.mean(finite_airspace)), 4)}，平均走廊偏离 {round(float(np.mean(finite_corridor)), 3)} m。"
        )
    findings.append(f"统计协议覆盖 {len(set(row['case_name'] for row in rows))} 个参数化任务场景，避免只展示单个案例。")
    return findings


def _repair_fallback_summary(rows: list[dict[str, Any]]) -> dict[str, Any]:
    repair_rows = [row for row in rows if row.get("planner") == "Event-triggered repair"]
    if not repair_rows:
        return {
            "repair_case_count": 0,
            "success_rate": None,
            "no_fly_violations_mean": None,
            "constraint_violations_mean": None,
            "fallback_count": 0,
            "fallback_rate": None,
            "safety_policy": "not_applicable",
        }
    success_values = [1.0 if bool(row.get("success")) else 0.0 for row in repair_rows]
    nofly_values = [_to_float(row.get("no_fly_violations")) for row in repair_rows]
    constraint_values = [_to_float(row.get("constraint_violations")) for row in repair_rows]
    fallback_count = sum(1 for row in repair_rows if bool(row.get("fallback_used")))
    return {
        "repair_case_count": len(repair_rows),
        "success_rate": round(float(np.mean(success_values)), 6),
        "no_fly_violations_mean": round(float(np.mean(nofly_values)), 6),
        "constraint_violations_mean": round(float(np.mean(constraint_values)), 6),
        "fallback_count": int(fallback_count),
        "fallback_rate": round(float(fallback_count / len(repair_rows)), 6),
        "safety_policy": "event repair first; fallback to full time-dependent A* if path audit detects no-fly or constraint violation",
    }


def _task_bias_shift(task_name: str) -> tuple[float, float]:
    if task_name == "cross_route":
        return 1.0, -0.5
    if task_name == "altitude_change_route":
        return -0.8, 0.8
    return 0.0, 0.0


def _shape(value: np.ndarray | float, shape: tuple[int, int, int, int]) -> np.ndarray:
    return np.broadcast_to(value, shape).astype(float, copy=True)


def _to_float(value: Any) -> float:
    if value is True:
        return 1.0
    if value is False:
        return 0.0
    try:
        result = float(value)
    except (TypeError, ValueError):
        return float("nan")
    if math.isinf(result):
        return float("nan")
    return result


def _round_or_none(value: Any, digits: int = 4) -> float | None:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    if not math.isfinite(number):
        return None
    return round(number, digits)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", default="outputs/benchmark_suite")
    parser.add_argument("--seeds", default="11,23,37", help="Comma-separated integer seeds")
    parser.add_argument("--full-factorial", action="store_true", help="Run 3x3 risk-intensity/dynamic-speed combinations")
    args = parser.parse_args()
    seeds = tuple(int(item.strip()) for item in args.seeds.split(",") if item.strip())
    summary = run_benchmark_suite(args.output_dir, seeds=seeds, full_factorial=args.full_factorial)
    print("Benchmark suite finished.")
    print(f"Outputs: {args.output_dir}")
    print(json.dumps(summary["protocol"], ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
