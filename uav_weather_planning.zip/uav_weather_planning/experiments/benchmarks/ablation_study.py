from __future__ import annotations

from dataclasses import replace
from pathlib import Path
import argparse
import csv
import json
from typing import Any

import numpy as np

from uav_weather_planning.global_planner import (
    EventTriggeredRepairReplanner,
    FlightConstraints,
    TimeDependentAStar,
    evaluate_path,
)
from uav_weather_planning.risk_field import RiskField4D
from uav_weather_planning.risk_field.risk_field_4d import State4D
from uav_weather_planning.visualization import plot_ablation_metrics, plot_algorithm_comparison
from uav_weather_planning.weather_simulation import make_dynamic_convection_update_pair


def run_ablation_study(
    output_dir: str | Path = "outputs/ablation_study",
    t_size: int = 18,
    z_size: int = 3,
    y_size: int = 16,
    x_size: int = 16,
) -> dict[str, Any]:
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    start = (1, 2, 2)
    goal = (1, y_size - 3, x_size - 3)
    initial_field, updated_field = make_dynamic_convection_update_pair(
        t_size=t_size,
        z_size=z_size,
        y_size=y_size,
        x_size=x_size,
    )
    static_field = updated_field.as_static_snapshot(0)
    no_weather = RiskField4D.uniform(*updated_field.shape)
    soft_no_fly_field = _soften_no_fly(updated_field)
    full_constraints = FlightConstraints(
        max_horizontal_step_cells=1.5,
        max_vertical_step_layers=1,
        max_turn_angle_deg=90.0,
        turn_penalty_weight=0.30,
        climb_penalty_weight=0.26,
        wait_penalty=0.12,
    )
    loose_constraints = FlightConstraints(
        max_horizontal_step_cells=1.5,
        max_vertical_step_layers=1,
        max_turn_angle_deg=180.0,
        turn_penalty_weight=0.0,
        climb_penalty_weight=0.0,
        wait_penalty=0.0,
    )
    rows: list[dict[str, Any]] = []
    paths: dict[str, list[State4D]] = {}

    full_result = TimeDependentAStar(updated_field, use_cvar=True, constraints=full_constraints).plan(start, goal)
    _append_case(
        rows,
        paths,
        name="Full dynamic 4D planner",
        label_cn="完整方法",
        group="risk_model_ablation",
        ablation_target="baseline",
        description="动态4D风险场 + CVaR尾部风险 + 能耗项 + 航迹约束",
        result=full_result,
        evaluation_field=updated_field,
        evaluation_constraints=full_constraints,
        replan_count=0,
    )

    planning_cases = [
        (
            "No-weather planner",
            "无天气风险",
            "weather_risk_field",
            "去掉气象风险场，仅按几何距离规划，再放回真实风险场评价。",
            TimeDependentAStar(no_weather, use_cvar=False, constraints=full_constraints),
            updated_field,
            full_constraints,
        ),
        (
            "Static risk planner",
            "去动态4D",
            "temporal_dynamics",
            "将第0时刻风险复制到全时段，检验动态风险场是否改变路径决策。",
            TimeDependentAStar(static_field, use_cvar=True, constraints=full_constraints),
            updated_field,
            full_constraints,
        ),
        (
            "Expected-risk only planner",
            "去CVaR尾部",
            "tail_risk_cvar",
            "只使用期望风险，关闭CVaR尾部风险权重。",
            TimeDependentAStar(updated_field, use_cvar=False, cvar_weight=0.0, constraints=full_constraints),
            updated_field,
            full_constraints,
        ),
        (
            "No energy term planner",
            "去能耗项",
            "energy_model",
            "关闭规划代价中的多旋翼能耗惩罚，但仍按完整能耗模型评价。",
            TimeDependentAStar(updated_field, use_cvar=True, energy_weight=0.0, constraints=full_constraints),
            updated_field,
            full_constraints,
        ),
        (
            "Loose trajectory planner",
            "弱化航迹约束",
            "trajectory_constraints",
            "放松转弯和等待惩罚，评价阶段仍按完整航迹约束审计。",
            TimeDependentAStar(updated_field, use_cvar=True, constraints=loose_constraints),
            updated_field,
            full_constraints,
        ),
        (
            "Soft-risk-only planner",
            "去硬禁飞",
            "hard_no_fly_constraint",
            "将硬禁飞区改为有限软代价，检验机会约束边界的必要性。",
            TimeDependentAStar(soft_no_fly_field, use_cvar=True, constraints=full_constraints),
            updated_field,
            full_constraints,
        ),
    ]
    for name, label_cn, target, description, planner, eval_field, eval_constraints in planning_cases:
        result = planner.plan(start, goal)
        _append_case(
            rows,
            paths,
            name=name,
            label_cn=label_cn,
            group="risk_model_ablation",
            ablation_target=target,
            description=description,
            result=result,
            evaluation_field=eval_field,
            evaluation_constraints=eval_constraints,
            replan_count=0,
        )

    initial_result = TimeDependentAStar(initial_field, use_cvar=True, constraints=full_constraints).plan(start, goal)
    _append_case(
        rows,
        paths,
        name="Stale initial forecast",
        label_cn="不重规划",
        group="replanning_ablation",
        ablation_target="forecast_update",
        description="只使用更新前预报路径，风险更新后不修正。",
        result=initial_result,
        evaluation_field=updated_field,
        evaluation_constraints=full_constraints,
        replan_count=0,
    )
    _append_case(
        rows,
        paths,
        name="Restart full search",
        label_cn="全局重搜",
        group="replanning_ablation",
        ablation_target="incremental_repair",
        description="风险更新后重新执行一次完整时间依赖A*搜索。",
        result=full_result,
        evaluation_field=updated_field,
        evaluation_constraints=full_constraints,
        replan_count=1,
        nodes_override=initial_result.nodes_expanded + full_result.nodes_expanded,
        elapsed_override=initial_result.elapsed_ms + full_result.elapsed_ms,
    )
    replanner = EventTriggeredRepairReplanner(
        initial_field,
        updated_field,
        update_time=max(3, t_size // 4),
        risk_threshold=12.0,
        constraints=full_constraints,
    )
    repaired = replanner.plan_and_repair(start, goal)
    _append_case(
        rows,
        paths,
        name="Event-triggered repair",
        label_cn="事件触发修复",
        group="replanning_ablation",
        ablation_target="incremental_repair",
        description="保留已执行路径前缀，只从受影响路径段触发局部修复。",
        result=repaired,
        evaluation_field=updated_field,
        evaluation_constraints=full_constraints,
        replan_count=len(repaired.events),
    )

    rows = _add_relative_deltas(rows, baseline_name="Full dynamic 4D planner")
    ablation_summary = {
        "mission": {"start": start, "goal": goal},
        "risk_field_shape": updated_field.shape,
        "baseline": "Full dynamic 4D planner",
        "groups": {
            "risk_model_ablation": "拆除气象风险、动态4D、CVaR、能耗、航迹约束和硬禁飞边界。",
            "replanning_ablation": "比较不重规划、重新全局搜索和事件触发修复。",
        },
        "metric_columns": list(rows[0].keys()) if rows else [],
        "key_findings": _build_key_findings(rows),
        "replan_events": [
            {
                "event_time": event.event_time,
                "reason": event.reason,
                "affected_voxels": event.affected_voxels,
                "repaired_from": event.repaired_from,
                "nodes_expanded": event.nodes_expanded,
                "elapsed_ms": round(event.elapsed_ms, 3),
            }
            for event in repaired.events
        ],
        "outputs": [
            "ablation_metrics.csv",
            "ablation_summary.json",
            "01_ablation_metrics.png",
            "02_ablation_path_comparison.png",
        ],
    }

    with (output_dir / "ablation_metrics.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    with (output_dir / "ablation_summary.json").open("w", encoding="utf-8") as f:
        json.dump({**ablation_summary, "rows": rows}, f, ensure_ascii=False, indent=2)

    plot_ablation_metrics(rows, output_dir / "01_ablation_metrics.png")
    selected_paths = {
        "完整方法": paths.get("Full dynamic 4D planner", []),
        "去动态4D": paths.get("Static risk planner", []),
        "去CVaR尾部": paths.get("Expected-risk only planner", []),
        "去硬禁飞": paths.get("Soft-risk-only planner", []),
        "事件触发修复": paths.get("Event-triggered repair", []),
    }
    plot_algorithm_comparison(selected_paths, updated_field, output_dir / "02_ablation_path_comparison.png")
    return {**ablation_summary, "rows": rows}


def _append_case(
    rows: list[dict[str, Any]],
    paths: dict[str, list[State4D]],
    *,
    name: str,
    label_cn: str,
    group: str,
    ablation_target: str,
    description: str,
    result: Any,
    evaluation_field: RiskField4D,
    evaluation_constraints: FlightConstraints,
    replan_count: int,
    nodes_override: int | None = None,
    elapsed_override: float | None = None,
) -> None:
    nodes = result.nodes_expanded if nodes_override is None else nodes_override
    elapsed = result.elapsed_ms if elapsed_override is None else elapsed_override
    metrics = evaluate_path(
        name,
        result.path,
        evaluation_field,
        nodes_expanded=nodes,
        elapsed_ms=elapsed,
        replan_count=replan_count,
        constraints=evaluation_constraints,
    )
    row = metrics.as_row()
    row.update(
        {
            "label_cn": label_cn,
            "group": group,
            "ablation_target": ablation_target,
            "description": description,
            "planner_success": bool(getattr(result, "success", bool(result.path))),
            "planner_reason": getattr(result, "reason", ""),
        }
    )
    rows.append(row)
    paths[name] = result.path


def _soften_no_fly(field: RiskField4D) -> RiskField4D:
    mask = field.no_fly_mask
    finite = field.total_cost[np.isfinite(field.total_cost) & (field.total_cost < 1e5)]
    cap_total = float(np.percentile(finite, 82)) if finite.size else 12.0
    expected = field.expected_cost.copy()
    cvar = field.cvar_cost.copy()
    total = field.total_cost.copy()
    expected[mask] = min(cap_total, float(np.percentile(expected[~mask], 85))) if np.any(~mask) else cap_total
    cvar[mask] = min(0.35 * cap_total, float(np.percentile(cvar[~mask], 85))) if np.any(~mask) else 0.35 * cap_total
    total[mask] = expected[mask] + 0.65 * cvar[mask]
    violation_probability = field.violation_probability.copy()
    violation_probability[mask] = np.minimum(violation_probability[mask], 0.82)
    return replace(
        field,
        expected_cost=expected,
        cvar_cost=cvar,
        total_cost=total,
        no_fly_mask=np.zeros_like(mask, dtype=bool),
        violation_probability=violation_probability,
        metadata={**field.metadata, "source": "soft_no_fly_ablation"},
    )


def _add_relative_deltas(rows: list[dict[str, Any]], baseline_name: str) -> list[dict[str, Any]]:
    baseline = next(row for row in rows if row["name"] == baseline_name)
    fields = {
        "expected_risk": "delta_expected_risk_pct",
        "cvar_risk": "delta_cvar_risk_pct",
        "cumulative_energy_kj": "delta_energy_pct",
        "nodes_expanded": "delta_nodes_expanded_pct",
        "elapsed_ms": "delta_elapsed_ms_pct",
        "turn_count": "delta_turn_count",
        "no_fly_violations": "delta_no_fly_violations",
        "constraint_violations": "delta_constraint_violations",
    }
    for row in rows:
        for key, delta_key in fields.items():
            base_value = baseline.get(key)
            value = row.get(key)
            if key in {"turn_count", "no_fly_violations", "constraint_violations"}:
                row[delta_key] = _as_float(value) - _as_float(base_value)
            else:
                row[delta_key] = _pct_delta(_as_float(value), _as_float(base_value))
    return rows


def _build_key_findings(rows: list[dict[str, Any]]) -> list[str]:
    by_name = {str(row["name"]): row for row in rows}
    findings = []
    static = by_name.get("Static risk planner")
    expected_only = by_name.get("Expected-risk only planner")
    soft = by_name.get("Soft-risk-only planner")
    stale = by_name.get("Stale initial forecast")
    restart = by_name.get("Restart full search")
    repair = by_name.get("Event-triggered repair")
    if static:
        findings.append(f"去掉动态4D后，期望风险变化 {static['delta_expected_risk_pct']}%，说明时间维风险会改变全局路径代价。")
    if expected_only:
        findings.append(f"去掉CVaR后，尾部风险变化 {expected_only['delta_cvar_risk_pct']}%，用于回答为什么不能只看平均风险。")
    if soft:
        findings.append(f"去掉硬禁飞边界后，禁飞侵入增量为 {soft['delta_no_fly_violations']}，说明机会约束边界不是图形装饰。")
    if stale:
        findings.append(f"风险更新后不重规划的禁飞侵入增量为 {stale['delta_no_fly_violations']}，支撑动态重规划必要性。")
    if restart and repair:
        restart_nodes = _as_float(restart.get("nodes_expanded"))
        repair_nodes = _as_float(repair.get("nodes_expanded"))
        savings = _pct_delta(repair_nodes, restart_nodes)
        findings.append(f"事件触发修复相对重新全局搜索的扩展节点变化为 {savings}%，用于对比重规划计算代价。")
    return findings


def _as_float(value: Any) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return 0.0


def _pct_delta(value: float, baseline: float) -> float | None:
    if baseline == 0.0 or not np.isfinite(baseline):
        return None
    return round(100.0 * (value - baseline) / baseline, 3)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", default="outputs/ablation_study")
    parser.add_argument("--t-size", type=int, default=18)
    parser.add_argument("--z-size", type=int, default=3)
    parser.add_argument("--y-size", type=int, default=16)
    parser.add_argument("--x-size", type=int, default=16)
    args = parser.parse_args()
    summary = run_ablation_study(
        output_dir=args.output_dir,
        t_size=args.t_size,
        z_size=args.z_size,
        y_size=args.y_size,
        x_size=args.x_size,
    )
    print("Ablation study finished.")
    print(f"Outputs: {args.output_dir}")
    for finding in summary["key_findings"]:
        print(f"- {finding}")


if __name__ == "__main__":
    main()
