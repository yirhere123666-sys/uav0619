from __future__ import annotations

from dataclasses import asdict, dataclass, replace
from pathlib import Path
import argparse
import csv
import json
from typing import Any

import numpy as np

from uav_weather_planning.experiments.benchmark_suite import TASKS, PAIRED_WEATHER_LEVELS, make_parameterized_benchmark_fields
from uav_weather_planning.global_planner import FlightConstraints, TimeDependentAStar, evaluate_path
from uav_weather_planning.risk import compute_cvar_field
from uav_weather_planning.risk_calibration.config import FusionParameterSet, load_fusion_parameters, load_threshold_evidence
from uav_weather_planning.risk_calibration.weight_search import (
    SearchObjectiveWeights,
    WeightSearchConfig,
    evaluate_candidate,
    make_calibration_cases,
)
from uav_weather_planning.risk_field import RiskField4D


RISK_WEIGHT_KEYS = [
    "wind_risk",
    "gust_risk",
    "shear_turbulence_risk",
    "convection_risk",
    "precipitation_risk",
    "visibility_risk",
]

PLANNER_WEIGHT_KEYS = ["cvar_weight", "energy_weight", "corridor_weight"]

UNCERTAINTY_PARAMETER_KEYS = [
    "uncertainty_conservative_weight",
    "uncertainty_sigma0",
    "uncertainty_beta",
]


@dataclass(frozen=True)
class SensitivityConfig:
    fusion_path: str | Path = "configs/risk_fusion_calibrated.yaml"
    threshold_path: str | Path = "configs/risk_thresholds_reference.yaml"
    perturbations: tuple[float, ...] = (0.10, 0.20, 0.30)
    case_count: int = 27
    seed: int = 20260611
    seeds: tuple[int, ...] = (11, 23, 37)
    t_size: int = 14
    z_size: int = 2
    y_size: int = 12
    x_size: int = 12
    use_benchmark_suite: bool = True


@dataclass(frozen=True)
class BenchmarkSensitivityCase:
    case_id: str
    task: Any
    weather_level: Any
    seed: int
    field: RiskField4D


def run_risk_weight_sensitivity(
    output_dir: str | Path = "outputs/risk_weight_sensitivity",
    config: SensitivityConfig | None = None,
) -> dict[str, Any]:
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    config = config or SensitivityConfig()
    baseline = load_fusion_parameters(config.fusion_path)
    thresholds = load_threshold_evidence(config.threshold_path)
    if config.use_benchmark_suite:
        cases = make_benchmark_sensitivity_cases(config)
    else:
        cases = make_calibration_cases(
            WeightSearchConfig(
                case_count=config.case_count,
                seed=config.seed,
                t_size=config.t_size,
                z_size=config.z_size,
                y_size=config.y_size,
                x_size=config.x_size,
            )
        )
    rows: list[dict[str, Any]] = []
    candidates = [("baseline", "baseline", 0.0, baseline)]
    for key in RISK_WEIGHT_KEYS:
        for magnitude in config.perturbations:
            for sign in (-1.0, 1.0):
                factor = 1.0 + sign * magnitude
                candidates.append((key, "risk_weight", sign * magnitude, _perturb_risk_weight(baseline, key, factor)))
    for key in PLANNER_WEIGHT_KEYS:
        for magnitude in config.perturbations:
            for sign in (-1.0, 1.0):
                factor = 1.0 + sign * magnitude
                candidates.append((key, "planner_weight", sign * magnitude, _perturb_planner_weight(baseline, key, factor)))

    for key in UNCERTAINTY_PARAMETER_KEYS:
        for magnitude in config.perturbations:
            for sign in (-1.0, 1.0):
                factor = 1.0 + sign * magnitude
                candidates.append(
                    (key, "epistemic_uncertainty_modulator", sign * magnitude, _perturb_uncertainty_parameter(baseline, key, factor))
                )

    # Chance limit is not a weight, but including it answers the common threshold-stability question.
    for magnitude in config.perturbations:
        for sign in (-1.0, 1.0):
            delta = sign * magnitude * 0.10
            candidates.append(("chance_constraint_limit", "threshold", sign * magnitude, _perturb_chance_limit(baseline, delta)))

    objective = SearchObjectiveWeights()
    for index, (parameter, parameter_type, relative_delta, params) in enumerate(candidates):
        candidate_id = "baseline" if index == 0 else f"{parameter}__{relative_delta:+.0%}"
        if config.use_benchmark_suite:
            candidate_rows = evaluate_benchmark_candidate(candidate_id, params, cases, objective)
        else:
            candidate_rows = evaluate_candidate(candidate_id, params, cases, thresholds.values, objective)
        for row in candidate_rows:
            row["parameter"] = parameter
            row["parameter_type"] = parameter_type
            row["relative_delta"] = relative_delta
            row["absolute_delta_percent"] = round(abs(relative_delta) * 100.0, 3)
        rows.extend(candidate_rows)

    summary_rows = summarize_sensitivity(rows)
    _write_csv(output_dir / "risk_weight_sensitivity.csv", rows)
    _write_csv(output_dir / "risk_weight_sensitivity_table.csv", summary_rows)
    summary = {
        "protocol": {
            **asdict(config),
            "fusion_path": str(config.fusion_path),
            "threshold_path": str(config.threshold_path),
            "case_count": len(cases),
            "candidate_count": len(candidates),
            "sample_source": "benchmark_suite_27_cases" if config.use_benchmark_suite else "calibration_weather_cube_cases",
            "benchmark_protocol": (
                "3 tasks x 3 paired weather levels x 3 seeds = 27 cases"
                if config.use_benchmark_suite
                else None
            ),
            "risk_weight_keys": RISK_WEIGHT_KEYS,
            "planner_weight_keys": PLANNER_WEIGHT_KEYS,
            "uncertainty_parameter_keys": UNCERTAINTY_PARAMETER_KEYS,
            "uncertainty_note": (
                "Epistemic uncertainty is not perturbed as a weather hazard weight. "
                "Sensitivity varies sigma0, beta and the small conservative margin separately."
            ),
            "chance_constraint_note": "Chance limit perturbation is included as threshold sensitivity, not as a fusion weight.",
        },
        "baseline": _find_summary(summary_rows, "baseline", 0.0),
        "stability_findings": stability_findings(summary_rows),
        "outputs": [
            "risk_weight_sensitivity.csv",
            "risk_weight_sensitivity_table.csv",
            "risk_weight_sensitivity_summary.json",
        ],
    }
    with (output_dir / "risk_weight_sensitivity_summary.json").open("w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)
    return summary


def make_benchmark_sensitivity_cases(config: SensitivityConfig) -> list[BenchmarkSensitivityCase]:
    cases: list[BenchmarkSensitivityCase] = []
    for task in TASKS:
        for level in PAIRED_WEATHER_LEVELS:
            for seed in config.seeds:
                _, updated_field = make_parameterized_benchmark_fields(
                    t_size=config.t_size,
                    z_size=config.z_size,
                    y_size=config.y_size,
                    x_size=config.x_size,
                    risk_intensity=level.risk_intensity,
                    dynamic_speed=level.dynamic_speed,
                    seed=seed,
                    task_bias=task.name,
                )
                cases.append(
                    BenchmarkSensitivityCase(
                        case_id=f"{task.name}__{level.name}__seed{seed}",
                        task=task,
                        weather_level=level,
                        seed=seed,
                        field=updated_field,
                    )
                )
                if len(cases) >= config.case_count:
                    return cases
    return cases


def evaluate_benchmark_candidate(
    candidate_id: str,
    params: FusionParameterSet,
    cases: list[BenchmarkSensitivityCase],
    objective_weights: SearchObjectiveWeights,
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    constraints = FlightConstraints(
        max_horizontal_step_cells=1.5,
        max_vertical_step_layers=1,
        max_turn_angle_deg=120.0,
        turn_penalty_weight=0.22,
        climb_penalty_weight=0.18,
        wait_penalty=0.08,
    )
    for case in cases:
        field = apply_fusion_parameters_to_field(case.field, params)
        planner = TimeDependentAStar(
            field,
            use_cvar=True,
            cvar_weight=float(params.planner_weights.get("cvar_weight", 0.55)),
            energy_weight=float(params.planner_weights.get("energy_weight", 0.35)),
            heuristic_weight=2.0,
            constraints=constraints,
        )
        result = planner.plan(case.task.start, case.task.goal)
        metrics = evaluate_path(
            candidate_id,
            result.path,
            field,
            nodes_expanded=result.nodes_expanded,
            elapsed_ms=result.elapsed_ms,
            constraints=constraints,
        ).as_row()
        planner_success = bool(result.success and metrics["success"])
        nofly = int(metrics.get("no_fly_violations", 0) or 0)
        cvar = _finite_or_penalty(metrics.get("cvar_risk"), 1e6)
        path_length = _finite_or_penalty(metrics.get("path_length"), 1e3)
        energy = _finite_or_penalty(metrics.get("cumulative_energy_kj"), 1e3)
        path_loss = (
            objective_weights.failed_plan
            if not planner_success
            else objective_weights.nofly_intrusion * nofly
            + objective_weights.cvar * cvar
            + objective_weights.normalized_path_length * path_length
            + 0.02 * energy
        )
        rows.append(
            {
                "candidate_id": candidate_id,
                "case_id": case.case_id,
                "split": "benchmark",
                "task": case.task.name,
                "weather_level": case.weather_level.name,
                "risk_intensity": case.weather_level.risk_intensity,
                "dynamic_speed": case.weather_level.dynamic_speed,
                "seed": case.seed,
                "voxel_brier": None,
                "voxel_soft_brier": None,
                "path_loss": round(float(path_loss), 6),
                "total_loss": round(float(path_loss), 6),
                "planner_success": planner_success,
                "path_label": "success" if planner_success else "unsafe_or_failed",
                "nofly_intrusions": nofly,
                "high_risk_exposure_time": metrics.get("near_no_fly_count"),
                "cumulative_cvar": cvar,
                "normalized_path_length": path_length,
                "normalized_energy": energy,
                "nodes_expanded": result.nodes_expanded,
                "elapsed_ms": round(result.elapsed_ms, 3),
                "path_length": metrics["path_length"],
                "geometric_length": metrics["geometric_length"],
                "expected_risk": metrics["expected_risk"],
                "cvar_risk": metrics["cvar_risk"],
                "total_cost": metrics["total_cost"],
                "chance_limit": round(params.chance_constraint_limit, 6),
                "uncertainty_conservative_weight": round(params.uncertainty_conservative_weight, 6),
                "uncertainty_sigma0": round(params.uncertainty_sigma0, 6),
                "uncertainty_beta": round(params.uncertainty_beta, 6),
                **{f"w_{name}": round(value, 6) for name, value in params.weights.items()},
                **{f"planner_{name}": round(value, 6) for name, value in params.planner_weights.items()},
            }
        )
    return rows


def apply_fusion_parameters_to_field(field: RiskField4D, params: FusionParameterSet) -> RiskField4D:
    expected = np.ones(field.shape, dtype=float)
    risk_score = np.zeros(field.shape, dtype=float)
    risk_weight_sum = 0.0
    ignored_uncertainty_weight_keys: list[str] = []
    for name, weight in params.weights.items():
        if name in {"uncertainty_risk", "epistemic_uncertainty"}:
            ignored_uncertainty_weight_keys.append(name)
            continue
        if not hasattr(field, name):
            continue
        channel = np.asarray(getattr(field, name), dtype=float)
        expected += float(weight) * channel
        if name.endswith("_risk"):
            risk_score += float(weight) * channel
            risk_weight_sum += float(weight)
    if risk_weight_sum > 0.0:
        risk_score = np.clip(risk_score / risk_weight_sum, 0.0, 1.0)
    cvar_cost = compute_cvar_field(
        risk_score,
        field.uncertainty,
        alpha=params.cvar_alpha,
        n_samples=64,
        seed=20260611,
        perturbation_scale=params.uncertainty_beta,
        base_sigma=params.uncertainty_sigma0,
        return_excess=True,
    )
    tail_ratio = np.clip(cvar_cost / np.maximum(risk_score, 1e-6), 0.0, 1.0)
    violation_probability = np.clip(
        0.66 * risk_score
        + 0.24 * tail_ratio
        + 0.10 * field.convection_risk,
        0.0,
        1.0,
    )
    exceedance = np.maximum(violation_probability - params.chance_constraint_limit, 0.0) / max(
        1.0 - params.chance_constraint_limit,
        1e-6,
    )
    expected = expected + 4.0 * exceedance
    no_fly = field.no_fly_mask.copy()
    total_cost = expected + params.cvar_lambda * cvar_cost + params.uncertainty_conservative_weight * field.uncertainty
    expected[no_fly] = 1e6
    cvar_cost[no_fly] = 1e6
    total_cost[no_fly] = 1e6
    return replace(
        field,
        expected_cost=expected,
        no_fly_mask=no_fly,
        cvar_cost=cvar_cost,
        total_cost=total_cost,
        violation_probability=violation_probability,
        channel_metadata={
            **field.channel_metadata,
            "sensitivity_weights": params.weights,
            "sensitivity_planner_weights": params.planner_weights,
            "sensitivity_uncertainty_parameters": {
                "role": "epistemic_distribution_width_modulator",
                "conservative_weight": params.uncertainty_conservative_weight,
                "sigma0": params.uncertainty_sigma0,
                "beta": params.uncertainty_beta,
                "ignored_weight_keys": ignored_uncertainty_weight_keys,
            },
            "chance_constraint_limit": params.chance_constraint_limit,
            "sensitivity_protocol": "benchmark_suite_weight_perturbation",
            "chance_constraint_treatment": "soft penalty in sensitivity; original benchmark no-fly core remains the hard constraint",
        },
    )


def summarize_sensitivity(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    grouped: dict[tuple[str, float], list[dict[str, Any]]] = {}
    for row in rows:
        key = (str(row["parameter"]), float(row["relative_delta"]))
        grouped.setdefault(key, []).append(row)
    out: list[dict[str, Any]] = []
    for (parameter, relative_delta), group in sorted(grouped.items(), key=lambda item: (item[0][0], item[0][1])):
        successes = np.asarray([bool(row["planner_success"]) for row in group], dtype=float)
        nofly = _array(group, "nofly_intrusions")
        cvar = _array(group, "cvar_risk")
        path_length = _array(group, "path_length")
        energy = _array(group, "normalized_energy")
        total_loss = _array(group, "total_loss")
        out.append(
            {
                "parameter": parameter,
                "parameter_type": group[0]["parameter_type"],
                "relative_delta": relative_delta,
                "absolute_delta_percent": round(abs(relative_delta) * 100.0, 3),
                "case_count": len(group),
                "success_rate_mean": round(float(np.mean(successes)), 6),
                "success_rate_std": round(float(np.std(successes, ddof=1)), 6) if len(successes) > 1 else 0.0,
                "nofly_intrusions_mean": _mean(nofly),
                "nofly_intrusions_std": _std(nofly),
                "cvar_mean": _mean(cvar),
                "cvar_std": _std(cvar),
                "path_length_mean": _mean(path_length),
                "path_length_std": _std(path_length),
                "energy_mean": _mean(energy),
                "energy_std": _std(energy),
                "total_loss_mean": _mean(total_loss),
                "total_loss_std": _std(total_loss),
            }
        )
    return out


def stability_findings(summary_rows: list[dict[str, Any]]) -> dict[str, Any]:
    plus_minus_20 = [
        row
        for row in summary_rows
        if row["parameter"] != "baseline" and abs(float(row["relative_delta"])) <= 0.20 + 1e-9
    ]
    plus_minus_30 = [
        row
        for row in summary_rows
        if row["parameter"] != "baseline" and abs(float(row["relative_delta"])) <= 0.30 + 1e-9
    ]
    return {
        "within_20_percent": _stability_block(plus_minus_20),
        "within_30_percent": _stability_block(plus_minus_30),
        "interpretation": (
            "If nofly_intrusions_mean stays near zero and success_rate_mean remains high under +/-20% perturbations, "
            "the planning conclusion is not dependent on one hand-picked weight."
        ),
    }


def _stability_block(rows: list[dict[str, Any]]) -> dict[str, Any]:
    if not rows:
        return {}
    return {
        "min_success_rate": round(float(min(row["success_rate_mean"] for row in rows)), 6),
        "max_nofly_intrusions_mean": round(float(max(row["nofly_intrusions_mean"] for row in rows)), 6),
        "mean_cvar_mean": _safe_mean([row["cvar_mean"] for row in rows]),
        "mean_path_length_mean": _safe_mean([row["path_length_mean"] for row in rows]),
        "mean_energy_mean": _safe_mean([row["energy_mean"] for row in rows]),
    }


def _perturb_risk_weight(params: FusionParameterSet, key: str, factor: float) -> FusionParameterSet:
    weights = dict(params.weights)
    weights[key] = max(0.01, float(weights[key]) * factor)
    return _copy_params(params, weights=weights)


def _perturb_planner_weight(params: FusionParameterSet, key: str, factor: float) -> FusionParameterSet:
    planner_weights = dict(params.planner_weights)
    planner_weights[key] = max(0.01, float(planner_weights.get(key, 1.0)) * factor)
    return _copy_params(params, planner_weights=planner_weights)


def _perturb_chance_limit(params: FusionParameterSet, delta: float) -> FusionParameterSet:
    return _copy_params(params, chance_constraint_limit=float(np.clip(params.chance_constraint_limit + delta, 0.50, 0.99)))


def _perturb_uncertainty_parameter(params: FusionParameterSet, key: str, factor: float) -> FusionParameterSet:
    if key == "uncertainty_conservative_weight":
        return _copy_params(params, uncertainty_conservative_weight=max(0.0, params.uncertainty_conservative_weight * factor))
    if key == "uncertainty_sigma0":
        return _copy_params(params, uncertainty_sigma0=float(np.clip(params.uncertainty_sigma0 * factor, 0.0, 0.20)))
    if key == "uncertainty_beta":
        return _copy_params(params, uncertainty_beta=float(np.clip(params.uncertainty_beta * factor, 0.0, 1.50)))
    raise KeyError(key)


def _copy_params(
    params: FusionParameterSet,
    *,
    weights: dict[str, float] | None = None,
    planner_weights: dict[str, float] | None = None,
    chance_constraint_limit: float | None = None,
    uncertainty_conservative_weight: float | None = None,
    uncertainty_sigma0: float | None = None,
    uncertainty_beta: float | None = None,
) -> FusionParameterSet:
    return FusionParameterSet(
        weights=weights or dict(params.weights),
        planner_weights=planner_weights or dict(params.planner_weights),
        chance_constraint_limit=params.chance_constraint_limit if chance_constraint_limit is None else chance_constraint_limit,
        envelope_probability_limit=params.envelope_probability_limit,
        cvar_alpha=params.cvar_alpha,
        cvar_lambda=params.cvar_lambda,
        base_cost=params.base_cost,
        joint_risk_weight=params.joint_risk_weight,
        uncertainty_conservative_weight=(
            params.uncertainty_conservative_weight
            if uncertainty_conservative_weight is None
            else uncertainty_conservative_weight
        ),
        uncertainty_sigma0=params.uncertainty_sigma0 if uncertainty_sigma0 is None else uncertainty_sigma0,
        uncertainty_beta=params.uncertainty_beta if uncertainty_beta is None else uncertainty_beta,
        source_path=params.source_path,
        metadata=params.metadata,
    )


def _find_summary(rows: list[dict[str, Any]], parameter: str, relative_delta: float) -> dict[str, Any] | None:
    for row in rows:
        if row["parameter"] == parameter and float(row["relative_delta"]) == relative_delta:
            return row
    return None


def _finite_or_penalty(value: Any, penalty: float) -> float:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return float(penalty)
    return result if np.isfinite(result) else float(penalty)


def _array(rows: list[dict[str, Any]], key: str) -> np.ndarray:
    values = []
    for row in rows:
        try:
            value = float(row.get(key, 0.0) or 0.0)
        except (TypeError, ValueError):
            value = float("nan")
        if np.isfinite(value):
            values.append(value)
    return np.asarray(values, dtype=float)


def _mean(values: np.ndarray) -> float | None:
    return round(float(np.mean(values)), 6) if values.size else None


def _std(values: np.ndarray) -> float | None:
    return round(float(np.std(values, ddof=1)), 6) if values.size > 1 else 0.0 if values.size == 1 else None


def _safe_mean(values: list[Any]) -> float | None:
    numeric = []
    for value in values:
        try:
            item = float(value)
        except (TypeError, ValueError):
            continue
        if np.isfinite(item):
            numeric.append(item)
    return round(float(np.mean(numeric)), 6) if numeric else None


def _write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        rows = [{"empty": True}]
    fieldnames: list[str] = []
    for row in rows:
        for key in row:
            if key not in fieldnames:
                fieldnames.append(key)
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", default="outputs/risk_weight_sensitivity")
    parser.add_argument("--fusion-path", default="configs/risk_fusion_calibrated.yaml")
    parser.add_argument("--case-count", type=int, default=27)
    parser.add_argument("--perturbations", default="0.10,0.20,0.30")
    args = parser.parse_args()
    perturbations = tuple(float(item.strip()) for item in args.perturbations.split(",") if item.strip())
    summary = run_risk_weight_sensitivity(
        args.output_dir,
        SensitivityConfig(
            fusion_path=args.fusion_path,
            case_count=args.case_count,
            perturbations=perturbations,
        ),
    )
    print("Risk weight sensitivity finished.")
    print(f"Outputs: {args.output_dir}")
    print(json.dumps(summary["stability_findings"], ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
