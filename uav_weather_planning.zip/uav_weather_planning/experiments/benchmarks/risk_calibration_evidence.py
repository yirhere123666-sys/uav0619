﻿from __future__ import annotations

from pathlib import Path
import argparse
import json

from uav_weather_planning.data_interface import LocalGFSReplayConfig, LocalGFSReplayLoader
from uav_weather_planning.experiments.coordinate_summary import coordinate_summary_from_risk_field
from uav_weather_planning.risk_calibration import (
    build_calibration_evidence,
    plot_calibration_curves,
    plot_calibration_histograms,
    write_calibration_report,
)
from uav_weather_planning.risk_models import build_risk_field_from_weather


def run_risk_calibration_evidence(
    output_dir: str | Path = "outputs/risk_calibration_evidence",
    config: LocalGFSReplayConfig | None = None,
) -> dict:
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    config = config or LocalGFSReplayConfig(cache_policy="reuse")
    cube = LocalGFSReplayLoader().load(config)
    risk_field = build_risk_field_from_weather(cube)
    evidence = build_calibration_evidence(cube, risk_field)
    write_calibration_report(evidence, output_dir / "risk_calibration_report.json")
    plot_calibration_curves(evidence, output_dir / "risk_calibration_curves.png")
    plot_calibration_histograms(evidence, output_dir / "risk_calibration_histograms.png")
    summary = {
        "source": cube.source_metadata,
        "weather_shape": cube.shape,
        "risk_shape": risk_field.shape,
        "coordinate_definition": coordinate_summary_from_risk_field(risk_field),
        "outputs": [
            "risk_calibration_report.json",
            "risk_calibration_curves.png",
            "risk_calibration_histograms.png",
        ],
        "channels": {
            name: {
                "ece": data["expected_calibration_error"],
                "mae": data["mean_absolute_error"],
                "brier": data["brier_score"],
                "correlation": data["correlation"],
            }
            for name, data in evidence["channels"].items()
        },
    }
    with (output_dir / "summary.json").open("w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)
    return summary


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", default="outputs/risk_calibration_evidence")
    parser.add_argument("--t-size", type=int, default=24)
    parser.add_argument("--z-size", type=int, default=4)
    parser.add_argument("--y-size", type=int, default=32)
    parser.add_argument("--x-size", type=int, default=32)
    parser.add_argument("--rebuild-cache", action="store_true")
    args = parser.parse_args()
    config = LocalGFSReplayConfig(
        t_size=args.t_size,
        z_size=args.z_size,
        y_size=args.y_size,
        x_size=args.x_size,
        cache_policy="refresh" if args.rebuild_cache else "reuse",
    )
    summary = run_risk_calibration_evidence(args.output_dir, config=config)
    print("Risk calibration evidence finished.")
    print(f"Outputs: {args.output_dir}")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
