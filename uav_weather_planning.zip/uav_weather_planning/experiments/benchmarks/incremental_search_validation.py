﻿from __future__ import annotations

from dataclasses import replace
from pathlib import Path
import argparse
import csv
import json

import numpy as np

from uav_weather_planning.global_planner import (
    FlightConstraints,
    IncrementalLPAStar,
    IncrementalRepairAdapter,
    TimeDependentAStar,
    evaluate_path,
)
from uav_weather_planning.risk_field import RiskField4D


def run_incremental_search_validation(
    output_dir: str | Path = "outputs/incremental_search_validation",
) -> dict:
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    initial_field = _make_base_field()
    updated_field = _apply_local_risk_update(initial_field)
    start = (0, 1, 1)
    goal = (0, 10, 10)
    constraints = FlightConstraints()

    lpa = IncrementalLPAStar(initial_field, start, goal, constraints=constraints)
    initial = lpa.run()
    g_count_before = len(lpa.g)
    rhs_count_before = len(lpa.rhs)
    open_count_before = len(lpa.open_keys)

    lpa.update_risk_field(updated_field)
    update_event = lpa.replan_events[-1]
    g_count_after_update = len(lpa.g)
    rhs_count_after_update = len(lpa.rhs)
    open_count_after_update = len(lpa.open_keys)

    repaired = lpa.run()
    repair_nodes = lpa.last_compute_nodes_expanded
    repair_elapsed_ms = lpa.last_compute_elapsed_ms

    restart = TimeDependentAStar(updated_field, constraints=constraints).plan(start, goal)
    stale_metrics = evaluate_path(
        "Initial path evaluated after update",
        initial.path,
        updated_field,
        initial.nodes_expanded,
        initial.elapsed_ms,
        constraints=constraints,
    )
    repaired_metrics = evaluate_path(
        "LPA* incremental repair",
        repaired.path,
        updated_field,
        repair_nodes,
        repair_elapsed_ms,
        replan_count=1,
        constraints=constraints,
    )
    restart_metrics = evaluate_path(
        "Restart full A*",
        restart.path,
        updated_field,
        restart.nodes_expanded,
        restart.elapsed_ms,
        replan_count=1,
        constraints=constraints,
    )
    adapter = IncrementalRepairAdapter(initial_field, constraints=constraints)
    adapter.plan_initial(start, goal)
    adapter_result = adapter.repair_after_update(
        updated_risk_field=updated_field,
        changed_voxels=initial_field.significant_changed_voxels(updated_field),
        goal=goal,
    )
    adapter_metrics = evaluate_path(
        "LPA* adapter incremental repair",
        adapter_result.path,
        updated_field,
        adapter_result.nodes_expanded,
        adapter_result.elapsed_ms,
        replan_count=1,
        constraints=constraints,
    )
    rows = [stale_metrics.as_row(), repaired_metrics.as_row(), adapter_metrics.as_row(), restart_metrics.as_row()]
    with (output_dir / "incremental_search_metrics.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)

    comparison = {
        "mission": {"start": start, "goal": goal},
        "field_shape": initial_field.shape,
        "heuristic_weight": lpa.heuristic_weight,
        "raw_changed_voxels": update_event.get("raw_changed_voxels"),
        "raw_changed_voxel_ratio": update_event.get("raw_changed_voxel_ratio"),
        "significant_changed_voxels": update_event.get("significant_changed_voxels"),
        "significant_changed_voxel_ratio": update_event.get("significant_changed_voxel_ratio"),
        "changed_voxels": update_event["affected_voxels"],
        "affected_nodes": update_event["affected_nodes"],
        "total_time_expanded_nodes": int(np.prod(initial_field.shape)),
        "reuse_audit": {
            "queue_reused": update_event["queue_reused"],
            "g_rhs_reused": update_event["g_rhs_reused"],
            "g_count_before_update": g_count_before,
            "rhs_count_before_update": rhs_count_before,
            "open_count_before_update": open_count_before,
            "g_count_after_update": g_count_after_update,
            "rhs_count_after_update": rhs_count_after_update,
            "open_count_after_update": open_count_after_update,
            "update_policy": update_event["update_policy"],
            "edge_cost_cache_enabled": True,
            "neighbor_cache_enabled": True,
        },
        "initial_lpa": {
            "success": initial.success,
            "path_length": len(initial.path),
            "cumulative_nodes_expanded": initial.nodes_expanded,
        },
        "incremental_repair": {
            "success": repaired.success,
            "path_length": len(repaired.path),
            "repair_nodes_expanded": repair_nodes,
            "repair_elapsed_ms": round(repair_elapsed_ms, 3),
        },
        "adapter_repair": {
            "success": adapter_result.success,
            "path_length": len(adapter_result.path),
            "nodes_expanded": adapter_result.nodes_expanded,
            "elapsed_ms": round(adapter_result.elapsed_ms, 3),
            "affected_nodes": adapter_result.affected_nodes,
            "g_rhs_reused": adapter_result.g_rhs_reused,
            "queue_reused": adapter_result.queue_reused,
            "edge_updates": adapter_result.edge_updates,
            "vertex_updates": adapter_result.vertex_updates,
            "fallback_used": adapter_result.fallback_used,
            "path_cvar": adapter_result.path_cvar,
            "max_segment_cvar": adapter_result.max_segment_cvar,
        },
        "restart_full_astar": {
            "success": restart.success,
            "path_length": len(restart.path),
            "nodes_expanded": restart.nodes_expanded,
            "elapsed_ms": round(restart.elapsed_ms, 3),
        },
        "relative_to_restart": {
            "node_delta_pct": _pct_delta(repair_nodes, restart.nodes_expanded),
            "elapsed_delta_pct": _pct_delta(repair_elapsed_ms, restart.elapsed_ms),
        },
        "defense_statement": (
            "This validates a D* Lite/LPA*-family incremental update mechanism that preserves g/rhs/open state "
            "and updates only significant changed voxels plus their predecessor neighborhood, with cached edge and "
            "neighbor evaluations inside the Python prototype. It should be described as an incremental-search "
            "framework/prototype with audited state reuse, not as proof that the current implementation is "
            "significantly faster than full replanning in all cases."
        ),
        "outputs": ["incremental_search_metrics.csv", "incremental_search_summary.json"],
    }
    with (output_dir / "incremental_search_summary.json").open("w", encoding="utf-8") as f:
        json.dump(comparison, f, ensure_ascii=False, indent=2)
    return comparison


def _make_base_field() -> RiskField4D:
    field = RiskField4D.uniform(14, 1, 12, 12, base_cost=1.0)
    field.coords = {
        "time": np.arange(14, dtype=float),
        "height": np.array([0.0]),
        "y": np.arange(12, dtype=float),
        "x": np.arange(12, dtype=float),
    }
    field.source_metadata = {"time_axis_unit": "seconds_from_replay_start", "grid": "incremental_validation_grid"}
    return field


def _apply_local_risk_update(field: RiskField4D) -> RiskField4D:
    updated = replace(
        field,
        expected_cost=field.expected_cost.copy(),
        cvar_cost=field.cvar_cost.copy(),
        total_cost=field.total_cost.copy(),
        no_fly_mask=field.no_fly_mask.copy(),
        convection_risk=field.convection_risk.copy(),
        uncertainty=field.uncertainty.copy(),
    )
    updated.expected_cost[4:9, 0, 4:8, 4:8] = 40.0
    updated.cvar_cost[4:9, 0, 4:8, 4:8] = 20.0
    updated.total_cost[4:9, 0, 4:8, 4:8] = 60.0
    updated.convection_risk[4:9, 0, 4:8, 4:8] = 1.0
    updated.uncertainty[4:9, 0, 4:8, 4:8] = 0.8
    updated.no_fly_mask[5:8, 0, 5:7, 5:7] = True
    updated.metadata = {**field.metadata, "source": "localized_incremental_update"}
    return updated


def _pct_delta(value: float, baseline: float) -> float | None:
    if baseline <= 0.0:
        return None
    return round(100.0 * (float(value) - float(baseline)) / float(baseline), 3)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", default="outputs/incremental_search_validation")
    args = parser.parse_args()
    summary = run_incremental_search_validation(args.output_dir)
    print("Incremental search validation finished.")
    print(f"Outputs: {args.output_dir}")
    print(json.dumps(summary["reuse_audit"], ensure_ascii=False, indent=2))
    print(json.dumps(summary["relative_to_restart"], ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
