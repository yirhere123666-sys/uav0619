from uav_weather_planning.experiments.real_replay.historical_weather_replay import *  # noqa: F401,F403
from uav_weather_planning.experiments.real_replay.historical_weather_replay import main as _main
from uav_weather_planning.experiments._compat import run_compat_main


if __name__ == "__main__":
    run_compat_main("uav_weather_planning.experiments.historical_weather_replay", "uav_weather_planning.experiments.real_replay.historical_weather_replay", _main)
