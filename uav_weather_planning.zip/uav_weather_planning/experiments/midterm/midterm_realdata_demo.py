﻿from __future__ import annotations

from pathlib import Path
import argparse
import json

from uav_weather_planning.data_interface import ERA5Loader, HRRRLoader, LocalGFSReplayConfig, LocalGFSReplayLoader, WeatherDependencyError, WeatherRequest
from uav_weather_planning.experiments.coordinate_summary import coordinate_summary_from_risk_field
from uav_weather_planning.risk_models import build_risk_field_from_weather
from uav_weather_planning.visualization import plot_risk_channels, plot_risk_timeseries


def run_realdata_demo(source: str, output_dir: str | Path = "outputs/midterm_realdata_demo", cache_only: bool = True) -> dict:
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    source = source.lower()
    if source == "local_gfs":
        cube = LocalGFSReplayLoader().load(LocalGFSReplayConfig(cache_policy="reuse"))
    elif source == "era5":
        request = WeatherRequest(
            source="ERA5",
            start_time="2026-01-22T00:00",
            bbox=(46.0, 125.0, 44.0, 127.0),
            variables=ERA5Loader.DEFAULT_VARIABLES,
            levels=(1000, 975, 950, 925),
            cache_policy="cache_only" if cache_only else "reuse",
        )
        cube = ERA5Loader().load(request)
    elif source == "hrrr":
        request = WeatherRequest(
            source="HRRR",
            start_time="2026-01-22T00:00",
            forecast_hours=(0, 1, 2, 3, 4, 5),
            cache_policy="cache_only" if cache_only else "reuse",
        )
        cube = HRRRLoader().load(request)
    else:
        raise ValueError("source must be local_gfs, era5 or hrrr")

    risk_field = build_risk_field_from_weather(cube)
    plot_risk_channels(risk_field, output_dir / f"{source}_risk_channels.png")
    plot_risk_timeseries(risk_field, output_dir / f"{source}_4d_risk_timeseries.png")
    summary = {
        "source": source,
        "weather_shape": cube.shape,
        "risk_shape": risk_field.shape,
        "coordinate_definition": coordinate_summary_from_risk_field(risk_field),
        "metadata": risk_field.metadata,
    }
    with (output_dir / f"{source}_summary.json").open("w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)
    return summary


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", choices=["local_gfs", "era5", "hrrr"], default="local_gfs")
    parser.add_argument("--download", action="store_true", help="Attempt real download instead of cache-only mode.")
    args = parser.parse_args()
    try:
        summary = run_realdata_demo(args.source, cache_only=not args.download)
    except (FileNotFoundError, WeatherDependencyError) as exc:
        print(f"Real-data demo did not run: {exc}")
        print("Prepare a WeatherCube cache or install/configure the required ERA5/HRRR dependencies.")
        return
    print(summary)


if __name__ == "__main__":
    main()
