﻿from __future__ import annotations

from pathlib import Path
import csv
import json

from uav_weather_planning.global_planner import (
    EventTriggeredRepairReplanner,
    FlightConstraints,
    MultirotorEnergyModel,
    TimeDependentAStar,
    evaluate_path,
)
from uav_weather_planning.risk_field import RiskField4D, make_midterm_synthetic_field
from uav_weather_planning.visualization import (
    plot_algorithm_comparison,
    plot_metrics,
    plot_path_on_risk,
    plot_replanning,
)


def run_midterm_demo(output_dir: str | Path = "outputs/midterm_demo") -> dict:
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    start = (1, 3, 3)
    goal = (1, 34, 34)
    constraints = FlightConstraints()

    full_field = make_midterm_synthetic_field(t_size=52, y_size=38, x_size=38, include_dynamic_storm=True)
    initial_forecast = make_midterm_synthetic_field(t_size=52, y_size=38, x_size=38, include_dynamic_storm=False)
    no_weather = RiskField4D.uniform(*full_field.shape)
    static_field = full_field.as_static_snapshot(0)

    planners = {
        "No-weather A*": TimeDependentAStar(no_weather, use_cvar=False, constraints=constraints),
        "Static-risk A*": TimeDependentAStar(static_field, use_cvar=True, constraints=constraints),
        "Time-dependent A*": TimeDependentAStar(full_field, use_cvar=True, constraints=constraints),
    }

    results = {}
    metrics = []
    for name, planner in planners.items():
        result = planner.plan(start, goal)
        results[name] = result
        metrics.append(
            evaluate_path(
                name=name,
                path=result.path,
                risk_field=full_field,
                nodes_expanded=result.nodes_expanded,
                elapsed_ms=result.elapsed_ms,
                constraints=constraints,
            )
        )

    initial_before_update = TimeDependentAStar(initial_forecast, use_cvar=True, constraints=constraints).plan(start, goal)
    full_restart = results["Time-dependent A*"]
    metrics.append(
        evaluate_path(
            name="Restart full search",
            path=full_restart.path,
            risk_field=full_field,
            nodes_expanded=initial_before_update.nodes_expanded + full_restart.nodes_expanded,
            elapsed_ms=initial_before_update.elapsed_ms + full_restart.elapsed_ms,
            replan_count=1,
            constraints=constraints,
        )
    )

    replanner = EventTriggeredRepairReplanner(
        initial_field=initial_forecast,
        updated_field=full_field,
        update_time=12,
        constraints=constraints,
    )
    repaired = replanner.plan_and_repair(start, goal)
    metrics.append(
        evaluate_path(
            name="D* Lite-style repair",
            path=repaired.path,
            risk_field=full_field,
            nodes_expanded=repaired.nodes_expanded,
            elapsed_ms=repaired.elapsed_ms,
            replan_count=len(repaired.events),
            constraints=constraints,
        )
    )

    paths_for_plot = {name: result.path for name, result in results.items()}
    paths_for_plot["Restart full search"] = full_restart.path
    paths_for_plot["D* Lite-style repair"] = repaired.path

    plot_path_on_risk(
        full_field,
        results["Static-risk A*"].path,
        output_dir / "01_static_risk_path.png",
        "Static-risk baseline path on t=0 risk snapshot",
        time_index=0,
    )
    plot_path_on_risk(
        full_field,
        results["Time-dependent A*"].path,
        output_dir / "02_time_dependent_path.png",
        "Time-dependent A* path on dynamic 4D risk field",
        time_index=24,
    )
    plot_replanning(full_field, repaired.path, repaired.events, output_dir / "03_dynamic_replanning.png")
    plot_algorithm_comparison(paths_for_plot, full_field, output_dir / "04_algorithm_comparison.png")
    plot_metrics(metrics, output_dir / "05_metrics_summary.png")

    rows = [m.as_row() for m in metrics]
    with (output_dir / "metrics.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)

    event_rows = [
        {
            "event_time": e.event_time,
            "reason": e.reason,
            "affected_voxels": e.affected_voxels,
            "repaired_from": e.repaired_from,
            "nodes_expanded": e.nodes_expanded,
            "elapsed_ms": round(e.elapsed_ms, 3),
        }
        for e in repaired.events
    ]
    summary = {
        "mission": {"start": start, "goal": goal},
        "flight_constraints": constraints.as_dict(),
        "energy_model": MultirotorEnergyModel(full_field).metadata(),
        "risk_field": full_field.metadata,
        "metrics": rows,
        "replan_events": event_rows,
        "midterm_claim": (
            "The current milestone completes a runnable 4D risk-field prototype, "
            "time-dependent global path planning, event-triggered D* Lite-style repair, "
            "visualization, and quantitative comparison. Trajectory optimization and NMPC "
            "remain planned post-midterm enhancements."
        ),
    }
    with (output_dir / "summary.json").open("w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)

    return summary


def main() -> None:
    summary = run_midterm_demo()
    print("Midterm demo complete.")
    print("Outputs: outputs/midterm_demo")
    print("Metrics:")
    for row in summary["metrics"]:
        print(row)
    print("Replan events:")
    for event in summary["replan_events"]:
        print(event)


if __name__ == "__main__":
    main()
