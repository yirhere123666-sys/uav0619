﻿from __future__ import annotations

import argparse
from pathlib import Path
import csv
import json

from uav_weather_planning.airspace import CorridorGraph
from uav_weather_planning.global_planner import (
    EventTriggeredRepairReplanner,
    FlightConstraints,
    MultirotorEnergyModel,
    TimeDependentAStar,
    evaluate_path,
)
from uav_weather_planning.risk_field import RiskField4D
from uav_weather_planning.visualization import (
    animate_path_over_time,
    animate_path_over_time_3d,
    animate_risk_field,
    animate_risk_volume_3d,
    animate_weather_channels,
    plot_algorithm_comparison,
    plot_metrics,
    plot_path_on_risk,
    plot_replanning,
    plot_risk_channels,
    plot_risk_channels_3d,
    plot_risk_timeseries,
    plot_risk_volume_3d,
)
from uav_weather_planning.weather_simulation import make_dynamic_convection_update_pair


def run_simulated_risk_demo(
    output_dir: str | Path = "outputs/midterm_simulated_risk_demo",
    make_animations: bool = True,
) -> dict:
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    start = (1, 2, 2)
    goal = (1, 17, 17)
    constraints = FlightConstraints()
    initial_field, updated_field = make_dynamic_convection_update_pair(t_size=26, z_size=3, y_size=20, x_size=20)
    airspace = CorridorGraph.from_mission(updated_field, start, goal, corridor_width_cells=5.0, speed_limit_mps=15.0)
    constraints.airspace = airspace
    no_weather = RiskField4D.uniform(*updated_field.shape)
    static_field = updated_field.as_static_snapshot(0)

    planners = {
        "No-weather A*": TimeDependentAStar(no_weather, use_cvar=False, constraints=constraints, heuristic_weight=2.0),
        "Static-risk A*": TimeDependentAStar(static_field, use_cvar=True, constraints=constraints, heuristic_weight=2.0),
        "Time-dependent A*": TimeDependentAStar(updated_field, use_cvar=True, constraints=constraints, heuristic_weight=2.0),
    }
    results = {}
    metrics = []
    for name, planner in planners.items():
        result = planner.plan(start, goal)
        results[name] = result
        metrics.append(evaluate_path(name, result.path, updated_field, result.nodes_expanded, result.elapsed_ms, constraints=constraints))

    initial_result = TimeDependentAStar(initial_field, use_cvar=True, constraints=constraints, heuristic_weight=2.0).plan(start, goal)
    restart_result = results["Time-dependent A*"]
    metrics.append(
        evaluate_path(
            "Restart full search",
            restart_result.path,
            updated_field,
            initial_result.nodes_expanded + restart_result.nodes_expanded,
            initial_result.elapsed_ms + restart_result.elapsed_ms,
            replan_count=1,
            constraints=constraints,
        )
    )

    replanner = EventTriggeredRepairReplanner(initial_field, updated_field, update_time=8, risk_threshold=12.0, constraints=constraints)
    repaired = replanner.plan_and_repair(start, goal)
    incremental_path = repaired.path
    metrics.append(
        evaluate_path(
            "Incremental dynamic repair",
            incremental_path,
            updated_field,
            repaired.nodes_expanded,
            repaired.elapsed_ms,
            replan_count=len(repaired.events),
            constraints=constraints,
        )
    )

    events = [
        {
            "event_time": event.event_time,
            "reason": event.reason,
            "affected_voxels": event.affected_voxels,
            "repaired_from": event.repaired_from,
            "nodes_expanded": event.nodes_expanded,
            "elapsed_ms": round(event.elapsed_ms, 3),
        }
        for event in repaired.events
    ]

    paths_for_plot = {name: result.path for name, result in results.items()}
    paths_for_plot["Restart full search"] = restart_result.path
    paths_for_plot["Incremental dynamic repair"] = incremental_path

    plot_risk_channels(updated_field, output_dir / "01_risk_channels.png", time_index=18, height_index=1)
    plot_risk_timeseries(updated_field, output_dir / "02_4d_risk_timeseries.png", height_index=1)
    plot_path_on_risk(updated_field, restart_result.path, output_dir / "03_dynamic_path.png", "融合四维风险场中的时间依赖路径", time_index=20)
    # Reuse the plot helper by adapting event dictionaries to attributes.
    plot_replanning(updated_field, incremental_path, [_EventProxy(e) for e in events], output_dir / "04_incremental_replanning.png")
    plot_algorithm_comparison(paths_for_plot, updated_field, output_dir / "05_algorithm_comparison.png")
    plot_metrics(metrics, output_dir / "06_metrics_summary.png")
    plot_risk_volume_3d(
        updated_field,
        output_dir / "11_3d_joint_risk_volume.png",
        time_index=20,
        channel="joint_risk",
        path=restart_result.path,
        title="三维联合风险体与时间依赖路径",
    )
    plot_risk_channels_3d(updated_field, output_dir / "12_3d_weather_risk_channels.png", time_index=20)
    animation_outputs: list[str] = []
    if make_animations:
        animate_risk_field(updated_field, output_dir / "07_dynamic_risk_field.gif", height_index=1, channel="total_cost", fps=4, frame_step=2)
        animate_path_over_time(updated_field, restart_result.path, output_dir / "08_time_dependent_path.gif", height_index=1, channel="total_cost", fps=4, frame_step=2)
        animate_path_over_time(updated_field, incremental_path, output_dir / "09_incremental_replanning_path.gif", height_index=1, channel="total_cost", fps=4, frame_step=2)
        animate_weather_channels(updated_field, output_dir / "10_dynamic_weather_channels.gif", height_index=1, fps=4, frame_step=2)
        animate_risk_volume_3d(
            updated_field,
            output_dir / "13_3d_joint_risk_volume.gif",
            channel="joint_risk",
            path=restart_result.path,
            fps=3,
            frame_step=4,
        )
        animate_path_over_time_3d(
            updated_field,
            incremental_path,
            output_dir / "14_3d_incremental_path.gif",
            channel="joint_risk",
            fps=3,
            frame_step=4,
        )
        animation_outputs = [
            "07_dynamic_risk_field.gif",
            "08_time_dependent_path.gif",
            "09_incremental_replanning_path.gif",
            "10_dynamic_weather_channels.gif",
            "13_3d_joint_risk_volume.gif",
            "14_3d_incremental_path.gif",
        ]

    rows = [m.as_row() for m in metrics]
    with (output_dir / "metrics.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)

    risk_model_report = _build_risk_model_report(updated_field, constraints)
    with (output_dir / "risk_model_report.json").open("w", encoding="utf-8") as f:
        json.dump(risk_model_report, f, ensure_ascii=False, indent=2)
    with (output_dir / "airspace_network.json").open("w", encoding="utf-8") as f:
        json.dump(airspace.as_dict(), f, ensure_ascii=False, indent=2)

    summary = {
        "mission": {"start": start, "goal": goal},
        "flight_constraints": constraints.as_dict(),
        "airspace_network": "airspace_network.json",
        "airspace_network_summary": airspace.as_summary(),
        "energy_model": MultirotorEnergyModel(updated_field).metadata(),
        "risk_field": updated_field.metadata,
        "risk_channels": updated_field.metadata.get("channels", []),
        "metrics": rows,
        "replan_events": events,
        "risk_model_report": "risk_model_report.json",
        "airspace_network_file": "airspace_network.json",
        "animations": animation_outputs,
        "three_dimensional_visualizations": [
            "11_3d_joint_risk_volume.png",
            "12_3d_weather_risk_channels.png",
            *[name for name in animation_outputs if name.startswith("13_3d") or name.startswith("14_3d")],
        ],
        "claim": "Complete pre-B-spline/NMPC milestone: multi-weather risk modeling, fused 4D risk field, dynamic global planning, incremental replanning, and comparison outputs.",
    }
    with (output_dir / "summary.json").open("w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)
    return summary


def _build_risk_model_report(risk_field: RiskField4D, constraints: FlightConstraints) -> dict:
    time = risk_field.coords.get("time", [])
    height = risk_field.coords.get("height", [])
    y = risk_field.coords.get("y", [])
    x = risk_field.coords.get("x", [])
    height_resolution = float(height[1] - height[0]) if len(height) > 1 else None
    return {
        "hard_boundary_explanation": {
            "plot_meaning": "图中的红色闭合线是 no_fly_mask 在当前时间和高度层上的等值线，不是人工画圈。",
            "definition": "no_fly_mask 由非补偿联合风险、成员/样本尾部风险和极端安全包络共同决定，不是把原始气象量直接二值化。",
        },
        "probabilistic_constraint_definition": {
            "violation_probability": "P_violate = 非补偿 joint_risk + CVaR尾部风险 + 极端包络超限概率；认知不确定性只调制风险分布宽度和小保守裕度。",
            "chance_constraint": "当 P_violate 超过机会约束上限时进入 no_fly_mask。",
            "safety_envelope": "极端气象量先经 sigmoid 映射为超限概率；超限概率过高时作为安全包络兜底禁飞。",
            "interpretation": "阈值不是风险场主体，而是概率映射和运行安全包络的参数。",
        },
        "risk_mapping_parameters": {
            "wind": "平均风、侧风和垂直风连续映射为 wind_risk，极端风速通过 sigmoid 形成超限概率。",
            "gust": "阵风按连续强度归一化，极端阵风通过超限概率进入安全包络。",
            "shear_turbulence": "垂直风切变、水平风场梯度和风向突变形成 shear/turbulence 风险。",
            "convection": "反射率和对流概率形成 convection_risk，强对流核心作为硬禁飞候选。",
            "precipitation": "降水强度连续映射为 precipitation_risk，强降水会提高感知和能耗风险。",
            "visibility": "能见度、云底、湿度、露点差和云水含量共同形成 visibility_risk。",
        },
        "risk_cube": {
            "shape_order": "(time, height, y, x)",
            "shape": list(risk_field.shape),
            "time_steps": int(risk_field.t_size),
            "height_levels_m": [float(v) for v in height],
            "height_resolution_m": height_resolution,
            "y_cells": int(risk_field.y_size),
            "x_cells": int(risk_field.x_size),
            "xy_resolution": "当前合成实验使用规划网格索引；真实天气回放由预处理投影坐标给出米级分辨率。",
            "time_resolution": "当前合成实验使用离散规划时刻；真实数据回放对应 ERA5/HRRR 或本地 GFS 的时间步长。",
        },
        "weather_variables": risk_field.source_metadata.get("variables", []),
        "risk_channels": risk_field.metadata.get("channels", []),
        "fusion": {
            "weights": risk_field.channel_metadata.get("weights", {}),
            "expected_cost_kernel": risk_field.channel_metadata.get("expected_cost_kernel"),
            "base_cost": risk_field.channel_metadata.get("base_cost"),
            "joint_risk_weight": risk_field.channel_metadata.get("joint_risk_weight"),
            "weighted_soft_cost_role": risk_field.channel_metadata.get("weighted_soft_cost_role"),
            "cvar_alpha": risk_field.channel_metadata.get("cvar_alpha"),
            "cvar_lambda": risk_field.channel_metadata.get("cvar_lambda"),
            "monte_carlo_samples": risk_field.channel_metadata.get("monte_carlo_samples"),
            "chance_constraint_limit": risk_field.channel_metadata.get("chance_constraint_limit"),
            "envelope_probability_limit": risk_field.channel_metadata.get("envelope_probability_limit"),
            "uncertainty_role": risk_field.channel_metadata.get("uncertainty_role"),
            "uncertainty_formula": (
                "sigma(x,t)=sigma0+beta*U(x,t); "
                "R_m(x,t)=clip(R(x,t)+sigma(x,t)*epsilon_m,0,1); "
                "C=E[R]+lambda_cvar*CVaR_alpha(R)+lambda_u*U"
            ),
            "uncertainty_conservative_weight": risk_field.channel_metadata.get("uncertainty_conservative_weight"),
            "uncertainty_sigma0": risk_field.channel_metadata.get("uncertainty_sigma0"),
            "uncertainty_beta": risk_field.channel_metadata.get("uncertainty_beta"),
            "ignored_uncertainty_weight_keys": risk_field.channel_metadata.get("ignored_uncertainty_weight_keys"),
        },
        "no_fly_statistics": {
            "ratio": float(risk_field.no_fly_mask.mean()),
            "voxel_count": int(risk_field.no_fly_mask.sum()),
            "total_voxels": int(risk_field.no_fly_mask.size),
            "max_violation_probability": float(risk_field.violation_probability.max()),
            "mean_violation_probability": float(risk_field.violation_probability.mean()),
        },
        "flight_constraints": constraints.as_dict(),
    }


class _EventProxy:
    def __init__(self, data: dict) -> None:
        self.event_time = int(data["event_time"])
        self.reason = data["reason"]
        self.affected_voxels = int(data["affected_voxels"])
        self.repaired_from = tuple(data["repaired_from"])
        self.nodes_expanded = int(data["nodes_expanded"])
        self.elapsed_ms = float(data["elapsed_ms"])


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", default="outputs/midterm_simulated_risk_demo")
    parser.add_argument("--no-animations", action="store_true")
    args = parser.parse_args()
    summary = run_simulated_risk_demo(args.output_dir, make_animations=not args.no_animations)
    print("Complete simulated risk demo finished.")
    print(f"Outputs: {args.output_dir}")
    for row in summary["metrics"]:
        print(row)
    for event in summary["replan_events"]:
        print(event)


if __name__ == "__main__":
    main()
